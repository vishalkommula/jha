# Introduction

This is a monorepo that holds all the source for the hosted SilverLake and CIF 20/20 web app.

For an overview of this repo, check out [this video](https://jackhenry.sharepoint.com/sites/UIEvolutionUS/Shared%20Documents/General/UI%20Evolution%20Program%20-%20Environment%20-%20GitHub-20211001_140559-Meeting%20Recording.mp4).

## Cloning the Repository

To clone the repo, you'll first need to [create a personal access token](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token). Be sure to "Enable SSO" for the JHABankingDevelopment organization. Once it's created you can use the token in place of your password.

## Required software
* [Visual Studio 2019](https://visualstudio.microsoft.com/vs/)
* [Visual Studio Code](https://code.visualstudio.com/)
* [Node.js](https://nodejs.org/)
* [WSL2](https://docs.microsoft.com/en-us/windows/wsl/install) (Windows only)
* [Docker Desktop](https://www.docker.com/products/docker-desktop)

## Front End Help
Check the web [README.md](./src/web/README.md) for help with code generation, building, debugging, and testing.

## Back End Help
Check the services [README.md](./src/services/README.md) for help with code generation, building, debugging, and testing.