﻿namespace Xpe.Cache.Model;

public record UserCacheOptions
{
    public TimeSpan? SlidingExpiration { get; set; } = TimeSpan.FromMinutes(5);
    
    public DateTime? AbsoluteExpiration { get; set; }
}