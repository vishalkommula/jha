﻿namespace Xpe.Cache;

public static class CacheConstants
{
    public const string XpeContextKey = "XpeContext";
    public const string UserIdKey = "UserId";
    public const string SessionIdKey = "SessionId";
    public const string ConnectionIdKey = "ConnectionId";
    public const string KerbTokenKey = "KerberosToken";
    public const string SamlTokenKey = "SamlToken";
    public const string MenuStateKey = "MenuState";
}