﻿using System.Collections.ObjectModel;
using System.ComponentModel;

namespace Xpe.Menu;

public static class ListExtensions
{
    public static void AddRange<T>(this ObservableCollection<T> o, IEnumerable<T>? items)
    {
        if (items == null)
        {
            return;
        }

        foreach (var item in items)
        {
            o.Add(item);
        }
    }

    public static void AddRange<T>(this BindingList<T> o, IEnumerable<T>? items)
    {
        if (items == null)
        {
            return;
        }

        foreach (var item in items)
        {
            o.Add(item);
        }
    }

    public static void RemoveAll<T>(this ObservableCollection<T> o, Predicate<T> match)
    {
        for (var x = o.Count - 1; x > -1; x--)
            if (match(o[x]))
            {
                o.RemoveAt(x);
            }
    }

    public static void RemoveAllAndDispose<T>(this IList<T> o, Predicate<T> match)
        where T : class, new()
    {
        for (var x = o.Count - 1; x > -1; x--)
        {
            if (!match(o[x]))
            {
                continue;
            }

            if (o[x] is IDisposable)
            {
                (o[x] as IDisposable).Dispose();
            }

            o.RemoveAt(x);
        }
    }

    public static void RemoveAll<T>(this ObservableCollection<T> o)
    {
        for (var x = o.Count - 1; x > -1; x--) o.RemoveAt(x);
    }

    public static void RemoveAll<T>(this BindingList<T> o, Predicate<T> match)
    {
        for (var x = o.Count - 1; x > -1; x--)
            if (match(o[x]))
            {
                o.RemoveAt(x);
            }
    }

    public static ObservableCollection<T> Clone<T>(this IEnumerable<T> items)
    {
        return new ObservableCollection<T>(items
            .Select(i => i is ICloneable cloneable ? (T) cloneable.Clone() : i));
    }
}