﻿using Xpe.Menu.Interfaces;

namespace Xpe.Menu;

public record SelectMenuItemResponse(
    MenuQueryResponseStatus Status, 
    IEnumerable<IMenuItem>? MenuItems,
    string[]? Errors = null);
