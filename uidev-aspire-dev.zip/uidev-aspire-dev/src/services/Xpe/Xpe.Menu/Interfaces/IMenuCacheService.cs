﻿using JackHenry.JHAContractTypes;

namespace Xpe.Menu.Interfaces;

public interface IMenuCacheService
{
    PrvdUsrOptsSrchRs_MType GetAllMenuItems();
    
    IMenuItem[] GetCoreMenuItems(string user);
    
    void UpdateCoreMenuItems(string user, IMenuItem[] items);
    
    IMenuItem[] GetDisplayedMenuItems(string user);
    
    void UpdateDisplayedMenuItems(string user, IMenuItem[] items);
}