﻿using JackHenry.JHAContractTypes;

namespace Xpe.Menu.Interfaces;

public interface IMenuItem
{
    string MenuId { get; set; }

    PrvdUsrOptInfo_CType MenuOpt { get; }

    string Title { get; set; }

    MenuType MenuType { get; }

    string Product { get; set; }

    bool IsPasswordRequired { get; }

    bool IsFavoriteMenuItem { get; set; }

    bool IsSameMenuOpt<T>(T menuItem)
        where T : IMenuItem;
}