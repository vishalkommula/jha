﻿using JackHenry.JHAContractTypes;

namespace Xpe.Menu;

public class ProviderUserMenuResponse
{
    public List<PrvdUsrOptInfo_CType> MenuOptions { get; set; }
    public string InitialMenu { get; set; }
}