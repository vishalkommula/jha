namespace Xpe.Menu;

public enum MenuQueryResponseStatus
{
    Success,
    Error
}