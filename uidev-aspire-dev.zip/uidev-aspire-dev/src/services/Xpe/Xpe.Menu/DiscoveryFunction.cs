﻿namespace Xpe.Menu;

public class DiscoveryFunction
{
    public string ImageName { get; set; }

    public bool IsAdded { get; set; }

    public string ISeriesTag { get; set; }

    public string UniqueItemName { get; set; }

    public string XpDisplayName { get; set; }

    public string XperienceProxyApplicationDestinationName { get; set; }

    public string XpStartUpMessage { get; set; }

    public override string ToString()
    {
        return string.Format(
            "Unique Name {0}; XpDisplayName {1}; Application {2}; Xp Startup Mesage {3}",
            UniqueItemName,
            XpDisplayName,
            XperienceProxyApplicationDestinationName,
            XpStartUpMessage);
    }
}