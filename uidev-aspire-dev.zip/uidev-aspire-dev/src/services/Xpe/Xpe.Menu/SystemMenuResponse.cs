namespace Xpe.Menu;

// public class SystemMenuResponse
// {
//     public IEnumerable<SystemMenuFolder> MenuItems { get; set; }
//
//     public string InitialMenu { get; set; }
//
//     public IEnumerable<string>? Errors { get; set; }
//
//     public MenuQueryResponseStatus Status { get; set; }
// }