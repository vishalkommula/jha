namespace Xpe.Menu;

public record MenuCommandResponse(bool Success, string[]? Errors = null);