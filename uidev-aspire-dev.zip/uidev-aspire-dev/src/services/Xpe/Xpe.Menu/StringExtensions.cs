﻿namespace Xpe.Menu;

public static class StringExtensions
{
    public static bool IsCaseInsensativeTrimmedEqual(this string s, string value)
    {
        if (s == null && value == null)
        {
            return true;
        }

        if (s == null || value == null)
        {
            return false;
        }

        return string.Compare(s.Trim(), value.Trim(), true) == 0;
    }
}