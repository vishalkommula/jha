﻿namespace Xpe.Menu;

public enum MenuType
{
    Folder,
    Item,
    Customize
}