﻿using System.Security.Claims;
using Xpe.Menu;
using Xpe.WebApi.Infrastructure.Commands;
using Xpe.WebApi.Infrastructure.Queries;
using MediatR;
using Microsoft.AspNetCore.SignalR;

namespace Xpe.WebApi.Hubs;

public class XpeHub : Hub
{
    private readonly ILogger<XpeHub> logger;
    private readonly IMediator mediator;

    public XpeHub(ILogger<XpeHub> logger, IMediator mediator)
    {
        this.logger = logger;
        this.mediator = mediator;
    }

    public async Task RegisterClient(RegisterClientCmd command)
    {
        command.ConnectionId = Context.ConnectionId;
        
        await mediator.Send(command);
    }

    public async Task<MenuQueryResponse> GetMenuItems(string userIdentifier)
    {
        await InitializeUserServiceAsync(userIdentifier);

        return await mediator.Send(new QueryMenuItems(userIdentifier));
    }

    public async Task<SelectMenuItemResponse> SelectMenuItem(QuerySelectedMenuItem request)
    {
        await InitializeUserServiceAsync(request.UserIdentifier);

        return await mediator.Send(request);
    }

    public async Task LaunchMenuItem(LaunchMenuItemCmd command)
    {
        await InitializeUserServiceAsync(command.UserIdentifier);

        await mediator.Send(command);
    }

    public async Task WorkWithSpoolFiles(LaunchWorkWithSpoolFilesCmd command)
    {
        await InitializeUserServiceAsync(command.UserIdentifier);

        await mediator.Send(command);
    }

    public async Task SendCommand(SendCommandCmd command)
    {
        await InitializeUserServiceAsync(command.UserIdentifier);

        await mediator.Send(command);
    }

    private async Task InitializeUserServiceAsync(string userIdentifier)
    {
        await mediator.Send(new IntializeUserServiceCmd(userIdentifier));
    }
}