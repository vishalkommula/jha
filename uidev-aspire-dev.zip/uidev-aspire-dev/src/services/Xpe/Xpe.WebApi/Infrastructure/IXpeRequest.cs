﻿using MediatR;

namespace Xpe.WebApi.Infrastructure;

public interface IXpeRequest : IRequest
{
    string UserIdentifier { get; }
}

public interface IXpeRequest<out TResponse> : IRequest<TResponse>
{
    string UserIdentifier { get; }
}