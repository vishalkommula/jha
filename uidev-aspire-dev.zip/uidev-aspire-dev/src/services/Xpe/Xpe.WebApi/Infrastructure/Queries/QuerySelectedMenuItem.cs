﻿using Xpe.Menu;
using MediatR;

namespace Xpe.WebApi.Infrastructure.Queries;

public record QuerySelectedMenuItem(string UserIdentifier, string MenuId) : IXpeRequest<SelectMenuItemResponse>;
