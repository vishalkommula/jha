﻿namespace Xpe.WebApi.Infrastructure.Services;

public class XpeBackgroundService : BackgroundService
{
    private readonly ILogger<XpeBackgroundService> logger;
    private readonly IServiceProvider serviceProvider;
    private readonly IXpeBackgroundTaskQueue xpeBackgroundTaskQueue;
    private readonly IXpeSessionManager xpeSessionManager;

    public XpeBackgroundService(
        ILogger<XpeBackgroundService> logger,
        IServiceProvider serviceProvider,
        IXpeBackgroundTaskQueue xpeBackgroundTaskQueue,
        IXpeSessionManager xpeSessionManager)
    {
        this.logger = logger;
        this.serviceProvider = serviceProvider;
        this.xpeBackgroundTaskQueue = xpeBackgroundTaskQueue;
        this.xpeSessionManager = xpeSessionManager;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var scope = serviceProvider.CreateScope();

        while (!stoppingToken.IsCancellationRequested)
        {
            var workItem = await xpeBackgroundTaskQueue.DequeueAsync(stoppingToken);
            await workItem(stoppingToken, scope, xpeSessionManager);
        }
    }
}