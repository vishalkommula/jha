﻿using System.Threading.Channels;

namespace Xpe.WebApi.Infrastructure.Services;

public class XpeBackgroundTaskQueue : IXpeBackgroundTaskQueue
{
    private const string BackgroundTasksConfigKey = "Xpe:BackgroundTasks";
    private const int BackgroundTasksDefaultValue = 1000;

    private readonly Channel<BackgroundWorkItem> queue;

    public XpeBackgroundTaskQueue(
        IConfiguration configuration,
        IServiceProvider serviceProvider)
    {
        ServiceProvider = serviceProvider;
        // Capacity should be set based on the expected application load and
        // number of concurrent threads accessing the queue.            
        // BoundedChannelFullMode.Wait will cause calls to WriteAsync() to return a task,
        // which completes only when space became available. This leads to backpressure,
        // in case too many publishers/calls start accumulating.
        var backgroundTasks = configuration.GetValue(BackgroundTasksConfigKey, BackgroundTasksDefaultValue);
        var options = new BoundedChannelOptions(backgroundTasks)
        {
            FullMode = BoundedChannelFullMode.Wait
        };
        queue = Channel.CreateBounded<BackgroundWorkItem>(options);
    }

    private IServiceProvider ServiceProvider { get; }

    public async ValueTask QueueBackgroundWorkItemAsync(BackgroundWorkItem workItem)
    {
        if (workItem == null)
        {
            throw new ArgumentNullException(nameof(workItem));
        }

        await queue.Writer.WriteAsync(workItem);
    }

    public async ValueTask<BackgroundWorkItem> DequeueAsync(CancellationToken cancellationToken)
    {
        return await queue.Reader.ReadAsync(cancellationToken);
    }
}