﻿using System.Collections.Concurrent;
using Xpe.Abstraction.Navigation;

namespace Xpe.WebApi.Infrastructure.Services;

public class XpeUserSessionManager : IXpeUserSessionManager
{
    private readonly ConcurrentDictionary<string, IXpeNavigationService> sessions = new();

    public IXpeNavigationService GetUserSession(IServiceScope scope, string sessionId)
    {
        if (sessions.ContainsKey(sessionId))
        {
            return sessions[sessionId];
        }

        var service = scope.ServiceProvider.GetRequiredService<IXpeNavigationService>();
        sessions.TryAdd(sessionId, service);
        return service;
    }
}