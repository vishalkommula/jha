﻿using Xpe.Abstraction.Model;
using Xpe.Menu.Navigation;
using Xpe.WebApi.Hubs;
using MediatR;
using Microsoft.AspNetCore.SignalR;
using Xpe.Cache;
using Xpe.Cache.Infrastructure;

namespace Xpe.WebApi.Infrastructure.Handlers;

public class UpdateScreenCmdHandler : AsyncRequestHandler<UpdateScreenCmd>
{
    public UpdateScreenCmdHandler(
        ILogger<UpdateScreenCmdHandler> logger,
        IUserCache cacheManager,
        IHubContext<XpeHub> hub)
    {
        Logger = logger;
        CacheManager = cacheManager;
        Hub = hub;
    }

    private ILogger<UpdateScreenCmdHandler> Logger { get; }
    private IUserCache CacheManager { get; }
    private IHubContext<XpeHub> Hub { get; }

    protected override async Task Handle(UpdateScreenCmd command, CancellationToken cancellationToken)
    {
        var cacheResponse = CacheManager.GetInMemoryCache<XpeConnectionContext>(
            command.UserIdentifier, CacheConstants.XpeContextKey);

        if (!cacheResponse.IsFound || cacheResponse.Value?.ConnectionId == null)
        {
            throw new ApplicationException("XPE connection context not found.");
        }

        await Hub.Clients
            .Client(cacheResponse.Value.ConnectionId)
            .SendCoreAsync("UpdateView", new object[] { command.ScreenData }, cancellationToken);
    }
}