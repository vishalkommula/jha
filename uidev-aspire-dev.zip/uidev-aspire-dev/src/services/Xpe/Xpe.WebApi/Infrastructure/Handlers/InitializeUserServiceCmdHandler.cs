﻿using Xpe.Abstraction.Services;
using Xpe.WebApi.Infrastructure.Commands;
using MediatR;

namespace Xpe.WebApi.Infrastructure.Handlers;

public class InitializeUserServiceCmdHandler : AsyncRequestHandler<IntializeUserServiceCmd>
{
    private readonly IISeriesConnectionInfoService iSeriesConnectionInfoService;
    private readonly ILogger<InitializeUserServiceCmdHandler> logger;
    private readonly IUserService userService;

    public InitializeUserServiceCmdHandler(
        ILogger<InitializeUserServiceCmdHandler> logger,
        IUserService userService,
        IISeriesConnectionInfoService iSeriesConnectionInfoService)
    {
        this.iSeriesConnectionInfoService = iSeriesConnectionInfoService;
        this.logger = logger;
        this.userService = userService;
    }

    protected override Task Handle(IntializeUserServiceCmd request, CancellationToken cancellationToken)
    {
        userService.Initialize(request.UserIdentifier);
        iSeriesConnectionInfoService.Initialize(request.UserIdentifier);
        return Task.FromResult(0);
    }
}