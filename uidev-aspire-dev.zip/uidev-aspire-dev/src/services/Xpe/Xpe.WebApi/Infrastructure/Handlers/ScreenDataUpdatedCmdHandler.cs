﻿using Xpe.Abstraction.Commands;
using Xpe.Abstraction.Navigation;
using MediatR;

namespace Xpe.WebApi.Infrastructure.Handlers;

public class ScreenDataUpdatedCmdHandler : RequestHandler<ScreenDataUpdatedCmd>
{
    public ScreenDataUpdatedCmdHandler(
        ILogger<ScreenDataUpdatedCmdHandler> logger,
        IXpeNavigationService xpeNavigationService)
    {
        Logger = logger;
        XpeNavigationService = xpeNavigationService;
    }

    private ILogger<ScreenDataUpdatedCmdHandler> Logger { get; }
    private IXpeNavigationService XpeNavigationService { get; }

    protected override void Handle(ScreenDataUpdatedCmd request)
    {
        XpeNavigationService.OnUpdateView(request);
    }
}