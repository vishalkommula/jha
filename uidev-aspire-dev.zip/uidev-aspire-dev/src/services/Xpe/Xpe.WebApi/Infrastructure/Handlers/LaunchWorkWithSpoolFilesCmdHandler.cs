﻿using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Model;
using Xpe.Abstraction.Navigation;
using Xpe.WebApi.Infrastructure.Commands;
using Xpe.WebApi.Infrastructure.Services;
using MediatR;
using Xpe.Cache;
using Xpe.Cache.Infrastructure;

namespace Xpe.WebApi.Infrastructure.Handlers;

public class LaunchWorkWithSpoolFilesCmdHandler : AsyncRequestHandler<LaunchWorkWithSpoolFilesCmd>
{
    private readonly IXpeBackgroundTaskQueue backgroundTaskQueue;
    private readonly IUserCache cacheManager;
    private readonly ILogger<LaunchWorkWithSpoolFilesCmdHandler> logger;

    public LaunchWorkWithSpoolFilesCmdHandler(
        ILogger<LaunchWorkWithSpoolFilesCmdHandler> logger,
        IUserCache cacheManager,
        IXpeBackgroundTaskQueue backgroundTaskQueue)
    {
        this.logger = logger;
        this.cacheManager = cacheManager;
        this.backgroundTaskQueue = backgroundTaskQueue;
    }

    protected override async Task Handle(LaunchWorkWithSpoolFilesCmd request, CancellationToken cancellationToken)
    {
        try
        {
            var xpeContext = cacheManager
                .GetInMemoryCache<XpeConnectionContext>(request.UserIdentifier, CacheConstants.XpeContextKey);

            if (!xpeContext.IsFound)
            {
                logger.LogTrace("Xpe Connection Context not found.");
            }

            await backgroundTaskQueue.QueueBackgroundWorkItemAsync((_, scope, xpeSessionManager) =>
            {
                var navigationService = xpeSessionManager.GetUserSession(scope, 
                    request.UserIdentifier, Guid.Empty.ToString());

                navigationService.Navigate(new XpeNavigationEventArgs
                {
                    UserIdentifier = request.UserIdentifier,
                    HeaderText = null,
                    InstitutionNumber = xpeContext.Value?.InstitutionNumber ?? "2021510",
                    BankName = xpeContext.Value?.BankName,
                    Menu = null,
                    Option = null,
                    ImsUserSelectedSecurityGroup = "No Group",
                    Program = "WRKSPLF",
                    FunctionKey2 = Key.None
                });

                return ValueTask.CompletedTask;
            });
        }
        catch (Exception e)
        {
            logger.LogError(e, "Error navigating xpe.");
        }
    }
}