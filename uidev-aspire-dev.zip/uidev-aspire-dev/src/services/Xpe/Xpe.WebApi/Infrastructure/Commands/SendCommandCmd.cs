﻿namespace Xpe.WebApi.Infrastructure.Commands;

public record SendCommandCmd(
    string UserIdentifier,
    string Key,
    bool IsSendingPing,
    bool IsMappedView) : IXpeRequest;