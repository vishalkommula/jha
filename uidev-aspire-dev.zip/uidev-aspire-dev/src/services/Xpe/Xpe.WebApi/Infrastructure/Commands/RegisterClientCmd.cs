﻿using MediatR;

namespace Xpe.WebApi.Infrastructure.Commands;

public record RegisterClientCmd(
    string UserIdentifier,
    string KerberosToken,
    string SamlAssertion) : IXpeRequest
{
    public string ConnectionId { get; set; }
}
