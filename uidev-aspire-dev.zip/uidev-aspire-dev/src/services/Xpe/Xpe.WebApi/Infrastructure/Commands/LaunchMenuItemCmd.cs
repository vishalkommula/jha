﻿using Xpe.Menu;
using MediatR;

namespace Xpe.WebApi.Infrastructure.Commands;

public record LaunchMenuItemCmd(string UserIdentifier, SystemMenuItem MenuItem) : IXpeRequest;