﻿using Xpe.Menu;
using MediatR;

namespace Xpe.WebApi.Infrastructure.Commands;

public record LaunchWorkWithSpoolFilesCmd(string UserIdentifier) : IXpeRequest;