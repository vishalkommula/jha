﻿using Xpe.Abstraction.Commands;
using Xpe.Menu.Navigation;
using Xpe.WebApi.Hubs;
using MediatR;

namespace Xpe.WebApi;

public static class MediatrServiceExtensions
{
    public static IServiceCollection AddXpeMediatr(this IServiceCollection services)
    {
        services.AddMediatR(
            config =>
            {
                config.AsScoped();
            },
            typeof(UpdateScreenCmd).Assembly,
            typeof(ScreenChangedCmd).Assembly,
            typeof(XpeHub).Assembly);

        return services;
    }
}