﻿using Ardalis.GuardClauses;
using JackHenry.UID.Cache.Extensions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Xpe.Cache;
using Xpe.Cache.Infrastructure;

namespace Xpe.DependencyInjection;

public static class CacheExtensions
{
    public static IServiceCollection Replace<TService>(this IServiceCollection services, object instance)
    {
        Guard.Against.Null(instance,
            nameof(instance));

        return services.Replace(
            new ServiceDescriptor(typeof(TService),
                instance));
    }

    public static IServiceCollection AddXpeCache(this IServiceCollection services)
    {
        services
            .AddJhaDistributedMemoryCache()
            .AddScoped<IUserCache, UserCache>();

        return services;
    }    
}