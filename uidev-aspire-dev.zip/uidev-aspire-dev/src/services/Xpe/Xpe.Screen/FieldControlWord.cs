﻿namespace Jha.X3.Xpe.Screen;

/// <summary>
/// The Field Control Word
/// </summary>
[Serializable]
public class FieldControlWord
{
    /// <summary>
    /// Gets or sets the raw data.
    /// </summary>
    /// <value>
    /// The raw data.
    /// </value>
    public ushort RawData
    {
        get;
        set;
    }

    /// <summary>
    /// Gets or sets the type.
    /// </summary>
    /// <value>
    /// The type.
    /// </value>
    public FieldControlWordType Type
    {
        get;
        set;
    }

    /// <summary>
    /// Gets or sets the data.
    /// </summary>
    /// <value>
    /// The data.
    /// </value>
    public byte Data
    {
        get;
        set;
    }
}
