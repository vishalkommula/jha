﻿using System.Collections.ObjectModel;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Jha.X3.Xpe.Screen;

[System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.79.0")]
[Serializable()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[XmlType(AnonymousType = true)]
public partial class FieldValue
{
    private static XmlSerializer serializer;

    /// <summary>
    /// Gets or sets the value.
    /// </summary>
    /// <value>
    /// The value.
    /// </value>
    public string Value { get; set; }

    /// <summary>
    /// Gets or sets the description.
    /// </summary>
    /// <value>
    /// The description.
    /// </value>
    public string Description { get; set;}

    /// <summary>
    /// Gets the serializer.
    /// </summary>
    /// <value>
    /// The serializer.
    /// </value>
    private static XmlSerializer Serializer
    {
        get
        {
            if ((serializer == null))
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(FieldValue));
            }
            return serializer;
        }
    }

    /// <summary>
    /// Test whether Value should be serialized
    /// </summary>
    public virtual bool ShouldSerializeValue()
    {
        return !string.IsNullOrEmpty(Value);
    }

    /// <summary>
    /// Test whether Description should be serialized
    /// </summary>
    public virtual bool ShouldSerializeDescription()
    {
        return !string.IsNullOrEmpty(Description);
    }

    #region Serialize/Deserialize
    /// <summary>
    /// Serializes current FieldValue object into an XML string
    /// </summary>
    /// <returns>string XML value</returns>
    public virtual string Serialize()
    {
        string serializedData = string.Empty;

        try
        {
            using (StreamReader streamReader = new StreamReader(new MemoryStream()))
            {
                System.Xml.XmlWriterSettings xmlWriterSettings = new System.Xml.XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                XmlWriter xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                Serializer.Serialize(xmlWriter, this);
                streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                serializedData = streamReader.ReadToEnd();
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    /// <summary>
    /// Deserializes workflow markup into an FieldValue object
    /// </summary>
    /// <param name="input">string workflow markup to deserialize</param>
    /// <param name="obj">Output FieldValue object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool Deserialize(string input, out FieldValue obj, out System.Exception exception)
    {
        exception = null;
        obj = default(FieldValue);

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <param name="obj">The object.</param>
    /// <returns></returns>
    public static bool Deserialize(string input, out FieldValue obj)
    {
        System.Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <returns></returns>
    public static FieldValue Deserialize(string input)
    {
        System.IO.StringReader stringReader = null;
        try
        {
            stringReader = new System.IO.StringReader(input);
            return ((FieldValue)(Serializer.Deserialize(System.Xml.XmlReader.Create(stringReader))));
        }
        finally
        {
            if ((stringReader != null))
            {
                stringReader.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes the specified s.
    /// </summary>
    /// <param name="s">The s.</param>
    /// <returns></returns>
    public static FieldValue Deserialize(System.IO.Stream s)
    {
        return ((FieldValue)(Serializer.Deserialize(s)));
    }
    #endregion

    /// <summary>
    /// Serializes current FieldValue object into file
    /// </summary>
    /// <param name="fileName">full path of outupt xml file</param>
    /// <param name="exception">output Exception value if failed</param>
    /// <returns>true if can serialize and save into file; otherwise, false</returns>
    public virtual bool SaveToFile(string fileName, out System.Exception exception)
    {
        exception = null;

        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (System.Exception e)
        {
            exception = e;
            return false;
        }
    }

    /// <summary>
    /// Saves to file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    public virtual void SaveToFile(string fileName)
    {
        System.IO.StreamWriter streamWriter = null;

        try
        {
            string xmlString = Serialize();
            System.IO.FileInfo xmlFile = new System.IO.FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if ((streamWriter != null))
            {
                streamWriter.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes xml markup from file into an FieldValue object
    /// </summary>
    /// <param name="fileName">string xml file to load and deserialize</param>
    /// <param name="obj">Output FieldValue object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool LoadFromFile(string fileName, out FieldValue obj, out System.Exception exception)
    {
        exception = null;
        obj = default(FieldValue);

        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool LoadFromFile(string fileName, out FieldValue obj)
    {
        System.Exception exception = null;
        return LoadFromFile(fileName, out obj, out exception);
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <returns></returns>
    public static FieldValue LoadFromFile(string fileName)
    {
        System.IO.FileStream file = null;
        System.IO.StreamReader sr = null;

        try
        {
            file = new System.IO.FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new System.IO.StreamReader(file);
            string xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();

            return Deserialize(xmlString);
        }
        finally
        {
            if ((file != null))
            {
                file.Dispose();
            }
            if ((sr != null))
            {
                sr.Dispose();
            }
        }
    }
}

[System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.79.0")]
[Serializable()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[XmlType(AnonymousType = true)]
[XmlRoot(Namespace = "", IsNullable = false)]
public partial class ScreenMap
{
    private static XmlSerializer serializer;

    private bool _shouldSerializeWinWidth;
    private bool _shouldSerializeScreenHeight;
    private bool _shouldSerializeScreenWidth;
    private bool _shouldSerializeWinLeft;
    private bool _shouldSerializeWinTop;
    private bool _shouldSerializeWinHeight;
    private bool _isLine24MessageIgnored;

    /// <summary>
    /// Initializes a new instance of the <see cref="ScreenMap"/> class.
    /// </summary>
    public ScreenMap()
    {
        this.GridArray = new ObservableCollection<ScreenMapGridArray>();
        this.NamePairArray = new ObservableCollection<ScreenField>();
        this.NamePairDetails = new ScreenMapNamePairDetails();
        this.ScreenActionKeyArray = new ObservableCollection<ScreenMapActionKey>();
    }

    /// <summary>
    /// Gets or sets the type of the screen.
    /// </summary>
    /// <value>
    /// The type of the screen.
    /// </value>
    public string ScreenType { get; set;}

    /// <summary>
    /// Gets or sets the screen design.
    /// </summary>
    /// <value>
    /// The screen design.
    /// </value>
    public string ScreenDesign { get; set;}

    /// <summary>
    /// Gets or sets the screen identifier.
    /// </summary>
    /// <value>
    /// The screen identifier.
    /// </value>
    public string ScreenId { get; set;}

    /// <summary>
    /// Gets or sets the function key parsing range.
    /// </summary>
    /// <value>
    /// The function key parsing range.
    /// </value>
    public string FunctionKeyParsingRange { get; set;}

    /// <summary>
    /// Gets or sets a value indicating whether this instance is line24 message ignored.
    /// </summary>
    /// <value>
    /// <c>true</c> if this instance is line24 message ignored; otherwise, <c>false</c>.
    /// </value>
    public bool IsLine24MessageIgnored { get; set;}

    /// <summary>
    /// Gets or sets the title.
    /// </summary>
    /// <value>
    /// The title.
    /// </value>
    public string Title { get; set;}

    /// <summary>
    /// Gets or sets the height of the screen.
    /// </summary>
    /// <value>
    /// The height of the screen.
    /// </value>
    public int ScreenHeight { get; set;}

    /// <summary>
    /// Gets or sets a value indicating whether [screen height specified].
    /// </summary>
    /// <value>
    /// <c>true</c> if [screen height specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool ScreenHeightSpecified { get; set;}

    /// <summary>
    /// Gets or sets the width of the screen.
    /// </summary>
    /// <value>
    /// The width of the screen.
    /// </value>
    public int ScreenWidth { get; set;}

    /// <summary>
    /// Gets or sets a value indicating whether [screen width specified].
    /// </summary>
    /// <value>
    /// <c>true</c> if [screen width specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool ScreenWidthSpecified { get; set;}

    /// <summary>
    /// Gets or sets the win top.
    /// </summary>
    /// <value>
    /// The win top.
    /// </value>
    public int WinTop { get; set;}

    /// <summary>
    /// Gets or sets a value indicating whether [win top specified].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [win top specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool WinTopSpecified { get; set;}

    /// <summary>
    /// Gets or sets the win left.
    /// </summary>
    /// <value>
    /// The win left.
    /// </value>
    public int WinLeft { get; set;}

    /// <summary>
    /// Gets or sets a value indicating whether [win left specified].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [win left specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool WinLeftSpecified { get; set;}

    /// <summary>
    /// Gets or sets the height of the win.
    /// </summary>
    /// <value>
    /// The height of the win.
    /// </value>
    public int WinHeight { get; set;}

    /// <summary>
    /// Gets or sets a value indicating whether [win height specified].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [win height specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool WinHeightSpecified { get; set;}

    /// <summary>
    /// Gets or sets the width of the win.
    /// </summary>
    /// <value>
    /// The width of the win.
    /// </value>
    public int WinWidth { get; set;}

    /// <summary>
    /// Gets or sets a value indicating whether [win width specified].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [win width specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool WinWidthSpecified { get; set;}

    /// <summary>
    /// Gets or sets the screen source.
    /// </summary>
    /// <value>
    /// The screen source.
    /// </value>
    public string ScreenSource { get; set;}

    /// <summary>
    /// Gets or sets the screen version.
    /// </summary>
    /// <value>
    /// The screen version.
    /// </value>
    public string ScreenVersion { get; set;}

    /// <summary>
    /// Gets or sets the screen action key array.
    /// </summary>
    /// <value>
    /// The screen action key array.
    /// </value>
    [XmlArrayItem("ActionKey", IsNullable = false)]
    public ObservableCollection<ScreenMapActionKey> ScreenActionKeyArray { get; set;}

    /// <summary>
    /// Gets or sets the name pair details.
    /// </summary>
    /// <value>
    /// The name pair details.
    /// </value>
    public ScreenMapNamePairDetails NamePairDetails { get; set;}

    /// <summary>
    /// Gets or sets the name pair array.
    /// </summary>
    /// <value>
    /// The name pair array.
    /// </value>
    [XmlArrayItem("Field", IsNullable = false)]
    public ObservableCollection<ScreenField> NamePairArray { get; set;}

    /// <summary>
    /// Gets or sets the grid array.
    /// </summary>
    /// <value>
    /// The grid array.
    /// </value>
    [XmlElement("GridArray")]
    public ObservableCollection<ScreenMapGridArray> GridArray { get; set;}

    /// <summary>
    /// Gets the serializer.
    /// </summary>
    /// <value>
    /// The serializer.
    /// </value>
    private static XmlSerializer Serializer
    {
        get
        {
            if ((serializer == null))
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(ScreenMap));
            }

            return serializer;
        }
    }

    /// <summary>
    /// Test whether ScreenActionKeyArray should be serialized
    /// </summary>
    public virtual bool ShouldSerializeScreenActionKeyArray()
    {
        return ScreenActionKeyArray != null && ScreenActionKeyArray.Count > 0;
    }

    /// <summary>
    /// Test whether NamePairArray should be serialized
    /// </summary>
    public virtual bool ShouldSerializeNamePairArray()
    {
        return NamePairArray != null && NamePairArray.Count > 0;
    }

    /// <summary>
    /// Test whether GridArray should be serialized
    /// </summary>
    public virtual bool ShouldSerializeGridArray()
    {
        return GridArray != null && GridArray.Count > 0;
    }

    /// <summary>
    /// Test whether ScreenHeight should be serialized
    /// </summary>
    public virtual bool ShouldSerializeScreenHeight()
    {
        if (_shouldSerializeScreenHeight)
        {
            return true;
        }

        return (ScreenHeight != default(int));
    }

    /// <summary>
    /// Test whether ScreenWidth should be serialized
    /// </summary>
    public virtual bool ShouldSerializeScreenWidth()
    {
        if (_shouldSerializeScreenWidth)
        {
            return true;
        }

        return (ScreenWidth != default(int));
    }

    /// <summary>
    /// Test whether WinTop should be serialized
    /// </summary>
    public virtual bool ShouldSerializeWinTop()
    {
        if (_shouldSerializeWinTop)
        {
            return true;
        }

        return (WinTop != default(int));
    }

    /// <summary>
    /// Test whether WinLeft should be serialized
    /// </summary>
    public virtual bool ShouldSerializeWinLeft()
    {
        if (_shouldSerializeWinLeft)
        {
            return true;
        }

        return (WinLeft != default(int));
    }

    /// <summary>
    /// Test whether WinHeight should be serialized
    /// </summary>
    public virtual bool ShouldSerializeWinHeight()
    {
        if (_shouldSerializeWinHeight)
        {
            return true;
        }

        return (WinHeight != default(int));
    }

    /// <summary>
    /// Test whether WinWidth should be serialized
    /// </summary>
    public virtual bool ShouldSerializeWinWidth()
    {
        if (_shouldSerializeWinWidth)
        {
            return true;
        }

        return (WinWidth != default(int));
    }

    /// <summary>
    /// Test whether NamePairDetails should be serialized
    /// </summary>
    public virtual bool ShouldSerializeNamePairDetails()
    {
        return (NamePairDetails != null);
    }

    /// <summary>
    /// Test whether ScreenType should be serialized
    /// </summary>
    public virtual bool ShouldSerializeScreenType()
    {
        return !string.IsNullOrEmpty(ScreenType);
    }

    /// <summary>
    /// Test whether ScreenDesign should be serialized
    /// </summary>
    public virtual bool ShouldSerializeScreenDesign()
    {
        return !string.IsNullOrEmpty(ScreenDesign);
    }

    /// <summary>
    /// Test whether ScreenId should be serialized
    /// </summary>
    public virtual bool ShouldSerializeScreenId()
    {
        return !string.IsNullOrEmpty(ScreenId);
    }

    /// <summary>
    /// Test whether IsLine24MessageIgnored should be serialized
    /// </summary>
    public virtual bool ShouldSerializeIsMessageIgnored()
    {
        if (_isLine24MessageIgnored)
        {
            return true;
        }

        return (_isLine24MessageIgnored != default(bool));
    }

    /// <summary>
    /// Test whether Title should be serialized
    /// </summary>
    public virtual bool ShouldSerializeTitle()
    {
        return !string.IsNullOrEmpty(Title);
    }

    /// <summary>
    /// Test whether ScreenSource should be serialized
    /// </summary>
    public virtual bool ShouldSerializeScreenSource()
    {
        return !string.IsNullOrEmpty(ScreenSource);
    }

    /// <summary>
    /// Test whether ScreenVersion should be serialized
    /// </summary>
    public virtual bool ShouldSerializeScreenVersion()
    {
        return !string.IsNullOrEmpty(ScreenVersion);
    }

    #region Serialize/Deserialize
    /// <summary>
    /// Serializes current ScreenMap object into an XML string
    /// </summary>
    /// <returns>string XML value</returns>
    public virtual string Serialize()
    {
        string serializedData = string.Empty;

        try
        {
            using (MemoryStream ms = new MemoryStream())
            {
                using (StreamReader streamReader = new StreamReader(ms))
                {
                    System.Xml.XmlWriterSettings xmlWriterSettings = new System.Xml.XmlWriterSettings();
                    xmlWriterSettings.Indent = true;
                    XmlWriter xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                    Serializer.Serialize(xmlWriter, this);
                    streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                    serializedData = streamReader.ReadToEnd();
                }
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    /// <summary>
    /// Deserializes workflow markup into an ScreenMap object
    /// </summary>
    /// <param name="input">string workflow markup to deserialize</param>
    /// <param name="obj">Output ScreenMap object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool Deserialize(string input, out ScreenMap obj, out System.Exception exception)
    {
        exception = null;
        obj = default(ScreenMap);

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool Deserialize(string input, out ScreenMap obj)
    {
        System.Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <returns>deserialized input</returns>
    public static ScreenMap Deserialize(string input)
    {
        System.IO.StringReader stringReader = null;
        try
        {
            stringReader = new System.IO.StringReader(input);

            return ((ScreenMap)(Serializer.Deserialize(System.Xml.XmlReader.Create(stringReader))));
        }
        finally
        {
            if ((stringReader != null))
            {
                stringReader.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes the specified s.
    /// </summary>
    /// <param name="s">The s.</param>
    /// <returns>deserialized stream</returns>
    public static ScreenMap Deserialize(System.IO.Stream s)
    {
        return ((ScreenMap)(Serializer.Deserialize(s)));
    }
    #endregion

    /// <summary>
    /// Serializes current ScreenMap object into file
    /// </summary>
    /// <param name="fileName">full path of outupt xml file</param>
    /// <param name="exception">output Exception value if failed</param>
    /// <returns>true if can serialize and save into file; otherwise, false</returns>
    public virtual bool SaveToFile(string fileName, out System.Exception exception)
    {
        exception = null;
        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (System.Exception e)
        {
            exception = e;
            return false;
        }
    }

    /// <summary>
    /// Saves to file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    public virtual void SaveToFile(string fileName)
    {
        System.IO.StreamWriter streamWriter = null;

        try
        {
            string xmlString = Serialize();
            System.IO.FileInfo xmlFile = new System.IO.FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if ((streamWriter != null))
            {
                streamWriter.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes xml markup from file into an ScreenMap object
    /// </summary>
    /// <param name="fileName">string xml file to load and deserialize</param>
    /// <param name="obj">Output ScreenMap object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool LoadFromFile(string fileName, out ScreenMap obj, out System.Exception exception)
    {
        exception = null;
        obj = default(ScreenMap);

        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool LoadFromFile(string fileName, out ScreenMap obj)
    {
        System.Exception exception = null;

        return LoadFromFile(fileName, out obj, out exception);
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <returns>deserialized xml string</returns>
    public static ScreenMap LoadFromFile(string fileName)
    {
        System.IO.FileStream file = null;
        System.IO.StreamReader sr = null;

        try
        {
            file = new System.IO.FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new System.IO.StreamReader(file);
            string xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();

            return Deserialize(xmlString);
        }
        finally
        {
            if ((file != null))
            {
                file.Dispose();
            }
            if ((sr != null))
            {
                sr.Dispose();
            }
        }
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="screenField5250">Name of the file.</param>
    /// <returns>screenField info</returns>
    public ScreenField GetMatchingField(ScreenField5250 screenField5250)
    {
        ScreenField screenField = this.NamePairArray.FirstOrDefault(f => f.Col == screenField5250.Col && f.Row == screenField5250.Row);

        if (screenField != null)
        {
            return screenField;
        }

        foreach (ScreenMapGridArray grid in this.GridArray)
        {
            screenField = grid.Grid.GridFields.FirstOrDefault(f => f.Col == screenField5250.Col && f.Row == screenField5250.Row);

            if (screenField != null)
            {
                return screenField;
            }
        }

        return null;
    }
}

[System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.79.0")]
[Serializable()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[XmlType(AnonymousType = true)]
public partial class ScreenMapActionKey
{
    private string _key;

    private string _action;

    private bool _isFocused;

    private bool _isMappedSubmitKey;

    private static XmlSerializer serializer;

    /// <summary>
    /// Initializes a new instance of the <see cref="ScreenMapActionKey"/> class.
    /// </summary>
    public ScreenMapActionKey()
    {
    }

    /// <summary>
    /// Gets or sets the key.
    /// </summary>
    /// <value>
    /// The key.
    /// </value>
    public string Key { get; set; }

    /// <summary>
    /// Gets or sets the action.
    /// </summary>
    /// <value>
    /// The action.
    /// </value>
    public string Action { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether this instance is focused.
    /// </summary>
    /// <value>
    /// <c>true</c> if this instance is focused; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool IsFocused { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether this instance is mapped submit key.
    /// </summary>
    /// <value>
    /// <c>true</c> if this instance is mapped submit key; otherwise, <c>false</c>.
    /// </value>
    public bool IsMappedSubmitKey { get; set; }

    /// <summary>
    /// Gets the serializer.
    /// </summary>
    /// <value>
    /// The serializer.
    /// </value>
    private static XmlSerializer Serializer
    {
        get
        {
            if ((serializer == null))
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(ScreenMapActionKey));
            }

            return serializer;
        }
    }

    /// <summary>
    /// Test whether Key should be serialized
    /// </summary>
    public virtual bool ShouldSerializeKey()
    {
        return !string.IsNullOrEmpty(Key);
    }

    /// <summary>
    /// Test whether Action should be serialized
    /// </summary>
    public virtual bool ShouldSerializeAction()
    {
        return !string.IsNullOrEmpty(Action);
    }

    #region Serialize/Deserialize
    /// <summary>
    /// Serializes current ScreenMapActionKey object into an XML string
    /// </summary>
    /// <returns>string XML value</returns>
    public virtual string Serialize()
    {
        string serializedData = string.Empty;

        try
        {
            using (StreamReader streamReader = new StreamReader(new MemoryStream()))
            {
                System.Xml.XmlWriterSettings xmlWriterSettings = new System.Xml.XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                XmlWriter xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                Serializer.Serialize(xmlWriter, this);
                streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                serializedData = streamReader.ReadToEnd();
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    /// <summary>
    /// Deserializes workflow markup into an ScreenMapActionKey object
    /// </summary>
    /// <param name="input">string workflow markup to deserialize</param>
    /// <param name="obj">Output ScreenMapActionKey object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool Deserialize(string input, out ScreenMapActionKey obj, out System.Exception exception)
    {
        exception = null;
        obj = default(ScreenMapActionKey);

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool Deserialize(string input, out ScreenMapActionKey obj)
    {
        System.Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <returns>deserialized input</returns>
    public static ScreenMapActionKey Deserialize(string input)
    {
        System.IO.StringReader stringReader = null;

        try
        {
            stringReader = new System.IO.StringReader(input);

            return ((ScreenMapActionKey)(Serializer.Deserialize(System.Xml.XmlReader.Create(stringReader))));
        }
        finally
        {
            if ((stringReader != null))
            {
                stringReader.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes the specified s.
    /// </summary>
    /// <param name="s">The s.</param>
    /// <returns>deserialized stream</returns>
    public static ScreenMapActionKey Deserialize(System.IO.Stream s)
    {
        return ((ScreenMapActionKey)(Serializer.Deserialize(s)));
    }
    #endregion

    /// <summary>
    /// Serializes current ScreenMapActionKey object into file
    /// </summary>
    /// <param name="fileName">full path of outupt xml file</param>
    /// <param name="exception">output Exception value if failed</param>
    /// <returns>true if can serialize and save into file; otherwise, false</returns>
    public virtual bool SaveToFile(string fileName, out System.Exception exception)
    {
        exception = null;

        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (System.Exception e)
        {
            exception = e;
            return false;
        }
    }

    /// <summary>
    /// Saves to file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    public virtual void SaveToFile(string fileName)
    {
        System.IO.StreamWriter streamWriter = null;

        try
        {
            string xmlString = Serialize();
            System.IO.FileInfo xmlFile = new System.IO.FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if ((streamWriter != null))
            {
                streamWriter.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes xml markup from file into an ScreenMapActionKey object
    /// </summary>
    /// <param name="fileName">string xml file to load and deserialize</param>
    /// <param name="obj">Output ScreenMapActionKey object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool LoadFromFile(string fileName, out ScreenMapActionKey obj, out System.Exception exception)
    {
        exception = null;
        obj = default(ScreenMapActionKey);

        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool LoadFromFile(string fileName, out ScreenMapActionKey obj)
    {
        System.Exception exception = null;
        return LoadFromFile(fileName, out obj, out exception);
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <returns>deserialized xml string</returns>
    public static ScreenMapActionKey LoadFromFile(string fileName)
    {
        System.IO.FileStream file = null;
        System.IO.StreamReader sr = null;

        try
        {
            file = new System.IO.FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new System.IO.StreamReader(file);
            string xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();

            return Deserialize(xmlString);
        }
        finally
        {
            if ((file != null))
            {
                file.Dispose();
            }
            if ((sr != null))
            {
                sr.Dispose();
            }
        }
    }
}

[System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.79.0")]
[Serializable()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
public partial class ScreenField
{
    private bool _shouldSerializeOptionField;

    private bool _shouldSerializeReadOnly;

    private bool _shouldSerializeSequence;

    private bool _shouldSerializeDecimalScale;

    private bool _shouldSerializeCol;

    private bool _shouldSerializeRow;

    private bool _shouldSerializeLength;

    private static XmlSerializer serializer;

    /// <summary>
    /// Initializes a new instance of the <see cref="ScreenField"/> class.
    /// </summary>
    public ScreenField()
    {
        FieldValueArray = new List<FieldValue>();
    }

    /// <summary>
    /// Gets or sets the field identifier.
    /// </summary>
    /// <value>
    /// The field identifier.
    /// </value>
    public string FieldId { get; set; }

    /// <summary>
    /// Gets or sets the field category.
    /// </summary>
    /// <value>
    /// The field category.
    /// </value>
    public string FieldCategory { get; set; }

    /// <summary>
    /// Gets or sets the field label.
    /// </summary>
    /// <value>
    /// The field label.
    /// </value>
    public string FieldLabel { get; set; }

    /// <summary>
    /// Gets or sets the field value array.
    /// </summary>
    /// <value>
    /// The field value array.
    /// </value>
    public List<FieldValue> FieldValueArray { get; set; }

    /// <summary>
    /// Gets or sets the field values string.
    /// </summary>
    /// <value>
    /// The field values string.
    /// </value>
    [XmlIgnore()]
    public string FieldValuesString { get; set; }

    /// <summary>
    /// Gets or sets the type of the data.
    /// </summary>
    /// <value>
    /// The type of the data.
    /// </value>
    public string DataType { get; set; }

    /// <summary>
    /// Gets or sets the length.
    /// </summary>
    /// <value>
    /// The length.
    /// </value>
    public int Length { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [length specified].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [length specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool LengthSpecified { get; set; }

    /// <summary>
    /// Gets or sets the row.
    /// </summary>
    /// <value>
    /// The row.
    /// </value>
    public int Row { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [row specified].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [row specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool RowSpecified { get; set; }

    /// <summary>
    /// Gets or sets the col.
    /// </summary>
    /// <value>
    /// The col.
    /// </value>
    public int Col { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [col specified].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [col specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool ColSpecified { get; set; }

    /// <summary>
    /// Gets or sets the decimal scale.
    /// </summary>
    /// <value>
    /// The decimal scale.
    /// </value>
    public int DecimalScale { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [decimal scale specified].
    /// </summary>
    /// <value>
    /// <c>true</c> if [decimal scale specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool DecimalScaleSpecified { get; set; }

    /// <summary>
    /// Gets or sets the sequence.
    /// </summary>
    /// <value>
    /// The sequence.
    /// </value>
    public int Sequence { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [sequence specified].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [sequence specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool SequenceSpecified { get; set; }

    /// <summary>
    /// Gets or sets the field reference identifier.
    /// </summary>
    /// <value>
    /// The field reference identifier.
    /// </value>
    public string FieldRefId { get; set; }

    /// <summary>
    /// Gets or sets the help identifier.
    /// </summary>
    /// <value>
    /// The help identifier.
    /// </value>
    public string HelpId { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [read only].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [read only]; otherwise, <c>false</c>.
    /// </value>
    public bool ReadOnly { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [read only specified].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [read only specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool ReadOnlySpecified { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [option field].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [option field]; otherwise, <c>false</c>.
    /// </value>
    public bool OptionField { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [option field specified].
    /// </summary>
    /// <value>
    /// <c>true</c> if [option field specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool OptionFieldSpecified { get; set; }

    /// <summary>
    /// Gets or sets the disp format.
    /// </summary>
    /// <value>
    /// The disp format.
    /// </value>
    public string DispFormat { get; set; }

    /// <summary>
    /// Gets or sets the prompt key.
    /// </summary>
    /// <value>
    /// The prompt key.
    /// </value>
    public string PromptKey { get; set; }

    /// <summary>
    /// Gets or sets the type of the link.
    /// </summary>
    /// <value>
    /// The type of the link.
    /// </value>
    public string LinkType { get; set; }

    /// <summary>
    /// Gets or sets the link data expression.
    /// </summary>
    /// <value>
    /// The link data expression.
    /// </value>
    public string LinkDataExpression { get; set; }

    /// <summary>
    /// Gets or sets the indicators.
    /// </summary>
    /// <value>
    /// The indicators.
    /// </value>
    public string Indicators { get; set; }

    /// <summary>
    /// Gets or sets the edit codes.
    /// </summary>
    /// <value>
    /// The edit codes.
    /// </value>
    public string EditCodes { get; set; }

    /// <summary>
    /// Gets or sets the edit codes.
    /// </summary>
    /// <value>
    /// The edit codes.
    /// </value>
    public string EditMask { get; set; }

    /// <summary>
    /// Gets or sets the Horizontal Alignment.
    /// </summary>
    /// <value>
    /// The Horizontal Alignment.
    /// </value>
    public string HorizontalAlignment { get; set; }

    /// <summary>
    /// Gets the serializer.
    /// </summary>
    /// <value>
    /// The serializer.
    /// </value>
    private static XmlSerializer Serializer
    {
        get
        {
            if ((serializer == null))
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(ScreenField));
            }

            return serializer;
        }
    }

    /// <summary>
    /// Test whether Length should be serialized
    /// </summary>
    public virtual bool ShouldSerializeLength()
    {
        if (_shouldSerializeLength)
        {
            return true;
        }

        return (Length != default(int));
    }

    /// <summary>
    /// Test whether Row should be serialized
    /// </summary>
    public virtual bool ShouldSerializeRow()
    {
        if (_shouldSerializeRow)
        {
            return true;
        }

        return (Row != default(int));
    }

    /// <summary>
    /// Test whether Col should be serialized
    /// </summary>
    public virtual bool ShouldSerializeCol()
    {
        if (_shouldSerializeCol)
        {
            return true;
        }

        return (Col != default(int));
    }

    /// <summary>
    /// Test whether DecimalScale should be serialized
    /// </summary>
    public virtual bool ShouldSerializeDecimalScale()
    {
        if (_shouldSerializeDecimalScale)
        {
            return true;
        }

        return (DecimalScale != default(int));
    }

    /// <summary>
    /// Test whether Sequence should be serialized
    /// </summary>
    public virtual bool ShouldSerializeSequence()
    {
        if (_shouldSerializeSequence)
        {
            return true;
        }

        return (Sequence != default(int));
    }

    /// <summary>
    /// Test whether ReadOnly should be serialized
    /// </summary>
    public virtual bool ShouldSerializeReadOnly()
    {
        if (_shouldSerializeReadOnly)
        {
            return true;
        }

        return (ReadOnly != default(bool));
    }

    /// <summary>
    /// Test whether OptionField should be serialized
    /// </summary>
    public virtual bool ShouldSerializeOptionField()
    {
        if (_shouldSerializeOptionField)
        {
            return true;
        }

        return (OptionField != default(bool));
    }

    /// <summary>
    /// Test whether FieldId should be serialized
    /// </summary>
    public virtual bool ShouldSerializeFieldId()
    {
        return !string.IsNullOrEmpty(FieldId);
    }

    /// <summary>
    /// Test whether FieldCategory should be serialized
    /// </summary>
    public virtual bool ShouldSerializeFieldCategory()
    {
        return !string.IsNullOrEmpty(FieldCategory);
    }

    /// <summary>
    /// Test whether FieldLabel should be serialized
    /// </summary>
    public virtual bool ShouldSerializeFieldLabel()
    {
        return !string.IsNullOrEmpty(FieldLabel);
    }

    /// <summary>
    /// Test whether FieldValueArray should be serialized
    /// </summary>
    public virtual bool ShouldSerializeFieldValueArray()
    {
        return FieldValueArray?.Any() ?? false;
    }

    /// <summary>
    /// Test whether DataType should be serialized
    /// </summary>
    public virtual bool ShouldSerializeDataType()
    {
        return !string.IsNullOrEmpty(DataType);
    }

    /// <summary>
    /// Test whether FieldRefId should be serialized
    /// </summary>
    public virtual bool ShouldSerializeFieldRefId()
    {
        return !string.IsNullOrEmpty(FieldRefId);
    }

    /// <summary>
    /// Test whether HelpId should be serialized
    /// </summary>
    public virtual bool ShouldSerializeHelpId()
    {
        return !string.IsNullOrEmpty(HelpId);
    }

    /// <summary>
    /// Test whether DispFormat should be serialized
    /// </summary>
    public virtual bool ShouldSerializeDispFormat()
    {
        return !string.IsNullOrEmpty(DispFormat);
    }

    /// <summary>
    /// Test whether PromptKey should be serialized
    /// </summary>
    public virtual bool ShouldSerializePromptKey()
    {
        return !string.IsNullOrEmpty(PromptKey);
    }

    /// <summary>
    /// Test whether LinkType should be serialized
    /// </summary>
    public virtual bool ShouldSerializeLinkType()
    {
        return !string.IsNullOrEmpty(LinkType);
    }

    /// <summary>
    /// Test whether LinkDataExpression should be serialized
    /// </summary>
    public virtual bool ShouldSerializeLinkDataExpression()
    {
        return !string.IsNullOrEmpty(LinkDataExpression);
    }

    /// <summary>
    /// Test whether Indicators should be serialized
    /// </summary>
    public virtual bool ShouldSerializeIndicators()
    {
        return !string.IsNullOrEmpty(Indicators);
    }

    /// <summary>
    /// Test whether EditCodes should be serialized
    /// </summary>
    public virtual bool ShouldSerializeEditCodes()
    {
        return !string.IsNullOrEmpty(EditCodes);
    }

    #region Serialize/Deserialize
    /// <summary>
    /// Serializes current ScreenField object into an XML string
    /// </summary>
    /// <returns>string XML value</returns>
    public virtual string Serialize()
    {
        string serializedData = string.Empty;

        try
        {
            using (StreamReader streamReader = new StreamReader(new MemoryStream()))
            {
                System.Xml.XmlWriterSettings xmlWriterSettings = new System.Xml.XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                XmlWriter xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                Serializer.Serialize(xmlWriter, this);
                streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                serializedData = streamReader.ReadToEnd();
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    /// <summary>
    /// Returns a <see cref="System.String" /> that represents this instance.
    /// </summary>
    /// <returns>
    /// A <see cref="System.String" /> that represents this instance.
    /// </returns>
    public override string ToString()
    {
        StringBuilder fieldString = new StringBuilder();
        fieldString.Append("Screen Field:");

        fieldString.Append("  Row:" + this.Row.ToString());
        fieldString.Append("  Col:" + this.Col.ToString());
        fieldString.Append("  Length:" + this.Length.ToString());
        fieldString.Append("  R/O:" + this.ReadOnly.ToString());

        if (this.FieldLabel != null && this.FieldLabel != string.Empty)
        {
            fieldString.Append("  Label:" + this.FieldLabel);
        }

        if (this.FieldCategory != null && this.FieldCategory != string.Empty)
        {
            fieldString.Append("  Category:" + this.FieldCategory);
        }

        fieldString.Append("  Seq:" + this.Sequence.ToString());

        if (this.DataType != null && this.DataType != string.Empty)
        {
            fieldString.Append("  Type:" + this.DataType);
        }

        fieldString.Append("  Decimal Scale:" + this.DecimalScale.ToString());

        if (this.DispFormat != null && this.DispFormat != string.Empty)
        {
            fieldString.Append("  Display Format" + this.DispFormat);
        }

        if (this.FieldRefId != null && this.FieldRefId != string.Empty)
        {
            fieldString.Append("  Field Ref:" + this.FieldRefId);
        }

        if (this.LinkType != null && this.LinkType != string.Empty)
        {
            fieldString.Append("  Link Type:" + this.LinkType);
        }

        if (this.LinkDataExpression != null && this.LinkDataExpression != string.Empty)
        {
            fieldString.Append("  Link Data Exp:" + this.LinkDataExpression);
        }

        return fieldString.ToString();
    }

    /// <summary>
    /// Deserializes workflow markup into an ScreenField object
    /// </summary>
    /// <param name="input">string workflow markup to deserialize</param>
    /// <param name="obj">Output ScreenField object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool Deserialize(string input, out ScreenField obj, out System.Exception exception)
    {
        exception = null;
        obj = default(ScreenField);

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool Deserialize(string input, out ScreenField obj)
    {
        System.Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <returns>deserialized input</returns>
    public static ScreenField Deserialize(string input)
    {
        System.IO.StringReader stringReader = null;
        try
        {
            stringReader = new System.IO.StringReader(input);

            return ((ScreenField)(Serializer.Deserialize(System.Xml.XmlReader.Create(stringReader))));
        }
        finally
        {
            if ((stringReader != null))
            {
                stringReader.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes the specified s.
    /// </summary>
    /// <param name="s">The s.</param>
    /// <returns>deserialized string</returns>
    public static ScreenField Deserialize(System.IO.Stream s)
    {
        return ((ScreenField)(Serializer.Deserialize(s)));
    }
    #endregion

    /// <summary>
    /// Serializes current ScreenField object into file
    /// </summary>
    /// <param name="fileName">full path of outupt xml file</param>
    /// <param name="exception">output Exception value if failed</param>
    /// <returns>true if can serialize and save into file; otherwise, false</returns>
    public virtual bool SaveToFile(string fileName, out System.Exception exception)
    {
        exception = null;

        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (System.Exception e)
        {
            exception = e;
            return false;
        }
    }

    /// <summary>
    /// Saves to file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    public virtual void SaveToFile(string fileName)
    {
        System.IO.StreamWriter streamWriter = null;

        try
        {
            string xmlString = Serialize();
            System.IO.FileInfo xmlFile = new System.IO.FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if ((streamWriter != null))
            {
                streamWriter.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes xml markup from file into an ScreenField object
    /// </summary>
    /// <param name="fileName">string xml file to load and deserialize</param>
    /// <param name="obj">Output ScreenField object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool LoadFromFile(string fileName, out ScreenField obj, out System.Exception exception)
    {
        exception = null;
        obj = default(ScreenField);

        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool LoadFromFile(string fileName, out ScreenField obj)
    {
        System.Exception exception = null;

        return LoadFromFile(fileName, out obj, out exception);
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <returns>deserialized xml string</returns>
    public static ScreenField LoadFromFile(string fileName)
    {
        System.IO.FileStream file = null;
        System.IO.StreamReader sr = null;

        try
        {
            file = new System.IO.FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new System.IO.StreamReader(file);
            string xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();

            return Deserialize(xmlString);
        }
        finally
        {
            if ((file != null))
            {
                file.Dispose();
            }
            if ((sr != null))
            {
                sr.Dispose();
            }
        }
    }
}

[System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.79.0")]
[Serializable()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[XmlType(AnonymousType = true)]
public partial class ScreenMapNamePairDetails
{
    private static XmlSerializer serializer;

    /// <summary>
    /// Initializes a new instance of the <see cref="ScreenMapNamePairDetails"/> class.
    /// </summary>
    public ScreenMapNamePairDetails()
    {
    }

    /// <summary>
    /// Gets or sets the header text.
    /// </summary>
    /// <value>
    /// The header text.
    /// </value>
    public string HeaderText { get; set; }

    /// <summary>
    /// Gets the serializer.
    /// </summary>
    /// <value>
    /// The serializer.
    /// </value>
    private static XmlSerializer Serializer
    {
        get
        {
            if ((serializer == null))
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(ScreenMapNamePairDetails));
            }

            return serializer;
        }
    }

    /// <summary>
    /// Test whether HeaderText should be serialized
    /// </summary>
    public virtual bool ShouldSerializeHeaderText()
    {
        return !string.IsNullOrEmpty(HeaderText);
    }

    #region Serialize/Deserialize
    /// <summary>
    /// Serializes current ScreenMapNamePairDetails object into an XML string
    /// </summary>
    /// <returns>string XML value</returns>
    public virtual string Serialize()
    {
        string serializedData = string.Empty;

        try
        {
            using (StreamReader streamReader = new StreamReader(new MemoryStream()))
            {
                System.Xml.XmlWriterSettings xmlWriterSettings = new System.Xml.XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                XmlWriter xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                Serializer.Serialize(xmlWriter, this);
                streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                serializedData = streamReader.ReadToEnd();
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    /// <summary>
    /// Deserializes workflow markup into an ScreenMapNamePairDetails object
    /// </summary>
    /// <param name="input">string workflow markup to deserialize</param>
    /// <param name="obj">Output ScreenMapNamePairDetails object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool Deserialize(string input, out ScreenMapNamePairDetails obj, out System.Exception exception)
    {
        exception = null;
        obj = default(ScreenMapNamePairDetails);

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool Deserialize(string input, out ScreenMapNamePairDetails obj)
    {
        System.Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <returns>deserialized input</returns>
    public static ScreenMapNamePairDetails Deserialize(string input)
    {
        System.IO.StringReader stringReader = null;
        try
        {
            stringReader = new System.IO.StringReader(input);
            return ((ScreenMapNamePairDetails)(Serializer.Deserialize(System.Xml.XmlReader.Create(stringReader))));
        }
        finally
        {
            if ((stringReader != null))
            {
                stringReader.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes the specified s.
    /// </summary>
    /// <param name="s">The s.</param>
    /// <returns>deserialized stream</returns>
    public static ScreenMapNamePairDetails Deserialize(System.IO.Stream s)
    {
        return ((ScreenMapNamePairDetails)(Serializer.Deserialize(s)));
    }
    #endregion

    /// <summary>
    /// Serializes current ScreenMapNamePairDetails object into file
    /// </summary>
    /// <param name="fileName">full path of outupt xml file</param>
    /// <param name="exception">output Exception value if failed</param>
    /// <returns>true if can serialize and save into file; otherwise, false</returns>
    public virtual bool SaveToFile(string fileName, out System.Exception exception)
    {
        exception = null;

        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (System.Exception e)
        {
            exception = e;
            return false;
        }
    }

    /// <summary>
    /// Saves to file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    public virtual void SaveToFile(string fileName)
    {
        System.IO.StreamWriter streamWriter = null;

        try
        {
            string xmlString = Serialize();
            System.IO.FileInfo xmlFile = new System.IO.FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if ((streamWriter != null))
            {
                streamWriter.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes xml markup from file into an ScreenMapNamePairDetails object
    /// </summary>
    /// <param name="fileName">string xml file to load and deserialize</param>
    /// <param name="obj">Output ScreenMapNamePairDetails object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool LoadFromFile(string fileName, out ScreenMapNamePairDetails obj, out System.Exception exception)
    {
        exception = null;
        obj = default(ScreenMapNamePairDetails);

        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool LoadFromFile(string fileName, out ScreenMapNamePairDetails obj)
    {
        System.Exception exception = null;
        return LoadFromFile(fileName, out obj, out exception);
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <returns>deserialized xml string</returns>
    public static ScreenMapNamePairDetails LoadFromFile(string fileName)
    {
        System.IO.FileStream file = null;
        System.IO.StreamReader sr = null;

        try
        {
            file = new System.IO.FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new System.IO.StreamReader(file);
            string xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();

            return Deserialize(xmlString);
        }
        finally
        {
            if ((file != null))
            {
                file.Dispose();
            }
            if ((sr != null))
            {
                sr.Dispose();
            }
        }
    }
}

[System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.79.0")]
[Serializable()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[XmlType(AnonymousType = true)]
public partial class ScreenMapGridArray
{
    private static XmlSerializer serializer;

    /// <summary>
    /// Initializes a new instance of the <see cref="ScreenMapGridArray"/> class.
    /// </summary>
    public ScreenMapGridArray()
    {
        this.Grid = new ScreenMapGridArrayGrid();
    }

    /// <summary>
    /// Gets or sets the grid.
    /// </summary>
    /// <value>
    /// The grid.
    /// </value>
    public ScreenMapGridArrayGrid Grid { get; set; }

    /// <summary>
    /// Gets the serializer.
    /// </summary>
    /// <value>
    /// The serializer.
    /// </value>
    private static XmlSerializer Serializer
    {
        get
        {
            if ((serializer == null))
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(ScreenMapGridArray));
            }

            return serializer;
        }
    }

    /// <summary>
    /// Test whether Grid should be serialized
    /// </summary>
    public virtual bool ShouldSerializeGrid()
    {
        return (Grid != null);
    }

    #region Serialize/Deserialize
    /// <summary>
    /// Serializes current ScreenMapGridArray object into an XML string
    /// </summary>
    /// <returns>string XML value</returns>
    public virtual string Serialize()
    {
        string serializedData = string.Empty;

        try
        {
            using (StreamReader streamReader = new StreamReader(new MemoryStream()))
            {
                System.Xml.XmlWriterSettings xmlWriterSettings = new System.Xml.XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                XmlWriter xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                Serializer.Serialize(xmlWriter, this);
                streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                serializedData = streamReader.ReadToEnd();
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    /// <summary>
    /// Deserializes workflow markup into an ScreenMapGridArray object
    /// </summary>
    /// <param name="input">string workflow markup to deserialize</param>
    /// <param name="obj">Output ScreenMapGridArray object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool Deserialize(string input, out ScreenMapGridArray obj, out System.Exception exception)
    {
        exception = null;
        obj = default(ScreenMapGridArray);

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool Deserialize(string input, out ScreenMapGridArray obj)
    {
        System.Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <returns>deserialized input</returns>
    public static ScreenMapGridArray Deserialize(string input)
    {
        System.IO.StringReader stringReader = null;

        try
        {
            stringReader = new System.IO.StringReader(input);
            return ((ScreenMapGridArray)(Serializer.Deserialize(System.Xml.XmlReader.Create(stringReader))));
        }
        finally
        {
            if ((stringReader != null))
            {
                stringReader.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes the specified s.
    /// </summary>
    /// <param name="s">The s.</param>
    /// <returns>deserialized stream</returns>
    public static ScreenMapGridArray Deserialize(System.IO.Stream s)
    {
        return ((ScreenMapGridArray)(Serializer.Deserialize(s)));
    }
    #endregion

    /// <summary>
    /// Serializes current ScreenMapGridArray object into file
    /// </summary>
    /// <param name="fileName">full path of outupt xml file</param>
    /// <param name="exception">output Exception value if failed</param>
    /// <returns>true if can serialize and save into file; otherwise, false</returns>
    public virtual bool SaveToFile(string fileName, out System.Exception exception)
    {
        exception = null;

        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (System.Exception e)
        {
            exception = e;
            return false;
        }
    }

    /// <summary>
    /// Saves to file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    public virtual void SaveToFile(string fileName)
    {
        System.IO.StreamWriter streamWriter = null;

        try
        {
            string xmlString = Serialize();
            System.IO.FileInfo xmlFile = new System.IO.FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if ((streamWriter != null))
            {
                streamWriter.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes xml markup from file into an ScreenMapGridArray object
    /// </summary>
    /// <param name="fileName">string xml file to load and deserialize</param>
    /// <param name="obj">Output ScreenMapGridArray object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool LoadFromFile(string fileName, out ScreenMapGridArray obj, out System.Exception exception)
    {
        exception = null;
        obj = default(ScreenMapGridArray);
        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool LoadFromFile(string fileName, out ScreenMapGridArray obj)
    {
        System.Exception exception = null;
        return LoadFromFile(fileName, out obj, out exception);
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <returns>deserialized xml string</returns>
    public static ScreenMapGridArray LoadFromFile(string fileName)
    {
        System.IO.FileStream file = null;
        System.IO.StreamReader sr = null;

        try
        {
            file = new System.IO.FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new System.IO.StreamReader(file);
            string xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();

            return Deserialize(xmlString);
        }
        finally
        {
            if ((file != null))
            {
                file.Dispose();
            }
            if ((sr != null))
            {
                sr.Dispose();
            }
        }
    }
}

[System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.79.0")]
[Serializable()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[XmlType(AnonymousType = true)]
public partial class ScreenMapGridArrayGrid
{
    private bool _shouldSerializeGridColOffset;

    private bool _shouldSerializeGridColCount;

    private bool _shouldSerializeGridRowCount;

    private bool _shouldSerializeGridRowsPerRec;

    private bool _shouldSerializeGridPageSize;

    private bool _shouldSerializeIsDynamicGrid;

    private bool _shouldSerializeAutoUnfoldGrid;

    private string _dynamicGridInsertMode;

    private static XmlSerializer serializer;

    /// <summary>
    /// Initializes a new instance of the <see cref="ScreenMapGridArrayGrid"/> class.
    /// </summary>
    public ScreenMapGridArrayGrid()
    {
        this.GridFields = new ObservableCollection<ScreenField>();
        this.GridOptionArray = new ObservableCollection<ScreenMapGridArrayGridGridOption>();
    }

    /// <summary>
    /// Gets or sets the grid unfold key.
    /// </summary>
    /// <value>
    /// The grid unfold key.
    /// </value>
    public string GridUnfoldKey { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [automatic unfold grid].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [automatic unfold grid]; otherwise, <c>false</c>.
    /// </value>
    public bool AutoUnfoldGrid { get; set; }

    /// <summary>
    /// Gets or sets the grid sort key.
    /// </summary>
    /// <value>
    /// The grid sort key.
    /// </value>
    public string GridSortKey { get; set; }

    /// <summary>
    /// Gets or sets the size of the grid page.
    /// </summary>
    /// <value>
    /// The size of the grid page.
    /// </value>
    public int GridPageSize { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [grid page size specified].
    /// </summary>
    /// <value>
    /// <c>true</c> if [grid page size specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool GridPageSizeSpecified { get; set; }

    /// <summary>
    /// Gets or sets the grid rows per record.
    /// </summary>
    /// <value>
    /// The grid rows per record.
    /// </value>
    public int GridRowsPerRec { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [grid rows per record specified].
    /// </summary>
    /// <value>
    /// <c>true</c> if [grid rows per record specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool GridRowsPerRecSpecified { get; set; }

    /// <summary>
    /// Gets or sets the grid row count.
    /// </summary>
    /// <value>
    /// The grid row count.
    /// </value>
    public int GridRowCount { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [grid row count specified].
    /// </summary>
    /// <value>
    /// <c>true</c> if [grid row count specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool GridRowCountSpecified { get; set; }

    /// <summary>
    /// Gets or sets the grid col count.
    /// </summary>
    /// <value>
    /// The grid col count.
    /// </value>
    public int GridColCount { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [grid col count specified].
    /// </summary>
    /// <value>
    /// <c>true</c> if [grid col count specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool GridColCountSpecified { get; set; }

    /// <summary>
    /// Gets or sets the grid col offset.
    /// </summary>
    /// <value>
    /// The grid col offset.
    /// </value>
    public int GridColOffset { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [grid col offset specified].
    /// </summary>
    /// <value>
    /// <c>true</c> if [grid col offset specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool GridColOffsetSpecified { get; set; }

    /// <summary>
    /// Gets or sets the grid header.
    /// </summary>
    /// <value>
    /// The grid header.
    /// </value>
    public string GridHeader { get; set; }

    /// <summary>
    /// Gets or sets the header text.
    /// </summary>
    /// <value>
    /// The header text.
    /// </value>
    public string HeaderText { get; set; }

    /// <summary>
    /// Gets or sets the next page direction.
    /// </summary>
    /// <value>
    /// The next page direction.
    /// </value>
    public string NextPageDirection { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether this instance is dynamic grid.
    /// </summary>
    /// <value>
    /// <c>true</c> if this instance is dynamic grid; otherwise, <c>false</c>.
    /// </value>
    public bool IsDynamicGrid { get; set; }

    /// <summary>
    /// Gets or sets the dynamic grid insert mode.
    /// </summary>
    /// <value>
    /// The dynamic grid insert mode.
    /// </value>
    public string DynamicGridInsertMode { get; set; }

    /// <summary>
    /// Gets or sets the grid option array.
    /// </summary>
    /// <value>
    /// The grid option array.
    /// </value>
    [XmlArrayItem("GridOption", IsNullable = false)]
    public ObservableCollection<ScreenMapGridArrayGridGridOption> GridOptionArray { get; set; }

    /// <summary>
    /// Gets or sets the grid fields.
    /// </summary>
    /// <value>
    /// The grid fields.
    /// </value>
    [XmlArrayItem("Field", IsNullable = false)]
    public ObservableCollection<ScreenField> GridFields { get; set; }

    /// <summary>
    /// Gets the serializer.
    /// </summary>
    /// <value>
    /// The serializer.
    /// </value>
    private static XmlSerializer Serializer
    {
        get
        {
            if ((serializer == null))
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(ScreenMapGridArrayGrid));
            }
            return serializer;
        }
    }

    /// <summary>
    /// Test whether GridOptionArray should be serialized
    /// </summary>
    public virtual bool ShouldSerializeGridOptionArray()
    {
        return GridOptionArray != null && GridOptionArray.Count > 0;
    }

    /// <summary>
    /// Test whether GridFields should be serialized
    /// </summary>
    public virtual bool ShouldSerializeGridFields()
    {
        return GridFields != null && GridFields.Count > 0;
    }

    /// <summary>
    /// Test whether GridPageSize should be serialized
    /// </summary>
    public virtual bool ShouldSerializeGridPageSize()
    {
        if (_shouldSerializeGridPageSize)
        {
            return true;
        }

        return (GridPageSize != default(int));
    }

    /// <summary>
    /// Test whether GridRowsPerRec should be serialized
    /// </summary>
    public virtual bool ShouldSerializeGridRowsPerRec()
    {
        if (_shouldSerializeGridRowsPerRec)
        {
            return true;
        }

        return (GridRowsPerRec != default(int));
    }

    /// <summary>
    /// Test whether GridRowCount should be serialized
    /// </summary>
    public virtual bool ShouldSerializeGridRowCount()
    {
        if (_shouldSerializeGridRowCount)
        {
            return true;
        }

        return (GridRowCount != default(int));
    }

    /// <summary>
    /// Test whether GridColCount should be serialized
    /// </summary>
    public virtual bool ShouldSerializeGridColCount()
    {
        if (_shouldSerializeGridColCount)
        {
            return true;
        }

        return (GridColCount != default(int));
    }

    /// <summary>
    /// Test whether GridColOffset should be serialized
    /// </summary>
    public virtual bool ShouldSerializeGridColOffset()
    {
        if (_shouldSerializeGridColOffset)
        {
            return true;
        }

        return (GridColOffset != default(int));
    }

    /// <summary>
    /// Test whether GridUnfoldKey should be serialized
    /// </summary>
    public virtual bool ShouldSerializeGridUnfoldKey()
    {
        return !string.IsNullOrEmpty(GridUnfoldKey);
    }

    /// <summary>
    /// Test whether GridHeader should be serialized
    /// </summary>
    public virtual bool ShouldSerializeGridHeader()
    {
        return !string.IsNullOrEmpty(GridHeader);
    }

    /// <summary>
    /// Test whether HeaderText should be serialized
    /// </summary>
    public virtual bool ShouldSerializeHeaderText()
    {
        return !string.IsNullOrEmpty(HeaderText);
    }

    /// <summary>
    /// Test whether NextPageDirection should be serialized
    /// </summary>
    public virtual bool ShouldSerializeNextPageDirection()
    {
        return !string.IsNullOrEmpty(NextPageDirection);
    }

    /// <summary>
    /// Test whether IsDynamicGrid should be serialized
    /// </summary>
    public virtual bool ShouldSerializeIsDynamicGrid()
    {
        if (_shouldSerializeIsDynamicGrid)
        {
            return true;
        }

        return (IsDynamicGrid != default(bool));
    }

    /// <summary>
    /// Shoulds the serialize automatic unfold grid.
    /// </summary>
    public virtual bool ShouldSerializeAutoUnfoldGrid()
    {
        if (_shouldSerializeAutoUnfoldGrid)
        {
            return true;
        }

        return (AutoUnfoldGrid != default(bool));
    }

    #region Serialize/Deserialize
    /// <summary>
    /// Serializes current ScreenMapGridArrayGrid object into an XML string
    /// </summary>
    /// <returns>string XML value</returns>
    public virtual string Serialize()
    {
        string serializedData = string.Empty;

        try
        {
            using (StreamReader streamReader = new StreamReader(new MemoryStream()))
            {
                System.Xml.XmlWriterSettings xmlWriterSettings = new System.Xml.XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                XmlWriter xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                Serializer.Serialize(xmlWriter, this);
                streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                serializedData = streamReader.ReadToEnd();
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    /// <summary>
    /// Deserializes workflow markup into an ScreenMapGridArrayGrid object
    /// </summary>
    /// <param name="input">string workflow markup to deserialize</param>
    /// <param name="obj">Output ScreenMapGridArrayGrid object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool Deserialize(string input, out ScreenMapGridArrayGrid obj, out System.Exception exception)
    {
        exception = null;
        obj = default(ScreenMapGridArrayGrid);

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool Deserialize(string input, out ScreenMapGridArrayGrid obj)
    {
        System.Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <returns>deserialized input</returns>
    public static ScreenMapGridArrayGrid Deserialize(string input)
    {
        System.IO.StringReader stringReader = null;

        try
        {
            stringReader = new System.IO.StringReader(input);
            return ((ScreenMapGridArrayGrid)(Serializer.Deserialize(System.Xml.XmlReader.Create(stringReader))));
        }
        finally
        {
            if ((stringReader != null))
            {
                stringReader.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes the specified s.
    /// </summary>
    /// <param name="s">The s.</param>
    /// <returns>deserialized stream</returns>
    public static ScreenMapGridArrayGrid Deserialize(System.IO.Stream s)
    {
        return ((ScreenMapGridArrayGrid)(Serializer.Deserialize(s)));
    }
    #endregion

    /// <summary>
    /// Serializes current ScreenMapGridArrayGrid object into file
    /// </summary>
    /// <param name="fileName">full path of outupt xml file</param>
    /// <param name="exception">output Exception value if failed</param>
    /// <returns>true if can serialize and save into file; otherwise, false</returns>
    public virtual bool SaveToFile(string fileName, out System.Exception exception)
    {
        exception = null;

        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (System.Exception e)
        {
            exception = e;
            return false;
        }
    }

    /// <summary>
    /// Saves to file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    public virtual void SaveToFile(string fileName)
    {
        System.IO.StreamWriter streamWriter = null;

        try
        {
            string xmlString = Serialize();
            System.IO.FileInfo xmlFile = new System.IO.FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if ((streamWriter != null))
            {
                streamWriter.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes xml markup from file into an ScreenMapGridArrayGrid object
    /// </summary>
    /// <param name="fileName">string xml file to load and deserialize</param>
    /// <param name="obj">Output ScreenMapGridArrayGrid object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool LoadFromFile(string fileName, out ScreenMapGridArrayGrid obj, out System.Exception exception)
    {
        exception = null;
        obj = default(ScreenMapGridArrayGrid);

        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool LoadFromFile(string fileName, out ScreenMapGridArrayGrid obj)
    {
        System.Exception exception = null;
        return LoadFromFile(fileName, out obj, out exception);
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <returns>deserialized xml string</returns>
    public static ScreenMapGridArrayGrid LoadFromFile(string fileName)
    {
        System.IO.FileStream file = null;
        System.IO.StreamReader sr = null;
        try
        {
            file = new System.IO.FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new System.IO.StreamReader(file);
            string xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();
            return Deserialize(xmlString);
        }
        finally
        {
            if ((file != null))
            {
                file.Dispose();
            }
            if ((sr != null))
            {
                sr.Dispose();
            }
        }
    }
}

[System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.6.79.0")]
[Serializable()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[XmlType(AnonymousType = true)]
public partial class ScreenMapGridArrayGridGridOption
{
    private bool _shouldSerializeCol;

    private bool _shouldSerializeRow;

    private bool _shouldSerializeDefault;

    private static XmlSerializer serializer;

    /// <summary>
    /// Initializes a new instance of the <see cref="ScreenMapGridArrayGridGridOption"/> class.
    /// </summary>
    public ScreenMapGridArrayGridGridOption()
    {
    }

    /// <summary>
    /// Gets or sets the option value.
    /// </summary>
    /// <value>
    /// The option value.
    /// </value>
    public string OptionValue { get; set; }

    /// <summary>
    /// Gets or sets the option action.
    /// </summary>
    /// <value>
    /// The option action.
    /// </value>
    public string OptionAction { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether this <see cref="ScreenMapGridArrayGridGridOption"/> is default.
    /// </summary>
    /// <value>
    ///   <c>true</c> if default; otherwise, <c>false</c>.
    /// </value>
    public bool Default { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [default specified].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [default specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool DefaultSpecified { get; set; }

    /// <summary>
    /// Gets or sets the row.
    /// </summary>
    /// <value>
    /// The row.
    /// </value>
    public int Row { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [row specified].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [row specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool RowSpecified { get; set; }

    /// <summary>
    /// Gets or sets the col.
    /// </summary>
    /// <value>
    /// The col.
    /// </value>
    public int Col { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether [col specified].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [col specified]; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore()]
    public bool ColSpecified { get; set; }

    /// <summary>
    /// Gets the serializer.
    /// </summary>
    /// <value>
    /// The serializer.
    /// </value>
    private static XmlSerializer Serializer
    {
        get
        {
            if ((serializer == null))
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(ScreenMapGridArrayGridGridOption));
            }

            return serializer;
        }
    }

    /// <summary>
    /// Test whether Default should be serialized
    /// </summary>
    public virtual bool ShouldSerializeDefault()
    {
        if (_shouldSerializeDefault)
        {
            return true;
        }

        return (Default != default(bool));
    }

    /// <summary>
    /// Test whether Row should be serialized
    /// </summary>
    public virtual bool ShouldSerializeRow()
    {
        if (_shouldSerializeRow)
        {
            return true;
        }

        return (Row != default(int));
    }

    /// <summary>
    /// Test whether Col should be serialized
    /// </summary>
    public virtual bool ShouldSerializeCol()
    {
        if (_shouldSerializeCol)
        {
            return true;
        }

        return (Col != default(int));
    }

    /// <summary>
    /// Test whether OptionValue should be serialized
    /// </summary>
    public virtual bool ShouldSerializeOptionValue()
    {
        return !string.IsNullOrEmpty(OptionValue);
    }

    /// <summary>
    /// Test whether OptionAction should be serialized
    /// </summary>
    public virtual bool ShouldSerializeOptionAction()
    {
        return !string.IsNullOrEmpty(OptionAction);
    }

    #region Serialize/Deserialize
    /// <summary>
    /// Serializes current ScreenMapGridArrayGridGridOption object into an XML string
    /// </summary>
    /// <returns>string XML value</returns>
    public virtual string Serialize()
    {
        string serializedData = string.Empty;

        try
        {
            using (StreamReader streamReader = new StreamReader(new MemoryStream()))
            {
                System.Xml.XmlWriterSettings xmlWriterSettings = new System.Xml.XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                XmlWriter xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                Serializer.Serialize(xmlWriter, this);
                streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                serializedData = streamReader.ReadToEnd();
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    /// <summary>
    /// Deserializes workflow markup into an ScreenMapGridArrayGridGridOption object
    /// </summary>
    /// <param name="input">string workflow markup to deserialize</param>
    /// <param name="obj">Output ScreenMapGridArrayGridGridOption object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool Deserialize(string input, out ScreenMapGridArrayGridGridOption obj, out System.Exception exception)
    {
        exception = null;
        obj = default(ScreenMapGridArrayGridGridOption);

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool Deserialize(string input, out ScreenMapGridArrayGridGridOption obj)
    {
        System.Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    /// <summary>
    /// Deserializes the specified input.
    /// </summary>
    /// <param name="input">The input.</param>
    /// <returns>deserialized input</returns>
    public static ScreenMapGridArrayGridGridOption Deserialize(string input)
    {
        System.IO.StringReader stringReader = null;

        try
        {
            stringReader = new System.IO.StringReader(input);
            return ((ScreenMapGridArrayGridGridOption)(Serializer.Deserialize(System.Xml.XmlReader.Create(stringReader))));
        }
        finally
        {
            if ((stringReader != null))
            {
                stringReader.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes the specified s.
    /// </summary>
    /// <param name="s">The s.</param>
    /// <returns>deserialized stream</returns>
    public static ScreenMapGridArrayGridGridOption Deserialize(System.IO.Stream s)
    {
        return ((ScreenMapGridArrayGridGridOption)(Serializer.Deserialize(s)));
    }
    #endregion

    /// <summary>
    /// Serializes current ScreenMapGridArrayGridGridOption object into file
    /// </summary>
    /// <param name="fileName">full path of outupt xml file</param>
    /// <param name="exception">output Exception value if failed</param>
    /// <returns>true if can serialize and save into file; otherwise, false</returns>
    public virtual bool SaveToFile(string fileName, out System.Exception exception)
    {
        exception = null;

        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (System.Exception e)
        {
            exception = e;
            return false;
        }
    }

    /// <summary>
    /// Saves to file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    public virtual void SaveToFile(string fileName)
    {
        System.IO.StreamWriter streamWriter = null;

        try
        {
            string xmlString = Serialize();
            System.IO.FileInfo xmlFile = new System.IO.FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if ((streamWriter != null))
            {
                streamWriter.Dispose();
            }
        }
    }

    /// <summary>
    /// Deserializes xml markup from file into an ScreenMapGridArrayGridGridOption object
    /// </summary>
    /// <param name="fileName">string xml file to load and deserialize</param>
    /// <param name="obj">Output ScreenMapGridArrayGridGridOption object</param>
    /// <param name="exception">output Exception value if deserialize failed</param>
    /// <returns>true if this Serializer can deserialize the object; otherwise, false</returns>
    public static bool LoadFromFile(string fileName, out ScreenMapGridArrayGridGridOption obj, out System.Exception exception)
    {
        exception = null;
        obj = default(ScreenMapGridArrayGridGridOption);

        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (System.Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <param name="obj">The object.</param>
    /// <returns>true or false</returns>
    public static bool LoadFromFile(string fileName, out ScreenMapGridArrayGridGridOption obj)
    {
        System.Exception exception = null;
        return LoadFromFile(fileName, out obj, out exception);
    }

    /// <summary>
    /// Loads from file.
    /// </summary>
    /// <param name="fileName">Name of the file.</param>
    /// <returns>deserialized xml string</returns>
    public static ScreenMapGridArrayGridGridOption LoadFromFile(string fileName)
    {
        System.IO.FileStream file = null;
        System.IO.StreamReader sr = null;
        try
        {
            file = new System.IO.FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new System.IO.StreamReader(file);
            string xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();
            return Deserialize(xmlString);
        }
        finally
        {
            if ((file != null))
            {
                file.Dispose();
            }
            if ((sr != null))
            {
                sr.Dispose();
            }
        }
    }
}