﻿namespace Jha.X3.Xpe.Screen;

public enum FieldShiftEditSpecification : byte
{
    // Accepts all characters, and the Shift keys are acknowledged.
    // 000 = Alpha shift = 0
    AlphaShift = 0,

    // Accepts only characters A--Z (both uppercase and lowercase plus the comma (,), period (.), dash (-), and blank characters).
    // Other (bits 5-7 = 001) characters cause operator errors. Some special characters for World Trade countries are also acceptable.
    // 001 = Alpha only = 1
    AlphaOnly = 1,

    // Accepts all characters.
    // 010 = Numeric shift = 2
    NumericShift = 2,

    // Field +, the Field -, or the Field Exit key to exit this field. If you use the Field - key to exit the field, the 5494
    // changes the zone of the low-order digit to X'D', unless it is one of the symbols (+,-, . or blank); in this case, an error results.
    // 011 = Numeric only = 3
    NumericOnly = 3,

    // This is the same as the alphabetic shift except that the keyboard is Katakana and is placed in Katakana shift.
    // 100 = Katakana shift = 4
    KatakanaShift = 4,

    // Allows digits 0-9 only from keyboard. Also allows the Dup key if the Dup enabled bit is in the FFW.
    // 101 = Digits only = 5
    DigitsOnly = 5,

    // Only a magnetic stripe reader or selector light pen can enter data into an I/O field without causing an error.
    // 110 = I/O-(feature input field) = 6
    IO = 6,

    // Allows only characters 0-9. An attempt to enter any other character causes an error. The signed numeric field must be at least 2 bytes
    // (bits 5-7 = 111) long. The last (rightmost) position is reserved for the signdisplay (- for negative and blank for positive).
    // You cannot type characters into this position. To exit this field, use either the Field +, the Field -, or the Field Exit key.
    // If you use the Field - key to exit this field, the 5494 right-adjusts the field and inserts a negative sign in the rightmost position.
    // If you use Field +, the 5494 right-adjusts the field and inserts a blank in the rightmost position. If the last character is negative,
    // the zone of the low-order digit is set to X'D' before the character is sent to the AS/400 system. If the last character is positive,
    // the low-order digit is not changed. The last sign position is not sent to the AS/400 system in response to either the
    // READ MDT or READ INPUT commands.
    // 111 = Signed numeric = 7
    SignedNumeric = 7
}