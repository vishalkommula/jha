using Xpe.Abstraction.Infrastructure;

namespace Xpe.Abstraction.Services;

public interface IISeriesConnectionInfoService
{
    ISeriesConnectionInfo ConnectionInfo { get; }

    void Initialize(ISeriesConnectionInfo connectionInfo);

    void Initialize(string userIdentifier);
}