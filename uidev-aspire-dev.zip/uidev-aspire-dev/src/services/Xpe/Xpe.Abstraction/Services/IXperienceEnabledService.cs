﻿using Xpe.Abstraction.Commands;
using Xpe.Abstraction.Model;

namespace Xpe.Abstraction.Services;

public delegate void UpdateViewEventHandler(object sender, UpdateViewEventArgs e);

public interface IXperienceEnabledService
{
    IInquiryResponse<object> SignOn(string userIdentifier, CurrentUserInfo currentUserInfo);
    
    IInquiryResponse<ScreenInfoRequest> SendCommand(ScreenInfoRequest screenInfoRequest);
    
    void OnScreenChanged(ScreenChangedCmd args, bool isStaticView);
    bool IsCustomScreen(ICurrentUserInfo userInfo, string screenId = null, string program = null, string screenAccountType = null, bool refresh = false);
    void EndSession(string userIdentifier, CurrentUserInfo currentUserInfo);
}