﻿using Xpe.Abstraction.Model;

namespace Xpe.Abstraction.Services;

public interface IJha5250
{
    void DisconnectFromServer();

    bool Initialize(string userIdentifier);

    void SendCommandToServer(ScreenInfoRequest screenInfoRequest);
}