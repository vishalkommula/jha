﻿using System.Xml.Serialization;

namespace Xpe.Abstraction.Model;

[XmlRoot(Namespace = "JackHenry.Banking")]
public class ToolbarSetting
{
    public string Key { get; set; }

    public string SerializationData { get; set; }
}