﻿using System.Xml;
using JackHenry.UID.Identity;

namespace Xpe.Abstraction.Model;

public interface ICurrentUserInfo
{
    PrvdInstInfoModel Institution { get; }

    BankingAlias Alias { get; }

    string InstitutionNumber { get; }

    string AliasName { get; }

    string SecurityGroup { get; }

    IWrappedImsSecurityToken SamlToken { get; }

    bool IsSAMLAuthRequired { get; }
}