﻿using System.Collections.Generic;

namespace Xpe.Abstraction.Model;

public class WriteToDisplayStructuredField
{
    public WriteToDisplayStructuredField(Queue<byte> snaRecord)
    {
        Length = snaRecord.Dequeue() * 256 + snaRecord.Dequeue();

        // The class is always the same.
        snaRecord.Dequeue();

        StructuredField = (StructuredField) snaRecord.Dequeue();


        // Remove the Minor Structures.
        for (var i = 4; i < Length; i++) snaRecord.Dequeue();
    }

    public int Length { get; }

    public StructuredField StructuredField { get; }

    public int WindowDepth { get; private set; }

    public int WindowWidth { get; private set; }
}