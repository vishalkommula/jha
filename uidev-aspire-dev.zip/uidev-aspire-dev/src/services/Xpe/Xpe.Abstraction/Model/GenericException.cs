﻿using System;
using System.Runtime.Serialization;

namespace Xpe.Abstraction.Model;

public class GenericException : Exception
{
    private string safePre;
    private string type;

    public GenericException()
        : this(string.Empty)
    {
    }

    public GenericException(string message)
        : this(null, message)
    {
    }

    public GenericException(string message, Exception innerException)
        : this(null, message, innerException)
    {
    }

    public GenericException(string xtraInfo, string message)
        : this(xtraInfo, message, null)
    {
    }

    public GenericException(string xtraInfo, string message, Exception innerException)
        : base(message, innerException)
    {
        ExceptionCreation = DateTime.Now;
        XtraInfo = xtraInfo;
    }

    public GenericException(SerializationInfo info, StreamingContext context)
        : base(info, context)
    {
        ExceptionCreation = DateTime.Now;
    }

    public string DetailedExceptionInformation => ExceptionUtil.ExceptionToString(this, true, ExtraJesInfo);

    public DateTime ExceptionCreation { get; }

    public string ExceptionType
    {
        get
        {
            if (string.IsNullOrEmpty(type))
            {
                type = GetType().ToString();
            }

            return type;
        }

        set => type = value;
    }

    public IXtraJesLogInfo ExtraJesInfo { get; set; }

    public string SafeExceptionInformation => Message;

    public string SafeExceptionPrefix
    {
        get
        {
            if (string.IsNullOrEmpty(safePre))
            {
                safePre = "An exception has occurred. ";
            }

            return safePre;
        }

        set => safePre = value;
    }

    public string SerializedExceptionString =>
        JhaSerializer.ToRawXmlString(
            new SerializedException
            {
                ExceptionTime = ExceptionCreation,
                ExceptionType = ExceptionType,
                ExtraInformation = XtraInfo,
                InnerException = InnerException != null ? InnerException.Message : string.Empty,
                SafeExceptionInformation = SafeExceptionInformation,
                Source = Source,
                Stack = StackTrace
            });

    public string XtraInfo { get; set; }

    public string Default(string input, string defaultValue)
    {
        return string.IsNullOrEmpty(input) ? defaultValue : input;
    }

    public override string ToString()
    {
        if (string.IsNullOrEmpty(XtraInfo))
        {
            return base.ToString();
        }

        return "Detailed Error Information: " + XtraInfo + " " + base.ToString();
    }
}