﻿// -----------------------------------------------------------------------
// <copyright file="ScreenInfoRequest.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

using System.Collections.Generic;

namespace Xpe.Abstraction.Model;

public class ScreenInfoRequest
{
    public ScreenInfoRequest(KeyPress key, CursorLocation cursorLocation)
    {
        Key = key;
        CursorLocation = cursorLocation;
    }

    public KeyPress Key { get; set; }

    public CursorLocation CursorLocation { get; set; }

    public List<ScreenField5250> ChangedFields { get; set; } = new();

    public string SocketCommand { get; set; }

    public static ScreenInfoRequest GetDummyCommand()
    {
        return new ScreenInfoRequest(new KeyPress(0, 0), new CursorLocation(0, 0));
    }
}