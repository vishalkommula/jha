﻿using System;

namespace Xpe.Abstraction.Model;

public interface IResponse<TPayload>
{
    string MessageId { get; set; }

    Exception Exception { get; set; }

    bool HasException { get; }

    TPayload Payload_Rs { get; set; }
}