namespace Xpe.Abstraction.Model;

public sealed class UIFunctionKey
{
    public const string AccountBalanceProtection = "AccountProtection";

    public const string AccountHistory = "AccountHistory";

    public const string AccountInquiry = "AccountInquiry";

    public const string AccountInquiryXPMessage = "AccountInquiryXPMessage";

    public const string AccountInquiryEmailLinkMessage = "AccountInquiryEmailLinkMessage";

    public const string GLAccountInquiry = "GLAccountInquiry";

    public const string AccountInquiryAccessTracking = "AccountInquiryAccessTracking";

    public const string AccountLookupReset = "Clear Search";

    public const string AccountMessages = "AccountMessages";

    public const string AccountRelationships = "AccountRelationships";

    public const string ACHWarehouse = "ACHWarehouse";

    public const string ActivityStatement = "ActivityStatement";

    public const string AddField = "AddField";

    public const string AdditionalAddressInquiry = "AdditionalAddressInquiry";

    public const string Alerts = "Alerts";

    public const string AlternatePaymentSchedule = "AlternatePaymentSchedule";

    public const string BalanceCalculations = "Balances";

    public const string Balances = "Balances";

    public const string BigRewards = "BigRewards";

    public const string BillInquiry = "BillInquiry";

    public const string CalcPrepaymentFee = "CalculatedPrepaymentFee";
    public const string CalcDebtProtFee = "CalculatedDebtProtectionFee";

    public const string CDAccountMaintenance = "CDAccountMaintenance";

    public const string CDAccountSummary = "CDAccountSummary";

    public const string CDPODBeneficiary = "CDPODBeneficiary";

    public const string CheckImageDetailViewer = "CheckImageDetailViewer";

    public const string CheckImageInquiry = "CheckImageInquiry";

    public const string CollateralTracking = "CollateralTracking";

    public const string CRAReporting = "CRAReporting";

    public const string CreditBureau2020 = "CreditBureau2020";

    public const string CustomerCreditLine = "CustomerCreditLine";

    public const string CustomerDDACombinedStatement = "CustomerDDACombinedStatement";

    public const string CustomerIdentification = "MultipleIds";

    public const string CustomerInquiry = "CustomerInquiry";

    public const string CustomerLitigation = "CustomerLitigation";

    public const string CustomerMaintenance = "CustomerMaintenance";

    public const string CustomerAllInOneMaintenance = "CustomerAllInOneMaintenance";

    public const string CustomerMarketingInfo = "CustomerMarketingInfo";

    public const string CustomerProfile = "CustomerProfile";

    public const string CustomerProfitability = "CustomerProfitability";

    public const string CustomerRelatedGroups = "CustomerRelatedCustomers";

    public const string CustomerTaxReporting = "CustomerTaxReporting";

    public const string CustomerWaivedIncome = "CustomerWaivedIncome";

    public const string DDAAATemporaryStatement = "DDAAATemporaryStatement";

    public const string DDAAccountAnalysisInquiry = "DDAAccountAnalysisInquiry";

    public const string DDAAccountLevelServiceCharge = "DDAAccountLevelServiceCharge";

    public const string DDAAccountMaintenance = "DDAAccountMaintenance";

    public const string DDAACHFilter = "DDAACHFilter";

    public const string DDAACHFilterInquiry = "DDAACHFilterInquiry";

    public const string DDAACHHistory = "DDAACHHistory";

    public const string DDAARPPositivePay = "DDAARPPositivePay";

    public const string DDABigRewards2 = "DDABigRewards2";

    public const string DDABounceProtection = "DDABounceProtection";

    public const string DDADepositFloat = "DDADepositFloat";

    public const string DDAEnhancedAccountAnalysisInquiry = "DDAEnhancedAccountAnalysisInquiry";

    public const string DDAEStatemnt = "DDAEStatemnt";

    public const string DDAFreshStart = "DDAFreshStart";

    public const string DDAHistoricalInformation = "DDAHistoricalInformation";

    public const string DDAImageCharges = "DDAImageCharges";

    public const string DDAPODBeneficiary = "DDAPODBeneficiary";

    public const string DDAPositivePay = "DDAPositivePay";

    public const string DDARewardsWarehouse = "DDARewardsWarehouse";

    public const string DDAServiceChargeCalculation = "DDAServiceChargeCalculation";

    public const string DDASmartEIP = "DDASmartEIP";

    public const string DDASplitTiered = "DDASplitTiered";

    public const string DDATemporaryStatement = "DDATemporaryStatement";

    public const string DDAWaivedIncome = "DDAWaivedIncome";

    public const string DisplayCallCenterAgentAdmin = "DisplayCallCenterAgentAdmin";

    public const string DisplayCallCenterCTI = "DisplayCallCenterCTI";

    public const string DisplayCallCenterReporting = "DisplayCallCenterReporting";

    public const string DocImgInq = "DocImgInq";

    public const string EnterAndUpdateWires = "EnterAndUpdateWires";

    public const string EnterprisePlugin = "EnterprisePlugin";

    public const string EscrowInsurance = "EscrowInsurance";

    public const string ExceptionItemHistory = "AccountExceptionItemHistory";

    public const string ExcessiveODOccasions = "ExcessiveODOccassions";

    public const string FASB = "FASB";

    public const string FieldDefs = "Field Editor";

    public const string FieldListing = "FieldListing";

    public const string GuarantorInquiry = "GuarantorInquiry";

    public const string GuarantorInquiryJWalk = "GuarantorInquiryJWalk";

    public const string Holds = "Holds";

    public const string ImageDetailViewer = "ImageDetailViewer";

    public const string ImageInquiry = "ImageInquriy";

    public const string ImageStatements = "ImageStatements";

    public const string ImportExportFields = "Import/Export Fields";

    public const string IRABeneficiaryInquiry = "IRABeneficiaryInquiry";

    public const string IRACreateStatement = "IRACreateStatement";

    public const string IRADistSequence = "IRADistSequence";

    public const string IRAInquiry = "IRAInquiry";

    public const string IRAMaintHistory = "IRAMaintHistory";

    public const string IRAStatementAddresses = "IRAStatementAddresses";

    public const string IRAUpdatePlans = "IRAUpdatePlans";

    public const string ITalkInquiry = "ITalkInquiry";

    public const string JwalkCustomerDocImgInq = "CustomerDocImgInq";

    public const string JwalkDDADocumentImageInquiry = "DDADocImgInq";

    public const string LineOfCredit = "LineOfCredit";

    public const string LineOfCreditAllocationTotals = "LineOfCreditAllocationTotals";

    public const string LineOfCreditCollateralTracking = "LineOfCreditCollateralTracking";

    public const string LineOfCreditGuidanceLines = "LineOfCreditGuidanceLines";

    public const string LineOfCreditJwalk = "LineOfCreditJwalk";

    public const string LineOfCreditLineReduction = "LineOfCreditLineReduction";

    public const string LineOfCreditLIP = "LineOfCreditLIP";

    public const string LineOfCreditMaintenance = "LineOfCreditMaintenance";

    public const string LineOfCreditOfficerList = "LineOfCreditOfficerList";

    public const string LoanAccountMaintenance = "LoanAccountMaintenance";

    public const string LoanAdditionalMaintenance = "LoanAdditionalMaintenance";

    public const string LoanAllAssociatedDemandAccounts = "LoanAllAssociatedDemandAccounts";

    public const string LoanAssumption = "LoanAssumption";

    public const string LoanHAMP = "LoanHAMP";

    public const string LoanBillInformation = "LoanBillInformation";

    public const string LoanBillFeeInformation = "LoanBillFeeInformation";

    public const string BondLetterTrackingInquiry = "BondLetterTrackingInquiry";

    public const string LoanConversionType = "LoanConversionType";

    public const string ConversionTypeInquiry = "ConversionTypeInquiry";

    public const string LoanCreditBureauFile = "LoanCreditBureauFile";

    public const string LoanDebtProtection = "LoanDebtProtection";

    public const string LoanExtension = "LoanExtension";

    public const string LoanFeeParticipantShare = "LoanFeeParticipantShare";

    public const string LoanInsuranceAccrual = "LoanInsuranceAccrual";

    public const string LoanLitigationAccount = "LoanLitigationAccount";

    public const string LoanMasterPlanLOC = "LoanMasterPlanLOC";

    public const string LoanParticipant = "LoanParticipant";

    public const string LoanPaymentChangeWarehouse = "LoanPaymentChangeWarehouse";

    public const string LoanPayoff = "LoanPayoff";

    public const string LoanPayoffJWalk = "LoanPayoffJWalk";

    public const string LoanRateSchedules = "LoanRateSchedules";

    public const string LoanRelatedAccounts = "LoanRelatedAccounts";

    public const string LoanRenewal = "LoanRenewal";

    public const string LoanReOccurringFee = "LoanReOccurringFee";

    public const string LoanRepaymentSchedule = "LoanRepaymentSchedule";

    public const string LoanServicing = "LoanServicing";

    public const string LoanSpecialInformationCodes = "SpecialInformationCodes";

    public const string LoanSpecialtyLending = "LoanSpecialtyLending";

    public const string LoanStopWarning = "LoanStopWarning";

    public const string LoanSupervisoryLTVPropertyTypes = "LoanSupervisoryLTVPropertyTypes";

    public const string LoanSyndicationAgent = "LoanSyndicationAgent";

    public const string LoanSyndicationMember = "LoanSyndicationMember";

    public const string LoanTieredRateInformation = "LoanTieredRateInformation";

    public const string LoanUnitPriced = "LoanUnitPriced";

    public const string Maintenance = "Maintenance";

    public const string ManualRateSchedules = "ManualRateSchedules";

    public const string MDACalculator = "MDACalculator";

    public const string MemoPost = "AccountMemoPost";

    public const string MovingIRAAccounts = "MovingIRAAccounts";

    public const string MultipleProtectionAccounts = "MultipleProtectionAccounts";

    public const string MutualSweeps = "MutualSweeps";

    public const string NetTellerAccountAccess = "NetTellerAccountAccess";

    public const string NetTellerAccountInquiry = "NetTellerInquiry";

    public const string NetTellerBillpay = "NetTellerBillpay";

    public const string NetTellerInternetBanking = "InternetBanking";

    public const string NetTellerTransferAccounts = "NetTellerXferInquiry";

    public const string NTAccessCmUser = "NTAccessCmUser";

    public const string NTBalanceTables = "NTBalanceTables";

    public const string NTMaintenanceHistory = "NTMaintenanceHistory";

    public const string NTViewSelAchComp = "NTViewSelAchComp";

    public const string NTAdditionalAchComp = "NTAdditionalAchComp";

    public const string OfficerList = "OfficerList";

    public const string PassportAssociatedAccounts = "PassportAssociatedAccounts";

    public const string PassportCardMaint = "PassportCardMaint";

    public const string PassportCardStatusChange = "PassportHotCard";

    public const string PassPortInquiry = "PassportInquiry";

    public const string PassportMaintHistory = "PassportMaintHistory";

    public const string PlanHistory = "PlanHistory";

    public const string PlanStatus = "PlanStatus";

    public const string PODBeneficiary = "PODBeneficiary";

    public const string PowerOn = "PowerOn";

    public const string PrintLoanHistory = "PrintLoanHistory";

    public const string ProductDefinitions = "ProductDefinitions";

    public const string RelationshipProfitabilityMgmt = "RelationshipProfitabilityMgmt";

    public const string RenewalMaintenanceInquiry = "RenewalMaintenanceInquiry";

    public const string RelBalanceHistory = "RelBalanceHistory";

    public const string RviMenuCustom = "RviMenuCustom";

    public const string CreditBureauScoreHistory = "CreditBureauScoreHistory";

    public const string SDAccessEntry = "SDAccessEntry";

    public const string SDAccountMaintenance = "SDAccountMaintenance";

    public const string SelectCustomer = "SelectCustomer";

    public const string ServiceFees = "ServiceFees";

    public const string ShadowChargeOff = "ShadowChargeOff";

    public const string ShadowLoan = "ShadowLoan";

    public const string SignatureCards = "SignatureCards";

    public const string SLTVCalculationInquiry = "SLTVCalculationInquiry";

    public const string StopsHolds = "StopsHolds";

    public const string SweepInquiry = "SweepInquiry";

    public const string TimeDepositAvailableInterest = "TimeDepositAvailableInterest";

    public const string TimeDepositMultiDeposit = "TimeDepositMultiDeposit";

    public const string TimeDepositPenaltyCalculation = "TimeDepositPenaltyCalculation";

    public const string TimeDepositRenewalType = "TimeDepositRenewalType";

    public const string TimeDepositRenewalTypeMaintenance = "TimeDepositRenewalTypeMaintenance";

    public const string TimeDepositWaivedPenalty = "TimeDepositWaivedPenalty";

    public const string TrancheLoanInquiry = "TrancheLoanInquiry";

    public const string TrancheLoanMaint = "TrancheLoanMaint";

    public const string Transfers = "Transfers";

    public const string ReestablishAFT = "ReestablishAFT";

    public const string TransactionEntry = "TransactionEntry";

    public const string TSetImageInquiry = "TSetImageInquiry";

    public const string ViewField = "ViewField";

    public const string WireInquiry = "WireInquiry";

    public const string Wires = "Wires";

    public const string ReoccurringFees = "ReoccurringFees";

    public const string WireInquiryJWalk = "WireInquiryJWalk";

    public const string GLEndOfMonthAccountInquiry = "GLEndOfMonthAccountInquiry";

    public const string GLConsolidatedAccountInquiry = "GLConsolidatedAccountInquiry";

    public const string GLProfile = "GLProfile";

    public const string GLMiniChartOfAccounts = "GLMiniChartOfAccounts";

    public const string IPay = "IPay";

    public const string SDAccessHistory = "SDAccessHistory";

    public const string AccountRelatedFunction = "AccountRelatedFunction";

    public const string NSFMultiTranMod = "NSFMultiTranMod";

    public const string YellowHammerDueDiligence = "YellowHammerDueDiligence";

    public const string GLAccountMaintenance = "GLAccountMaintenance";

    public const string Workflow = "Workflow";

    public const string IncorporateSoldLoans = "IncorporateSoldLoans";

    public const string ContactTracking = "ContactTracking";

    public const string IncrementInquiryTrackingCounter = "IncrementInquiryTrackingCounter";

    public const string LoanPastDue = "LoanPastDue";

    public const string CSPIEmailInquiry = "CSPIEmailInquiry";

    public const string AuroraImages = "AuroraImages";

    public const string MarquisInquiry = "MarquisInquiry";

    public const string LoanBankruptcyInquiry = "LoanBankruptcyInquiry";

    public const string PrepaymentPenaltyCalculation = "PrepaymentPenaltyCalculation";

    public const string FHLBNYMortgageInquiry = "FHLBNYMortgageInquiry";

    public const string FHLBNYMortgageMaintenance = "FHLBNYMortgageMaintenance";

    public const string InterestRewardsInquiry = "InterestRewardsInquiry";

    public const string RealVisionViewing = "RealVisionViewing";

    public const string CustomerServicesInquiry = "CustomerServicesInquiry";

    public const string TicklerInquiry = "TicklerInquiry";

    public const string TallyhoATMInquiry = "TallyhoATMInquiry";

    public const string GuidelineExceptionInquiry = "GuidelineExceptionInquiry";

    public const string CRM = "CRM";

    public const string R360BalanceInquiry = "R360BalanceInquiry";

    public const string UserFileInquiry = "UserFileInquiry";

    public const string AdditionalPropertyAddressFileMaintenance = "AdditionalPropertyAddressFileMaintenance";

    public const string BeneficialOwnerInquiry = "BeneficialOwnerInquiry";

    public const string DepositRewardsInquiry = "DepositRewardsInquiry";

    public const string HSAInquiry = "HSAInquiry";

    public const string UserFileMaintenance = "UserFileMaintenance";

    public const string SicCodeList = "SicCodeList";

    public const string TranCodeInternalDescription = "TranCodeInternalDescription";

    public const string CheckMailingAddressInquiry = "CheckMailingAddressInquiry";

    public const string LoanTransactionInput = "LoanTransactionInput";

    public const string CustomSolicitScreen = "CustomSolicitScreen";

    public const string CIBCustomFieldInquiry = "CIBCustomFieldInquiry";

    public const string XPEPendingProcess = "XPEPendingProcess";

    public const string XPEGeneralNavHoldScreen = "XPEGeneralNavHoldScreen";

    public const string CafeStyleRewards = "CafeStyleRewards";

    public const string ServiceFeesMaintenance = "ServiceFeesMaintenance";

    public const string PDFStatements = "PDFStatements";

    public const string MLLLending = "MLLLending";

    public const string JhaSafeguard = "JhaSafeguard";

    public const string LoanVantageInquiry = "LoanVantageInquiry";

    public const string EnterUpdateClosingTransactions = "EnterUpdateClosingTransactions";

    public const string MultiBrandInquiry = nameof(MultiBrandInquiry);

    public const string CustomerProfileAccounts = "CustomerProfileAccounts";

    public const string SupportUserAudit = "SupportUserAudit";

    public const string AtmDebitInquiry = "AtmDebitInquiry";

    public const string AverageBalancebyMonth = "AverageBalancebyMonth";

    public const string CardLimitsInquiry = "CardLimitsInquiry";

    public const string CardLimitsMaint = "CardLimitsMaint";

    public const string IntlWireTrnAdd = nameof(IntlWireTrnAdd);

    public const string TwelveMonthAverages = "TwelveMonthAverages";

    public const string ServiceChargeItemBucketCounts = "ServiceChargeItemBucketCounts";

    public const string ExpressEscrowSubAccountListing = "ExpressEscrowSubAccountListing";

    public const string OFACACHSuspectCertification = nameof(OFACACHSuspectCertification);

    public const string PriorDayOFACACHSuspectCertification = nameof(PriorDayOFACACHSuspectCertification);

    public const string GLAcctRecon = nameof(GLAcctRecon);

    public const string QuickAssist = nameof(QuickAssist);

    public const string GLAcctReconTrnSrch = nameof(GLAcctReconTrnSrch);

    public const string GLAcctReconTrnInq = nameof(GLAcctReconTrnInq);

    public const string GLAcctReconTrnAdd = nameof(GLAcctReconTrnAdd);

    public const string GLAcctReconFedAdd = nameof(GLAcctReconFedAdd);

    public const string GLAcctReconEnhTrnSrch = nameof(GLAcctReconEnhTrnSrch);

    public const string GLBatchTrnAdd = nameof(GLBatchTrnAdd);

    public const string GLBatchTrnAddTransactions = nameof(GLBatchTrnAddTransactions);

    public const string GLBatchSrch = nameof(GLBatchSrch);

    public const string GLBatchTrnSrch = nameof(GLBatchTrnSrch);

    public const string GLBatchTrnInq = nameof(GLBatchTrnInq);

    public const string GLBatchTrnSrchStandAlone = nameof(GLBatchTrnSrchStandAlone);

    public const string LoftBenefitsInquiry = nameof(LoftBenefitsInquiry);

    public const string InstDefFields = nameof(InstDefFields);

    public const string GLBatchTrnAddSingle = nameof(GLBatchTrnAddSingle);
    public const string GLBatchTrnAddSingleTransactions = nameof(GLBatchTrnAddSingleTransactions);

    public const string RateSwap = nameof(RateSwap);

    public const string GLReconParmSrch = nameof(GLReconParmSrch);

    public const string CIFRelParmSrch = nameof(CIFRelParmSrch);

    public const string CIFToCIFRelationships = nameof(CIFToCIFRelationships);
}