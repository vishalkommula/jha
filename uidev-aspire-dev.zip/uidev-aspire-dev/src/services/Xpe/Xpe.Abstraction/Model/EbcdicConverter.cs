﻿using System.Text;

namespace Xpe.Abstraction.Model;

public class EbcdicConverter : IEbcdicConverter
{
    public byte[] StringToEbcdic(string data)
    {
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        var encoding = Encoding.GetEncoding("IBM037");
        return encoding.GetBytes(data);
    }

    public string EbcdicToString(byte[] data)
    {
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        var encoding = Encoding.GetEncoding("IBM037");
        return encoding.GetString(data);
    }
}