﻿using System;
using System.Text;

namespace Xpe.Abstraction.Model;

[Serializable]
public class DeviceLookupItem : IDeviceLookupItem
{
    private string deviceName;
    private string deviceSequence;
    private string iSeriesPrinter;
    private string machineName;
    private string networkPrinter;
    private string printer;

    public DeviceLookupItem()
    {
    }

    public DeviceLookupItem(DeviceFileItem item)
    {
        MachineName = item.MachineName;
        DeviceName = item.DeviceName;
        DeviceSequence = item.DeviceSequence;
        ISeriesPrinter = item.ISeriesPrinter;
        NetworkPrinter = item.NetworkPrinter;
        PcPrinter = item.PCPrinter?.ToLower() != "default" ? item.PCPrinter : string.Empty;
    }

    public string MachineName
    {
        get => machineName;
        set => machineName = value;
    }

    public string DeviceName
    {
        get => deviceName;
        set => deviceName = value;
    }

    public string DeviceSequence
    {
        get => deviceSequence;
        set => deviceSequence = value;
    }

    public string ISeriesPrinter
    {
        get => iSeriesPrinter;
        set => iSeriesPrinter = value;
    }

    public string NetworkPrinter
    {
        get => networkPrinter;
        set => networkPrinter = value;
    }

    public string PcPrinter
    {
        get => printer;
        set => printer = value;
    }

    public bool IsEmpty =>
        string.IsNullOrEmpty(MachineName) &&
        string.IsNullOrEmpty(DeviceName) &&
        string.IsNullOrEmpty(DeviceSequence) &&
        string.IsNullOrEmpty(ISeriesPrinter) &&
        string.IsNullOrEmpty(NetworkPrinter) &&
        string.IsNullOrEmpty(PcPrinter);

    public string GetConnectionParameters()
    {
        var connectionString = new StringBuilder();

        if (!string.IsNullOrEmpty(DeviceName))
        {
            connectionString.Append($@"/gdevn={DeviceName}");
        }
        else
        {
            return connectionString.ToString();
        }

        if (!string.IsNullOrEmpty(DeviceSequence))
        {
            connectionString.Append($@" /gdevns={DeviceSequence}");
        }

        if (!string.IsNullOrEmpty(ISeriesPrinter))
        {
            connectionString.Append($@" /gdefp={ISeriesPrinter}");
        }

        if (!string.IsNullOrEmpty(NetworkPrinter))
        {
            connectionString.Append($@" /gemut5250ap={NetworkPrinter}");
        }

        if (!string.IsNullOrEmpty(PcPrinter))
        {
            connectionString.Append($@" /PCPrinter={PcPrinter}");
        }

        return connectionString.ToString();
    }
}