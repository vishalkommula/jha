﻿using JackHenry.JHAContractTypes;

namespace Xpe.Abstraction.Model;

public class IAdapterModel : IIAdapter
{
    public IAdapterModel(
        string iadapterInstitutionId,
        bool isSSL,
        string key,
        int port,
        string server,
        bool reqSAMLAuth)
    {
        IAdapterInstitutionId = iadapterInstitutionId;
        IsSSL = isSSL;
        Key = key;
        Port = port;
        Server = server;
        RequireSAMLAuth = reqSAMLAuth;
    }

    public bool RequireSAMLAuth { get; }

    public string HeaderVersion => "2008.1";

    public string IAdapterInstitutionId { get; }

    public bool IsSSL { get; }

    public string Key { get; }

    public int Port { get; }

    public string Server { get; set; }
}