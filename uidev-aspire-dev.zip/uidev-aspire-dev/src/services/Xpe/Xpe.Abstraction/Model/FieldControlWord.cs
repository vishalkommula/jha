﻿using System;
using Xpe.Abstraction.Enums;

namespace Xpe.Abstraction.Model;

[Serializable]
public class FieldControlWord
{
    public ushort RawData { get; set; }

    public FieldControlWordType Type { get; set; }

    public byte Data { get; set; }
}