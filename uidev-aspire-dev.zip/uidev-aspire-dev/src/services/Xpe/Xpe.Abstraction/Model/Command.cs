﻿namespace Xpe.Abstraction.Model;

public enum Command : byte
{
    ClearUnit = 0x40, // 16 - WP
    ClearUnitAlternate = 0x20, // 32 - WP
    ClearFormatTable = 0x50, // 80 - WP
    WriteToDisplay = 0x11, // 17
    WriteErrorCode = 0x21, // 33 - WP
    WriteErrorCodeToWindow = 0x22, // 34 - WP
    ReadInputFields = 0x42, // 66
    ReadMDTFields = 0x52, // 82
    ReadMDTAlternate = 0x82, // 130
    ReadScreen = 0x62, // 98 - WP
    ReadScreenWithExtendedAttributes = 0x64, // 100 - WP
    ReadScreenToPrint = 0x66, // 102
    ReadScreenToPrintWithExtendedAttributes = 0x68, // 104
    ReadScreenToPrintWithGridlines = 0x6A, // 106
    ReadScreenToPrintWithExtendedAttributesAndGridlines = 0x6C, // 108
    ReadImmediate = 0x72, // 114
    ReadModifiedImmediateAlternate = 0x83, // 131
    SaveScreen = 0x02, // 2 - WP
    SavePartialScreen = 0x03, // 3
    RestoreScreen = 0x12, // 18 - WP
    RestorePartialScreen = 0x13, // 19
    Roll = 0x23, // 35
    WriteStructuredField = 0xF3, // 243 - WP
    WriteSingleStructuredField = 0xF4, // 244
    CopyToPrinter = 0x16 // 22 - WP
}