﻿// -----------------------------------------------------------------------
// <copyright file="IFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

using System;
using System.ComponentModel;

namespace Xpe.Abstraction.Model;

public interface IFieldItem
{
    bool IsItemDisplayed { get; }

    bool IsFocused { get; }

    string FieldID { get; }
}