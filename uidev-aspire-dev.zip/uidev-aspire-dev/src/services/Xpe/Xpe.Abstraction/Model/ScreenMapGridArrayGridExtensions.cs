﻿using Xpe.Abstraction.Extensions;

namespace Xpe.Abstraction.Model;

using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public static class ScreenMapGridArrayGridExtensions
{
    public static UnfoldKeyData GetUnFoldKeyData(this ScreenMapGridArrayGrid grid)
    {
        UnfoldKeyData data = new UnfoldKeyData();

        if (!string.IsNullOrWhiteSpace(grid.GridUnfoldKey))
        {
            string funcRegex = "^F([0-2][0-9]|[1-9])";
            string key = Regex.Match(grid.GridUnfoldKey, funcRegex, RegexOptions.IgnoreCase).Value;

            if (!string.IsNullOrWhiteSpace(key) && grid.GridUnfoldKey.Trim() != key)
            {
                string expression = grid.GridUnfoldKey.Replace(key, string.Empty).Trim();

                var value = Regex.Match(expression, @"^({).*:.*(})$", RegexOptions.IgnoreCase).Value;

                if (!string.IsNullOrEmpty(value))
                {
                    data.StateExpression = value;
                }
            }

            if (!string.IsNullOrEmpty(key))
            {
                data.Key = key.ToUpper().Replace("F0", "F");
            }
        }

        return data;
    }

    public static bool IsGridConvertToNVPGrid(this ScreenMapGridArrayGrid grid, List<ScreenField5250> inputFields)
    {
        if (!grid.IsDynamicGrid && grid.GridFields != null && grid.GridFields.Any() && inputFields != null)
        {
            ScreenField screenField = grid.GridFields.FirstOrDefault();

            if (screenField != null)
            {
                List<ScreenField5250> gridInputFields = inputFields.Where(f => grid.GridFields.Any(s => s.Col == f.Col) && f.Row >= screenField.Row && f.Row < (screenField.Row + grid.GridPageSize)).ToList();

                if (gridInputFields != null && gridInputFields.Any())
                {
                    ScreenField defaultOptionField = grid.GridFields.FirstOrDefault(f => f.OptionField);

                    if (defaultOptionField == null)
                    {
                        return true;
                    }
                    else
                    {
                        List<ScreenField5250> gridOptionFields = gridInputFields.Where(f => f.Col == defaultOptionField.Col).ToList();

                        if (gridOptionFields != null && gridInputFields.Count > gridOptionFields.Count)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }
        }

        return false;
    }
}
