﻿// -----------------------------------------------------------------------
// <copyright file="StringExtensions.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2013 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace Xpe.Abstraction.Model;

public static class StringExtensions
{
    public static bool IsCaseInsensativeTrimmedEqual(this string s, string value)
    {
        if (s == null && value == null)
        {
            return true;
        }

        if (s == null || value == null)
        {
            return false;
        }

        return string.Compare(s.Trim(), value.Trim(), true) == 0;
    }
}