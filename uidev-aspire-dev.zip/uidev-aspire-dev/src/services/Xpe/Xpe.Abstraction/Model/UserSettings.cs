using System.Xml.Serialization;

namespace Xpe.Abstraction.Model;

[XmlRoot(Namespace = "JackHenry.Banking")]
public class UserSettings
{
}