﻿namespace Xpe.Abstraction.Model;

public class InputField
{
    public InputField(ScreenField5250 screenField)
    {
        this.ScreenField = screenField;

        if (!string.IsNullOrWhiteSpace(this.ScreenField.Data))
        {
            this.ScreenField.Data = this.ScreenField.Data.TrimEnd();
        }
    }

    public ScreenField5250 ScreenField { get; }

    public string FieldValue
    {
        get
        {
            if (this.ScreenField.FieldFormatWord != null && this.ScreenField.FieldFormatWord.Monocase)
            {
                return this.ScreenField.Data.ToUpper();
            }
            else
            {
                return this.ScreenField.Data;
            }
        }

        set
        {
            if (this.ScreenField.Data != value)
            {
                this.ScreenField.Data = value;
            }
        }
    }
}