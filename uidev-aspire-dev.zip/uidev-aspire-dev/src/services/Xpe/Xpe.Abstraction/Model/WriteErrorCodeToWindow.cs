﻿using System.Collections.Generic;
using Xpe.Abstraction.Enums;

namespace Xpe.Abstraction.Model;

public class WriteErrorCodeToWindow
{
    public WriteErrorCodeToWindow(Queue<byte> snaRecord, IEbcdicConverter ebcdicConversion)
    {
        StartColumn = snaRecord.Dequeue();
        EndColumn = snaRecord.Dequeue();
        Attribute = (FieldAttribute) snaRecord.Dequeue();
        ErrorData = string.Empty;

        while (
            ErrorData.Length < Length &&
            (FieldAttribute) snaRecord.Peek() != FieldAttribute.NonDisplay27 &&
            (FieldAttribute) snaRecord.Peek() != FieldAttribute.NonDisplay27 &&
            (FieldAttribute) snaRecord.Peek() != FieldAttribute.NonDisplay27 &&
            (FieldAttribute) snaRecord.Peek() != FieldAttribute.NonDisplay27)
            ErrorData = $"{ErrorData}{ebcdicConversion.EbcdicToString(snaRecord.Dequeue())}";
    }

    public int StartColumn { get; }

    public int EndColumn { get; }

    public int Length => EndColumn - StartColumn;

    public FieldAttribute Attribute { get; }

    public string ErrorData { get; }
}