﻿using System;
using Xpe.Abstraction.Enums;

namespace Xpe.Abstraction.Model;

[Serializable]
public class FieldFormatWord
{
    public ushort RawBits { get; set; }

    // (bit 2) Entries are not allowed in this field. If the workstation operator tries to enter something into this field, an error results.
    // 0 = This is not a bypass field
    // 1 = This is a bypass field

    public bool Bypass { get; set; }

    // (bit 3) The 5494 repeats X'1C' from the cursor position to the end of the field when the workstation operator presses the Dup key;
    // this displays on the workscreen as an overstruck asterisk.
    // 0 = Duplication or Field Mark is not allowed in this ¦
    // 1 = Duplication or Field Mark is allowed in this field

    public bool DupOrFieldMarkEnable { get; set; }

    // (bit 4)
    // 0 = This field has not been modified
    // 1 = This field has been modified

    public bool ModifiedDataTag { get; set; }

    // (bits 5-7)
    // 000 = Alpha shift
    // 001 = Alpha only
    // 010 = Numeric shift
    // 011 = Numeric only
    // 100 = Katakana shift
    // 101 = Digits only
    // 110 = I/O-(feature input field)
    // 111 = Signed numeric

    public FieldShiftEditSpecification FieldShiftEditSpecification { get; set; }

    // (bit 8) The contents of all fields, including the modified READ MDT fields, are sent to the AS/400 system. The operator begins
    // by pressing one of the field exit keys or by entering the last character in last
    // 0 = No auto enter
    // 1 = Auto enter when field is exited

    public bool AutoEnter { get; set; }

    // (bit 9) Requires the workstation operator to exit the field with a nondata key. When the operator has entered the last character,
    // the cursor remains under the character and blinks, indicating that a Field Exit key is required.
    // 0 = Field Exit key is not required
    // 1 = Field Exit key is required

    public bool FieldExitRequired { get; set; }

    // (bit 10) Regardless of the shift state, the keyboard enters only the uppercase characters A-Z in the field.
    // 0 = Accept lower case letters
    // 1 = Translate operator keyed letters to uppercase

    public bool Monocase { get; set; }

    // (bit 11) Reserved

    // (bit 12) Requires the workstation operator to enter something in the file before the 5494 allows the Enter key to be active. The 5494
    // recognizes the state of these fields by checking the MDT bit for the field. If the workstation operator tries to bypass the field using a
    // Field +, Field -, or Field Exit key, an error occurs.
    // 0 = Not mandatory enter field
    // 1 = Mandatory enter field

    public bool MandatoryEnter { get; set; }

    // (bits 13-15) Fills all leftmost unoccupied positions of a field with the specified character; characters are right-adjust and spaces
    // are blank-filled or zero-filled. The operator must specify this as either blank or 0. The fill character appears on the workstation screen.
    // 000 = No adjust specified
    // 010 = Reserved
    // 011 = Reserved
    // 100 = Reserved
    // 101 = Right adjust, zero fill
    // 110 = Right adjust, blank fill
    // 111 = Mandatory fill

    public MandatoryFill RightAdjustMandatoryFill { get; set; }
}