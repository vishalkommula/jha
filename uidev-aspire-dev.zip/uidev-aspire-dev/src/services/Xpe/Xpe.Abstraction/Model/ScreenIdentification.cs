﻿using System.Collections.Generic;

namespace Xpe.Abstraction.Model;

public class ScreenIdentification
{
    public const string JumpScreen = "JHAJUMPFM-XPJUMPOPT";
    public const string TimeTrackJumpScreen = "PRJUMPFM-XPJUMPOPT";
    public const string MiscJumpScreen = "JHAJUMPFM-MISCSF";
    public const string SignonScreen = "QDUI132-USRRCD";
    public const string DisplayMessagesScreen = "QDDSPEXT-HEADER-SCREEN1-INFFMT";
    public const string AccountPrompt = "JHSLCTFM-PROMPT";
    public const string GLAccountPrompt = "GL5000FM-SF01";
    public const string CustomerAccountPrompt = "CF5000FM-PROMPT";
    public const string NettellerAccountPrompt = "HB9000FM-SF00";
    public const string MultipleAccountPrompt = "JHINQRFM-MENU";
    public const string DemandDepositsInquiry = "DD5000FM-DDINQ1";
    public const string CustomerInquiry = "CF5000FM-SFLC-SFLOPT";
    public const string GeneralLedgerInquiry = "GL5000FM-SF02";
    public const string NonJHAInquiry = "JH5100FM-DISPLY";
    public const string PlanInquiry = "CD5100FM-SFLBC-SFLOPB";
    public const string SafeBoxInquiry = "SD5000FM-SDINQ1";
    public const string TimeDepositInquiry = "CD5000FM-CDINQ1";
    public const string LoanInquiry1 = "LN5000FM-LNINQ1";
    public const string LoanInquiry2 = "LN5000FM-LNINQ1C";
    public const string LoanAdditionalPrompt = "LN5070-PROMPT";
    public const string LoanPayoff = "LN5050FM-SFLLC-SFLL-SFLOPT";
    public const string NettellerInquiry = "HB9000FM-SF02";
    public const string CreditLineInquiry = "LN5150FM-SFLLC-SFOPT2";
    public const string CreditLinePrompt = "LN5150FM-SF01";
    public const string PlanAccountPrompt = "CD5105FM-PROMPT";
    public const string OfferingInquiry1 = "LNS120FM-SFLXO-SFLXC-SFLOPX";
    public const string OfferingInquiry2 = "LNA120FM-SFLBC-SFLOPTB";
    public const string WorkMessagesScreen = "QDDSPMSG-WKSDISP";
    public const string ProgrammersMenu = "JHDSPFFM-SFLDC-SFLD-SFLOF";
    public const string ReverseJumpScreen = "XPJUMPFM-XPJUMPRQST";
    public const string CustomerIdMaintenance = "CFMLIDFM-SFLIC-SFLI-SFLOPT";
    public const string PendingProcess = "PROCESSFM-PROCESS";
    public const string GLAccountRecon = "GLR550FM-SFLAC-SFLA-SFLOPT";
    public const string GLTransactionEntry = "GL0200FM-SFLAC-SFLA-SFLAF";
    public const string GLBatchTotalsByDate = "GL0200FM-SFLAC2-SFLA2-SFLAF";
    public const string GLTransactionEntryPrompt = "GL0200FM-PROMPT";
    public const string NonPostedItems = "EP0600FM-EP0600BC-EP0600BS-EP0600BF";
    public const string NonPostedItemsResolved = "EP0600FM-EP0600BC-EP0600BS-EP0600D3-EP0600BF";
    public const string ACHSuspectCertification = "CF7700FM-SFLSELC-SFLSEL-SFLSELO";
    public const string PriorDayACHSuspectCertification = "CF7700FM-SFLSELC-SFLSEL-SFLSELO1";
    public const string WindowsCommandScreen = "JHXPECMDFM-XPECMD";
    public const string ImageViewerScreen = "JHXPEIMGFM-IMAGEINFC-IMAGEINF";
    public const string GLTransactionUpdate = "GL0255FM-SFLAC-SFLA-SFLAF";
    public const string GLTransactionUpdatePrompt = "GL0255FM-SF01";
    public const string AlertsBypass = "JH5250FM-SFLMC-SFLM-SFLOPT";
    public const string ImageSearchParmScreen = "JHXPEIMGFM-PROMPT";
    public const string CrossAppTrnAddScreen = "CF2220SFM-UPLWND";
    public const string CrossAppTrnAddScreen2 = "CF2220ASFM-UPLWND";
    public const string DisplayProgramMessages = "QDDSPEXT-HEADER-SCREEN1-INQFMT";
    public const string ChangePasswordScreen = "QMNDDCGP-REC2";
    public const string ChangePasswordScreen2 = "QMNDDCGP-CPMSGC-CPMSG-REC2-CPMSG";
    public const string ChangePasswordScreen3 = "QMNDDCGP-REC1";
    public const string ChangePasswordScreen4 = "QMNDDCGP-CPMSGC-CPMSG-REC1-CPMSG";
    public const string ARPProcessIncoming = "AR1000PT-ERROR";
    public const string ARPProcessIncoming2 = "AR1000PT-AR1010RUN";
    public const string ARPProcessIncoming3 = "AR1000PT-AR1010CANC";
    public const string ARPProcessIncoming4 = "AR1000PT-AR2000RUN";
    public const string ARPProcessIncoming5 = "AR1000PT-AR2000CANC";
    public const string ARPProcessIncoming6 = "AR1000PT-AR1040RUN";
    public const string ARPProcessIncoming7 = "AR1000PT-AR1040CANC";
    public const string ARPProcessIncoming8 = "AR1000PT-AR1030RUN";
    public const string ARPProcessIncoming9 = "AR1000PT-AR1030CANC";

    public static readonly List<string> InquiryScreens = new()
    {
        DemandDepositsInquiry,
        LoanInquiry1,
        LoanInquiry2,
        TimeDepositInquiry,
        NonJHAInquiry,
        CustomerInquiry,
        GeneralLedgerInquiry,
        PlanInquiry,
        NettellerInquiry,
        CreditLineInquiry
    };

    public static readonly List<string> IBMLibraries = new()
    {
        "QSYS",
        "QQRYLIB",
        "QPDA",
        "QSQL"
    };

    public static readonly List<string> GeneralNavHoldScreens = new()
    {
        GLTransactionEntry,
        GLBatchTotalsByDate,
        GLTransactionEntryPrompt,
        GLTransactionUpdate,
        GLTransactionUpdatePrompt,
        CustomerIdMaintenance,
        ARPProcessIncoming,
        ARPProcessIncoming2,
        ARPProcessIncoming3,
        ARPProcessIncoming4,
        ARPProcessIncoming5,
        ARPProcessIncoming6,
        ARPProcessIncoming7,
        ARPProcessIncoming8,
        ARPProcessIncoming9
    };

    public static readonly List<string> StaticLayoutScreens = new()
    {
        NonPostedItems,
        NonPostedItemsResolved,
        ACHSuspectCertification
    };

    public static readonly List<string> AllowedMappedIBMScreens = new()
    {
        DisplayProgramMessages,
        ChangePasswordScreen,
        ChangePasswordScreen2,
        ChangePasswordScreen3,
        ChangePasswordScreen4
    };
}