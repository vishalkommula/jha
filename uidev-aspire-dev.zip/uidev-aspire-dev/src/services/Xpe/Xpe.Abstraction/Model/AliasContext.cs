﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security;
using System.Text;
using System.Xml.Serialization;
using Xpe.Abstraction.Extensions;

namespace Xpe.Abstraction.Model;

[Serializable]
public class AliasContext
{
    private const string SecretKeyText = "SecretKey=";
    private const string AdapterText = "iAdapter=";
    private Dictionary<string, SecureString> aliasContexts;

    private string originalContext;

    public AliasContext()
    {
        DoInitialSetup();
    }

    public AliasContext(string context)
        : this()
    {
        if (string.IsNullOrEmpty(context))
        {
            Debug.Assert(false, "you are not configured.");
            throw new Exception("Please check your alias information - you could be configured incorrectly.");
        }

        SetContextValues(context);
    }

    public string IAdapter
    {
        get => GetContextValue(AdapterText);

        set => SetContextValue(AdapterText, value);
    }

    public string SecretKey
    {
        get => GetContextValue(SecretKeyText);

        set => SetContextValue(SecretKeyText, value);
    }

    [XmlIgnore]
    public string StrippediAdapter
    {
        get => string.IsNullOrEmpty(IAdapter)
            ? string.Empty
            : IAdapter.Replace(AdapterText, string.Empty)
                .Replace(";", string.Empty);

        set
        {
            if (string.IsNullOrEmpty(value))
            {
                return;
            }

            IAdapter = Stripped(value);
        }
    }

    public string GetFullContext()
    {
        var context = new StringBuilder();

        foreach (var item in aliasContexts.OrderBy(k => k.Key))
        {
            var value = item.Value?.GetDecryptedValue();
            if (!string.IsNullOrEmpty(value))
            {
                context.Append(item.Key).Append(value).Append(';');
            }
        }

        return context.ToString();
    }

    private string GetContextValue(string key)
    {
        return aliasContexts.ContainsKey(key)
            ? aliasContexts[key]?.GetDecryptedValue()
            : string.Empty;
    }

    private void SetContextValue(string key, string value)
    {
        if (aliasContexts.ContainsKey(key))
        {
            aliasContexts[key] = value?.ToSecureString();
        }
        else
        {
            aliasContexts.Add(key, value?.ToSecureString());
        }
    }

    private void DoInitialSetup()
    {
        aliasContexts ??= new Dictionary<string, SecureString>();

        SecretKey = string.Empty;
        IAdapter = string.Empty;
    }

    private void SetContextValues(string context)
    {
        if (string.IsNullOrEmpty(context))
        {
            return;
        }

        originalContext = context;

        var key = string.Empty;
        var value = string.Empty;

        var seperatedContexts = context.Split(';').ToList();

        seperatedContexts.ForEach(sc =>
        {
            if (string.IsNullOrEmpty(sc))
            {
                return;
            }

            var index = sc.LastIndexOf('=');
            key = sc.Substring(0, index + 1);
            value = sc.Substring(index + 1, sc.Length - (index + 1));

            if (!aliasContexts.ContainsKey(key))
            {
                aliasContexts.Add(key, value?.ToSecureString());
            }
            else
            {
                aliasContexts[key] = value?.ToSecureString();
            }
        });
    }

    private static string Stripped(string input)
    {
        if (string.IsNullOrEmpty(input))
        {
            return string.Empty;
        }


        var lio = input.LastIndexOf(';');

        if (lio > -1)
        {
            input = input[..lio];
        }

        var iAdapter = input.ToLower()
            .Replace(AdapterText, string.Empty)
            .Replace(";", string.Empty);

        return $"iAdapter={iAdapter};";
    }
}