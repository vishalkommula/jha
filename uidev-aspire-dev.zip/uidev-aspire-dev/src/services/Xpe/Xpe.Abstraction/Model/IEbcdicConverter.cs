﻿namespace Xpe.Abstraction.Model;

public interface IEbcdicConverter
{
    byte[] StringToEbcdic(string data);

    string EbcdicToString(params byte[] data);
}