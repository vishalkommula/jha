﻿using System.Collections.Generic;
using System.Linq;
using Xpe.Abstraction.Extensions;

namespace Xpe.Abstraction.Model;

public class ScreenInfoResponse
{
    public ScreenInfoResponse()
    {
    }

    public ScreenInfoResponse(string screenLibrary, string screenId, string screenMapData, int screenHeight,
        int screenWidth, CursorLocation cursorLocation, int errorRow, List<ScreenField5250> inputFields,
        List<ScreenField5250> outputFields)
    {
        ScreenLibrary = screenLibrary;
        ScreenId = screenId;
        ScreenMapData = screenMapData;
        ScreenHeight = screenHeight;
        ScreenWidth = screenWidth;
        CursorLocation = cursorLocation;
        ErrorRow = errorRow;

        ScreenMap = JhaSerializer.XmlDeserialize<ScreenMap>(screenMapData);

        if (inputFields != null)
        {
            InputFields = inputFields.Where(f => f.IsVisible()).ToList();
        }

        if (outputFields != null)
        {
            OutputFields = new List<ScreenField5250>();
            NonDisplayOutputFields = new List<ScreenField5250>();

            foreach (var f in outputFields)
            {
                if (f.IsVisible())
                {
                    OutputFields.Add(f);
                }
                else
                {
                    NonDisplayOutputFields.Add(f);
                }
            }
        }
    }

    public int ErrorRow { get; set; }

    public string ScreenId { get; }

    public string ScreenLibrary { get; }

    public ScreenMap ScreenMap { get; }

    public string ScreenMapData { get; }

    public int ScreenHeight { get; }

    public int ScreenWidth { get; }

    public CursorLocation CursorLocation { get; }

    public List<ScreenField5250> InputFields { get; }

    public List<ScreenField5250> OutputFields { get; }

    public List<ScreenField5250> NonDisplayOutputFields { get; }

    public IEnumerable<ScreenField5250> AllFields => InputFields.Union(OutputFields);

    public IEnumerable<ScreenField5250> AllFieldsIncludingNonDisplay =>
        InputFields.Union(OutputFields).Union(NonDisplayOutputFields);

    public bool IsIBMScreen
    {
        get
        {
            return !string.IsNullOrEmpty(ScreenLibrary) &&
                   ScreenIdentification.IBMLibraries
                       .Any(i => ScreenLibrary.ToLower().StartsWith(i.ToLower())) &&
                   ScreenIdentification.AllowedMappedIBMScreens.All(i => i != ScreenId);
        }
    }
}