﻿using System;

namespace Xpe.Abstraction.Model;

public class JHA5250Exception : Exception
{
    public JHA5250Exception(string message, string errorDetails)
        : base(message)
    {
        ErrorDetails = errorDetails;
    }

    public string ErrorDetails { get; }

    public override string Message => $"{base.Message} Error details: '{ErrorDetails}'";
}