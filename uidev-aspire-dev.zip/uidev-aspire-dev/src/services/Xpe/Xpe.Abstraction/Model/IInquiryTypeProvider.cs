﻿namespace Xpe.Abstraction.Model;

using System.Collections.Generic;

using JackHenry.JHAContractTypes;

public interface IInquiryTypeProvider
{
    string AllDDA
    {
        get;
    }

    string AllLoans
    {
        get;
    }

    string AllTypes
    {
        get;
    }

    string ATMCode
    {
        get;
    }

    string CDCode
    {
        get;
    }

    string AllCreditLines
    {
        get;
    }

    string CheckingCode
    {
        get;
    }

    string ClubCode
    {
        get;
    }

    string CustomerType
    {
        get;
    }

    string CustomerCIFIdCode
    {
        get;
    }

    string CustomerTaxIdCode
    {
        get;
    }

    string GLCode
    {
        get;
    }

    string InternetCode
    {
        get;
    }

    string IRACode
    {
        get;
    }

    string LineOfCreditCode
    {
        get;
    }

    string LetterOfCreditCode
    {
        get;
    }

    string LIPCode
    {
        get;
    }

    string LoanCode
    {
        get;
    }

    string LoanTypeOCode
    {
        get;
    }

    string NonJhaType
    {
        get;
    }

    string SafeDepositCode
    {
        get;
    }

    string SavingsCode
    {
        get;
    }

    string ShareHolderCode
    {
        get;
    }

    string VendorCode
    {
        get;
    }

    string CreditCardCode
    {
        get;
    }

    string[] NonJhaTypes
    {
        get;
    }

    Dictionary<string, string> AppCodes
    {
        get;
    }

    bool IsAcctMod(IAccount account);

    bool IsAllCreditLines(IAccount ia);

    bool IsAllDDA(IAccount ia);

    bool IsAllLoan(IAccount ia);

    bool IsAllNonJha(IAccount ia);

    bool IsAllTypes(IAccount ia);

    bool IsATM(IAccount ia);

    bool IsCD(IAccount ia);

    bool IsCDIRA(IAccount ia);

    bool IsChecking(IAccount ia);

    bool IsClub(IAccount ia);

    bool IsCustomer(IAccount ia);

    bool IsDDA(IAccount ia);

    bool IsEFTCardMod(IAccount account);

    bool IsGL(IAccount ia);

    bool IsInternet(IAccount ia);

    bool IsIRA(IAccount ia);

    bool IsJwalkInquiry(IAccount ia);

    bool IsITalkInquiry(IAccount ia);

    bool IsLetterOfCredit(IAccount ia);

    bool IsLineOfCredit(IAccount ia);

    bool IsLIP(IAccount ia);

    bool IsLOCMod(IAccount account);

    bool IsMiscellaneous(IAccount ia);

    bool IsMiscellaneousForCustomerHeader(IAccount ia);

    bool IsNonJha(IAccount ia);

    bool IsRevolvingLoan(IAccount ia);

    bool IsCustMod(IAccount account);

    bool IsSafeDeposit(IAccount ia);

    bool IsSavings(IAccount ia);

    bool IsShareholder(IAccount ia);

    bool IsStandardLoan(IAccount ia);

    bool IsUnoccupiedOrUnavailableSafeDeposit(IAccount ia);

    bool IsVendor(IAccount ia);

    bool IsCreditCard(IAccount ia);

    string GetBigAccountType(IAccount ia);

    string[] GetLikeTypeCodes(IAccount ia);

    bool IsLoan(IAccount ia);

    bool IsNonJha(AccountId_CType accountId);

    bool IsParticipationLoan(IAccount account);

    bool IsShadowLoan(IAccount account);

    bool IsSpecialityLendingLoan(IAccount account);

    bool IsMPLOCLoan(IAccount account);

    bool IsUnitPricedLoan(IAccount account);

    bool IsDealerLoan(IAccount account);

    string GetAccountTypeByCompAcctType(string compAcctType);

    bool IsCustomerBeneficialOwner(IAccount account);

    bool IsAccountAppCode(string appCode);

    string GetAccountAppCode(string acctType);

    decimal GetAcctSrchRecBalance(AcctSrchRec_CType acct);

    string FormatAcctSrchRecBalance(AcctSrchRec_CType acct, decimal balance);
}