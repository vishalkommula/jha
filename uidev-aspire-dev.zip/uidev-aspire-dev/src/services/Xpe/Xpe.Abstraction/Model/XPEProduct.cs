﻿namespace Xpe.Abstraction.Model;

public class XpeProduct
{
    public const string TimeTrack = "TimeTrack";
    public const string PassPort = "PassPort";
    public const string NetTellerSL = "NetTellerSL";
    public const string NetTellerCF = "NetTellerCF";
}