// -----------------------------------------------------------------------
// <copyright file="ScreenData.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using JackHenry.JHAContractTypes;

namespace Xpe.Abstraction.Model;

public class ScreenData : IScreenData
{
    public ScreenData()
    {
    }

    public ScreenData(ScreenInfoResponse screenInfo, bool isMappedScreen = false, bool isStaticLayoutScreen = false)
    {
        ScreenInfo = screenInfo;
        IsMappedScreen = isMappedScreen;
        IsStaticLayoutScreen = isStaticLayoutScreen;
    }

    public string RecordDetailHeader { get; set; } = "Fields";

    public ScreenField5250 CurrentPage { get; set; }

    public ScreenField5250 TotalPages { get; set; }

    // public List<IToolbarItem> GridToolbarItems { get; set; } = new List<IToolbarItem>();

    public bool HasMappingFileProcessingException => MappingFileProcessingException != null;

    public Exception MappingFileProcessingException { get; set; }

    public List<string> ErrorMessages { get; set; } = new();

    public List<string> WarningMessages { get; set; } = new();

    public List<string> InfoMessages { get; set; } = new();

    public List<ScreenMapActionKey> ScreenActionItems { get; set; }

    public ScreenInfoResponse ScreenInfo { get; set; }

    public bool IsStaticLayoutScreen { get; }

    public bool IsMappedScreen { get; set; }

    public string ScreenName { get; set; }

    //public List<IFieldItem> FieldItems { get; set; }

    //public XpeSentencePanel SentencePanel { get; set; }

    //public List<XpeGridData> Grids { get; set; }

    //public List<NVPGridData> NVPGrids { get; set; }

    public string BannerMessageType { get; set; } = MessageFilterType.None;

    //public IAccount CurrentAccount { get; set; }

    public List<string> MultipleAccountTypes { get; set; }

    public string PageMode { get; set; }

    public BannerMessageFields BannerFields { get; set; }

    public bool IsPingMessage { get; set; }

    public string NVPImageViewerOverrideKey { get; set; }

    public string NVPImageViewerIdRRCCC { get; set; }

    public string GridImageViewerOverrideOption { get; set; }

    public int GridImageIdColumn { get; set; }

    public List<ToolbarItem> ToolbarItems { get; set; }
}