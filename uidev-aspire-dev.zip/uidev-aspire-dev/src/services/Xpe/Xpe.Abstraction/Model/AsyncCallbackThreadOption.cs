﻿namespace Xpe.Abstraction.Model;

public enum AsyncCallbackThreadOption
{
    CurrentThread,
    BackgroundThread,
    UIThread
}