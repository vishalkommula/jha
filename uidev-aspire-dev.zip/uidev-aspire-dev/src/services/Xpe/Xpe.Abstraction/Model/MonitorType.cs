﻿namespace Xpe.Abstraction.Model;

public enum MonitorType
{
    CommandData,
    MappedFields,
    ISeriesFields,
    ScreenMap
}