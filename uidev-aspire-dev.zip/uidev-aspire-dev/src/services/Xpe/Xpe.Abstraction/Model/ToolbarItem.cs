﻿using Xpe.Abstraction.Enums;

namespace Xpe.Abstraction.Model;

public class ToolbarItem
{
    public ToolbarItem()
    {
    }

    public ToolbarItem(string key, string text, string iconType, bool isVisible, bool autoHide, string tooltip)
    {
        this.Key = key;
        this.Text = text;
        this.IsVisible = isVisible;
        this.AutoHide = autoHide;
        this.ToolTip = tooltip;
        this.IconType = iconType;
    }

    public string Text { get; set; }
    public string Key { get; set; }
    public bool IsVisible { get; set; }
    public bool AutoHide { get; set; }
    public string IconType { get; set; }
    public string ToolTip { get; set; }
}
