﻿using System.Text;
using Xpe.Abstraction.Enums;

namespace Xpe.Abstraction.Model;

public class PrinterFileItem
{
    public PrinterFileItem()
    {
    }

    public PrinterFileItem(string key)
    {
        Key = key;
    }

    public string Key { get; set; }

    public string PrinterDevice { get; set; }

    public string PrinterType { get; set; } = "*NONE";

    public string PrinterMsgQueueName { get; set; }

    public string PrinterMsgQueueLib { get; set; } = "*LIBL";

    public string PrinterFont { get; set; } = "11";

    public IBMPPRSRC1AND2 PrinterPaperSource1 { get; set; } = IBMPPRSRC1AND2.LETTER;

    public IBMPPRSRC1AND2 PrinterPaperSource2 { get; set; } = IBMPPRSRC1AND2.NONE;

    public IBMENVELOPE PrinterEnvelope { get; set; } = IBMENVELOPE.NONE;

    public bool IsEmpty => string.IsNullOrEmpty(Key);

    public string GetHash()
    {
        var sb = new StringBuilder();
        sb.Append(string.IsNullOrWhiteSpace(Key) ? "NOVAL" : Key.GetHashCode().ToString());
        sb.Append(string.IsNullOrWhiteSpace(PrinterDevice) ? "NOVAL" : PrinterDevice.GetHashCode().ToString());
        sb.Append(string.IsNullOrWhiteSpace(PrinterType) ? "NOVAL" : PrinterType.GetHashCode().ToString());
        sb.Append(string.IsNullOrWhiteSpace(PrinterMsgQueueName)
            ? "NOVAL"
            : PrinterMsgQueueName.GetHashCode().ToString());
        sb.Append(string.IsNullOrWhiteSpace(PrinterMsgQueueLib)
            ? "NOVAL"
            : PrinterMsgQueueLib.GetHashCode().ToString());
        sb.Append(string.IsNullOrWhiteSpace(PrinterFont) ? "NOVAL" : PrinterFont.GetHashCode().ToString());
        sb.Append(PrinterPaperSource1.GetHashCode());
        sb.Append(PrinterPaperSource2.GetHashCode());
        sb.Append(PrinterEnvelope.GetHashCode());
        return sb.ToString();
    }
}