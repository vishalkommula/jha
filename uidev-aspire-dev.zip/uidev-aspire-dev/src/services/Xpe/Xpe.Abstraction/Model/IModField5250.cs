﻿// -----------------------------------------------------------------------
// <copyright file="IModField5250.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

using System.Collections.Generic;

namespace Xpe.Abstraction.Model;

public interface IModField5250
{
    void AddToChangedList(List<ScreenField5250> changedList, bool includeModifiedDataTagField);
}