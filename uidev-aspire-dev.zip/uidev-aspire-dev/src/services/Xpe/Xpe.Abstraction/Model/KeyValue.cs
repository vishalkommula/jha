﻿using System.Xml.Serialization;

namespace Xpe.Abstraction.Model;

[XmlRoot(Namespace = "JackHenry.Banking")]
public class KeyValue
{
    public KeyValue()
    {
    }

    public KeyValue(object key, object value)
    {
        Key = key;
        Value = value;
    }

    public object Key { get; set; }

    [XmlIgnore] public string StringKey => Key != null ? Key.ToString() : string.Empty;

    [XmlIgnore] public string StringValue => Value != null ? Value.ToString() : string.Empty;

    public object Value { get; set; }
}