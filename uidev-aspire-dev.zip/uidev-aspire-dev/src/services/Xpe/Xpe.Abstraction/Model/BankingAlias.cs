﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Security;
using System.Xml.Serialization;
using JackHenry.Enterprise.BusinessObjects.Jes;
using Xpe.Abstraction.Extensions;

namespace Xpe.Abstraction.Model;

[XmlRoot(Namespace = "JackHenry.Banking")]
public class BankingAlias : AliasClaimRec_CType
{
    private AliasContext context;
    private bool isDirty;
    private bool isPasswordExpired;
    private SecureString pwd;

    public BankingAlias()
    {
    }

    public BankingAlias(string userName, string desc, bool isDefault, string iAdapter)
        : this()
    {
        Alias ??= new Alias_Type();

        Alias = new Alias_Type
        {
            Value = userName
        };

        AliasDesc = new Desc_Type
        {
            Value = desc
        };

        IsDefault = isDefault;

        AliasContext = new AliasContext_Type
        {
            Value = iAdapter
        };

        Context = new AliasContext(iAdapter);

        IsDirty = true;
    }

    [XmlIgnore]
    public AliasContext Context
    {
        get => context ??= InitializeContext();

        private set
        {
            AliasContext ??= new AliasContext_Type();
            AliasContext.Value = value != null ? value.IAdapter : string.Empty;
            context = value;

            RaisePropertyChanged(nameof(Context));
        }
    }

    [XmlElement(Order = 19)]
    public string Description
    {
        get => AliasDesc == null ? string.Empty : AliasDesc.Value;

        set
        {
            AliasDesc ??= new Desc_Type();
            if (AliasDesc.Value == value)
            {
                return;
            }

            AliasDesc.Value = value;

            RaisePropertyChanged(nameof(Description));
        }
    }

    [XmlIgnore]
    public string DisplayName => string.Format(IsPasswordExpired
            ? "{0} (On {1}, Password Expired)"
            : "{0} (On {1})",
        string.IsNullOrEmpty(Name)
            ? "*Unknown Alias"
            : Name,
        string.IsNullOrEmpty(IAdapter)
            ? "*Unknown Server"
            : IAdapter);

    [XmlIgnore]
    // ReSharper disable once InconsistentNaming
    public string IAdapter
    {
        get => Context.StrippediAdapter;

        set
        {
            Context.StrippediAdapter = value;
            AliasContext ??= new AliasContext_Type();
            AliasContext.Value = value != null ? Context.IAdapter : string.Empty;

            RaisePropertyChanged(nameof(IAdapter));
            RaisePropertyChanged(nameof(DisplayName));
        }
    }

    [XmlElement(Order = 18)]
    public bool IsDefault
    {
        get
        {
            if (AliasDft == null)
            {
                return false;
            }

            return bool.TryParse(AliasDft.Value, out var ret) && ret;
        }

        set
        {
            AliasDft ??= new AliasDft_Type();
            AliasDft.Value = value.ToString();

            RaisePropertyChanged(nameof(IsDefault));
        }
    }

    [XmlIgnore]
    public bool IsDirty
    {
        get => isDirty;

        private set
        {
            if (isDirty == value)
            {
                return;
            }

            isDirty = value;
            RaisePropertyChanged(nameof(IsDirty));
        }
    }

    [XmlElement(Order = 17)]
    public string Name
    {
        get => Alias == null ? string.Empty : Alias.Value;

        set
        {
            Alias ??= new Alias_Type();
            Alias.Value = value;

            RaisePropertyChanged(nameof(Name));
            RaisePropertyChanged(nameof(DisplayName));
        }
    }

    [XmlIgnore]
    public string Password
    {
        get => pwd?.GetDecryptedValue();

        set => pwd = value?.ToSecureString();
    }

    [XmlIgnore]
    public bool IsPasswordExpired
    {
        get => isPasswordExpired;

        set
        {
            isPasswordExpired = value;

            RaisePropertyChanged(nameof(IsPasswordExpired));
            RaisePropertyChanged(nameof(DisplayName));
        }
    }

    [XmlElement(Order = 20)]
    public string Product
    {
        get => AppliesToApp == null ? string.Empty : AppliesToApp.Value;

        set
        {
            AppliesToApp ??= new AppliesToApp_Type();

            if (AppliesToApp.Value == value)
            {
                return;
            }

            AppliesToApp.Value = value;
            RaisePropertyChanged(nameof(Product));
        }
    }

    public int CompareTo(object obj)
    {
        if (obj is not BankingAlias other)
        {
            return 1;
        }

        if (Name == other.Name && AliasContext == other.AliasContext && Product == other.Product)
        {
            return 0;
        }

        return string.Compare(Name, other.Name, StringComparison.Ordinal);
    }

    public event PropertyChangedEventHandler PropertyChanged;

    public AliasContext InitializeContext()
    {
        AliasContext ??= new AliasContext_Type();

        return string.IsNullOrEmpty(AliasContext.Value)
            ? new AliasContext()
            : new AliasContext(AliasContext.Value);
    }

    protected override void RaisePropertyChanged(string propertyName)
    {
        var handler = PropertyChanged;

        if (handler == null)
        {
            return;
        }

        if (propertyName != "IsDirty")
        {
            IsDirty = true;
        }

        var e = new PropertyChangedEventArgs(propertyName);
        handler(this, e);
    }

    public class AliasEqualityComparer : IEqualityComparer<BankingAlias>
    {
        public bool Equals(BankingAlias s1, BankingAlias s2)
        {
            if (s1 == null && s2 == null)
            {
                return true;
            }

            return s1?.CompareTo(s2) == 0;
        }

        public int GetHashCode(BankingAlias alias)
        {
            var strHash = alias.AliasContext + alias.Product + alias.Name;

            return strHash.GetHashCode();
        }
    }
}