namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Services;

using Microsoft.Extensions.Logging;

using System;
using System.Linq;
using System.Windows;
using System.Windows.Input;

public class CrossAppTrnAddCF2220FMScreenHandler : BaseScreenHandler
{
    public CrossAppTrnAddCF2220FMScreenHandler(ILogger<CrossAppTrnAddCF2220FMScreenHandler> logger)
    {
        Logger = logger;
    }

    private ILogger<CrossAppTrnAddCF2220FMScreenHandler> Logger { get; }

    public override bool IsScreenHandler(string screenId) => screenId == ScreenIdentification.CrossAppTrnAddScreen || screenId == ScreenIdentification.CrossAppTrnAddScreen2;

    public override HandleScreenInfoRequest HandleScreen(
        ScreenData screenData,
        ICurrentUserInfo userInfo,
        string sessionId,
        Action<ScreenInfoRequest> defferredCommand,
        IXperienceEnabledService xperienceEnabledService)
    {
        try
        {
            //TODO: Implement
            //if (!screenData.IsPingMessage)
            //{
            //    this.EventService.Publish<ShowCrossAppTranImportDialogEvent, ShowCrossAppTranUploadDialogEventArgs>(
            //        new ShowCrossAppTranUploadDialogEventArgs(
            //            windowIdentifier,
            //            maxRecords: this.GetFieldAsInt(screenData, "13043", "max records"),
            //            batchNumber: this.GetFieldAsInt(screenData, "11043", "batch number"),
            //            transactionSet: this.GetFieldAsInt(screenData, "12043", "transaction set"),
            //            callback: r => this.HandleSpreadsheetUploadResult(r, windowIdentifier, screenData.ScreenInfo.CursorLocation)));
            //}

            return null;
        }
        catch (Exception ex)
        {
            Logger.LogError("Error opening the spreadsheet upload dialog", ex);

            return new HandleScreenInfoRequest(new KeyPress(Key.F3, Key.None), screenData.ScreenInfo.CursorLocation);
        }
    }

    private int GetFieldAsInt(ScreenData screenData, string rrccc, string fieldName)
    {
        try
        {
            return int.Parse(screenData.ScreenInfo.AllFieldsIncludingNonDisplay.Single(f => f.RRCCC == rrccc).Data);
        }
        catch (Exception ex)
        {
            throw new Exception($"Couldn't get a value for {fieldName}", ex);
        }
    }

    //private void HandleSpreadsheetUploadResult(ProgressEnum result, string windowIdentifier, CursorLocation cursorLocation)
    //{
    //    Key resultKey;

    //    if (result == ProgressEnum.Canceled)
    //    {
    //        resultKey = Key.F12;
    //    }
    //    else if (result == ProgressEnum.Failed)
    //    {
    //        resultKey = Key.F3;
    //    }
    //    else
    //    {
    //        resultKey = Key.Enter;
    //    }

    //    this.EventService.Publish<SendXPEScreenCommandEvent, SendXPEScreenCommandEventArgs>(
    //        new SendXPEScreenCommandEventArgs(
    //            windowIdentifier,
    //            new ScreenInfoRequest(
    //                new KeyPress(resultKey, Key.None),
    //                cursorLocation)));
    //}
}
