﻿namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using System;
using System.Threading.Tasks;

public abstract class BaseScreenHandler : IScreenHandler
{
    public virtual bool IsScreenHandler(string screenId) => false;

    public virtual bool IsInputObserver(string screenId) => false;

    public virtual bool IsMenuOptionObserver() => false;

    public virtual HandleScreenInfoRequest HandleScreen(
        ScreenData screenData,
        ICurrentUserInfo userInfo,
        string sessionId,
        Action<ScreenInfoRequest> defferredCommand,
        IXperienceEnabledService xperienceEnabledService) => null;

    public virtual Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo) => null;

    public virtual bool MenuOptionSelected(XpeNavigationEventArgs args) => false;
}