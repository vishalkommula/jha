﻿namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using System;
using System.Linq;
using System.Threading.Tasks;

public class DD0900FMScreenHandler : IScreenHandler
{
    public DD0900FMScreenHandler(/*IInquiryTypeProvider inquiryTypeProvider*/)
    {
        //this.InquiryTypeProvider = inquiryTypeProvider;
        this.ScreenId = "DD0900FM-SFLAC-SFLA-SFLAO";
        this.FieldRefId = "ACCTNO";
        this.RelatedFunction = UIFunctionKey.MemoPost;
        //this.AccountType = this.InquiryTypeProvider.AllDDA;
    }

    //private IInquiryTypeProvider InquiryTypeProvider { get; set; }

    private string RelatedFunction { get; set; }

    private string ScreenId { get; set; }

    private string FieldRefId { get; set; }

    private string AccountType { get; set; }

    public HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        HandleScreenInfoRequest rq = null;

        if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId))
        {
            if (screenData.ScreenInfo.ScreenMapData != null && screenData.ScreenInfo.AllFields != null)
            {
                try
                {
                    var screenMap = ScreenMap.Deserialize(screenData.ScreenInfo.ScreenMapData);

                    if (screenMap != null && screenMap.NamePairArray != null)
                    {
                        var field = screenMap.NamePairArray.FirstOrDefault(s => s.FieldRefId == this.FieldRefId);

                        if (field != null)
                        {
                            var value = screenData.ScreenInfo.AllFields.FirstOrDefault(f => f.Col == field.Col && f.Row == field.Row);

                            //TODO: Implement
                            //if (value != null && value.Data != null)
                            //{
                            //    IAccount account = new MiniAccount(value.Data.Trim(), this.AccountType);

                            //    AccountRequestedEventArgs args = new AccountRequestedEventArgs(account, null, true, this.RelatedFunction, null, windowIdentifier);
                            //    args.RelatedFunctionByPassUserSettingsForAutoStart = true;

                            //    this.EventService.Publish<AccountRequestedEvent, AccountRequestedEventArgs>(args);

                            //    rq = new HandleScreenInfoRequest(new KeyPress(Key.F12, Key.None), screenData.ScreenInfo.CursorLocation);
                            //}
                        }
                    }
                }
                catch
                {
                }
            }
        }

        return rq;
    }

    public bool IsInputObserver(string screenId)
    {
        return false;
    }

    public bool IsMenuOptionObserver()
    {
        return false;
    }

    public bool IsScreenHandler(string screenId)
    {
        return screenId == this.ScreenId;
    }

    public bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        return false;
    }

    public Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        return null;
    }
}
