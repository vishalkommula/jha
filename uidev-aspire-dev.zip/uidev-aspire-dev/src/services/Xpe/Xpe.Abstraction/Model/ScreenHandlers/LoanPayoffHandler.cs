﻿namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Navigation;

public class LoanPayoffHandler : AccountRelatedFunctionHandler
{
    private XpeNavigationEventArgs args;

    public LoanPayoffHandler() : base()
    {
        this.RelatedFunction = UIFunctionKey.LoanPayoff;
        this.ScreenId = "LN5050FM-SFLLC-SFLL-SFLOPT";
        this.PreviousScreenWhenHandled = true;
    }

    public override bool IsMenuOptionObserver()
    {
        return true;
    }

    public override bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        this.args = args;
        return false;
    }

    public override bool IsScreenHandler(string screenId)
    {
        if (this.ScreenId == screenId && this.args.FunctionKey != Key.None)
        {
            return false;
        }
        else
        {
            return base.IsScreenHandler(screenId);
        }
    }
}