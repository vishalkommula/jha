﻿using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Services;

namespace Xpe.Abstraction.Model.ScreenHandlers;

public class SD5000FMScreenHandler : AccountInquiryScreenHandler
{
    public SD5000FMScreenHandler(
        IUserService userService,
        IXperienceEnabledService xperienceEnabledService)
        : base(ScreenIdentification.SafeBoxInquiry, userService, xperienceEnabledService)
    {
    }

    public override bool IsScreenHandler(string screenId)
    {
        //// Don't handle the screen if we are going to a "related function" from the inquiry screen, ex. F17 for access history
        if (base.IsScreenHandler(screenId) && this.Args != null && this.Args.FunctionKey == Key.None)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
