﻿namespace Xpe.Abstraction.Model.ScreenHandlers;

public interface ICustomScreenHandlerMapping
{
    bool TryGetCustomScreenHandlerFromScreenId(string screenId, out string resolveGuid);
}