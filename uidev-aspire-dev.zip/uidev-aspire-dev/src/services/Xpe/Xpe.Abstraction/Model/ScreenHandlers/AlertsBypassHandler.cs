﻿namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using System;
using System.Collections.Generic;
using System.Threading.Tasks;

public class AlertsBypassHandler : IScreenHandler
{
    public AlertsBypassHandler()
    {
        this.MessagesScreenList = new List<string>() { "JH5250FM-SFLMC-SFLM-SFLOPT", "JH5250FM-SFLCMC-SFLCM-SFLOPC" };
        this.ValidProgramList = new List<string>() { "DD0900C", "LN0900C", "CD0900C", "LN5050C", "CD9020C" };
    }

    private List<string> MessagesScreenList { get; set; }

    private List<string> ValidProgramList { get; set; }

    private string CurrentMenuProgram { get; set; }

    public HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId))
        {
            return new HandleScreenInfoRequest(new KeyPress(Key.Enter, Key.None), screenData.ScreenInfo.CursorLocation);
        }

        return null;
    }

    public bool IsInputObserver(string screenId)
    {
        return false;
    }

    public bool IsMenuOptionObserver()
    {
        return true;
    }

    public bool IsScreenHandler(string screenId)
    {
        if (this.CurrentMenuProgram != null && this.MessagesScreenList.Contains(screenId))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        if (args.Program != null && this.ValidProgramList.Contains(args.Program))
        {
            this.CurrentMenuProgram = args.Program;
        }
        else
        {
            this.CurrentMenuProgram = null;
        }

        return false;
    }

    public Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        return null;
    }
}
