namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class BreakMessageScreenHandler : IScreenHandler
{
    public BreakMessageScreenHandler()
    {
        this.ScreenId = ScreenIdentification.WorkMessagesScreen;
    }

    private string ScreenId { get; set; }

    public virtual HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        HandleScreenInfoRequest screenInfoRequest = null;

        if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId))
        {
            if (screenData.ScreenInfo.AllFields?.Count() > 0)
            {
                bool isPingMessage = screenData.IsPingMessage;
                StringBuilder sb = new StringBuilder();

                foreach (ScreenField5250 field in screenData.ScreenInfo.AllFields)
                {
                    // Grab the message content so we can include it in the JhaNotification details
                    if (field.Row > 7 && field.Row < 21 && field.FieldSize > 1)
                    {
                        sb.AppendLine(field.Data);
                    }

                    // If we're coming from a Ping, F11 to remove the virtual terminal message.
                    if (field.Data.Contains("Connection to an IBM i host system is operational."))
                    {
                        isPingMessage = true;
                        screenInfoRequest = new HandleScreenInfoRequest(new KeyPress(Key.F11, Key.None), new CursorLocation(field.Row, field.Col));
                        this.LogToMonitor(string.Format("Sending F11 to remove a virtual terminal message at Row: {0} Column: {1}", field.Row.ToString(), field.Col.ToString()), MonitorType.CommandData, sessionId);
                        break;
                    }
                }

                string message = sb.ToString();

                // If we're not coming from a Ping and we have messages, we throw up a JhaNotification (to alert them if they are working in another Xperience tab)
                if (!isPingMessage && !string.IsNullOrEmpty(message) && !message.Contains("(No messages available)"))
                {
                    //this.EventService.Publish<JHANotificationEvent, JhaNotification>(new JhaNotification("Break Message Received", sb.ToString()));
                }
            }
        }

        return screenInfoRequest;
    }

    public bool IsInputObserver(string screenId)
    {
        return false;
    }

    public bool IsMenuOptionObserver()
    {
        return true;
    }

    public virtual bool IsScreenHandler(string screenId)
    {
        return this.ScreenId == screenId;
    }

    public bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        return false;
    }

    public Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        return null;
    }

    protected void LogToMonitor(string logText, MonitorType monitorType, string sessionId)
    {
        if (logText != null && !string.IsNullOrEmpty(sessionId))
        {
            //this.EventService.Publish<FusionHistoryEvent, FusionHistoryEventArgs>(
            //    new FusionHistoryEventArgs()
            //    {
            //        LogText = logText,
            //        MonitorType = monitorType,
            //        SessionId = sessionId
            //    });
        }
    }
}
