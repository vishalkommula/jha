﻿namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using System;
using System.Threading.Tasks;

public class PROCESSFMScreenHandler : IScreenHandler
{
    public PROCESSFMScreenHandler()
    {
        this.ScreenId = ScreenIdentification.PendingProcess;
    }

    public string ScreenId { get; set; }

    public HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId))
        {
            //TODO: Implement
            //this.NavigationAlertService.RegisterNavigationHold(UIFunctionKey.XPEPendingProcess, windowIdentifier, screenData.ScreenInfo.ScreenId, null);
        }

        return null;
    }

    public bool IsInputObserver(string screenId)
    {
        return false;
    }

    public bool IsMenuOptionObserver()
    {
        return false;
    }

    public bool IsScreenHandler(string screenId)
    {
        return screenId == this.ScreenId;
    }

    public bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        return false;
    }

    public Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        return null;
    }
}
