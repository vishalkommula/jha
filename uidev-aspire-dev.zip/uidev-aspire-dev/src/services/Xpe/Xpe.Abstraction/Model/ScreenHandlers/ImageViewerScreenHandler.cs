namespace Xpe.Abstraction.Model.ScreenHandlers;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JackHenry.JHAContractTypes;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using Microsoft.Extensions.Logging;

public class ImageViewerScreenHandler : IScreenHandler
{
    public ImageViewerScreenHandler(ILogger<ImageViewerScreenHandler> logger)
    {
        Logger = logger;
    }

    private ILogger<ImageViewerScreenHandler> Logger { get; }

    public HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> defferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId))
        {
            //TODO: Implement
            //try
            //{
            //    List<IImageItem> imageItems = new List<IImageItem>();

            //    foreach (ScreenField5250 imageIdField in screenData.ScreenInfo.AllFields.Where(f => f.Col == screenData.GridImageIdColumn && !string.IsNullOrEmpty(f.Data)))
            //    {
            //        imageItems.Add(new XPECheckImageModel(imageIdField.Data));
            //    }

            //    if (imageItems.Any())
            //    {
            //        IImageItem selectedImageItem = imageItems.FirstOrDefault();
            //        string uniqueId = string.Format("{0}_{1}", UIFunctionKey.ImageDetailViewer, selectedImageItem.ImgNum);
            //        InstitutionSettings institutionSettings = this.viewSettingsService.RetrieveInstitutionSetting<InstitutionSettings>(userInfo.InstitutionNumber, false, false)?.Payload_Rs;

            //        this.eventService.Publish<ShowImageViewerDialogEvent, ShowImageViewerDialogEventArgs>(
            //            new ShowImageViewerDialogEventArgs(uniqueId, windowIdentifier, null, selectedImageItem, null, imageItems, false, institutionSettings?.GetPersistedWsSettingsByType(WebServiceType.Statement)?.IsWebServiceEnabled == true));
            //    }
            //}
            //catch (Exception ex)
            //{
            //    this.loggingService.LogException("Opening image viewer", null, ex);
            //    DialogService.ShowErrorNotificationDialog(windowIdentifier, "Error opening image viewer.", ex.Message);
            //}

            ////Always return F12 command so Image Viewer screen is never visible to users.  It was a screen specifically created for XPE to grab an image Id and launch
            ////the image viewer.  The user needs to be taken back to their original screen prior to the Image Viewer screen loading.
            return new HandleScreenInfoRequest(new KeyPress(Key.F12, Key.None), screenData.ScreenInfo.CursorLocation);
        }

        return null;
    }

    public bool IsInputObserver(string screenId)
    {
        return false;
    }

    public bool IsMenuOptionObserver()
    {
        return false;
    }

    public bool IsScreenHandler(string screenId)
    {
        return screenId == ScreenIdentification.ImageViewerScreen;
    }

    public bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        return false;
    }

    public Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        return null;
    }
}
