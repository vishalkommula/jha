﻿namespace Xpe.Abstraction.Model.ScreenHandlers;

using System;
using System.Threading.Tasks;
using JackHenry.JHAContractTypes;

using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

public class BaseRelatedFunctionHandler : IRelatedFunctionScreenHandler
{
    public BaseRelatedFunctionHandler()
    {
    }

    public string ScreenId { get; set; }

    public string RelatedFunction { get; set; }

    public bool PreviousScreenWhenHandled { get; set; }

    //private ToolbarFunctionClickedEventArgs FunctionToolbarArgs { get; set; }

    public virtual IAccount GetAccountFromScreenField(ScreenData screenData)
    {
        ////must be overriden
        return null;
    }

    public virtual HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        HandleScreenInfoRequest rq = null;

        //TODO: Implement
        if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId))
        {
            //IAccount account = this.GetAccountFromScreenField(screenData);

            //if (account != null)
            //{
            //    bool functionOpened = false;

            //    if (this.FunctionToolbarArgs != null && this.FunctionService != null && this.FunctionToolbarArgs.Account.AcctId == account.AcctId && this.FunctionToolbarArgs.Account.AcctType == account.AcctType)
            //    {
            //        // if we are inquiring on same account inside a related function and it tries to link to another related function
            //        // we open the related function instead of opening a new C&I with that related function
            //        IFunction function = this.FunctionService.RetrieveFunction(this.RelatedFunction, account, userInfo);

            //        if (function != null)
            //        {
            //            this.FunctionToolbarArgs.Function = function;
            //            function.Command.Execute(this.FunctionToolbarArgs);
            //            functionOpened = true;
            //            function.Dispose();
            //        }
            //    }

            //    if (!functionOpened)
            //    {
            //        AccountRequestedEventArgs args = new AccountRequestedEventArgs(account, null, true, this.RelatedFunction, null, windowIdentifier);
            //        args.RelatedFunctionByPassUserSettingsForAutoStart = true;

            //        this.EventService.Publish<AccountRequestedEvent, AccountRequestedEventArgs>(args);
            //    }

            //    if (this.PreviousScreenWhenHandled)
            //    {
            //        rq = new HandleScreenInfoRequest(new KeyPress(Key.F12, Key.None), screenData.ScreenInfo.CursorLocation);
            //    }
            //}
        }

        return rq;
    }

    public virtual bool IsInputObserver(string screenId)
    {
        return false;
    }

    public virtual bool IsMenuOptionObserver()
    {
        return false;
    }

    public virtual bool IsScreenHandler(string screenId)
    {
        switch (screenId)
        {
            case "LN5250FM-SFLLC-SFLL-SFOPT2":
                this.RelatedFunction = UIFunctionKey.GuarantorInquiry;
                return true;
            case "LN5900FM-SFLAC-SFLA-SFLOPT":
                this.RelatedFunction = UIFunctionKey.LoanBillFeeInformation;
                return true;
            case "LN6850FM-SFLIC-SFLI-SFLOPI":
                this.RelatedFunction = UIFunctionKey.EscrowInsurance;
                return true;
            case "CD9065FM-SFLAC-SFLA-SFLAF":
                this.RelatedFunction = UIFunctionKey.PODBeneficiary;
                return true;
            case "DD9065FM-SFLAC-SFLA-SFLAF":
                this.RelatedFunction = UIFunctionKey.PODBeneficiary;
                return true;
        }

        return false;
    }

    public virtual bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        return false;
    }

    public virtual Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        return null;
    }
}