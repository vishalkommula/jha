namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using Microsoft.Extensions.Logging;

using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

public class GLReconGLR500CScreenHandler : IScreenHandler
{
    //// private readonly ILoggingService loggingService;
    private static readonly object objectLocker = new object();

    private Guid? informationDialogId;
    private int moreCount = 1;
    private bool processingExcelExport;
    private string screenId = ScreenIdentification.GLAccountRecon;

    public GLReconGLR500CScreenHandler(ILogger<GLReconGLR500CScreenHandler> logger)
    {
        Logger = logger;
    }

    public ILogger<GLReconGLR500CScreenHandler> Logger { get; }

    public HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> defferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        HandleScreenInfoRequest rq = null;

        //TODO: Implement
        //if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId))
        //{
        //    if (this.IsExportGridRequest)
        //    {
        //        if (this.ProcessingExportRequest)
        //        {
        //            //// keep track of how many times we do this to get more records for export
        //            //// so when it is done we can go back to the first screen export started on
        //            //// when they click the export button it's always going to try to get the next set of records
        //            this.moreCount++;

        //            if (this.CancelExportProcess)
        //            {
        //                //// if we canceled don't try and export the last screen grid data
        //                //// we do this because it could have canceled from previous call where it could not
        //                //// export the grid, so don't continue so it doesn't get in a loop trying to get more records

        //                if (File.Exists(this.GridExcelExportFilePath))
        //                {
        //                    //// lets delete the file that was created because they canceled the export
        //                    File.Delete(this.GridExcelExportFilePath);
        //                }

        //                //// set this to null so it won't open the file as they canceled the export
        //                this.GridExcelExportFilePath = null;
        //            }
        //            else
        //            {
        //                //// export current screen grid data and return request for more records when there are more records
        //                rq = this.ExportGridData(screenData, false);
        //            }
        //        }

        //        if (rq == null)
        //        {
        //            //// we have reached where we can't get more records or they canceled the export
        //            //// so we are done processing export of records
        //            this.ProcessingExportRequest = false;

        //            XpeGridData grid = this.GetGridData(screenData);

        //            //// we have moved through the screen so go back to previous
        //            //// until we get to the screen we started on
        //            if (this.moreCount > 0 && grid != null && grid.PreviousDataCommand != null)
        //            {
        //                this.moreCount--;
        //                rq = new ExportGridHandleScreenInfoRequest(grid.PreviousDataCommand, this.GridExportIndex, true);
        //            }
        //        }
        //    }

        //    if (rq == null)
        //    {
        //        this.CompleteExport(screenData);
        //    }
        //}
        //else
        //{
        //    //// we came to a screen that was not this screen, reset and clear everything to ensure this handler starts over
        //    this.Reset();
        //}

        return rq;
    }

    public bool IsInputObserver(string screenId)
    {
        return true;
    }

    public bool IsMenuOptionObserver()
    {
        return true;
    }

    public bool IsScreenHandler(string screenId)
    {
        return this.screenId == screenId;
    }

    public bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        return false;
    }

    public Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        //TODO: Implement
        //if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId) && screenInfoRq is ExportGridHandleScreenInfoRequest)
        //{
        //    //// this is called the first time a menu is observed and in this case we sent the ExportGridHandleScreenInfoRequest
        //    //// that's the only request type we care about handling for this handler
        //    ExportGridHandleScreenInfoRequest handleScreenInfoRequest = screenInfoRq as ExportGridHandleScreenInfoRequest;

        //    //// save the grid index for the grid we request to do an export on
        //    this.GridExportIndex = handleScreenInfoRequest.GridExportIndex;

        //    this.IsExportGridRequest = true;

        //    if (screenInfoRq.Key.Key == Key.PageDown || handleScreenInfoRequest.LastPage)
        //    {
        //        //// we are sending previous when we are on the last page so we are still processing
        //        //// ensure the request was for a page down, as we know this means we are getting more records
        //        //// and starting this process for export
        //        this.ProcessingExportRequest = true;
        //    }
        //    else
        //    {
        //        //// we are not processing more records for export so don't do any more exports
        //        //// currently I don't think this is being callsed but if it was
        //        //// we are probably navigating through previous records to go back to first screen
        //        //// if not and some other key then we still not going to want to continue exporting data
        //        this.ProcessingExportRequest = false;
        //    }

        //    //// export current screen data when excel export is called for the first time from the button
        //    //// when it gets more records it will be handled in the HandleScreen method
        //    this.ExportGridData(screenData, handleScreenInfoRequest.FirstTime);

        //    if (handleScreenInfoRequest.LastPage)
        //    {
        //        //// if this was the last page set this so it doesn't try and do the export of the same screen
        //        //// return true that we handled this request in this handler so don't send the data command on to the server
        //        this.CompleteExport(screenData);
        //        return Task.FromResult(true);
        //    }
        //}

        return Task.FromResult(false);
    }

    //private XpeGridData GetGridData(ScreenData screenData)
    //{
    //    XpeGridData grid = null;

    //    if (screenData.NVPGrids != null && screenData.NVPGrids.Any(i => i.Index == this.GridExportIndex))
    //    {
    //        grid = screenData.NVPGrids.First(i => i.Index == this.GridExportIndex);
    //    }
    //    else if (screenData.Grids != null && screenData.Grids.Any(i => i.Index == this.GridExportIndex))
    //    {
    //        grid = screenData.Grids.First(i => i.Index == this.GridExportIndex);
    //    }

    //    return grid;
    //}

    //private void Reset()
    //{
    //    this.IsExportGridRequest = false;
    //    this.moreCount = 0;
    //    this.ProcessingExportRequest = false;
    //    this.GridExportIndex = -1;
    //    this.GridExcelExportFilePath = null;
    //    this.CancelExportProcess = false;
    //}
}
