﻿namespace Xpe.Abstraction.Model.ScreenHandlers;

public interface IRelatedFunctionScreenHandler : IScreenHandler
{
   //IUIFunctionsService FunctionService { get; set; }

   //ToolbarFunctionClickedEventArgs FunctionToolbarArgs { get; set; }
}
