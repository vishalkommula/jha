﻿namespace Xpe.Abstraction.Model.ScreenHandlers;

using System.Collections.Generic;

/// <summary>
/// The CustomScreenHandlerMapping
/// </summary>
/// <remarks>
/// This model is registered by ABA and it contains a mapping dictionary for GUID identified models that are registered for the instititution.
/// This exists so that a single institution can have multiple custom screen handlers.
/// </remarks>
/// <example>
/// Foreach institution that wants custom screen handlers, you will:
///     1. Create a CustomScreenHandlerMapping class in the custom location which will inherit this object.
///     2. Add ScreenId-to-Guid mappings via the ScreenHandlerMapping dictionary by adding them in the constructor of your custom inheriting class.
/// Foreach screen the client wants a custom screen handler for, you will:
///     1. Create the Custom Screen Handler in the custom location which may or may not override an existing screen handler. (it must apply the IScreenHandler and ICustomScreenHandler interfaces, either by inheritance or otherwise)
///     2. In the Institution's overriden CustomScreenHandlerMapping class's constructor, simply add a {screenid, guid} entry to the dictionary.
///     3. Register your Custom Screen Handler with the ICustomScreenHandler interface and set the name to the GUID that was added to the mapping dictionary (its registered in the custom module.
///     Now, when the screenid is hit, the customscreenmapping will be resolved and the GUID pulled from the dictionary to be uniquely resolved and used.
/// </example>
public class CustomScreenHandlerMapping : ICustomScreenHandlerMapping
{
    private Dictionary<string, string> ScreenHandlerMapping { get; } = new()
    {
        //// format:  { "XPE-Screen-Name", "The Constant variable name for this screen's GUID variable above" }
        //// example: { "IP5000-Display", SCREEN_NAME }
    };

    public bool TryGetCustomScreenHandlerFromScreenId(string screenId, out string resolveGuid)
    {
        return this.ScreenHandlerMapping.TryGetValue(screenId, out resolveGuid);
    }
}
