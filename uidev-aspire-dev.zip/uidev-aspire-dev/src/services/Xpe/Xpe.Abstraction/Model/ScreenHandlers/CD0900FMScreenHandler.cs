﻿// -----------------------------------------------------------------------
// <copyright file="CD0900FMScreenHandler.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2016 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace Xpe.Abstraction.Model.ScreenHandlers
{
    using Xpe.Abstraction.Enums;
    using Xpe.Abstraction.Navigation;
    using Xpe.Abstraction.Services;

    using System;
    using System.Linq;
    using System.Threading.Tasks;

    public class CD0900FMScreenHandler : IScreenHandler
    {
        public CD0900FMScreenHandler(/*IInquiryTypeProvider inquiryTypeProvider*/)
        {
            //this.InquiryTypeProvider = inquiryTypeProvider;
            this.ScreenId = "CD0900FM-SFLAC-SFLA-SFLAO";
            this.FieldRefId = "ACCTNO";
            //this.RelatedFunction = UIFunctionKey.MemoPost;
            //this.AccountType = this.InquiryTypeProvider.CDCode;
        }

        //private IInquiryTypeProvider InquiryTypeProvider { get; set; }

        private string RelatedFunction { get; set; }

        private string ScreenId { get; set; }

        private string FieldRefId { get; set; }

        private string AccountType { get; set; }

        public HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
        {
            HandleScreenInfoRequest rq = null;

            if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId))
            {
                //TODO: Implement
                ////Find the cust id in the screen data, and open customer inquiry with the specified related function
                //if (screenData.ScreenInfo.ScreenMap != null && screenData.ScreenInfo.AllFields != null)
                //{
                //    try
                //    {
                //        var screenMap = ScreenMap.Deserialize(screenData.ScreenInfo.ScreenMap);

                //        if (screenMap != null && screenMap.NamePairArray != null)
                //        {
                //            var field = screenMap.NamePairArray.FirstOrDefault(s => s.FieldRefId == this.FieldRefId);

                //            if (field != null)
                //            {
                //                var value = screenData.ScreenInfo.AllFields.FirstOrDefault(f => f.Col == field.Col && f.Row == field.Row);

                //                if (value != null && value.Data != null)
                //                {
                //                    IAccount account = new MiniAccount(value.Data, this.AccountType);

                //                    AccountRequestedEventArgs args = new AccountRequestedEventArgs(account, null, true, this.RelatedFunction, null, windowIdentifier);
                //                    args.RelatedFunctionByPassUserSettingsForAutoStart = true;

                //                    this.EventService.Publish<AccountRequestedEvent, AccountRequestedEventArgs>(args);

                //                    rq = new HandleScreenInfoRequest(new KeyPress(Key.F12, Key.None), screenData.ScreenInfo.CursorLocation);
                //                }
                //            }
                //        }
                //    }
                //    catch
                //    {
                //    }
                //}
            }

            return rq;
        }

        public bool IsInputObserver(string screenId)
        {
            return false;
        }

        public bool IsMenuOptionObserver()
        {
            return false;
        }

        public bool IsScreenHandler(string screenId)
        {
            return screenId == this.ScreenId;
        }

        public bool MenuOptionSelected(XpeNavigationEventArgs args)
        {
            return false;
        }

        public Task<bool> ObserveInputAsync(
            ScreenData screenData,
            ScreenInfoRequest screenInfoRq,
            ICurrentUserInfo userInfo)
        {
            return null;
        }
    }
}
