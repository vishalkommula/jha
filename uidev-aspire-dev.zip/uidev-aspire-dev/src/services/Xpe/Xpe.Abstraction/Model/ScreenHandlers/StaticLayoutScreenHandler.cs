namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using System;
using System.Threading.Tasks;

public class StaticLayoutScreenHandler : IScreenHandler
{
    public StaticLayoutScreenHandler()
    {
    }

    public HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId) && screenData.IsStaticLayoutScreen)
        {
            //switch (screenData.ScreenInfo.ScreenId)
            //{
            //    case ScreenIdentification.NonPostedItems:
            //    case ScreenIdentification.NonPostedItemsResolved:
            //        screenData.ScreenName = "Non-Posted Items";
            //        break;
            //    case ScreenIdentification.ACHSuspectCertification:
            //        screenData.ScreenName = "OFAC ACH Certification";
            //        break;
            //}

            //this.eventService.Publish<ShowAlternateViewEvent, ShowAlternateViewEventArgs>(new ShowAlternateViewEventArgs() { StaticViewScreenData = screenData, WindowIdentifier = windowIdentifier, ViewIdentifier = screenData.ScreenInfo.ScreenId });
        }

        return null;
    }

    public bool IsInputObserver(string screenId)
    {
        return false;
    }

    public bool IsMenuOptionObserver()
    {
        return false;
    }

    public bool IsScreenHandler(string screenId)
    {
        return ScreenIdentification.StaticLayoutScreens.Contains(screenId);
    }

    public bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        return false;
    }

    public Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        return null;
    }
}
