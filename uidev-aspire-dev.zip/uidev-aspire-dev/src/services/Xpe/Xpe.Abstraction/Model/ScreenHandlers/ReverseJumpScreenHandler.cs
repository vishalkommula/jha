namespace Xpe.Abstraction.Model.ScreenHandlers;

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using JackHenry.JHAContractTypes;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using Microsoft.Extensions.Logging;

public class ReverseJumpScreenHandler : IScreenHandler
{

public ReverseJumpScreenHandler(ILogger<ReverseJumpScreenHandler> logger, /*IInquiryTypeProvider inquiryTypeProvider, IInquiryTypeService inquiryTypeService, */IXperienceEnabledService xperienceEnabledService)
    {
        //this.InquiryTypeProvider = inquiryTypeProvider;
        //this.InquiryTypeService = inquiryTypeService;
        this.Logger = logger;
        XperienceEnabledService = xperienceEnabledService;
    }
    private ILogger<ReverseJumpScreenHandler> Logger { get; }

    private IXperienceEnabledService XperienceEnabledService { get; }

    //private IInquiryTypeProvider InquiryTypeProvider { get; set; }

    //private IInquiryTypeService InquiryTypeService { get; set; }

    private List<KeyValuePair<string, string>> JumpScreenParameters { get; set; }

    private Hashtable ReverseDialogOpen { get; set; } = new Hashtable();

    public HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        HandleScreenInfoRequest screenInfoRequest = null;
        
        //TODO: Implement
        //if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId) && !this.ReverseDialogOpen.ContainsKey(windowIdentifier))
        //{
        //    try
        //    {
        //        ////This screen is not viewable by the user (it's behind a dialog)....we see this screen when users are attempting to add an account from certain
        //        ////screens (ex. LNS120FM-SFLXC-SFLX-SFLOPX).  We catch it here and use the account number and type values to open up C & A in a dialog - allowing users to
        //        ////select an account.  Once an account is selected we send those values back so the account is added to the appropriate screen.  Else if they close/cancel
        //        ////the dialog, we send the Previous command to take us back
        //        ScreenField5250 customerNumberField = this.GetFieldByRowCol(7, 11, screenData.ScreenInfo.AllFields);
        //        ScreenField5250 accountNumberField = this.GetFieldByRowCol(8, 11, screenData.ScreenInfo.AllFields);
        //        ScreenField5250 accountTypeField = this.GetFieldByRowCol(8, 35, screenData.ScreenInfo.AllFields);
        //        ScreenField5250 programField = this.GetFieldByRowCol(9, 11, screenData.ScreenInfo.AllFields);
        //        ScreenField5250 serviceField = this.GetFieldByRowCol(10, 11, screenData.ScreenInfo.AllFields);
        //        ScreenField5250 userIdField = this.GetFieldByRowCol(11, 11, screenData.ScreenInfo.AllFields);
        //        ScreenField5250 productField = this.GetFieldByRowCol(1, 127, screenData.ScreenInfo.AllFields);
        //        ScreenField5250 lnUnitIdField = this.GetFieldByRowCol(12, 11, screenData.ScreenInfo.AllFields);
        //        ScreenField5250 filter1Name = this.GetFieldByRowCol(7, 46, screenData.ScreenInfo.AllFields);
        //        ScreenField5250 filter1Value = this.GetFieldByRowCol(8, 48, screenData.ScreenInfo.AllFields);
        //        ScreenField5250 filter2Name = this.GetFieldByRowCol(9, 46, screenData.ScreenInfo.AllFields);
        //        ScreenField5250 filter2Value = this.GetFieldByRowCol(10, 48, screenData.ScreenInfo.AllFields);
        //        ScreenField5250 filter3Name = this.GetFieldByRowCol(11, 46, screenData.ScreenInfo.AllFields);
        //        ScreenField5250 filter3Value = this.GetFieldByRowCol(12, 48, screenData.ScreenInfo.AllFields);
        //        ScreenField5250 modeValue = this.GetFieldByRowCol(09, 29, screenData.ScreenInfo.AllFields);

        //        JWalkReverseNavigationEventArgs reverseJumpArgs = new JWalkReverseNavigationEventArgs();
        //        reverseJumpArgs.UserInfo = userInfo;
        //        reverseJumpArgs.WindowIdentifier = windowIdentifier;
        //        reverseJumpArgs.CustId = customerNumberField != null ? customerNumberField.Data.Trim().TrimStart('0') : null;
        //        reverseJumpArgs.AccountNum = accountNumberField != null ? accountNumberField.Data.Trim().TrimStart('0') : null;
        //        reverseJumpArgs.AccountType = accountTypeField != null ? accountTypeField.Data.Trim() : null;

        //        if (!string.IsNullOrEmpty(reverseJumpArgs.AccountNum) && !string.IsNullOrEmpty(reverseJumpArgs.AccountType))
        //        {
        //            reverseJumpArgs.Account = new MiniAccount(reverseJumpArgs.AccountNum, reverseJumpArgs.AccountType)
        //            {
        //                CustId = reverseJumpArgs.CustId
        //            };
        //        }
        //        else if ((string.IsNullOrEmpty(reverseJumpArgs.AccountType) || reverseJumpArgs.AccountType == this.InquiryTypeProvider.CustomerType) && !string.IsNullOrEmpty(reverseJumpArgs.CustId))
        //        {
        //            reverseJumpArgs.Account = new MiniAccount(reverseJumpArgs.CustId, this.InquiryTypeProvider.CustomerType)
        //            {
        //                CustId = reverseJumpArgs.CustId
        //            };
        //        }

        //        reverseJumpArgs.Program = programField != null ? programField.Data.Trim() : null;
        //        reverseJumpArgs.Service = serviceField != null ? serviceField.Data.Trim() : null;
        //        reverseJumpArgs.UserId = userIdField != null ? userIdField.Data.Trim() : null;
        //        reverseJumpArgs.Product = productField != null ? productField.Data.Trim() : null;
        //        reverseJumpArgs.LnUnitId = lnUnitIdField != null ? lnUnitIdField.Data.Trim() : null;
        //        reverseJumpArgs.Filters = new List<KeyValuePair<string, string>>();

        //        if (filter1Name != null && !string.IsNullOrEmpty(filter1Name.Data?.Trim()))
        //        {
        //            reverseJumpArgs.Filters.Add(new KeyValuePair<string, string>(filter1Name.Data?.Trim(), filter1Value != null ? filter1Value.Data?.Trim() : null));
        //        }

        //        if (filter2Name != null && !string.IsNullOrEmpty(filter2Name.Data?.Trim()))
        //        {
        //            reverseJumpArgs.Filters.Add(new KeyValuePair<string, string>(filter2Name.Data?.Trim(), filter1Value != null ? filter2Value.Data?.Trim() : null));
        //        }

        //        if (filter3Name != null && !string.IsNullOrEmpty(filter3Name.Data?.Trim()))
        //        {
        //            reverseJumpArgs.Filters.Add(new KeyValuePair<string, string>(filter3Name.Data?.Trim(), filter1Value != null ? filter3Value.Data?.Trim() : null));
        //        }

        //        //// you need to call the call back in your view/dialog or whatever is opening to let xpe know its closed
        //        reverseJumpArgs.CallBack = a => this.DialogCallBack(a, screenData, deferredCommand, windowIdentifier, reverseJumpArgs);

        //        ////key that will be sent for OK on dialog
        //        reverseJumpArgs.FunctionKey = Key.Enter;

        //        ////key that will be sent for Cancel on dialog
        //        reverseJumpArgs.FunctionKey2 = Key.F12;

        //        if (modeValue != null && !string.IsNullOrEmpty(modeValue.Data?.Trim()))
        //        {
        //            reverseJumpArgs.Mode = modeValue.Data?.Trim();
        //        }

        //        switch (reverseJumpArgs.Service.ToLower().Trim())
        //        {
        //            case XpeResourceStrings.ReverseJumpServiceCustomerAccountLookup:
        //            case XpeResourceStrings.ReverseJumpServiceLoanAccountLookup:
        //                reverseJumpArgs.CallBack = null;

        //                bool isCustomer = reverseJumpArgs.AccountType == this.InquiryTypeProvider.CustomerType && !string.IsNullOrEmpty(reverseJumpArgs.CustId);

        //                List<InquiryType> inquiryTypes = this.InquiryTypeService.GetInquiryTypes(userInfo.InstitutionNumber);
        //                InquiryType accountInquiryType = isCustomer ? inquiryTypes.FirstOrDefault(i => i.TypeCode == this.InquiryTypeProvider.CustomerType) : inquiryTypes.FirstOrDefault(i => i.TypeCode == accountTypeField.Data);
        //                AccountSearchArgs accountSearchArgs = new AccountSearchArgs(new InquiryType[] { accountInquiryType }, this.InquiryTypeProvider);
        //                accountSearchArgs.SelectedInquiryType = accountInquiryType;

        //                AccountLookupDialogArgs args = new AccountLookupDialogArgs((a) => this.DialogCallBack(new JWalkReverseNavigationReturnArgs(a.Account?.AcctId, a.Account?.AcctType, a.Account?.CustId?.Value, !a.Canceled ? reverseJumpArgs.FunctionKey : reverseJumpArgs.FunctionKey2), screenData, deferredCommand, windowIdentifier, reverseJumpArgs), windowIdentifier)
        //                {
        //                    Title = isCustomer ? "Customer Lookup" : "Account Lookup",
        //                    AccountSearchArgs = accountSearchArgs,
        //                    FromXPEReverseJump = true
        //                };

        //                this.ReverseDialogOpen.Add(windowIdentifier, true);

        //                this.EventService.Publish<AccountLookupDialogEvent, AccountLookupDialogArgs>(args);

        //                break;

        //            case XpeResourceStrings.ReverseJumpServiceInstDefFldSrch:
        //                this.ShowAccountRelatedFunctionInAlternateDialog<IInstDefFieldsView, IInstDefFieldsViewModel>(reverseJumpArgs, UIFunctionKey.InstDefFields.ToString(), userInfo, windowIdentifier);
        //                break;
        //            case XpeResourceStrings.ReverseJumpServicePDBeneAdd:
        //            case XpeResourceStrings.ReverseJumpServicePDBeneMod:
        //                reverseJumpArgs.FunctionKey = Key.F12;

        //                ////open POD beneficiary related function
        //                this.ShowAccountRelatedFunctionInAlternateDialog<IAccountPODBeneficiaryView, IAccountPODBeneficiaryViewModel>(reverseJumpArgs, UIFunctionKey.PODBeneficiary.ToString(), userInfo, windowIdentifier);

        //                break;

        //            case XpeResourceStrings.ReverseJumpServiceCDIBenAdd:
        //            case XpeResourceStrings.ReverseJumpServiceCDIBenMod:
        //                ////open IRA Tax Plan beneficiary related function

        //                if (reverseJumpArgs.Filters.Any(f => f.Key.ToString().Trim() == "PlnCode" && !string.IsNullOrEmpty(f.Value?.Trim())))
        //                {
        //                    reverseJumpArgs.Account = new MiniAccount(reverseJumpArgs.Filters.First(f => f.Key.ToString().Trim() == "PlnCode").Value?.Trim(), this.InquiryTypeProvider.IRACode)
        //                    {
        //                        CustId = reverseJumpArgs.CustId
        //                    };

        //                    this.ShowAccountRelatedFunctionInAlternateDialog<IIRABeneficiaryView, IIRABeneficiaryViewModel>(reverseJumpArgs, UIFunctionKey.IRABeneficiaryInquiry.ToString(), userInfo, windowIdentifier);
        //                }

        //                break;

        //            case XpeResourceStrings.ReverseJumpServiceEscrwInq:
        //                this.ShowAccountRelatedFunctionInAlternateDialogRegion(reverseJumpArgs, UIFunctionKey.EscrowInsurance, userInfo, windowIdentifier);
        //                break;
        //        }
        //    }
        //    catch
        //    {
        //        screenInfoRequest = new HandleScreenInfoRequest(new KeyPress(Key.F12, Key.None), screenData.ScreenInfo.CursorLocation);
        //    }
        //}

        return screenInfoRequest;
    }

    public bool IsInputObserver(string screenId)
    {
        return false;
    }

    public bool IsMenuOptionObserver()
    {
        return false;
    }

    public bool IsScreenHandler(string screenId)
    {
        return screenId == ScreenIdentification.ReverseJumpScreen;
    }

    public bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        return false;
    }

    public Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        return null;
    }

    //private void DialogCallBack(JWalkReverseNavigationReturnArgs result, ScreenData screenData, Action<ScreenInfoRequest> deferredCommand, string windowIdentifier, JWalkReverseNavigationEventArgs args)
    //{
    //    ScreenInfoRequest screenInfoRequest = new ScreenInfoRequest(new KeyPress(result.CommandKey, Key.None), screenData.ScreenInfo.CursorLocation);

    //    try
    //    {
    //        if (result.CommandKey == args.FunctionKey)
    //        {
    //            //// user clicked OK button
    //            ScreenField5250 accountNumberInput = this.GetFieldByRowCol(14, 18, screenData.ScreenInfo.AllFields);
    //            ScreenField5250 accountTypeInput = this.GetFieldByRowCol(15, 18, screenData.ScreenInfo.AllFields);

    //            var accountInputFields = new List<ScreenField5250>();

    //            if (!string.IsNullOrEmpty(result.AccountNumber) && !string.IsNullOrEmpty(result.AccountType))
    //            {
    //                ////Update the values for the account number/type fields so we can send them back in the data stream
    //                accountNumberInput.Data = result.AccountType == this.InquiryTypeProvider.CustomerType ? result.CustId : result.AccountNumber;
    //                accountTypeInput.Data = result.AccountType;

    //                accountInputFields.Add(accountNumberInput);
    //                accountInputFields.Add(accountTypeInput);
    //            }

    //            screenInfoRequest.CursorLocation = screenData.ScreenInfo.CursorLocation;

    //            if (accountInputFields.Any())
    //            {
    //                screenInfoRequest.ChangedFields = accountInputFields;
    //            }

    //            deferredCommand(screenInfoRequest);
    //        }
    //        else
    //        {
    //            deferredCommand(screenInfoRequest);
    //        }
    //    }
    //    catch
    //    {
    //        ////go to previous if there is an exception
    //        screenInfoRequest = new ScreenInfoRequest(new KeyPress(Key.F12, Key.None), screenData.ScreenInfo.CursorLocation);
    //        deferredCommand(screenInfoRequest);
    //    }
    //    finally
    //    {
    //        if (this.ReverseDialogOpen.ContainsKey(windowIdentifier))
    //        {
    //            this.ReverseDialogOpen.Remove(windowIdentifier);
    //        }
    //    }
    //}

    //private ScreenField5250 GetFieldByRowCol(int row, int column, IEnumerable<ScreenField5250> fields)
    //{
    //    return fields.FirstOrDefault(f => f.Row == row && f.Col == column);
    //}

    //private void ShowAccountRelatedFunctionInAlternateDialog<TView, TViewModel>(JWalkReverseNavigationEventArgs reverseJumpArgs, string functionKey, ICurrentUserInfo userInfo, string windowIdentifier)
    //    where TView : IView
    //    where TViewModel : IWindowedParameterizedViewModel<RelatedFunctionArgs<TagEventArguments>>
    //{
    //    IFunction function = this.functionsService.RetrieveFunction(functionKey.ToString(), reverseJumpArgs.Account as IAccount, userInfo);

    //    if (function != null)
    //    {
    //    reverseJumpArgs.Description = function.Name;
    //    reverseJumpArgs.ImageIcon = function.IconType;
    //    reverseJumpArgs.RelatedFunctionKey = functionKey.ToString();
    //    }
    //    else if (functionKey.ToString() == UIFunctionKey.InstDefFields.ToString())
    //    {
    //        reverseJumpArgs.Description = "Institution Defined Fields";
    //        reverseJumpArgs.ImageIcon = Enterprise.Controls.Wpf.Resources.JhaImageTypes.ViewList;
    //        reverseJumpArgs.RelatedFunctionKey = functionKey.ToString();
    //    }

    //    Application.Current.Dispatcher.InvokeIfRequired(
    //        () =>
    //        {
    //            try
    //            {
    //                if (this.dialogService.ShowDialog<SilverLakeLiteAlternateViewReverseJumpDialog, SilverLakeLiteAlternateViewReverseJumpDialogViewModel, JWalkReverseNavigationEventArgs>(windowIdentifier, reverseJumpArgs, true, Common.Dialog.Constants.DialogSizeOptions.UseProductLevelGridHeightAndWidth))
    //                {
    //                    this.ReverseDialogOpen.Add(windowIdentifier, true);

    //                    RelatedFunctionArgs<TagEventArguments> relatedFunctionArgs = new RelatedFunctionArgs<TagEventArguments>(reverseJumpArgs.Account as IAccount, new TagEventArguments(reverseJumpArgs, null), null, null);

    //                    //// show instdeffld function inside the reverse jump dialog
    //                    this.regionService.AppendAndActivateViewInRegion<TView, TViewModel, RelatedFunctionArgs<TagEventArguments>>(
    //                        Infrastructure.RegionNames.AlternateViewReverseJumpDialogRegion,
    //                        string.Concat(functionKey, windowIdentifier),
    //                        relatedFunctionArgs,
    //                        null,
    //                        windowIdentifier);
    //                }
    //            }
    //            catch (Exception ex)
    //            {
    //                this.loggingService.LogException(ex);
    //                DialogService.ShowErrorNotificationDialog(windowIdentifier, "Error opening reverse jump dialog", ex.Message);
    //            }
    //        });
    //}

    //private void ShowAccountRelatedFunctionInAlternateDialogRegion(JWalkReverseNavigationEventArgs reverseJumpArgs, string functionKey, ICurrentUserInfo userInfo, string windowIdentifier)
    //{
    //    IFunction function = this.functionsService.RetrieveFunction(functionKey.ToString(), reverseJumpArgs.Account as IAccount, userInfo);

    //    if (function != null)
    //    {
    //        reverseJumpArgs.Description = function.Name;
    //        reverseJumpArgs.ImageIcon = function.IconType;
    //        reverseJumpArgs.RelatedFunctionKey = functionKey.ToString();
    //    }
    //    else if (functionKey.ToString() == UIFunctionKey.InstDefFields.ToString())
    //    {
    //        reverseJumpArgs.Description = "Institution Defined Fields";
    //        reverseJumpArgs.ImageIcon = Enterprise.Controls.Wpf.Resources.JhaImageTypes.ViewList;
    //        reverseJumpArgs.RelatedFunctionKey = functionKey.ToString();
    //    }

    //    Application.Current.Dispatcher.InvokeIfRequired(
    //        () =>
    //        {
    //            try
    //            {
    //                if (this.dialogService.ShowDialog<SilverLakeLiteAlternateViewReverseJumpDialog, SilverLakeLiteAlternateViewReverseJumpDialogViewModel, JWalkReverseNavigationEventArgs>(windowIdentifier, reverseJumpArgs, true, Common.Dialog.Constants.DialogSizeOptions.UseProductLevelGridHeightAndWidth))
    //                {
    //                    this.ReverseDialogOpen.Add(windowIdentifier, true);

    //                    this.EventService.Publish<GenericToolbarEvent, PayloadWindowEventArgs<AccountEventParameter>>(
    //                        new PayloadWindowEventArgs<AccountEventParameter>(
    //                            new AccountEventParameter(
    //                            functionKey,
    //                            reverseJumpArgs.Account as IAccount,
    //                            string.Empty)
    //                            {
    //                                AlternateRegionName = string.Concat(Infrastructure.RegionNames.AlternateViewReverseJumpDialogRegion, windowIdentifier),
    //                                Tag = reverseJumpArgs
    //                            },
    //                            windowIdentifier));
    //                }
    //            }
    //            catch (Exception ex)
    //            {
    //                this.loggingService.LogException(ex);
    //                DialogService.ShowErrorNotificationDialog(windowIdentifier, "Error opening reverse jump dialog", ex.Message);
    //            }
    //        });
    //}
}