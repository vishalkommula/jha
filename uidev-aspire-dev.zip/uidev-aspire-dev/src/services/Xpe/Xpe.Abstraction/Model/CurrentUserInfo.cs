﻿using System.Xml;
using JackHenry.UID.Identity;

namespace Xpe.Abstraction.Model;

public class CurrentUserInfo : ICurrentUserInfo
{
    public BankingAlias Alias { get; set; }

    public PrvdInstInfoModel Institution { get; set; }

    public string InstitutionNumber => Institution?.PrvdInstId?.Value;

    public string AliasName => Alias?.Name;

    public string SecurityGroup { get; set; }

    public IWrappedImsSecurityToken SamlToken { get; set; }

    public bool IsSAMLAuthRequired => Institution?.PrvdInstInfo?.ReqSAMLAuth?.Value.ToLower() == "true";
}