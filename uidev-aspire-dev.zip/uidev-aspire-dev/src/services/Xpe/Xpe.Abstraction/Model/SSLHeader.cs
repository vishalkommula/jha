﻿using System.Collections.Generic;

namespace Xpe.Abstraction.Model;

public class SSLHeader
{
    public enum SSLDataType : byte
    {
        ChangeCipherSpec = 0x14,
        Alert = 0x15,
        Handshake = 0x16,
        ApplicationData = 0x17,
        None = 0x00
    }

    public enum SSLProtocol : byte
    {
        SSLV3 = 0x00,
        TLS10 = 0x01,
        TLS11 = 0x02,
        TLS12 = 0x03
    }

    public SSLHeader(List<byte> snaRecord)
    {
        if ((SSLDataType) snaRecord[0] == SSLDataType.ChangeCipherSpec ||
            (SSLDataType) snaRecord[0] == SSLDataType.Alert ||
            (SSLDataType) snaRecord[0] == SSLDataType.Handshake ||
            (SSLDataType) snaRecord[0] == SSLDataType.ApplicationData)
        {
            DataType = (SSLDataType) snaRecord[0];
        }

        if (DataType != SSLDataType.None && snaRecord[1] == 0x03 &&
            ((SSLProtocol) snaRecord[2] == SSLProtocol.SSLV3 || (SSLProtocol) snaRecord[2] == SSLProtocol.TLS10 ||
             (SSLProtocol) snaRecord[2] == SSLProtocol.TLS11 || (SSLProtocol) snaRecord[2] == SSLProtocol.TLS12) &&
            snaRecord[7] == 0x12 && snaRecord[8] == 0xA0)
        {
            Protocol = (SSLProtocol) snaRecord[2];
            Length = snaRecord[4] * 256 + snaRecord[3];
            snaRecord.RemoveRange(0, 5);
        }
    }

    public SSLDataType DataType { get; }

    public SSLProtocol Protocol { get; }

    public int Length { get; }
}