using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using JackHenry.Enterprise.Collections;
using JackHenry.JHAContractTypes;
using Xpe.Abstraction.Enums;

namespace Xpe.Abstraction.Model;

public class ParmValues : ObservableCollection<ParmValSrchRec_CType>, IDisposable, ICloneable
{
    public ParmValues()
    {
    }

    public ParmValues(IEnumerable<ParmValSrchRec_CType> parmValues)
    {
        this.AddRange(parmValues);
    }

    public object Clone()
    {
        var clone = new ParmValues();

        foreach (var rec in this)
        {
            var cloneRec = new ParmValSrchRec_CType
            {
                ParmValCode = rec.ParmValCode?.Value,
                ParmValDesc = rec.ParmValDesc?.Value,
                ParmValInfoArray = rec.ParmValInfoArray?.Clone() as ParmValInfo_CType[]
            };

            clone.Add(cloneRec);
        }

        return clone;
    }

    public void Dispose()
    {
        Clear();
    }

    public bool ContainsCode(string code)
    {
        var query = from p in this
            where p.ParmValCode == code
            select p;
        return query.Any();
    }

    public List<ParmValSrchRec_CType> GetAllExcluding(string[] values)
    {
        var parmValue = new List<ParmValSrchRec_CType>();
        var oktoAdd = true;

        this.ToList().ForEach(v =>
        {
            oktoAdd = values.All(s => v.ParmValCode != s);

            if (oktoAdd)
            {
                parmValue.Add(v);
            }
        });

        return parmValue;
    }

    public List<ParmValSrchRec_CType> GetAllExcludingSystem()
    {
        var parmValue = new List<ParmValSrchRec_CType>();
        var query = from p in this
            where p.ParmValCode != SvcDictFieldUsage.SYSTEM.ToString()
            select p;

        // query.Count() sometimes run into intermittent problems with its iterator.
        // We shouldn't need this here anyway, since a non-null query will create a
        // list with 0 objects if the count is 0.
        parmValue = query.ToList();

        return parmValue;
    }

    public ParmValSrchRec_CType GetByCode(string code)
    {
        var parmValue = new ParmValSrchRec_CType();
        var query = from p in this
            where p.ParmValCode == code
            select p;
        if (query.Any())
        {
            parmValue = query.First();
        }

        return parmValue;
    }
}