﻿namespace Xpe.Abstraction.Extensions;

public static class GenericExtensions
{
    public static T CloneObject<T>(this T objectToClone)
        where T : class, new()
    {
        var objectToCloneString = JhaSerializer.Serialize(objectToClone);

        return JhaSerializer.XmlDeserialize<T>(objectToCloneString);
    }
}