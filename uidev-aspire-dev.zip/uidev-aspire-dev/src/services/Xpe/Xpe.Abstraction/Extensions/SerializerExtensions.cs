﻿using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Xpe.Abstraction.Extensions;

public static class SerializerExtensions
{
    public static string Serialize<T>(this T dataTypeSource) where T : class, new()
    {
        var xmlSerializer = new XmlSerializer(typeof(T));
        var output = new MemoryStream();
        var settings = new XmlWriterSettings
        {
            Encoding = Encoding.UTF8,
            NamespaceHandling = NamespaceHandling.Default,
            CloseOutput = true
        };
        string str1;
        using (var xmlWriter = XmlWriter.Create(output, settings))
        {
            xmlSerializer.Serialize(xmlWriter, dataTypeSource);
            str1 = Encoding.UTF8.GetString(output.GetBuffer());
        }

        var str2 = str1.Substring(str1.IndexOf(Convert.ToChar(60)));
        return str2.Substring(0, str2.LastIndexOf(Convert.ToChar(62)) + 1);
    }

    public static T Deserialize<T>(this string stringInXmlFormat) where T : class, new()
    {
        return (T) new XmlSerializer(typeof(T)).Deserialize(
            new XmlTextReader(new StringReader(stringInXmlFormat)));
    }
}