// -----------------------------------------------------------------------
// <copyright file="ScreenFieldExtensions.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Xpe.Abstraction.Model;

namespace Xpe.Abstraction.Extensions;

public static class ScreenFieldExtensions
{
    public static bool IsDisplayFormat(this ScreenField field, string displayFormat)
    {
        return field.DispFormat == displayFormat;
    }

    public static bool IsDisplayFormatError(this ScreenField field)
    {
        return field.DispFormat == ScreenFieldDisplayFormat.Error;
    }

    public static bool IsDisplayFormatWarning(this ScreenField field)
    {
        return field.DispFormat == ScreenFieldDisplayFormat.Warning;
    }

    public static bool IsDisplayFormatNotification(this ScreenField field)
    {
        return field.DispFormat == ScreenFieldDisplayFormat.Notification;
    }

    public static bool IsDisplayFormatNoWrap(this ScreenField field)
    {
        return field.DispFormat == ScreenFieldDisplayFormat.NoWrap;
    }

    public static bool IsDisplayFormatZip(this ScreenField field)
    {
        return field.DispFormat == ScreenFieldDisplayFormat.Zip;
    }

    public static bool IsDisplayFormatPhone(this ScreenField field)
    {
        return field.DispFormat == ScreenFieldDisplayFormat.Phone;
    }

    public static bool IsDisplayFormatAMonthDayYearDate(this ScreenField field)
    {
        return ScreenFieldDisplayFormat.IsMonthDayYearDate(field.DispFormat);
    }

    public static bool IsDisplayFormatATwoDigitYear(this ScreenField field)
    {
        return ScreenFieldDisplayFormat.IsTwoDigitYear(field.DispFormat);
    }

    public static bool IsDisplayFormatJulianDate(this ScreenField field)
    {
        return ScreenFieldDisplayFormat.IsJulianDate(field.DispFormat);
    }

    public static bool IsDisplayFormatCurrency(this ScreenField field)
    {
        return ScreenFieldDisplayFormat.IsCurrency(field.DispFormat);
    }

    public static bool IsDisplayFormatIgnored(this ScreenField field)
    {
        return ScreenFieldDisplayFormat.IsIgnored(field.DispFormat);
    }

    public static bool IsDisplayFormatBlank(this ScreenField field)
    {
        return ScreenFieldDisplayFormat.IsBlank(field.DispFormat);
    }

    public static bool IsDisplayFormatRate(this ScreenField field)
    {
        return ScreenFieldDisplayFormat.IsRate(field.DispFormat);
    }

    public static bool IsDisplayFormatTime(this ScreenField field)
    {
        return ScreenFieldDisplayFormat.IsTime(field.DispFormat);
    }

    public static bool IsDisplayFormatNegativePrefix(this ScreenField field)
    {
        return ScreenFieldDisplayFormat.IsNegativePrefix(field.DispFormat);
    }

    public static bool IsDecimal(this ScreenField field)
    {
        return field.DataType == ScreenFieldDataType.Decimal;
    }

    public static bool IsInt(this ScreenField field)
    {
        return field.DataType == ScreenFieldDataType.Int;
    }

    public static bool IsEditMasked(this ScreenField field)
    {
        return false;
    }

    public static bool IsFieldValueList(this ScreenField field)
    {
        return field.FieldValueArray != null && field.FieldValueArray.Any();
    }

    public static bool IsCheckBox(this ScreenField field)
    {
        return field.FieldValueArray != null &&
               field.FieldValueArray.Count == 2 &&
               field.FieldValueArray.Any(fv => fv.Description != null && fv.Description.ToLower() == "checked") &&
               field.FieldValueArray.Any(fv => fv.Description != null && fv.Description.ToLower() == "unchecked");
    }

    public static bool IsLinkTypeDecimal(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.Decimal;
    }

    public static bool IsLinkTypeURL(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.URL;
    }

    public static bool IsLinkTypeZip(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.Zip;
    }

    public static bool IsLinkTypePhoneNumber(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.PhoneNumber;
    }

    public static bool IsLinkTypeEmailAddress(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.EmailAddress;
    }

    public static bool IsLinkTypeLabel(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.Label;
    }

    public static bool IsLinkTypeColumnTotal(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.ColumnTotal;
    }

    public static bool IsLinkTypeAccount(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.AccountNumber;
    }

    public static bool IsLinkTypeGLAccount(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.GLAccountNumber;
    }

    public static bool IsLinkTypeCustomer(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.CustomerNumber;
    }

    public static bool IsLinkTypeValue(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.Value;
    }

    public static bool IsLinkTypeCombined(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.Combined;
    }

    public static bool IsLinkTypeDate(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.Date;
    }

    public static bool IsLinkTypePlan(this ScreenField field)
    {
        return field.FieldLabel.IsCaseInsensativeTrimmedEqual(ScreenFieldLinkType.PlanCode);
    }

    public static bool IsLinkTypeNavigation(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.Navigation;
    }

    public static bool IsLinkTypeKeyPressNav(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.KeyPressNav;
    }

    public static bool IsLinkTypeContinedField(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.ContinuedField;
    }

    public static bool IsLinkTypeImage(this ScreenField field)
    {
        return field.LinkType == ScreenFieldLinkType.Image;
    }

    public static bool IsCategoryGridBegin(this ScreenField field)
    {
        return field.FieldCategory == ScreenMapFieldCategory.GridBegin;
    }

    public static bool IsCategoryGridEnd(this ScreenField field)
    {
        return field.FieldCategory == ScreenMapFieldCategory.GridEnd;
    }

    public static bool IsCategoryRecordDetialItem(this ScreenField field)
    {
        return field.FieldCategory == ScreenMapFieldCategory.Header ||
               field.FieldCategory == ScreenMapFieldCategory.Field ||
               field.FieldCategory == ScreenMapFieldCategory.AddressType;
    }

    public static bool IsCategoryBanner(this ScreenField field)
    {
        return field.FieldCategory == ScreenMapFieldCategory.Banner;
    }

    public static bool IsCategoryPageTitle(this ScreenField field)
    {
        return field.FieldCategory == ScreenMapFieldCategory.PageTitle;
    }

    public static bool IsCategoryPageMode(this ScreenField field)
    {
        return field.FieldCategory == ScreenMapFieldCategory.PageMode;
    }

    public static bool IsCategoryMessage(this ScreenField field)
    {
        return field.FieldCategory == ScreenMapFieldCategory.Message;
    }

    public static bool IsCategorySentence(this ScreenField field)
    {
        return field.FieldCategory == ScreenMapFieldCategory.Sentence;
    }

    public static bool IsCategorySentenceHeader(this ScreenField field)
    {
        return field.FieldCategory == ScreenMapFieldCategory.SentenceHeader;
    }

    public static bool IsCategoryColumn(this ScreenField field)
    {
        return field.FieldCategory == ScreenMapFieldCategory.Column;
    }

    public static bool IsCategoryField(this ScreenField field)
    {
        return field.FieldCategory == ScreenMapFieldCategory.Field;
    }

    public static bool IsCategorySearch(this ScreenField field)
    {
        return field.FieldCategory == ScreenMapFieldCategory.Search;
    }

    public static bool IsCategoryCurrentPage(this ScreenField field)
    {
        return field.FieldCategory == ScreenMapFieldCategory.CurrentPage;
    }

    public static bool IsCategoryTotalPages(this ScreenField field)
    {
        return field.FieldCategory == ScreenMapFieldCategory.TotalPages;
    }

    public static string GetDateFormatFromDisplayFormat(this ScreenField field)
    {
        if (field.IsDisplayFormatAMonthDayYearDate() ||
            field.IsDisplayFormatJulianDate())
        {
            return field.DispFormat.Replace('D', 'd').Replace('Y', 'y');
        }

        return string.Empty;
    }

    public static ScreenField Clone(this ScreenField screenField)
    {
        var objectToCloneString = JhaSerializer.Serialize(screenField);

        return JhaSerializer.XmlDeserialize<ScreenField>(objectToCloneString);
    }

    public static bool HasRangeLinkDataExpression(this ScreenField screenField)
    {
        return !string.IsNullOrEmpty(screenField.LinkDataExpression) &&
               screenField.LinkDataExpression.Contains("RANGE");
    }

    public static List<string> TokenizeLinkDataExpression(this ScreenField namePair,
        IEnumerable<ScreenField5250> fields5250)
    {
        return TokenizeLinkDataExpression(namePair.LinkDataExpression, fields5250,
            namePair.IsCategoryMessage());
    }

    public static List<string> TokenizeLinkDataExpression(string expression, IEnumerable<ScreenField5250> fields5250,
        bool isCategoryMessage)
    {
        // Split the Link Data Expression by strings contained in brackets
        var fieldValues = Regex.Split(expression, "(?={)|(?<=})").ToList();

        // Strip brackets from all known tokens (SPACE, RANGE, field references) and leave/display the rest
        for (var i = 0; i < fieldValues.Count; i++)
            if (fieldValues[i].StartsWith("{SPACE:", true, CultureInfo.InvariantCulture) ||
                fieldValues[i].StartsWith("{RANGE", true, CultureInfo.InvariantCulture) ||
                Regex.IsMatch(fieldValues[i], "{[0-9]{5}}"))
            {
                fieldValues[i] = fieldValues[i].Replace("{", string.Empty);
                fieldValues[i] = fieldValues[i].Replace("}", string.Empty);
            }

        // If the expression contains SPACE, add the specified # of spaces to the list of field values
        if (fieldValues.Any(x => x.StartsWith("SPACE", true, CultureInfo.InvariantCulture)))
        {
            for (var i = 0; i < fieldValues.Count; i++)
                if (fieldValues[i].StartsWith("SPACE", true, CultureInfo.InvariantCulture))
                {
                    var spacerString = Regex.Match(fieldValues[i], @"\d+").Value;
                    int spaceCount;

                    if (int.TryParse(spacerString, out spaceCount))
                    {
                        spacerString = new string(' ', spaceCount);

                        fieldValues.RemoveAt(i);
                        fieldValues.Insert(i, spacerString);
                    }
                }
        }

        // If the expression contains a RANGE, combine the RANGE into a formatted string and insert it into the returned List
        if (fieldValues.Any(x => x.StartsWith("RANGE", true, CultureInfo.InvariantCulture)))
        {
            var fields5250List = fields5250.DistinctBy(f => f.RRCCC).OrderBy(x => x.Row).ThenBy(y => y.Col).ToList();

            for (var i = 0; i < fieldValues.Count; i++)
                if (fieldValues[i].StartsWith("RANGE", true, CultureInfo.InvariantCulture))
                {
                    var rangeValues = Regex.Split(fieldValues[i], @":").ToList();
                    rangeValues.RemoveAll(x => !IsValidRRCCC(x));

                    // We should have 2 field references within the RANGE
                    if (rangeValues.Count == 2)
                    {
                        var sb = new StringBuilder();

                        // Start and End values referenced in the RANGE
                        var startValue = Convert.ToInt32(rangeValues[0]);
                        var endValue = Convert.ToInt32(rangeValues[1]);

                        // Get the field that contains the referenced RRCCC start location
                        var matchedFieldStart = fields5250List.FirstOrDefault(x => x.RRCCCs.Contains(rangeValues[0]));

                        if (matchedFieldStart == null)
                        {
                            // Get the closest 5250 field that's within the RANGE
                            matchedFieldStart = fields5250List.FirstOrDefault(x =>
                                Convert.ToInt32(x.RRCCC) >= startValue && Convert.ToInt32(x.RRCCC) <= endValue);

                            // Add the appropriate amount of beginning spaces and set the start value
                            if (matchedFieldStart != null)
                            {
                                sb.Append(new string(' ', Convert.ToInt32(matchedFieldStart.RRCCC) - startValue));

                                rangeValues[0] = matchedFieldStart.RRCCC;
                                startValue = Convert.ToInt32(matchedFieldStart.RRCCC);
                            }
                        }

                        // Get the field that contains the referenced RRCCC end location
                        var matchedFieldEnd = fields5250List.FirstOrDefault(x => x.RRCCCs.Contains(rangeValues[1]));
                        var endSpacers = new StringBuilder();

                        // If a field wasn't found, get the closest field and create a string of end spaces that will be appended to the formatted string
                        if (matchedFieldEnd == null)
                        {
                            matchedFieldEnd = fields5250List.LastOrDefault(x =>
                                Convert.ToInt32(x.RRCCCs.Max()) >= startValue &&
                                Convert.ToInt32(x.RRCCCs.Max()) <= endValue);

                            var spacerCount = 0;

                            if (matchedFieldEnd != null)
                            {
                                if (matchedFieldEnd.RRCCCs.Any() && matchedFieldEnd.RRCCCs != null)
                                {
                                    spacerCount = endValue - Convert.ToInt32(matchedFieldEnd.RRCCCs.Last());
                                    rangeValues[1] = matchedFieldEnd.RRCCCs.Last();
                                }
                                else
                                {
                                    spacerCount = endValue - Convert.ToInt32(matchedFieldEnd.RRCCC);
                                    rangeValues[1] = matchedFieldEnd.RRCCC;
                                    endValue = Convert.ToInt32(matchedFieldEnd.RRCCC);
                                }

                                endSpacers.Append(new string(' ', spacerCount));
                            }
                        }

                        var inputFieldsExisting = false;

                        if (matchedFieldStart != null && matchedFieldEnd != null)
                        {
                            // Actual field location of the first and last matched fields within the RANGE
                            var firstFieldLoc = Convert.ToInt32(matchedFieldStart.RRCCC);
                            var lastFieldLoc = Convert.ToInt32(matchedFieldEnd.RRCCC);
                            var previousFieldEndRRCCC = 0;
                            var previousFieldRow = 0;

                            foreach (var screenField5250 in fields5250List)
                            {
                                // Trim the single space fields (located between most fields with data) if indicated in the mapper
                                if (fieldValues[i].StartsWith("RANGETRIM", true, CultureInfo.InvariantCulture) &&
                                    !string.IsNullOrEmpty(screenField5250.FieldName) &&
                                    screenField5250.RRCCCs.Count == 1)
                                {
                                    continue;
                                }

                                var fieldLoc = Convert.ToInt32(screenField5250.RRCCC);

                                if (fieldLoc >= firstFieldLoc && fieldLoc <= lastFieldLoc)
                                {
                                    // Add spacing between fields by subtracting the last RRCCC value of the previous field from the beginning RRCCC value of the current field
                                    var padding = fieldLoc - (previousFieldEndRRCCC + 1);

                                    // If the 5250 field is an empty string and field size is 0, we interpret this as an empty space
                                    if (screenField5250.Data == string.Empty && screenField5250.FieldSize == 0)
                                    {
                                        padding++;
                                    }

                                    // Only add the padding if we're not on the first field
                                    if (padding > 0 && previousFieldEndRRCCC > 0)
                                    {
                                        // Add padding if we're on the same row.  Else, add a newline.
                                        if (previousFieldRow == screenField5250.Row)
                                        {
                                            sb.Append(new string(' ', padding));
                                        }
                                        else
                                        {
                                            screenField5250.Data = screenField5250.Data.TrimStart();
                                            sb.Append("\r\n");
                                        }
                                    }

                                    // Trim all colon strings from message-type fields.  These are green-screen window/prompt separators that should not be included in the formatted string
                                    if (isCategoryMessage && screenField5250.Data.Trim() == ":")
                                    {
                                        screenField5250.Data = screenField5250.Data.Replace(":", " ");
                                    }

                                    // If the current field is the first or last field in the RANGE, adjust the string to start/end at the specified location.
                                    // Else, append the whole string.
                                    if ((screenField5250.RRCCCs.Contains(rangeValues[0]) ||
                                         screenField5250.RRCCCs.Contains(rangeValues[1]))
                                        && screenField5250.IsOutputField())
                                    {
                                        var lastFieldRRCCC = Convert.ToInt32(screenField5250.RRCCCs.Last());
                                        var length = lastFieldRRCCC - startValue + 1;
                                        var startIndex = screenField5250.RRCCCs.Contains(rangeValues[0])
                                            ? matchedFieldStart.RRCCCs.FindIndex(x => x == rangeValues[0])
                                            : 0;

                                        if (firstFieldLoc == lastFieldLoc)
                                        {
                                            length = endValue - startValue + 1;
                                        }
                                        else if (screenField5250.RRCCCs.Contains(rangeValues[1]))
                                        {
                                            length = endValue - Convert.ToInt32(screenField5250.RRCCC) + 1;
                                        }

                                        if (screenField5250.FieldSize < length - startIndex)
                                        {
                                            length = screenField5250.FieldSize;
                                        }

                                        if (!string.IsNullOrEmpty(screenField5250.Data))
                                        {
                                            if (screenField5250.Data.Length >= startIndex + length)
                                            {
                                                sb.Append(screenField5250.Data.Substring(startIndex, length));
                                            }
                                            else if (screenField5250.Data.Length < startIndex + length &&
                                                     screenField5250.Data.Length >= startIndex)
                                            {
                                                sb.Append(screenField5250.Data.Substring(startIndex));
                                            }
                                        }

                                        // If the RANGE was contained within 1 field, break so we don't append the same string information twice
                                        if (firstFieldLoc == lastFieldLoc)
                                        {
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        if (screenField5250.IsInputField())
                                        {
                                            inputFieldsExisting = true;
                                            sb.Append(string.Format("{{{0}}}", screenField5250.RRCCC));
                                        }
                                        else
                                        {
                                            sb.Append(screenField5250.Data);
                                        }
                                    }

                                    previousFieldEndRRCCC =
                                        screenField5250.RRCCCs.Any() && screenField5250.RRCCCs != null
                                            ? Convert.ToInt32(screenField5250.RRCCCs.Last())
                                            : Convert.ToInt32(screenField5250.RRCCC);
                                    previousFieldRow = screenField5250.Row;
                                }
                            }
                        }

                        sb.Append(endSpacers);

                        var formattedString = isCategoryMessage ? sb.ToString().Trim() : sb.ToString();

                        // Remove the value that contained the RANGE reference and replace it with our built string.  If input fields exist in the RANGE, tokenize the string again so each
                        // field reference is returned as a separate list item
                        if (inputFieldsExisting)
                        {
                            fieldValues.RemoveAt(i);
                            fieldValues.InsertRange(i,
                                TokenizeLinkDataExpression(formattedString, fields5250, isCategoryMessage));
                        }
                        else
                        {
                            fieldValues.RemoveAt(i);
                            fieldValues.Insert(i, formattedString);
                        }
                    }
                }
        }

        return fieldValues;
    }

    public static bool IsValidRRCCC(string rrccc)
    {
        int n;
        var isNumeric = int.TryParse(rrccc, out n);

        if (isNumeric && rrccc.Length == 5)
        {
            return true;
        }

        return false;
    }

    public static string FormatLinkDataExpression(string expression, IEnumerable<ScreenField5250> allFields,
        bool insertFirstCharSpace, bool isCategoryMessage, bool preserveInputFieldLength = false)
    {
        if (!string.IsNullOrEmpty(expression))
        {
            // Get the list of output fields to combine and the separators
            var fieldValues = TokenizeLinkDataExpression(expression, allFields, isCategoryMessage);

            if (fieldValues.Any())
            {
                // If there is not a delimeter defined before the first combined field, add a default space.
                if (string.IsNullOrEmpty(fieldValues[0]) && insertFirstCharSpace)
                {
                    fieldValues[0] = " ";
                }

                // Iterate through the combined RRCCC's and get their output field values
                for (var i = 0; i < fieldValues.Count; i++)
                {
                    int n;
                    var isNumeric = int.TryParse(fieldValues[i], out n);

                    if (isNumeric && fieldValues[i].Length == 5)
                    {
                        var screen5250 = ScreenField5250Extensions.GetFieldByRRCCC(fieldValues[i], allFields);

                        if (screen5250 != null && screen5250.IsOutputField())
                        {
                            if (!string.IsNullOrEmpty(screen5250.Data))
                            {
                                fieldValues[i] = screen5250.Data.Trim();
                            }
                            else
                            {
                                // If any of the 5250 fields came back as an empty string, return null.  This prevents us from displaying a mixture of static text with empty output fields in between.
                                return null;
                            }
                        }
                        else if (screen5250 != null && preserveInputFieldLength)
                        {
                            if (string.IsNullOrWhiteSpace(screen5250.Data))
                            {
                                fieldValues[i] = new string(' ', screen5250.FieldSize);
                            }
                            else
                            {
                                fieldValues[i] = screen5250.Data.PadRight(screen5250.FieldSize, ' ');
                            }
                        }
                        else
                        {
                            fieldValues[i] = string.Empty;
                        }
                    }
                }

                // Combine the values into one string
                var sb = new StringBuilder();

                foreach (var value in fieldValues)
                {
                    if (value == "\\r\\n")
                    {
                        sb.AppendLine();
                    }
                    else
                    {
                        sb.Append(value);
                    }
                }

                return sb.ToString();
            }
        }

        return null;
    }

    public static string FormatLinkDataExpression(this ScreenField namePair, IEnumerable<ScreenField5250> allFields,
        bool insertFirstCharSpace)
    {
        return FormatLinkDataExpression(namePair.LinkDataExpression, allFields, insertFirstCharSpace,
            namePair.IsCategoryMessage());
    }

    public static string FormatDynamicLabelText(this ScreenField namePair, IEnumerable<ScreenField5250> allFields)
    {
        if (!string.IsNullOrEmpty(namePair.FieldLabel))
        {
            return FormatLinkDataExpression(namePair.FieldLabel, allFields, false,
                namePair.IsCategoryMessage());
        }

        return null;
    }

    public static double CalculateFieldWidth(int maxLength, bool isMonospace)
    {
        // Pixel width for tahoma 11 pt is up to 11 pixels.  Consolas is 6.5 pixels.
        var charPixelWidth = isMonospace ? 6.75 : 11;

        var fieldWidth = maxLength * charPixelWidth;

        if (isMonospace)
        {
            fieldWidth += 25;
        }
        else
        {
            fieldWidth += 20;
        }

        var minWidth = 21;

        // Return a min width of 16
        return fieldWidth < minWidth ? minWidth : fieldWidth;
    }

    public static string GetRRCCC(this ScreenField namePair)
    {
        return string.Format("{0:00}{1:000}", namePair.Row, namePair.Col);
    }
}