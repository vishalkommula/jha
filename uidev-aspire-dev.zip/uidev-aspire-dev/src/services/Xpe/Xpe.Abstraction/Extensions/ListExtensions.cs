﻿using System;
using System.Collections;

namespace Xpe.Abstraction.Extensions;

public static class ListExtensions
{
    public static void DisposeCollection(this IList collection)
    {
        if (collection == null)
        {
            return;
        }

        try
        {
            if (collection is IDisposable disposable)
            {
                disposable.Dispose();
            }
            else
            {
                foreach (var item in collection)
                {
                    if (item is IDisposable disposable1)
                    {
                        disposable1.Dispose();
                    }
                }
            }

            if (collection.Count > 0)
            {
                collection.Clear();
            }
        }
        catch
        {
            // ignored
        }
    }
}