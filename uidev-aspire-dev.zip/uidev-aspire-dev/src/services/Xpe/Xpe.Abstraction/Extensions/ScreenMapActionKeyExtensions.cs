﻿using Xpe.Abstraction.Model;

namespace Xpe.Abstraction.Extensions;

public static class ScreenMapActionKeyExtensions
{
    public static bool IsMoreForceDisplay(this ScreenMapActionKey actionKey)
    {
        return actionKey.Key != null && actionKey.Key.ToUpper() == "F24" && actionKey.Action != null && actionKey.Action.ToLower().Contains("{forcedisplay}");
    }

    public static bool IsMoreIgnored(this ScreenMapActionKey actionKey)
    {
        return actionKey.Key != null && actionKey.Key.ToUpper() == "F24" && actionKey.Action != null && actionKey.Action.ToLower().Contains("{ignore}");
    }

    public static bool IsMoreFunction(this ScreenMapActionKey actionKey)
    {
        return actionKey.Key != null && actionKey.Key.ToUpper() == "F24" && actionKey.Action != null && actionKey.Action.ToLower().Contains("more");
    }

    public static bool IsPromptFunction(this ScreenMapActionKey actionKey)
    {
        return actionKey.Key != null && actionKey.Key.ToUpper() == "F4";
    }

    public static bool IsFieldValues(this ScreenMapActionKey actionKey)
    {
        return actionKey.Action != null && (actionKey.Action.ToLower() == "field values" || actionKey.Action.ToLower() == "fld values");
    }

    public static bool IsForceDisplay(this ScreenMapActionKey actionKey)
    {
        return actionKey.Action != null && actionKey.Action.ToLower().Contains("{forcedisplay}");
    }

    public static bool IsTypeHelp(this ScreenMapActionKey actionkey)
    {
        return actionkey.Action != null && actionkey.Action.ToLower() == "type help";
    }

    public static bool IsIgnore(this ScreenMapActionKey actionKey)
    {
        return actionKey.Action != null && actionKey.Action.ToLower().Contains("{ignore}");
    }

    public static bool IsEnter(this ScreenMapActionKey actionKey)
    {
        return actionKey.Key != null && actionKey.Key.ToLower() == "enter";
    }

    public static bool HasEnterActionText(this ScreenMapActionKey actionKey)
    {
        return actionKey.Key != null && actionKey.Key.ToLower().Trim() == "enter";
    }

    public static bool IsOK(this ScreenMapActionKey actionKey)
    {
        return actionKey.Action != null && actionKey.Action.ToLower() == "ok";
    }
}