﻿namespace Xpe.Abstraction.Extensions;

public class UnfoldKeyData
{
    public string Key { get; set; }

    public string StateExpression { get; set; }
}