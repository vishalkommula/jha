﻿namespace Xpe.Abstraction.Infrastructure;

public interface ICachedSetting
{
    bool IsDirty { get; set; }

    void Save();
}