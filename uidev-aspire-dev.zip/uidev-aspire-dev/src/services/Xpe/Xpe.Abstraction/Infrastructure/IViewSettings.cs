﻿using System.Collections.Generic;
using System.ComponentModel;
using Xpe.Abstraction.Model;

namespace Xpe.Abstraction.Infrastructure;

public interface IViewSettings : INotifyPropertyChanged, ICachedSetting
{
    string InstitutionKey { get; set; }

    bool IsDefaultValueForSetting { get; set; }

    bool NoValueExists { get; set; }

    string Key { get; }

    bool ShouldUpgrade { get; }

    bool TrackChanges { get; set; }

    List<PropertyChange> PropertyChanges { get; }

    string UserName { get; }

    int Version { get; }

    void AddDefaultValues();

    List<PropertyChange> Reset();

    void SetToNotDirty();

    void Upgrade();

    void LogChange(string propertyName, object oldValue, object newValue, string propertyDescription,
        bool forceLog = false);
}