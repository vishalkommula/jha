﻿using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace Xpe.Abstraction.Infrastructure;

public interface ICertificateValidationStrategy
{
    bool CertificateValidationCallback(object sender,
        X509Certificate certificate,
        X509Chain chain,
        SslPolicyErrors sslPolicyErrors);
}