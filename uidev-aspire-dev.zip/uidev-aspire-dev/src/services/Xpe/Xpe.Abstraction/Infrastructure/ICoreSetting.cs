namespace Xpe.Abstraction.Infrastructure;

public interface ICoreSetting
{
}