﻿namespace Xpe.Abstraction.Infrastructure;

// ReSharper disable once InconsistentNaming
public class ISeriesConnectionInfo
{
    public string Product { get; set; }

    public string User { get; set; }

    public string HostName { get; set; }

    public int Port { get; set; }

    public int ReceiveBufferSize { get; set; }

    public string Device { get; set; }
}