﻿using JackHenry.JHAContractTypes;
using Xpe.Abstraction.Model;

namespace Xpe.Abstraction.Infrastructure;

public interface IInstitutionService
{
    PrvdInstInfoModel GetCurrentInstitution();

    IIAdapter GetIAdapter();
}