﻿using System.IO;
using System.Threading;

namespace Xpe.Abstraction.Infrastructure;

public interface IISeriesServer
{
    bool IsConnected { get; set; }
    Stream ServerStream { get; set; }
    ITcpClient ServerSocket { get; set; }
    ManualResetEvent ConnectionStatus { get; set; }
    byte[] DataStreamBuffer { get; set; }

    void ConnectToServer(ISeriesConnectionInfo connectionInfo);
    void DisconnectFromServer();
    void SendRequestToServer(byte[] request);
}