using System.ComponentModel;

namespace Xpe.Abstraction.Infrastructure;

public enum CoreProductCode
{
    SilverLake,

    [Description("SilverLake Summit")] SilverLakeSummit
}