﻿namespace Xpe.Abstraction.Enums;

public enum EnterpriseAuditEventAction
{
    Crt,
    Del,
    Mod,
    Start,
    Stop,
    Inq
}