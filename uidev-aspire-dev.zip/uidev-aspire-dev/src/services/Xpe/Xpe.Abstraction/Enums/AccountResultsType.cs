﻿namespace Xpe.Abstraction.Enums;

public enum AccountResultsType
{
    Default,
    Customer,
    Account,
    LineOfCredit,
    Plan,
    GeneralLedger
}