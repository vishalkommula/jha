﻿namespace Xpe.Abstraction.Enums;

/// </summary>
public enum SvcDictElemCanocType
{
    Open,
    Closed,
    NA
}