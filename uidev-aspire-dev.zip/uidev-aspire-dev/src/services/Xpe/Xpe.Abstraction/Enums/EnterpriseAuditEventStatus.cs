﻿namespace Xpe.Abstraction.Enums;

public enum EnterpriseAuditEventStatus
{
    Success,
    Failure,
    Unknown
}