﻿namespace Xpe.Abstraction.Enums;

public enum MandatoryFill : byte
{
    // 000 = No adjust specified = 0
    None = 0,

    // 001 = Reserved = 1
    Reserved1 = 1,

    // 011 = Reserved = 2
    Reserved2 = 2,

    // 011 = Reserved = 3
    Reserved3 = 3,

    // 100 = Reserved = 4
    Reserved4 = 4,

    // 101 = Right adjust, zero fill = 5
    RightAdjustZeroFill = 5,

    // 110 = Right adjust, blank fill = 6
    RightAdjustBlankFill = 6,

    // 111 = Mandatory fill = 7
    MandatoryFill = 7
}