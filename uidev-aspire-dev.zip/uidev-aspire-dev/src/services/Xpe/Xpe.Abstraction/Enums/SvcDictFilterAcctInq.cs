﻿namespace Xpe.Abstraction.Enums;

public enum SvcDictFilterAcctInq
{
    AcctType,
    FieldKey,
    BrCode,
    ProdCode,
    AppCode,
    GLAcctId,
    RptMenu,
    BatchNum,
    UIFldLvl,
    SvcName
}