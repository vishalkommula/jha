﻿using System;
using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

[Serializable]
public enum InquirySearchField
{
    [Description("Account Number")] Account_Number,

    Account_Number_EndsWith,

    [Description("CIF Number")] CIF_Number,

    [Description("Name")] Customer_Name,

    [Description("Name (Contains)")] Name_Contains,

    [Description("Telephone")] Customer_Phone,

    [Description("Email")] Customer_Email,

    [Description("Tax ID")] Customer_Tax_ID,

    [Description("Customer Address")] Customer_Address,

    [Description("Title")] Customer_Title,

    [Description("Title")] GLSearch_TitleContains,

    GLSearch_Title,
    GLSearch,

    [Description("Account Number")] ATM_Deposit_Account_Number,

    [Description("Account Number")] GL_Account_Number,

    [Description("Account Number")] Deposit_Account_Number,

    None
}