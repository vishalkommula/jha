﻿namespace Xpe.Abstraction.Enums;

public enum PerformanceAuditItemType
{
    Thread,
    Process
}