namespace Xpe.Abstraction.Enums;

public enum PersistedSettingType
{
    User,
    System,
    Institution
}