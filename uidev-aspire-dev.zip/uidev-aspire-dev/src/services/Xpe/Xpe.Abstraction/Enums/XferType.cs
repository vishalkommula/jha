﻿namespace Xpe.Abstraction.Enums;

public enum XferType
{
    All,
    ACH,
    Xfer,
    Fut,
    Tele,
    Undefined
}