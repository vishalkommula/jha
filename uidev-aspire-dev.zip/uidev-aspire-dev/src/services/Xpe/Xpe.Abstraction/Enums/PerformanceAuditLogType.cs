﻿namespace Xpe.Abstraction.Enums;

public enum PerformanceAuditLogType
{
    Audit,
    Violation
}