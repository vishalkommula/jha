﻿using System;
using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

[Serializable]
public enum WebServiceType
{
    None,
    EL,
    IMS,
    PS,
    Customer,
    Deposit,
    Image,
    Inquiry,
    Loan,
    Transaction,
    NetTeller,
    IVR,

    [Description("Check and Statement Image")]
    Statement,

    IPay,

    [Description("Enterprise Workflow")] Workflow,

    Synapsys,
    IdentityManagement,
    CreditCard,
    TSetList,
    EnterpriseAudit
}