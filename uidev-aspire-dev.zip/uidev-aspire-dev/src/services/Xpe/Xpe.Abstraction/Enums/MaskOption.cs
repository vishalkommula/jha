﻿namespace Xpe.Abstraction.Enums;

public enum MaskOption
{
    Mask,
    Prompt,
    Clear
}