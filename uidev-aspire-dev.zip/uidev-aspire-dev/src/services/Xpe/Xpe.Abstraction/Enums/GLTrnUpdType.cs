﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum GLTrnUpdType
{
    NotSet,
    [Description("Resolve")] R,
    [Description("Unresolve")] U,
    [Description("Resolve All")] RA,
    [Description("Unresolve All")] UA,
    [Description("Delete")] D,
    [Description("Move All")] MA,
    [Description("Move/Create New ID")] M
}