﻿namespace Xpe.Abstraction.Enums;

public enum SvcCallLvl
{
    Defaults = 1,
    Requirements = 2,
    NotSet = 0
}