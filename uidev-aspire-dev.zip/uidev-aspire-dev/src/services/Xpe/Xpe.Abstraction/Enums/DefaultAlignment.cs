﻿namespace Xpe.Abstraction.Enums;

public enum DefaultAlignment
{
    DefaultLeft = 0,
    NoAlignment = 1,
    DefaultRight = 2
}