﻿using System;

namespace Xpe.Abstraction.Enums;

[Serializable]
public enum ProductMode
{
    Inquiry,
    Add,
    Update
}