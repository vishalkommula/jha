﻿namespace Xpe.Abstraction.Enums;

public enum MaskType
{
    Masked,
    UnMaskType
}