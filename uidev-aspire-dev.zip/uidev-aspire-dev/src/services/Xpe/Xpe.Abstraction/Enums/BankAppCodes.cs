﻿namespace Xpe.Abstraction.Enums;

public enum BankAppCodes
{
    LN,
    DD,
    CI,
    CT,
    CO,
    CF,
    SD,
    LE
}