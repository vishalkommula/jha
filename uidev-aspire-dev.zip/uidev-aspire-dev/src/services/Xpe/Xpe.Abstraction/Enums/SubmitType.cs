﻿namespace Xpe.Abstraction.Enums;

public enum SubmitType
{
    SaveAndSubmit,
    SaveAndContinue
}