﻿using System;

namespace Xpe.Abstraction.Enums;

[Serializable]
public enum FilterType
{
    NotSet,
    DisplayWhen,
    DoNotDisplayWhen
}