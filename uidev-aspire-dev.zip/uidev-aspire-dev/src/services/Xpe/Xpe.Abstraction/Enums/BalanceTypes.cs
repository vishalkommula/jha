﻿namespace Xpe.Abstraction.Enums;

public enum BalanceTypes
{
    AvailableBalance,
    CollectedBalance,
    LedgerBalance,
    None
}