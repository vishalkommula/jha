﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum SpecDesigNatType
{
    [Description("Unknown")] Unknown,

    [Description("Individual")] Indv,

    [Description("Business")] Bus,

    [Description("Vessel")] Vesl,

    [Description("Entity")] Entity
}