﻿namespace Xpe.Abstraction.Enums;

public enum BusinessMessageTypes
{
    Alert,
    Exc,
    ChgBack,
    Collat,
    Col,
    CrBack,
    ExcSus,
    Main,
    ODPrvlg,
    NonClsf
}