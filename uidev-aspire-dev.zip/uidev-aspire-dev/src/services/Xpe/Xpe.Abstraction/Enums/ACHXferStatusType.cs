﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum ACHXferStatusType
{
    [Description("All ACH")] All,

    [Description("Active ACH")] Active,

    [Description("Inactive ACH")] Inactive
}