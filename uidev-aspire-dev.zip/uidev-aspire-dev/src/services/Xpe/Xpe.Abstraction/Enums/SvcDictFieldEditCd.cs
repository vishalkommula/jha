﻿namespace Xpe.Abstraction.Enums;

/// Data Dictionary Field Edit Cd's available
/// </summary>
public enum SvcDictFieldEditCd
{
    CURRENCY,
    RATE,
    DATETIME,
    DATE,
    TIME,
    PHONE1,
    PHONE2,
    PHONE3,
    YESNO,
    SPECIAL,
    DATETIMELONG,
    TIMELONG,
    ZIPCODE,
    NUMERIC,
    JULIAN,
    PERCENT,
    SSN,
    TAXID,
    DATEYEARS,
    DATEMONTHS,
    DATEDAYS,
    PHONE4,
    PHONE5,
    GLABNORMALBAL,
    NotSet
}