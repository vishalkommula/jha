﻿using System;

namespace Xpe.Abstraction.Enums;

[Serializable]
public enum ProductFieldType
{
    NotSet,
    Header,
    Blank,
    Field,
    Column,
    Folder,
    Content,
    Label
}