﻿namespace Xpe.Abstraction.Enums;

public enum EventProgram
{
    FieldEditor,
    ScreenEditor,
    UserMaintenance,
    TemplateMaintenance,
    SystemMaintenance,
    InstitutionMaintenance
}