﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum NavigationResponseType
{
    [Description("Notify Can proceed with navigation in progress")]
    Proceed,

    [Description("Notify Cancel navigation in progress")]
    Cancel
}