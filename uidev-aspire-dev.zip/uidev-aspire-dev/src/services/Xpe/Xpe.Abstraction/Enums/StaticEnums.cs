using System.Collections.Generic;
using JackHenry.JHAContractTypes;
using Xpe.Abstraction.Model;

namespace Xpe.Abstraction.Enums;

public class StaticEnums
{
    private static ParmValues formatStrings;

    private static ParmValues usage;

    public static List<string> NumericSeparators => new() { " ", "+", "-", "*", "/", "(", ")" };

    public static List<string> DateSeparators => new() { "-", "+" };

    public static List<string> StringSeparators => new() { "Space", ";", ":", "-", "/", "|", "&", "," };

    public static string GetFormatDescritpion(string format)
    {
        var val = GetFormatStrings().GetByCode(format);

        if (val != null)
        {
            return val.ParmValDesc;
        }

        return null;
    }

    public static ParmValues GetFormatStrings()
    {
        if (formatStrings == null)
        {
            formatStrings = new ParmValues();
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = string.Empty,
                ParmValDesc = string.Empty
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "CURRENCY",
                ParmValDesc = "Currency"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "RATE",
                ParmValDesc = "Interest Rate"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "DATETIME",
                ParmValDesc = "Date & Time "
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "DATE",
                ParmValDesc = "Date"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "TIME",
                ParmValDesc = "Time"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "DATETIMELONG",
                ParmValDesc = "Date & Time Include Seconds"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "TIMELONG",
                ParmValDesc = "Time Include Seconds"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "PHONE1",
                ParmValDesc = "Phone (XXX)XXX-XXXX"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "PHONE2",
                ParmValDesc = "Phone XXX-XXX-XXXX"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "PHONE3",
                ParmValDesc = "Phone XXX-XXXX"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "PHONE4",
                ParmValDesc = "International LandLine XXX-XX-X-XXXXXXX"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "PHONE5",
                ParmValDesc = "International CellPhone XXX-XX-XXXXXXXXX"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "YESNO",
                ParmValDesc = "Yes/No"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "SPECIAL",
                ParmValDesc = "Special"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "ZIPCODE",
                ParmValDesc = "Zip Code XXXXX-XXXX"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "NUMERIC",
                ParmValDesc = "Numeric"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "JULIAN",
                ParmValDesc = "Julian"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "PERCENT",
                ParmValDesc = "Percent"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "SSN",
                ParmValDesc = "SSN XXX-XX-XXXX"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "TAXID",
                ParmValDesc = "Tax ID XX-XXXXXXXX"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "DATEDAYS",
                ParmValDesc = "Days"
            });
            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "DATEMONTHS",
                ParmValDesc = "Months"
            });

            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "DATEYEARS",
                ParmValDesc = "Years"
            });

            formatStrings.Add(new ParmValSrchRec_CType
            {
                ParmValCode = "GLABNORMALBAL",
                ParmValDesc = "GL Abnormal Balance"
            });
        }

        return formatStrings;
    }

    public static string GetMsgTypeCode(MessageTypes msgType)
    {
        var code = string.Empty;

        switch (msgType)
        {
            case MessageTypes.Alert:
                return "Alert";

            case MessageTypes.Collateral:
                return "Collat";

            case MessageTypes.Collections:
                return "Col";

            case MessageTypes.Message:
                return "NonClsf";

            case MessageTypes.ExcessODComment:
                return "ODPrvlg";

            case MessageTypes.PassPort:
                return "T";
        }

        return code;
    }

    public static ParmValues GetUsage()
    {
        if (usage == null)
        {
            usage = new ParmValues();
            usage.Add(new ParmValSrchRec_CType
            {
                ParmValCode = string.Empty,
                ParmValDesc = string.Empty
            });
            usage.Add(new ParmValSrchRec_CType
            {
                ParmValCode = SvcDictFieldUsage.ACCT.ToString(),
                ParmValDesc = "Account"
            });
            usage.Add(new ParmValSrchRec_CType
            {
                ParmValCode = SvcDictFieldUsage.CALC.ToString(),
                ParmValDesc = "Calculated Concatenation"
            });
            usage.Add(new ParmValSrchRec_CType
            {
                ParmValCode = SvcDictFieldUsage.CONCAT.ToString(),
                ParmValDesc = "String Concatenation"
            });
            usage.Add(new ParmValSrchRec_CType
            {
                ParmValCode = SvcDictFieldUsage.EMAIL.ToString(),
                ParmValDesc = "Email"
            });
            usage.Add(new ParmValSrchRec_CType
            {
                ParmValCode = SvcDictFieldUsage.SYSTEM.ToString(),
                ParmValDesc = "System"
            });
            usage.Add(new ParmValSrchRec_CType
            {
                ParmValCode = SvcDictFieldUsage.URL.ToString(),
                ParmValDesc = "Web URL Address"
            });
            usage.Add(new ParmValSrchRec_CType
            {
                ParmValCode = SvcDictFieldUsage.BANNER.ToString(),
                ParmValDesc = "Banner"
            });
            usage.Add(new ParmValSrchRec_CType
            {
                ParmValCode = SvcDictFieldUsage.DATECALC.ToString(),
                ParmValDesc = "Date Calculation"
            });
        }

        return usage;
    }

    public enum BankAppCodes
    {
        LN,
        DD,
        CI,
        CT,
        CO,
        CF,
        SD,
        LE
    }
}