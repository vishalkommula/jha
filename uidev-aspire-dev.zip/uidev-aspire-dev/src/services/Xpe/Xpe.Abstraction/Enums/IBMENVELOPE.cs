﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum IBMENVELOPE : byte
{
    [Description("*NONE")] NONE = 0XFF,
    [Description("*MFRTYPMDL")] MFRTYPMDL = 0X00,
    [Description("*B5")] B5 = 0X06,
    [Description("*MONARCH")] MONARCH = 0x09,
    [Description("*NUMBER9")] NUMBER9 = 0X0A,
    [Description("*NUMBER10")] NUMBER10 = 0X0B,
    [Description("*C5")] C5 = 0X0C,
    [Description("*DL")] DL = 0X0D
}