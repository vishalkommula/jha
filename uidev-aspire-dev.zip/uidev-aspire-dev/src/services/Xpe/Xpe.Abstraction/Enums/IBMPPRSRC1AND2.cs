﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum IBMPPRSRC1AND2 : byte
{
    [Description("*NONE")] NONE = 0XFF,
    [Description("*MFRTYPMDL")] MFRTYPMDL = 0X00,
    [Description("*LETTER")] LETTER = 0X01,
    [Description("*LEGAL")] LEGAL = 0X02,
    [Description("*EXECUTIVE")] EXECUTIVE = 0X03,
    [Description("*A4")] A4 = 0X04,
    [Description("*A5")] A5 = 0X05,
    [Description("*B5")] B5 = 0X06,
    [Description("*CONT80")] CONT80 = 0X07,
    [Description("*CONT132")] CONT132 = 0X08,
    [Description("*A3")] A3 = 0X0E,
    [Description("*B4")] B4 = 0X0F,
    [Description("*LEDGER")] LEDGER = 0X10
}