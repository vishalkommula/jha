﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum OFACMatchType
{
    [Description("Address")] Addr,

    [Description("Seasonal address")] SeasonalAddr,

    [Description("Customer name")] Custname,

    [Description("OFAC Name")] OFACName,

    [Description("OFAC Alias")] OFACAlias
}