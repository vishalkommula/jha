﻿namespace Xpe.Abstraction.Enums;

public enum NSFStat
{
    NotSet,
    Paid,
    Ret,
    Susp,
    OD
}