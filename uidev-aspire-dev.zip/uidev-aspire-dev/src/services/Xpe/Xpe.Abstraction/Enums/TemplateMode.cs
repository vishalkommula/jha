﻿namespace Xpe.Abstraction.Enums;

public enum TemplateMode
{
    Copy,
    Add
}