﻿namespace Xpe.Abstraction.Enums;

public enum NavigationType
{
    None,
    Next,
    Previous,
    Exit,
    Submit,
    Inquiry,
    Refresh,
    Import,
    InitializeAdd,
    EditModeStarting,
    NavigateRequest,
    BatchNumberChanged,
    DoAdd,
    DoAddFedItems,
    SetView
}