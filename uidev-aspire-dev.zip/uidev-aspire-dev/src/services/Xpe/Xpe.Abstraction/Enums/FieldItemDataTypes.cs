﻿namespace Xpe.Abstraction.Enums;

public enum FieldItemDataTypes
{
    Text,
    LongText,
    MaskedText,
    List,
    Date,
    DateTime,
    Time,
    Currency,
    Number,
    Code,
    Rate,
    YesNo
}
