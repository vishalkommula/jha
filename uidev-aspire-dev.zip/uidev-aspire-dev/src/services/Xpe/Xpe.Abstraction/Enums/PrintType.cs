﻿using System;

namespace Xpe.Abstraction.Enums;

[Serializable]
public enum PrintType
{
    Header,
    Footer
}