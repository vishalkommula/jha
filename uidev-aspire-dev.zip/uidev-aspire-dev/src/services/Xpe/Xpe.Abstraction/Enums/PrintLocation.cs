﻿using System;

namespace Xpe.Abstraction.Enums;

[Serializable]
public enum PrintLocation
{
    Left,
    Middle,
    Right
}