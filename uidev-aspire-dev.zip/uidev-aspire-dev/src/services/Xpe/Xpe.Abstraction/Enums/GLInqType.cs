﻿namespace Xpe.Abstraction.Enums;

public enum GLInqType
{
    PriorEOM,
    Cnsldt,
    Cur
}