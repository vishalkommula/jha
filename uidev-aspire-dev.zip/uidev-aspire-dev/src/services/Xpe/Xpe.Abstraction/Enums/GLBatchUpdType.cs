﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum GLBatchUpdType
{
    NotSet,
    [Description("UnApprove")] U,
    [Description("Approve")] A,
    [Description("In Process")] I,
    [Description("Not In Process")] NI,
    [Description("Delete")] Delete
}