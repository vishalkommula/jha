﻿namespace Xpe.Abstraction.Enums;

public enum VisualStyleFilterContextType
{
    NotSet,
    Customer,
    Account,
    InstDefFields,
    CoreParmSrchFields
}