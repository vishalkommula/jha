﻿namespace Xpe.Abstraction.Enums;

public enum View
{
    AllFields,
    ProductFields
}