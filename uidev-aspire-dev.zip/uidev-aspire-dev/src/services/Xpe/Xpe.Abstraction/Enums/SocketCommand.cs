﻿// -----------------------------------------------------------------------
// <copyright file="SocketCommand.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace Xpe.Abstraction.Enums;

/// Valid Socket Commands.
/// </summary>
public class SocketCommand
{
    /// <summary>
    ///     The logon. Log on the user (initial request only)
    /// </summary>
    public const string LOGON = "LOGON";

    /// <summary>
    ///     The logoff. Log off the user and end the session
    /// </summary>
    public const string LOGOFF = "LOGOFF";

    /// <summary>
    ///     The error
    /// </summary>
    public const string ERROR = "ERROR";

    /// <summary>
    ///     The timeout
    /// </summary>
    public const string TIMEOUT = "TIMEOUT";

    /// <summary>
    ///     The screenid
    /// </summary>
    public const string SCREENID = "SCREENID";

    /// <summary>
    ///     The screenmap
    /// </summary>
    public const string SCREENMAP = "SCREENMAP";

    /// <summary>
    ///     The startup
    /// </summary>
    public const string STARTUP = "STARTUP";

    /// <summary>
    ///     The sysrq
    /// </summary>
    public const string SYSRQ = "SYSRQ";

    /// <summary>
    ///     The attn
    /// </summary>
    public const string ATTN = "ATTN";

    /// <summary>
    ///     The errorhelp
    /// </summary>
    public const string ERRORHELP = "ERRORHELP";

    /// <summary>
    ///     The testrq
    /// </summary>
    public const string TESTRQ = "TESTRQ";

    /// <summary>
    ///     The ping
    /// </summary>
    public const string PING = "PING";

    /// <summary>
    ///     The device
    /// </summary>
    public const string DEVICE = "DEVICE";

    public const string PRINTER = "PRINTER";
}