﻿namespace Xpe.Abstraction.Enums;

public enum PayeeAccountType
{
    Payee,
    Account,
    None
}