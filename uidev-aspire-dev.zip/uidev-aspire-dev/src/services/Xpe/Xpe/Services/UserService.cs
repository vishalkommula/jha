﻿using System;
using System.Collections.Generic;
using System.Linq;
using JackHenry.UID.Identity;
using Xpe.Abstraction;
using Xpe.Abstraction.Model;
using Xpe.Abstraction.Services;
using MediatR;

using Microsoft.Extensions.Caching.Memory;
using Xpe.Cache;
using Xpe.Cache.Infrastructure;
using static System.Boolean;

namespace Xpe.Services;

public class UserService : IUserService
{
    private const string CoreAppUri = "http://jackhenry.com/application/Core";

    public UserService(IUserCache cacheManager)
    {
        CacheManager = cacheManager;
    }

    private IUserCache CacheManager { get; }
    
    public CurrentUserInfo CurrentUserInfo { get; set; }

    public XpeConnectionContext XpeConnectionContext { get; private set; }
    
    public BankingAlias? GetCurrentBankingAlias()
    {
        // TODO: MockData - Replace with real call

        var securityToken = new WrappedImsSecurityToken(XpeConnectionContext.SamlAssertion);
        var aliases = securityToken.GetAliases(CoreAppUri);
        var aliasClaim = aliases.LastOrDefault(x => x.AliasContext.Contains("iCoreDev"));

        if (aliasClaim == null)
        {
            return null;
        }

        if (!TryParse(aliasClaim.AliasDft, out var isDefaultAlias))
        {
            isDefaultAlias = false;
        }

        var iAdapter = aliasClaim.AliasContext.Split(";").FirstOrDefault();

        return new BankingAlias(
            aliasClaim.Alias,
            aliasClaim.AliasDesc,
            isDefaultAlias,
            iAdapter);
    }

    public void Initialize(string userIdentifier)
    {
        var response = CacheManager.GetInMemoryCache<XpeConnectionContext>(
            userIdentifier, CacheConstants.XpeContextKey);

        if (!response.IsFound || response.Value == null)
        {
            throw new ApplicationException($"{nameof(XpeConnectionContext)} not found.");
        }

        XpeConnectionContext = response.Value;
    }
}