using Xpe.Abstraction.Infrastructure;
using Xpe.Abstraction.Services;

namespace Xpe.Services;

public class ISeriesConnectionInfoService : IISeriesConnectionInfoService
{
    public ISeriesConnectionInfoService()
    {        
        ConnectionInfo = new ISeriesConnectionInfo
        {
            HostName = "iCoreDev.jhacorp.com",
            Port = 51040,
            ReceiveBufferSize = 66000,
            Product = "S",
            User = null,
            Device = "          "
        };
    }

    public ISeriesConnectionInfo ConnectionInfo { get; private set; }

    public void Initialize(ISeriesConnectionInfo connectionInfo)
    {
        this.ConnectionInfo = connectionInfo;
    }

    public void Initialize(string userIdentifier)
    {
        this.ConnectionInfo.User = userIdentifier;
    }
}