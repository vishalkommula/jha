﻿using System;
using System.IO;
using System.Linq;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using Ardalis.GuardClauses;

using Xpe.Abstraction.Infrastructure;
using Xpe.Abstraction.Services;
using Microsoft.Extensions.Logging;

using static JackHenry.Banking.IAdapter.Infrastructure.Enums.StaticEnums;

namespace Xpe.Infrastructure;

// ReSharper disable once InconsistentNaming
public class ISeriesServer : IISeriesServer
{
    private readonly object serverStreamLock = new();

    public ISeriesServer(ILogger<ISeriesServer> logger,
        IDnsLookup dnsLookup,
        ITcpClient tcpClient,
        IISeriesConnectionInfoService connectionInfoService,
        IISeriesConnectionCallbackStrategy connectionCallbackStrategy,
        ICertificateValidationStrategy certificateValidationStrategy)
    {
        Logger = Guard.Against.Null(logger,
            nameof(logger));

        DnsLookup = Guard.Against.Null(dnsLookup,
            nameof(dnsLookup));

        ServerSocket = Guard.Against.Null(tcpClient,
            nameof(tcpClient));

        ConnectionInfoService = Guard.Against.Null(connectionInfoService,
            nameof(connectionInfoService));

        ConnectionCallbackStrategy = Guard.Against.Null(connectionCallbackStrategy,
            nameof(connectionCallbackStrategy));

        CertificateValidationStrategy = Guard.Against.Null(certificateValidationStrategy,
            nameof(certificateValidationStrategy));

        ConnectionStatus = new ManualResetEvent(false);

        DataStreamBuffer = new byte[ConnectionInfoService.ConnectionInfo.ReceiveBufferSize];
    }

    private IISeriesConnectionInfoService ConnectionInfoService { get; }
    private ILogger<IISeriesServer> Logger { get; }
    private IDnsLookup DnsLookup { get; }
    private IISeriesConnectionCallbackStrategy ConnectionCallbackStrategy { get; }
    private ICertificateValidationStrategy CertificateValidationStrategy { get; }

    public bool IsConnected { get; set; }
    public Stream ServerStream { get; set; }
    public ITcpClient ServerSocket { get; set; }
    public ManualResetEvent ConnectionStatus { get; set; }
    public byte[] DataStreamBuffer { get; set; }

    public void ConnectToServer(ISeriesConnectionInfo connectionInfo)
    {
        try
        {
            ConnectionStatus.Reset();

            var ipAddresses = DnsLookup.GetHostAddress(connectionInfo.HostName);

            if (ipAddresses?.Any() != true)
            {
                throw new Exception("DNS could not resolve hostname.");
            }

            var ipAddress = ipAddresses.First();
            var addressFamily = DnsLookup.GetAddressFamily(ipAddress);

            if (addressFamily == AddressFamily.InterNetworkV6 && DnsLookup.OSSupportsIPv6() == false &&
                ipAddresses.Any(i =>
                {
                    var aFam = DnsLookup.GetAddressFamily(i);
                    return aFam != AddressFamily.InterNetworkV6;
                }))
            {
                ipAddress = ipAddresses
                    .First(i => DnsLookup.GetAddressFamily(i) != AddressFamily.InterNetworkV6);
            }

            ServerSocket.Initialize(ipAddress.AddressFamily,
                connectionInfo.ReceiveBufferSize);

            if (false)
            {
                // 992 for secure telnet
                ServerSocket.BeginConnect(ipAddress,
                    connectionInfo.Port,
                    ConnectionCallbackStrategy.ConnectToServerCallback,
                    this);

                // wait here until the connect finishes.
                // The callback sets allDone.
                ConnectionStatus.WaitOne();

                if (!IsConnected)
                {
                    throw new Exception("Connection failed.");
                }

                SslStream sslStream = new SslStream(this.ServerSocket.GetStream(), false, new RemoteCertificateValidationCallback(this.CertificateValidationCallback));

                sslStream.AuthenticateAsClient(connectionInfo.HostName, null, SslProtocols.Tls12, false);

                Logger.LogTrace(
                    string.Format(
                        "SSL connection established. SSL Protocol: {0}, Key Exchance Algorithm: {1}, Key Exchange Strength: {2}, Cipher Algorithm: {3}, Cipher Strength {4}, Hash Algorithm: {5}, Hash Strength: {6}. ",
                        sslStream.SslProtocol.ToString(),
                        sslStream.KeyExchangeAlgorithm.ToString(),
                        sslStream.KeyExchangeStrength.ToString(),
                        sslStream.CipherAlgorithm.ToString(),
                        sslStream.CipherStrength.ToString(),
                        sslStream.HashAlgorithm.ToString(),
                        sslStream.HashStrength.ToString()),
                    LogType.Trace);

                this.ServerStream = sslStream;
            }
            else
            {
                // 23 for telnet
                ServerSocket.BeginConnect(ipAddress,
                    connectionInfo.Port,
                    ConnectionCallbackStrategy.ConnectToServerCallback,
                    this);

                // wait here until the connect finishes.
                // The callback sets allDone.
                ConnectionStatus.WaitOne();

                if (!IsConnected)
                {
                    throw new Exception("Connection failed.");
                }

                this.ServerStream = this.ServerSocket.GetStream();
            }
        }
        catch (Exception ex)
        {
            Logger.LogError(ex,
                "ISeries connection failed with \"{Reason}\" in method {Method}",
                ex.Message,
                nameof(ConnectToServer));

            throw new Exception($"An error occurred attempting to connect to the server: {ex.Message}");
        }
    }

    public void DisconnectFromServer()
    {
        try
        {
            ServerStream?.Dispose();
            ServerStream = null;

            ServerSocket?.Close();
            ServerSocket = null;
        }
        finally
        {
            IsConnected = false;

            Logger.LogDebug("{Method}: ISeries server disconnected",
                nameof(DisconnectFromServer));
        }
    }

    public void SendRequestToServer(byte[] request)
    {
        lock (serverStreamLock)
        {
            ServerStream?.Write(request, 0, request.Length);
            ServerStream?.Flush();
        }

        Logger.LogDebug("{Method}: ServerStream flushed",
            nameof(SendRequestToServer));
    }

    private bool CertificateValidationCallback(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
    {
        try
        {
            bool chainValidated = false;

            // Check all properties
            chain.ChainPolicy.VerificationFlags = X509VerificationFlags.NoFlag;

            ////Set Revocation
            chain.ChainPolicy.RevocationMode = X509RevocationMode.Online;
            chain.ChainPolicy.RevocationFlag = X509RevocationFlag.EntireChain;

            // Build the chain
            chain.Build(new X509Certificate2(certificate));

            // Are there any failures from building the chain?
            if (chain.ChainStatus.Length == 0)
            {
                chainValidated = true;
            }
            else
            {
                // If there is a status, verify the status is NoError
                if (chain.ChainStatus[0].Status == X509ChainStatusFlags.NoError)
                {
                    chainValidated = true;
                }
                else
                {
                    StringBuilder statArray = new StringBuilder();
                    foreach (X509ChainStatus stat in chain.ChainStatus)
                    {
                        statArray.AppendFormat(stat.Status.ToString() + " --> " + stat.StatusInformation, Environment.NewLine);
                    }

                    throw new AuthenticationException(string.Format("iAdapter - SSL Certificate Validation Error: {0}", sslPolicyErrors + Environment.NewLine + statArray.ToString()));
                }
            }

            return chainValidated;
        }
        catch (AuthenticationException aex)
        {
            throw new AuthenticationException($"{aex.Message} Certificate Common Name: {new X509Certificate2(certificate).GetNameInfo(X509NameType.SimpleName, false)}");
        }
    }
}