﻿using System;
using System.Collections.Generic;
using System.Text;
using Xpe.Abstraction.Model;

namespace Xpe.Infrastructure;

public class SocketHeader
{
    public SocketHeader(List<byte> snaRecord)
    {
        Format = Encoding.UTF8.GetString(snaRecord.GetRange(0, 6).ToArray());
        Length = Convert.ToInt16(Encoding.UTF8.GetString(snaRecord.GetRange(6, 7).ToArray()));
        Product = Encoding.UTF8.GetString(snaRecord.GetRange(13, 1).ToArray());
        User = Encoding.UTF8.GetString(snaRecord.GetRange(14, 10).ToArray());
        Command = Encoding.UTF8.GetString(snaRecord.GetRange(24, 10).ToArray());
        OperationCode = (OperationCode) snaRecord[34];

        snaRecord.RemoveRange(0, 35);
    }

    public SocketHeader(string product, string user, string command, OperationCode operationCode)
    {
        Format = "FUSION";
        Product = product;
        User = user;
        Command = command;
        OperationCode = operationCode;
    }

    public string Format { get; set; }

    public int Length { get; set; }

    public string Product { get; set; }

    public string Command { get; set; }

    public string User { get; set; }

    public OperationCode OperationCode { get; set; }

    public List<byte> GetRequest(List<byte> data = null)
    {
        var request = new List<byte>();

        request.AddRange(Encoding.UTF8.GetBytes(Format));
        request.AddRange(Encoding.UTF8.GetBytes(Product));
        request.AddRange(Encoding.UTF8.GetBytes($"{User,-10}"));
        request.AddRange(Encoding.UTF8.GetBytes($"{Command,-10}"));
        request.Add((byte) OperationCode);

        if (data is { Count: > 0 })
        {
            request.AddRange(data);
        }

        // After the request has been build, insert the length at the 6th index.
        Length = request.Count + 7;
        request.InsertRange(6, Encoding.UTF8.GetBytes($"{Length:0000000}"));

        return request;
    }
}