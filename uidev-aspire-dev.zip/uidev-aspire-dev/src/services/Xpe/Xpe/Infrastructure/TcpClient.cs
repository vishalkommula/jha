﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using Ardalis.GuardClauses;
using Xpe.Abstraction.Infrastructure;
using Microsoft.Extensions.Logging;

namespace Xpe.Infrastructure;

public class TcpClient : ITcpClient
{
    public TcpClient(ILogger<TcpClient> logger)
    {
        Logger = logger;
    }

    private System.Net.Sockets.TcpClient Client { get; set; }

    private ILogger<TcpClient> Logger { get; }

    public bool IsConnected => Client.Connected;

    public int ReceiveBufferSize => Client.ReceiveBufferSize;

    public void Initialize(AddressFamily addressFamily, int receiveBufferSize)
    {
        Client = new System.Net.Sockets.TcpClient(addressFamily)
        {
            ReceiveBufferSize = receiveBufferSize
        };

        Guard.Against.Null(Client,
            nameof(Client));
    }

    public void BeginConnect(
        IPAddress ipAddress,
        int port,
        Action<IAsyncResult> connectToServerCallback,
        IISeriesServer state)
    {
        Guard.Against.Null(connectToServerCallback,
            nameof(connectToServerCallback));

        Guard.Against.Null(ipAddress,
            nameof(ipAddress));

        Guard.Against.Null(state,
            nameof(state));

        Client.BeginConnect(ipAddress,
            port,
            new AsyncCallback(connectToServerCallback),
            state);
    }

    public Stream GetStream()
    {
        return Client?.GetStream();
    }

    public void Close()
    {
        Client?.Close();
    }

    public void EndConnect(IAsyncResult asyncResult)
    {
        Client?.EndConnect(asyncResult);
    }
}