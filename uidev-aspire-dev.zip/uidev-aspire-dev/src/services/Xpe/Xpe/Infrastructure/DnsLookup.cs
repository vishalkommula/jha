﻿using System.Net;
using System.Net.Sockets;
using Xpe.Abstraction.Infrastructure;

namespace Xpe.Infrastructure;

public class DnsLookup : IDnsLookup
{
    public AddressFamily GetAddressFamily(IPAddress address)
    {
        return address.AddressFamily;
    }

    public IPAddress[] GetHostAddress(string hostName)
    {
        return Dns.GetHostAddresses(hostName);
    }

    public bool OSSupportsIPv6()
    {
        return Socket.OSSupportsIPv6;
    }
}