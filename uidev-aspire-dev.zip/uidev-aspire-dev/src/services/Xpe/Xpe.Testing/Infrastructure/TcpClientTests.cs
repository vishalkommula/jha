﻿using Jha.X3.Xpe.Abstraction.Infrastructure;
using Jha.X3.Xpe.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Jha.X3.Xpe.Testing.Infrastructure;

public class TcpClientTests
{
    public TcpClientTests()
    {
        Logger = new Mock<ILogger<TcpClient>>();

        ServiceProvider = new ServiceCollection()
            .AddSingleton(_ => Logger.Object)
            .AddSingleton<ITcpClient, TcpClient>()
            .BuildServiceProvider();

        TcpClient = ServiceProvider.GetRequiredService<ITcpClient>();
    }

    private ServiceProvider ServiceProvider { get; }

    private ITcpClient TcpClient { get; }

    private Mock<ILogger<TcpClient>> Logger { get; }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.UnitTest)]
    public void Can_create()
    {
        Assert.NotNull(TcpClient);
    }
}