﻿using System;
using System.Threading;
using Jha.X3.Xpe.Abstraction.Infrastructure;
using Jha.X3.Xpe.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Jha.X3.Xpe.Testing.Infrastructure;

// ReSharper disable once InconsistentNaming
public class IISeriesConnectionCallbackStrategyTests
{
    public IISeriesConnectionCallbackStrategyTests()
    {
        MockLogger = new Mock<ILogger<ISeriesConnectionCallbackStrategy>>();
        MockAsyncResult = new Mock<IAsyncResult>();
        MockTcpClient = new Mock<ITcpClient>();
        MockServer = new Mock<IISeriesServer>();

        ServiceProvider = new ServiceCollection()
            .AddSingleton(_ => MockLogger.Object)
            .AddSingleton(_ => MockAsyncResult.Object)
            .AddSingleton(_ => MockTcpClient.Object)
            .AddSingleton(_ => MockServer.Object)
            .AddSingleton<IISeriesConnectionCallbackStrategy, ISeriesConnectionCallbackStrategy>()
            .BuildServiceProvider();

        CallbackStrategy = ServiceProvider.GetService<IISeriesConnectionCallbackStrategy>();
    }

    private IServiceProvider ServiceProvider { get; }
    private IISeriesConnectionCallbackStrategy CallbackStrategy { get; }
    private Mock<ILogger<ISeriesConnectionCallbackStrategy>> MockLogger { get; }
    private Mock<IAsyncResult> MockAsyncResult { get; }
    private Mock<ITcpClient> MockTcpClient { get; }
    private Mock<IISeriesServer> MockServer { get; }

    private void ResetMocks()
    {
        MockLogger.Reset();
        MockAsyncResult.Reset();
        MockTcpClient.Reset();
        MockServer.Reset();
    }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.UnitTest)]
    public void Success_for_callback()
    {
        ResetMocks();

        MockAsyncResult.Setup(o => o.AsyncState)
            .Returns(() => MockServer.Object);
        MockServer.Setup(o => o.ConnectionStatus)
            .Returns(() => new ManualResetEvent(false));
        MockServer.Setup(o => o.ServerSocket)
            .Returns(() => MockTcpClient.Object);
        MockTcpClient.Setup(o => o.IsConnected).Returns(true);

        CallbackStrategy.ConnectToServerCallback(MockAsyncResult.Object);

        MockTcpClient.Verify(o => o.EndConnect(MockAsyncResult.Object));
        MockServer.VerifySet(o => o.IsConnected = true);
    }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.UnitTest)]
    public void Success_when_not_connected()
    {
        ResetMocks();

        MockAsyncResult.Setup(o => o.AsyncState)
            .Returns(() => MockServer.Object);
        MockServer.Setup(o => o.ConnectionStatus)
            .Returns(() => new ManualResetEvent(false));
        MockServer.Setup(o => o.ServerSocket)
            .Returns(() => MockTcpClient.Object);
        MockTcpClient.Setup(o => o.IsConnected).Returns(false);

        CallbackStrategy.ConnectToServerCallback(MockAsyncResult.Object);

        MockServer.VerifySet(o => o.IsConnected = false);

        // TODO: Verify logging
    }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.UnitTest)]
    public void Success_for_exception()
    {
        ResetMocks();

        MockAsyncResult.Setup(o => o.AsyncState)
            .Returns(() => MockServer.Object);
        MockServer.Setup(o => o.ConnectionStatus)
            .Returns(() => new ManualResetEvent(false));
        MockServer.Setup(o => o.ServerSocket)
            .Returns(() => MockTcpClient.Object);
        MockTcpClient.Setup(o => o.IsConnected).Returns(true);

        MockTcpClient
            .Setup(o => o.EndConnect(MockAsyncResult.Object))
            .Throws(() => new Exception("Testing"));

        CallbackStrategy.ConnectToServerCallback(MockAsyncResult.Object);

        MockServer.VerifySet(o => o.IsConnected = false);

        // TODO: Verify logging
    }
}