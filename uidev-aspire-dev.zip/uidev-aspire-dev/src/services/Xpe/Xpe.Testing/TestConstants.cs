﻿namespace Jha.X3.Xpe.Testing;

public static class TestConstants
{
    public const string TestCategory = "Category";
    public const string UnitTest = "UnitTest";
    public const string IntegrationTest = "IntegrationTest";
}