﻿// -----------------------------------------------------------------------
// <copyright file="ITrustedCertificateSettings.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Interfaces;

using JackHenry.Banking.IAdapter.Infrastructure.Models;

using System.Collections.ObjectModel;

public interface ITrustedCertificateSettings
{
    ObservableCollection<TrustedCertificateModel> TrustedCerts
    {
        get;
        set;
    }

    string TLSSecurityStrength
    {
        get;
        set;
    }
}
