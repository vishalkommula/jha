// ----------------------------------------------------------------------
// <copyright file="GenericExceptions.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// ----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Models; 
using JackHenry.Banking.IAdapter.Infrastructure.Extensions;

using EBO = JackHenry.Enterprise.BusinessObjects;

public class GenericExceptions
{
    public const string AccountIsCurrentlyLocked = "Account is currently locked. Please try again or cancel.";
    public const string RecordIsCurrentlyLocked = "Record is currently locked. Please try again or cancel.";
    public const string AccountNotFound = "Account not found";
    public const string AccountRelationshipsRetrievedException = "Error retrieving account relationships";
    public const string AccountRetrievedException = "processing retrieved account";
    public const string CustomerNotFound = "Customer not found";
    public const string CustomerRetrievedException = "Error processing retrieved customer account";
    public const string DefaultErrorMessage = "An error occurred processing your request. Please see the log for further information.";
    public const string DefaultProductDoesNotExist = "Default screen does not exist for ";
    public const string ErrorInResults = "Results might be incomplete, there were errors for this search.";
    public const string ErrorOpeningDocumentMergeTemplate = "Unable to open the template file. Please ensure the file exists (and is not open in another application) and try the merge again.";
    public const string ErrorRetrievingACHDistributionDefaults = "Error Retrieving ACH Distribution Defaults";
    public const string IAdapterDown = "Unable to communicate with the IAdapter.";
    public const string ImageStatmentPendingLoading = "Your image statement is still generating. Please try again momentarily.";
    public const string InvalidAccountNavigationReturn = "Invalid account look up navigation return";
    public const string InvalidEmail = "Please enter a valid email";
    public const string JesConnectionFailureException = "***Could not connect to the JES server***";
    public const string NavigationServiceExceptionAddView = "Error adding view within navigation service";
    public const string NoAvailableInstitutions = "No available institutions so application will close. ";
    public const string NoRecordsMatchSelectionCriteria = "No records match selection criteria";
    public const string NoRecordsReturnedForSearchCriteria = "No records were returned for the search criteria";
    public const string NoRecordsToDisplay = "No records to display";
    public const string NotAuthorized = "Not Authorized";
    public const string NotAuthorizedToViewAccount = "Not Authorized to View Account";
    public const string PartialResultsDisplayed = "Displaying first {0} of {1} results. For more specific results, please refine your search.";
    public const string PhoneNumberNotValid = "Phone Number is not valid";
    public const string RateScheduleRequired = "Rate Schedule required when rate schedule code is set to Yes";
    public const string SaveUserPersistedSettingException = "Error persisting user settings";
    public const string SearchAccountNumberLength = "Must enter at least last 4 digits of account number";
    public const string SearchCardNumberLength = "Must enter at least last 4 digits of card number";
    public const string SearchCriteriaEmpty = "Search criteria can not be empty";
    public const string SearchPhoneNumberLength = "Must enter at least last 4 digits of phone number";
    public const string SearchSdbAccountNumberLength = "Must enter at least last 2 digits of account number";
    public const string SearchTaxIdNumberLength = "Must enter at least last 4 digits of tax ID number";
    public const string SSNTaxIdNotValid = "SSN/Tax ID is not valid";
    public const string SummaryProductDoesNotExist = "Summary screen does not exist for ";
    public const string UnableToLoadIMSUser = "Communications between the Xperience message bus and application are not valid at this time.  Application will shutdown.";
    public const string UnableToRetrieveIMSUser = "Unable to retrieve the IMS user from the Xperience interface";
    public const string UnexpectedException = "UnexpectedException";
    public const string UnexpectedOthereResult = "UnexpectedOtherResult";
    public const string ZipCodeNotValid = "Zip Code is not valid";
    public const string ProductDoesNotExist = "Product screen does not exist for ";

    public static void PrefixIAdapterErrorMessageWithServiceProvider<T>(T faultType)
    {
        if (faultType is EBO.Tpg.HdrFault_MType)
        {
            foreach (EBO.Tpg.FaultMsgRec_CType fault in (faultType as EBO.Tpg.HdrFault_MType).FaultRecInfoArray)
            {
                PrefixIAdapterErrorMessageWithServiceProvider<EBO.Tpg.FaultMsgRec_CType>(fault);
            }
        }
        else if (faultType is EBO.Tpg.FaultMsgRec_CType)
        {
            PrefixIAdapterErrorProvider(faultType as EBO.Tpg.FaultMsgRec_CType);
        }
    }

    private static void PrefixIAdapterErrorProvider(EBO.Tpg.FaultMsgRec_CType faultMessage)
    {
        long errorCode;
        string serviceProvider = string.Empty;

        if (long.TryParse(faultMessage.ErrCode.Value, out errorCode) && FaultIsErrorMessage(faultMessage))
        {
            if (errorCode >= 9000)
            {
                serviceProvider = ServiceProvider.IAdapter;
            }
            else
            {
                serviceProvider = ServiceProvider.BusinessServices;
            }
        }

        faultMessage.ErrDesc.Value = string.Format("{0}{1}", GenericExceptions.AddColon(serviceProvider), faultMessage.ErrDesc.Value);
    }

    private static bool FaultIsErrorMessage(EBO.Tpg.FaultMsgRec_CType faultMessage)
    {
        return faultMessage.ErrCat.Value.IsCaseInsensativeEqual("error");
    }

    private static string AddColon(string message)
    {
        string returnMessage = string.Empty;

        if (!string.IsNullOrEmpty(message))
        {
            returnMessage = message + " : ";
        }

        return returnMessage;
    }
}
