// -----------------------------------------------------------------------
// <copyright file="JhaSerializer.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Models;

using JackHenry.Banking.IAdapter.Infrastructure.Interfaces;

using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

public class JhaSerializer
{
    private static readonly byte[] SALT = new byte[] { 0x26, 0xdc, 0xff, 0x00, 0xad, 0xed, 0x7a, 0xee, 0xc5, 0xfe, 0x07, 0xaf, 0x4d, 0x08, 0x22, 0x3c };

    private static object objectlock = new object();
    private static Dictionary<string, XmlSerializer> serializers = new Dictionary<string, XmlSerializer>();

    public static XmlSerializer GetSerializer(Type type)
    {
        lock (objectlock)
        {
            var key = string.Concat(type.Name, type.GetHashCode().ToString());

            XmlSerializer serializer;

            if (!serializers.TryGetValue(key, out serializer))
            {
                serializer = new XmlSerializer(type);

                serializers.Add(key, serializer);
            }

            return serializer;
        }
    }

    public static object DeserializeUnknownType(string filePath)
    {
        FileInfo f = new FileInfo(filePath);
        using (Stream s = f.Open(FileMode.Open))
        {
            BinaryFormatter b = new BinaryFormatter();
            return b.Deserialize(s);
        }
    }

    public static string Serialize<T>(T o)
    {
        return InternalSerialize(o);
    }

    public static string Serialize(object o)
    {
        return InternalSerialize(o);
    }

    public static void Serialize(object o, string filePath)
    {
        if (o == null)
        {
            return;
        }

        XmlSerialize(o, filePath);
    }

    public static string ToRawXmlString<T>(T obj, XmlQualifiedName[] namespaces = null)
    {
        return SerializeToStrippedXML(GetSerializer(typeof(T)), obj, namespaces);
    }

    public static T XmlDeserialize<T>(string xml)
    {
        if (string.IsNullOrEmpty(xml))
        {
            return default(T);
        }

        return (T)XmlDeserialize(xml, typeof(T));
    }

    public static object XmlDeserialize(string xml, Type type)
    {
        try
        {
            using (StringReader sr = new StringReader(xml))
            {
                XmlSerializer xs = GetSerializer(type);
                return xs.Deserialize(sr);
            }
        }
        catch (Exception ex)
        {
            throw new XmlException("Error deserializing object: " + type.Name, ex);
        }
    }

    public static object XmlDeserializeFromFile(string filePath, Type type)
    {
        using (FileStream r = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Read, FileShare.ReadWrite))
        {
            XmlSerializer xmls = GetSerializer(type);
            return xmls.Deserialize(r);
        }
    }

    public static string XmlSerialize(object obj)
    {
        if (obj == null)
        {
            return string.Empty;
        }

        using (MemoryStream ms = new MemoryStream())
        {
            XmlSerializer xs = GetSerializer(obj.GetType());
            xs.Serialize(ms, obj);
            ms.Seek(0, SeekOrigin.Begin);

            using (StreamReader sr = new StreamReader(ms))
            {
                XmlDocument xd = new XmlDocument();

                xd.LoadXml(sr.ReadToEnd());

                foreach (XmlNode node in xd)
                {
                    if (node.NodeType == XmlNodeType.XmlDeclaration)
                    {
                        xd.RemoveChild(node);
                    }
                }

                return xd.OuterXml;
            }
        }
    }

    public static void XmlSerialize(object obj, string filePath)
    {
        if (obj == null)
        {
            return;
        }

        using (FileStream fs = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
        {
            System.Xml.Serialization.XmlSerializer xmls = new System.Xml.Serialization.XmlSerializer(obj.GetType());

            System.Xml.Serialization.XmlSerializerNamespaces osn = new System.Xml.Serialization.XmlSerializerNamespaces();
            osn.Add(string.Empty, string.Empty);

            xmls.Serialize(fs, obj, osn);
        }
    }

    public static bool EncryptAndSerialize(object obj, string fileName, ILoggingService loggingService)
    {
        try
        {
            using (FileStream fs = File.Open(fileName, FileMode.Create))
            {
                EncryptAndSerialize(obj, fs);
            }

            return true;
        }
        catch (Exception ex)
        {
            loggingService.LogException("Error exporting xml encrypted data", ex.Message, ex);
            return false;
        }
    }

    public static void EncryptAndSerialize(object obj, Stream outputStream)
    {
        string magicStringThatCannotBeChanged = "3e28aa8b-3362-48c5-b923-fcd354ab25dd";
        UnicodeEncoding aue = new UnicodeEncoding();
        using (RijndaelManaged rmcrypto = new RijndaelManaged())
        {
            using (Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(magicStringThatCannotBeChanged, SALT))
            {
                rmcrypto.Key = pdb.GetBytes(32);
                rmcrypto.IV = pdb.GetBytes(16);

                using (CryptoStream cs = new CryptoStream(outputStream, rmcrypto.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    XmlSerializer xmlser = new XmlSerializer(obj.GetType());
                    xmlser.Serialize(cs, obj);
                }
            }
        }
    }

    public static T DecryptAndDeserialize<T>(string filename, ILoggingService loggingService, bool throwError = false)
    {
        try
        {
            string magicStringThatCannotBeChanged = "3e28aa8b-3362-48c5-b923-fcd354ab25dd";

            XmlDocument doc = new XmlDocument();
            doc.PreserveWhitespace = true;

            FileStream afileStream = new FileStream(filename, FileMode.Open);
            StreamReader astreamReader = new StreamReader(afileStream);
            UnicodeEncoding aue = new UnicodeEncoding();
            RijndaelManaged rmcrypto = new RijndaelManaged();

            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(magicStringThatCannotBeChanged, SALT);
            rmcrypto.Key = pdb.GetBytes(32);
            rmcrypto.IV = pdb.GetBytes(16);

            using (CryptoStream acryptoStream = new CryptoStream(afileStream, rmcrypto.CreateDecryptor(), CryptoStreamMode.Read))
            {
                using (XmlReader reader = new XmlTextReader(acryptoStream))
                {
                    doc.Load(reader);
                }

                afileStream.Close();
            }

            return (T)XmlDeserialize<T>(doc.OuterXml);
        }
        catch (Exception ex)
        {
            loggingService.LogException("Error importing xml encrypted data", ex.Message, ex);

            if (throwError)
            {
                throw ex;
            }
        }

        return default(T);
    }

    public static T DecryptAndDeserialize<T>(Stream stream, ILoggingService loggingService, bool throwError = false)
    {
        try
        {
            string magicStringThatCannotBeChanged = "3e28aa8b-3362-48c5-b923-fcd354ab25dd";

            XmlDocument doc = new XmlDocument();
            doc.PreserveWhitespace = true;

            StreamReader astreamReader = new StreamReader(stream);
            UnicodeEncoding aue = new UnicodeEncoding();
            RijndaelManaged rmcrypto = new RijndaelManaged();

            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(magicStringThatCannotBeChanged, SALT);
            rmcrypto.Key = pdb.GetBytes(32);
            rmcrypto.IV = pdb.GetBytes(16);

            using (CryptoStream acryptoStream = new CryptoStream(stream, rmcrypto.CreateDecryptor(), CryptoStreamMode.Read))
            {
                using (XmlReader reader = new XmlTextReader(acryptoStream))
                {
                    doc.Load(reader);
                }

                stream.Close();
            }

            return (T)XmlDeserialize<T>(doc.OuterXml);
        }
        catch (Exception ex)
        {
            loggingService.LogException("Error importing xml encrypted data", ex.Message, ex);

            if (throwError)
            {
                throw ex;
            }
        }

        return default(T);
    }

    private static string InternalSerialize(object o)
    {
        if (o == null)
        {
            return string.Empty;
        }

        return XmlSerialize(o);
    }

    private static string SerializeToStrippedXML(XmlSerializer serializer, object o, XmlQualifiedName[] namespaces)
    {
        StringBuilder sb = new StringBuilder();
        using (System.Xml.XmlWriter xmlWriter = System.Xml.XmlWriter.Create(
                                                                     sb,
                                                                     new System.Xml.XmlWriterSettings()
                                                                     {
                                                                         OmitXmlDeclaration = true,
                                                                         NewLineChars = string.Empty,
                                                                         NewLineHandling = System.Xml.NewLineHandling.Replace
                                                                     }))
        {
            XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
            ns.Add(string.Empty, string.Empty);

            if (namespaces != null)
            {
                foreach (XmlQualifiedName name in namespaces)
                {
                    ns.Add(name.Name, name.Namespace);
                }
            }

            serializer.Serialize(xmlWriter, o, ns);
        }

        return sb.ToString();
    }
}
