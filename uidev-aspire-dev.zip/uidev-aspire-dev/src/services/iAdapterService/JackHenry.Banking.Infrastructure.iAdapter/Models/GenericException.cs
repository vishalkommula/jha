﻿// ----------------------------------------------------------------------
// <copyright file="GenericException.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// ----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Models; 
using System;

[Serializable]
public class GenericException : Exception
{
    private string type;

    public GenericException()
        : this(string.Empty)
    {
    }

    public GenericException(string message)
        : this(null, message)
    {
    }

    public GenericException(string message, Exception innerException)
        : this(null, message, innerException)
    {
    }

    public GenericException(string xtraInfo, string message)
        : this(xtraInfo, message, null)
    {
    }

    public GenericException(string xtraInfo, string message, Exception innerException)
        : base(message, innerException)
    {
        this.ExceptionCreation = DateTime.Now;
        this.XtraInfo = xtraInfo;
    }

    public DateTime ExceptionCreation
    {
        get;
        private set;
    }

    public string ExceptionType
    {
        get
        {
            if (string.IsNullOrEmpty(this.type))
            {
                this.type = this.GetType().ToString();
            }

            return this.type;
        }

        set
        {
            this.type = value;
        }
    }

    public string XtraInfo
    {
        get;
        set;
    }
}
