// -----------------------------------------------------------------------
// <copyright file="CompressionHelper.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace JackHenry.Banking.IAdapter.Infrastructure.Models;

using System;
using System.IO;
using System.Text;

public static class CompressionHelper
{
    public static string GZipBase64Compress(string value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return value;
        }

        using (MemoryStream stream = new MemoryStream(Encoding.UTF8.GetBytes(value)))
        {
            using (MemoryStream compressStream = new MemoryStream())
            {
                using (System.IO.Compression.GZipStream zipStream = new System.IO.Compression.GZipStream(compressStream, System.IO.Compression.CompressionMode.Compress, true))
                {
                    stream.CopyTo(zipStream);
                }

                return Convert.ToBase64String(compressStream.ToArray());
            }
        }
    }

    public static string GZipBase64Decompress(string value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return value;
        }

        using (MemoryStream stream = new MemoryStream())
        {
            using (MemoryStream decompressStream = new MemoryStream(Convert.FromBase64String(value)))
            {
                using (System.IO.Compression.GZipStream zipStream = new System.IO.Compression.GZipStream(decompressStream, System.IO.Compression.CompressionMode.Decompress, true))
                {
                    zipStream.CopyTo(stream);
                }

                return Encoding.UTF8.GetString(stream.ToArray());
            }
        }
    }

    public static string ZlibDecompress(byte[] value)
    {
        if (value == null)
        {
            throw new ArgumentNullException("No value passed in to decompress");
        }

        using (MemoryStream stream = new MemoryStream())
        {
            using (MemoryStream decompressStream = new MemoryStream(value))
            {
                using (Ionic.Zlib.ZlibStream zipStream = new Ionic.Zlib.ZlibStream(decompressStream, Ionic.Zlib.CompressionMode.Decompress, true))
                {
                    zipStream.CopyTo(stream);
                }

                return Encoding.UTF8.GetString(stream.ToArray());
            }
        }
    }

    public static string ZlibCompress(byte[] value)
    {
        if (value == null)
        {
            throw new ArgumentNullException("No value passed in to compress");
        }

        using (MemoryStream stream = new MemoryStream(value))
        {
            using (MemoryStream compressStream = new MemoryStream())
            {
                stream.Seek(0, SeekOrigin.Begin);
                using (Ionic.Zlib.ZlibStream zipStream = new Ionic.Zlib.ZlibStream(compressStream, Ionic.Zlib.CompressionMode.Compress, true))
                {
                    stream.CopyTo(zipStream);
                }

                return Encoding.UTF8.GetString(compressStream.ToArray());
            }
        }
    }
}
