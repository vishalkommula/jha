﻿// -----------------------------------------------------------------------
// <copyright file="MasterAdapterSetting.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2013 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

using JackHenry.JHAContractTypes;

namespace JackHenry.Banking.IAdapter.Infrastructure.Models;
public interface IMasterAdapterSetting : IIAdapter
{
    string DisplayName { get; }

    string EncryptedKey { get; set; }

    bool IsNonSSL { get; }

    bool IsSSLSerialized { get; set; }

    string ServicePrincipalName { get; set; }

    DateTime TLSDateTime { get; }

    string TLSDateTimeString { get; set; }
}
