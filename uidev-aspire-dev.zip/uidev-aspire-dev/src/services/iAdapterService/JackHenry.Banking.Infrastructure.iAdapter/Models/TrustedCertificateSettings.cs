// -----------------------------------------------------------------------
// <copyright file="TrustedCertificateSettings.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Models;

using JackHenry.Banking.IAdapter.Infrastructure.Interfaces;

using System.Collections.ObjectModel;

public class TrustedCertificateSettings : ITrustedCertificateSettings
{
    public TrustedCertificateSettings()
    {
    }

    public ObservableCollection<TrustedCertificateModel> TrustedCerts { get; set; }

    public string TLSSecurityStrength { get; set; }

    public void AddTrustedCertificateModel(TrustedCertificateModel additionalTrustedCertificateModel)
    {
        this.TrustedCerts.Add(additionalTrustedCertificateModel);
    }

    public void DeleteTrustedCertificateModel(TrustedCertificateModel additionalTrustedCertificateModel)
    {
        this.TrustedCerts.Remove(additionalTrustedCertificateModel);
    }
}
