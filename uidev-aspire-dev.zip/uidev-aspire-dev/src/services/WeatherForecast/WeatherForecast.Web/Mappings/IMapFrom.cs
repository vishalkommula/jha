﻿// ----------------------------------------------------------------------
// <copyright file="IMapFrom.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.Web.Mappings
{
    using AutoMapper;

    public interface IMapFrom<T>
    {
        void Mapping(Profile profile)
        {
            profile.CreateMap(typeof(T), this.GetType());
        }
    }
}
