// ----------------------------------------------------------------------
// <copyright file="ForecastTests.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.UnitTests.Core.Entities
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using WeatherForecast.Core.Entities;
    using WeatherForecast.Core.Exceptions;
    using WeatherForecast.Core.ValueObjects;

    using Xunit;

    [ExcludeFromCodeCoverage]
    public class ForecastTests
    {
        [Fact]
        public void SetForecastDate_DateOnly_ValueMatches()
        {
            var forecast = new Forecast();
            var newDate = new DateTime(2021, 09, 15);

            forecast.ForecastDate = newDate;

            Assert.Equal(forecast.ForecastDate, newDate);
        }

        [Fact]
        public void SetForecastDate_DateAndTime_Throws()
        {
            var forecast = new Forecast();

            Assert.Throws<InvalidForecastDateException>(() =>
                forecast.ForecastDate = new DateTime(2021, 09, 15) + TimeSpan.FromSeconds(1));
        }

        [Theory]
        [InlineData("Partly cloudy")]
        [InlineData("Sunny")]
        [InlineData("Snowing")]
        public void SetSummary_NonEmptyString_ValueMatches(string summary)
        {
            var forecast = new Forecast();

            forecast.Summary = summary;

            Assert.Equal(forecast.Summary, summary);
        }

        [Theory]
        [InlineData((string)null)]
        [InlineData("")]
        [InlineData(" ")]
        public void SetSummary_EmptyString_Throws(string summary)
        {
            var forecast = new Forecast();

            Assert.Throws<ArgumentNullException>(() =>
                forecast.Summary = summary);
        }

        [Fact]
        public void UpdateCurrentTemperature_PassValue_Matches()
        {
            var forecast = new Forecast();

            var newCurrent = new Temperature(0, Temperature.UnitOfMeasure.Celsius);
            var newFeelsLike = new Temperature(-3, Temperature.UnitOfMeasure.Celsius);

            forecast.UpdateCurrentTemperature(newCurrent, newFeelsLike);

            Assert.Equal(forecast.CurrentTemperature, newCurrent);
            Assert.Equal(forecast.FeelsLikeTemperature, newFeelsLike);
        }

        [Fact]
        public void UpdateCurrentTemperature_PassNullCurrent_Throws()
        {
            var forecast = new Forecast();

            Assert.Throws<ArgumentNullException>(() =>
                forecast.UpdateCurrentTemperature(
                    null,
                    new Temperature(0, Temperature.UnitOfMeasure.Celsius)));
        }

        [Fact]
        public void UpdateCurrentTemperature_PassNullFeelsLike_Throws()
        {
            var forecast = new Forecast();

            Assert.Throws<ArgumentNullException>(() =>
                forecast.UpdateCurrentTemperature(
                    new Temperature(0, Temperature.UnitOfMeasure.Celsius),
                    null));
        }

        [Theory]
        [InlineData(97, 81)]
        [InlineData(99, 99)]
        public void UpdateHighAndLow_PassValidValues_ValuesMatch(decimal high, decimal low)
        {
            var forecast = new Forecast();
            var highTemp = new Temperature(high, Temperature.UnitOfMeasure.Fahrenheit);
            var lowTemp = new Temperature(low, Temperature.UnitOfMeasure.Fahrenheit);

            forecast.UpdateHighAndLow(highTemp, lowTemp);

            Assert.Equal(forecast.HighTemperature, highTemp);
            Assert.Equal(forecast.LowTemperature, lowTemp);
        }

        // Null high and low should throw
        [Fact]
        public void UpdateHighAndLow_PassNullHigh_Throws()
        {
            var forecast = new Forecast();

            Assert.Throws<ArgumentNullException>(() =>
                forecast.UpdateHighAndLow(
                    null,
                    new Temperature(0, Temperature.UnitOfMeasure.Celsius)));
        }

        // Null high and low should throw
        [Fact]
        public void UpdateHighAndLow_PassNullLow_Throws()
        {
            var forecast = new Forecast();

            Assert.Throws<ArgumentNullException>(() =>
                forecast.UpdateHighAndLow(
                    new Temperature(0, Temperature.UnitOfMeasure.Celsius),
                    null));
        }

        // High can't be lower than low
        [Theory]
        [InlineData(81, 97)]
        [InlineData(0, 1)]
        public void UpdateHighAndLow_HighLowerThanLow_Throws(decimal high, decimal low)
        {
            var forecast = new Forecast();
            var highTemp = new Temperature(high, Temperature.UnitOfMeasure.Fahrenheit);
            var lowTemp = new Temperature(low, Temperature.UnitOfMeasure.Fahrenheit);

            Assert.Throws<InvalidHighAndLowTempException>(() =>
                forecast.UpdateHighAndLow(highTemp, lowTemp));
        }
    }
}
