﻿// ----------------------------------------------------------------------
// <copyright file="MappingTests.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.UnitTests.Web.Mappings
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text.Json;
    using AutoMapper;
    using WeatherForecast.Web.Mappings;
    using Xunit;

    [ExcludeFromCodeCoverage]
    public class MappingTests
    {
        public MappingTests()
        {
            this.Configuration = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<MappingProfile>();
            });

            this.Mapper = this.Configuration.CreateMapper();
        }

        public static IEnumerable<object[]> AutoMapperTypes { get; } = typeof(MappingProfile).Assembly.GetExportedTypes()
            .Select(t =>
            {
                Type i = t.GetInterfaces().FirstOrDefault(i =>
                    i.IsGenericType &&
                    i.GetGenericTypeDefinition() == typeof(IMapFrom<>));

                return (
                    source: i?.GetGenericArguments()?.ElementAtOrDefault(0),
                    destination: t);
            })
            .Where(x => x.source != null)
            .Select(x => new object[] { x.source, x.destination })
            .ToList();

        private IConfigurationProvider Configuration { get; }

        private IMapper Mapper { get; }

        [Fact]
        public void ShouldHaveValidConfiguration()
        {
            this.Configuration.AssertConfigurationIsValid();
        }

        [Theory]
        [MemberData(nameof(AutoMapperTypes))]
        public void ShouldSupportMappingFromSourceToDestination(Type source, Type destination)
        {
            var instance = this.GetInstanceOf(source);

            JsonSerializer.Serialize(this.Mapper.Map(instance, source, destination));
        }

        private object GetInstanceOf(Type type)
        {
            if (type.GetConstructor(Type.EmptyTypes) != null)
            {
                return Activator.CreateInstance(type);
            }

            // Type without parameterless constructor
            return FormatterServices.GetUninitializedObject(type);
        }
    }
}
