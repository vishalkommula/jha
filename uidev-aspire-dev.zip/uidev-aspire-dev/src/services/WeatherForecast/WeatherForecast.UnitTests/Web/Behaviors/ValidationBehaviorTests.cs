﻿// ----------------------------------------------------------------------
// <copyright file="ValidationBehaviorTests.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.UnitTests.Web.Behaviors
{
    using System.Diagnostics.CodeAnalysis;
    using System.Threading;
    using System.Threading.Tasks;
    using FluentValidation;
    using FluentValidation.Results;
    using Moq;
    using WeatherForecast.Web.Behaviors;
    using Xunit;

    [ExcludeFromCodeCoverage]
    public class ValidationBehaviorTests
    {
        private Mock<IValidator<TestRequest>> validatorMock;
        private ValidationBehavior<TestRequest, TestResponse> behavior;
        private TestRequest request;
        private TestResponse response;

        public ValidationBehaviorTests()
        {
            this.validatorMock = new Mock<IValidator<TestRequest>>();
            this.behavior = new ValidationBehavior<TestRequest, TestResponse>(
                new[] { this.validatorMock.Object });
            this.request = new TestRequest();
            this.response = new TestResponse();
        }

        [Fact]
        public void Validators_ConstructorArgumentSaved()
        {
            Assert.NotNull(this.behavior.Validators);
            Assert.Contains(this.validatorMock.Object, this.behavior.Validators);
        }

        [Fact]
        public async Task Handle_ValidatorWithFailure_Throws()
        {
            var result = new ValidationResult(new[]
            {
                new ValidationFailure("test property", "test failure")
            });

            this.validatorMock
                .Setup(v => v.ValidateAsync(
                    It.IsAny<IValidationContext>(),
                    It.IsAny<CancellationToken>()))
                .Returns(Task.FromResult(result));

            await Assert.ThrowsAsync<ValidationException>(
                () => this.behavior.Handle(
                    this.request,
                    CancellationToken.None,
                    () => Task.FromResult(this.response)));
        }

        [Fact]
        public async Task Handle_ValidatorNoFailure_ReturnsResponse()
        {
            var result = new ValidationResult();

            this.validatorMock
                .Setup(v => v.ValidateAsync(
                    It.IsAny<IValidationContext>(),
                    It.IsAny<CancellationToken>()))
                .Returns(Task.FromResult(result));

            var localResponse = await this.behavior.Handle(
                this.request,
                CancellationToken.None,
                () => Task.FromResult(this.response));

            Assert.Equal(localResponse, this.response);
        }

        public class TestRequest
        {
        }

        public class TestResponse
        {
        }
    }
}
