﻿// ----------------------------------------------------------------------
// <copyright file="DependencyInjection.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.Infrastructure
{
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using WeatherForecast.Core.Interfaces;
    using WeatherForecast.Infrastructure.Repositories;
    using WeatherForecast.Infrastructure.Services;

    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IWeatherForecastRepository, WeatherForecastRepository>();
            services.AddTransient<IDateTime, DateTimeService>();

            return services;
        }
    }
}