﻿// ----------------------------------------------------------------------
// <copyright file="DateTimeService.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.Infrastructure.Services
{
    using System;
    using WeatherForecast.Core.Interfaces;

    internal class DateTimeService : IDateTime
    {
        public DateTime Now => DateTime.Now;
    }
}
