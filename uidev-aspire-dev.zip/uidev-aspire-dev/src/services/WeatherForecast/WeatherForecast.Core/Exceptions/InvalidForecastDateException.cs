﻿// ----------------------------------------------------------------------
// <copyright file="InvalidForecastDateException.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.Core.Exceptions
{
    using System;

    public class InvalidForecastDateException : Exception
    {
        public InvalidForecastDateException()
            : this("Invalid forecast date.")
        {
        }

        public InvalidForecastDateException(string message)
            : this(message, null)
        {
        }

        public InvalidForecastDateException(string message, Exception innerException)
        {
        }
    }
}