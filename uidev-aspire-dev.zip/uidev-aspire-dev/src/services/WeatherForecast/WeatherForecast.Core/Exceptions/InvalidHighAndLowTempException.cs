﻿// ----------------------------------------------------------------------
// <copyright file="InvalidHighAndLowTempException.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.Core.Exceptions
{
    using System;

    public class InvalidHighAndLowTempException : Exception
    {
        public InvalidHighAndLowTempException()
            : this("Invalid high and low temperature.")
        {
        }

        public InvalidHighAndLowTempException(string message)
            : this(message, null)
        {
        }

        public InvalidHighAndLowTempException(string message, Exception innerException)
        {
        }
    }
}