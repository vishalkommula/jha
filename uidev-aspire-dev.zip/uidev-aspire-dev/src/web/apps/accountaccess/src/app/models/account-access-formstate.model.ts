import { PageMode } from '@uid/uid-models';

export interface AccountAccessFormStateModel {
    pageMode: PageMode;
    width: string; // default details view size
};
