import * as AccountAccessFunction from '../account-access-details/account-access.function';
describe('Account Access Function Test',()=> {
    it('accountAccessFormField should be executed',()=> {
        const fields = AccountAccessFunction.accountAccessFormField();
        expect(fields).toBeTruthy();
    });

    it('hideField should be executed if accessAlw is yes',()=> {
        const value = AccountAccessFunction.hideField({accessAlw: 'Yes'} as any, {} as any);
        expect(value).toBeFalsy();
    });

    it('hideField should be executed if accessAlw is no',()=> {
        const value = AccountAccessFunction.hideField({accessAlw: 'No'} as any, {} as any);
        expect(value).toBeTruthy();
    });
});
