/* eslint-disable arrow-body-style */
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';
import { RootActions } from '@uid/uid-root-store';
import { DataService } from '../../service/data.service';
import * as AccountAccessActions from '../actions/accountaccess.actions';

@Injectable()
export class AccountAccessEffects {
    constructor (private dataservice: DataService, private action$: Actions) {}

    loadIntnetAccessInfoRecord$ = createEffect(() => this.action$.pipe(
        ofType(AccountAccessActions.getIntnetAccessInfoRecord),
        switchMap((action) =>
        this.dataservice.getIntnetFinIdRecord(action.intnetFinInstIdInqRequest)
        .pipe(
          switchMap((intnetFinInstIdInqResponse)=> {
            const actionToDispatch = [];
            if(intnetFinInstIdInqResponse.intnetAccessInfoRecord === undefined){
              actionToDispatch.push(RootActions.gridViewAction());
            }
            actionToDispatch.push(AccountAccessActions.getIntnetAccessInfoRecordSuccess({intnetFinInstIdInqResponse}));
            return actionToDispatch;
          }),
          catchError((error)=> of(AccountAccessActions.getIntnetAccessInfoRecordFailure({error})))
        )
        )
    ));

    rowDetailClicked$ = createEffect(() => {
        return this.action$.pipe(
          ofType(AccountAccessActions.gridRowShowDetailButtonClicked),
          switchMap(() => of(RootActions.detailsViewAction()))
        );
      });
}
