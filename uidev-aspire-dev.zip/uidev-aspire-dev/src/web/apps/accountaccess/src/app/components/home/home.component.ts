import { Component, OnInit, ViewChild } from '@angular/core';
import { ColDef,
         GridOptions,
         GridReadyEvent,
         GridSizeChangedEvent,
         RowDoubleClickedEvent,
         RowSelectedEvent,
         SideBarDef } from 'ag-grid-community';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { SplitterViewEnum, SplitterViewStateModel } from '@uid/uid-primary-detail';
import { ButtonRendererClickParms, ButtonRendererComponent } from '@uid/uid-angular-controls';
import { UidGridAngular, WatchColumnDefinitionModel } from '@uid/uid-directives';
import * as FromRootStore from '@uid/uid-root-store';
import { RootActions } from '@uid/uid-root-store';
import { AccountType } from '@uid/uid-models';
import * as AccountAccessActions from '../../store/actions/accountaccess.actions';
import * as AccountAccessSelectors from '../../store/selectors/accountaccess.selectors';
import * as AccountAccessFunctions from './account-access-details/account-access.function';
import { AccIdAccessInfoRecItemModel } from '../../models/account-id-access-info-record-item.model';
import { RelCodeAccessInfoRecItemModel } from '../../models/relationship-access-code-info-record-item.model';
import { IntnetAccessInfoRecItemModel } from '../../models/intnet-access-info-record-item.model';
import { AccountAccessFormStateModel } from '../../models/account-access-formstate.model';
import { IntnetFinInstIdInqRequestModel } from '../../models/intnet-fin-inst-id-inq-request.model';
import { AccountAccessGridColDef } from './account-access-grid-col.def';

@Component({
  selector: 'uid-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  @ViewChild('uidGrid')
  uidGrid = {} as UidGridAngular;

  accountIdAccess$: Observable<string | undefined>;
  accountIdAccessArray$: Observable<AccIdAccessInfoRecItemModel[] | undefined>;
  relationshipCodeAccessArray$: Observable<RelCodeAccessInfoRecItemModel[] | undefined>;
  currentSelectedRecord$: Observable<AccIdAccessInfoRecItemModel>;
  splitterViewStateModel$: Observable<SplitterViewStateModel | null>;
  watchColumns$: Observable<WatchColumnDefinitionModel>;
  intnetAccessInfoRecord$: Observable<IntnetAccessInfoRecItemModel | undefined>;
  intnetFinInstIdValue$: Observable<string>;

  accountAccessActions = AccountAccessActions;
  accountAccessSelectors = AccountAccessSelectors;
  fromRootStore = FromRootStore;
  rootActions = RootActions;
  accountAccessFormFields = AccountAccessFunctions.accountAccessFormField();
  accountAccessFormState$: Observable<AccountAccessFormStateModel>;
  splitterViewEnum = SplitterViewEnum;
  showDialogBox = false;

  defaultColDef: ColDef;
  columnDefs: ColDef[];
  gridOptions: GridOptions;
  autoGroupColumnDef: ColDef;
  sideBar: SideBarDef;
  relCustId = 'RelCustId';
  relAccId = 'RelAcctId';

  frameworkComponents = {
    buttonRenderer: ButtonRendererComponent,
  };

  constructor(private store: Store, private rootStore: Store<FromRootStore.State>, gridDef: AccountAccessGridColDef) {

    this.defaultColDef = gridDef.default;
    this.columnDefs = gridDef.columns;
    this.gridOptions = gridDef.gridOptions;
    this.sideBar = gridDef.sideBar;
    this.autoGroupColumnDef = gridDef.autoGroupColumnDef;

    this.accountIdAccess$ = this.store.select(this.accountAccessSelectors.selectAccountIdAccess);
    this.accountIdAccessArray$ = this.store.select(this.accountAccessSelectors.selectAccountIdAccessArray);
    this.relationshipCodeAccessArray$ = this.store.select(this.accountAccessSelectors.selectRelationshipCodeAccessArray);
    this.currentSelectedRecord$ = this.store.select(this.accountAccessSelectors.selectCurrentSelectedRecord);
    this.splitterViewStateModel$ = this.rootStore.select(this.fromRootStore.selectSplitterViewStateModel);
    this.watchColumns$ = this.store.select(this.accountAccessSelectors.selectGridWatchColumns);
    this.intnetAccessInfoRecord$ = this.store.select(this.accountAccessSelectors.selectIntnetAccessInfoRecord);
    this.accountAccessFormState$ = this.store.select(this.accountAccessSelectors.selectFormState);
    this.intnetFinInstIdValue$ = this.store.select(this.accountAccessSelectors.selectIntnetFinInstId);
    this.mapGridButtons(gridDef);
  }

  ngOnInit(): void {
    this.store.dispatch(this.accountAccessActions.getIntnetAccessInfoRecord({intnetFinInstIdInqRequest: {} as IntnetFinInstIdInqRequestModel}));
  }

  onGridReady(event: GridReadyEvent) {
    if (!event || !event.columnApi || !this.gridOptions) {
        return;
    }
    event.api.sizeColumnsToFit();
    event.api.expandAll();
  }

  mapGridButtons(gridDef: AccountAccessGridColDef): void {
    const detailButton = gridDef.buttonRendererList.find((x) => x.iconType === 'preview');

    if (detailButton) {
        detailButton.onClick = this.detailButtonClick.bind(this);
    }
  }

  detailButtonClick(event: ButtonRendererClickParms) {
    if (event.rowIndex !== null && event.rowIndex !== undefined && this.uidGrid && this.uidGrid.uidApi) {
      this.uidGrid.uidApi.selectRecord(event.rowIndex);
    }
    this.store.dispatch(this.accountAccessActions.gridRowShowDetailButtonClicked());
  }

  onGridSizeChanged(event: GridSizeChangedEvent) {
    event.api.sizeColumnsToFit();
  }

  onRowSelected(event: RowSelectedEvent) {
    // if the selected node is grouped node, the first child node will be selected by default
    if(event.node.group){
      event.node.setSelected(false);
      if(event.node.rowIndex !== null){
        this.uidGrid.uidApi.selectRecord(event.node.rowIndex + 1);
      }
      return;
    }
    if(event.node.isSelected()){
      // update the current selected record details in state
      this.store.dispatch(this.accountAccessActions.updateCurrentSelectedRecord({currentRecord: event.data}));
    }
  }

  onRowDoubleClicked(event: RowDoubleClickedEvent) {
    this.store.dispatch(RootActions.detailsViewAction());
  }

  toggleSplitView() {
    this.rootStore.dispatch(this.rootActions.toggleSplitViewAction());
  }

  // account access method popup close
  dialogBoxClose(event: any){
    this.showDialogBox = false;
  }

  returnToGridView() {
    this.rootStore.dispatch(this.rootActions.gridViewAction());
  }

  getAccountTypeEnumValue(enumString: any){
    const enumValue = (<any>AccountType)[enumString];
    return enumValue === undefined ? '' : enumValue;
  }
}
