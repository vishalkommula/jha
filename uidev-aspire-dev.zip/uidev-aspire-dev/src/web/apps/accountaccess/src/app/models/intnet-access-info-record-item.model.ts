import { AccIdAccessInfoRecItemModel } from './account-id-access-info-record-item.model';
import { RelCodeAccessInfoRecItemModel } from './relationship-access-code-info-record-item.model';

export interface IntnetAccessInfoRecItemModel {
    acctIdAccess: string;
    relCodeAccessArray?: RelCodeAccessInfoRecItemModel[];
    acctIdAccessArray: AccIdAccessInfoRecItemModel[];
}
