import { FormlyFieldConfig } from '@ngx-formly/core';
import { FormDataTypeEnum } from '@uid/uid-angular-controls';
import { AccIdAccessInfoRecItemModel } from '../../../models/account-id-access-info-record-item.model';

// hide the fields if access allowed is no
export const hideField = function(model: AccIdAccessInfoRecItemModel){
    return (model.accessAlw === 'Yes' ? false : true);
};


export function accountAccessFormField(): FormlyFieldConfig[] {
    return[
        {
            templateOptions: { label: 'Account Details' },
            wrappers: ['record-detail-block'],
            fieldGroup: [
                {
                    key: 'accessAlw',
                    templateOptions: {
                        label: 'Access Allowed'
                    },
                    type: FormDataTypeEnum.input,
                },
                {
                    key: 'acctId',
                    templateOptions: {
                        label: 'Account',
                        hyperlinkClick: ()=> {
                            console.log('Hyperlink call back event');
                        }
                    },
                    type: FormDataTypeEnum.hyperlink,
                    hideExpression: hideField
                },
                {
                    key: 'aliasAcctName',
                    templateOptions: {
                        label: 'Pseudo Account Name'
                    },
                    type: FormDataTypeEnum.input,
                    hideExpression: hideField
                },
                {
                    key: 'acctType',
                    templateOptions: {
                        label: 'Type'
                    },
                    type: FormDataTypeEnum.input,
                    hideExpression: hideField
                },
                {
                    key: 'prodDesc',
                    templateOptions: {
                        label: 'Product'
                    },
                    type: FormDataTypeEnum.input,
                    hideExpression: hideField
                },
                {
                    key: 'acctRelDesc',
                    templateOptions: {
                        label: 'Relationship'
                    },
                    type: FormDataTypeEnum.input,
                    hideExpression: hideField
                },
                {
                    key: 'rmk',
                    templateOptions: {
                        label: 'Remarks'
                    },
                    type: FormDataTypeEnum.input,
                    hideExpression: hideField
                }
            ]
        },
        {
            templateOptions: { label: 'Hard Charge' },
            wrappers: ['record-detail-block'],
            hideExpression: hideField,
            fieldGroup: [
                {
                    key: 'stopPmtAddFeeAmt',
                    templateOptions: {
                        label: 'Add Stop Payments'
                    },
                    type: FormDataTypeEnum.currency,
                },
                {
                    key: 'xferFromFeeAmt',
                    templateOptions: {
                        label: 'Transfer From Account'
                    },
                    type: FormDataTypeEnum.currency,
                },
                {
                    key: 'stmtRetrvFeeAmt',
                    templateOptions: {
                        label: 'Demand Deposit Statements'
                    },
                    type: FormDataTypeEnum.currency,
                }
            ]
        },
        {
            templateOptions: { label: 'Account Analysis' },
            wrappers: ['record-detail-block'],
            hideExpression: hideField,
            fieldGroup: [
                {
                    key: 'stopPmtAddAnlysId',
                    templateOptions: {
                        label: 'Add Stop Payments'
                    },
                    type: FormDataTypeEnum.input,
                },
                {
                    key: 'xferFromAnlysId',
                    templateOptions: {
                        label: 'Transfer From Account'
                    },
                    type: FormDataTypeEnum.input,
                },
                {
                    key: 'stmtRetrvAnlysId',
                    templateOptions: {
                        label: 'Demand Deposit Statements'
                    },
                    type: FormDataTypeEnum.input,
                }
            ]
        },
        {
            templateOptions: { label: 'Other' },
            wrappers: ['record-detail-block'],
            hideExpression: hideField,
            fieldGroup: [
                {
                    key: 'feeChgStmtType',
                    templateOptions: {
                        label: 'Hard Charge at Statement'
                    },
                    type: FormDataTypeEnum.input,
                },
                {
                    key: 'acctElecDocType',
                    templateOptions: {
                        label: 'E-Statement'
                    },
                    type: FormDataTypeEnum.input,
                },
                {
                    key: 'lnPmtAlw',
                    templateOptions: {
                        label: 'Loan Payment'
                    },
                    type: FormDataTypeEnum.input,
                }
            ]
        }
    ];
};
