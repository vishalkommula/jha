import { HomeComponent } from './home.component';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

let component: HomeComponent;

const storeMock = {
  dispatch: jest.fn(),
  select: jest.fn(),
};

const rootStoreMock = {
  dispatch: jest.fn(),
  select: jest.fn(),
  toggleSplitViewAction: jest.fn(),
  gridViewAction: jest.fn()
};

const rootActions = {
  toggleSplitViewAction: jest.fn(),
  gridViewAction: jest.fn()
};

const gridDef = {
  columns: [],
  defautColDef: {},
  gridOptions: {},
  buttonRendererList: {
    find: jest.fn()
  }
};

const accountAccessActionsMock = {
  getIntnetAccessInfoRecord: jest.fn(),
  gridRowShowDetailButtonClicked: jest.fn(),
  updateCurrentSelectedRecord: jest.fn()
};

const accountAccessSelectorsMock = {
  selectAccountIdAccess: jest.fn(),
  selectAccountIdAccessArray: jest.fn(),
  selectRelationshipCodeAccessArray: jest.fn(),
  selectCurrentSelectedRecord: jest.fn(),
  selectCurrentRowIndex: jest.fn(),
  selectGridWatchColumns: jest.fn(),
  selectIntnetAccessInfoRecord: jest.fn()
};

describe('Account Access Home Component Test',() => {
  beforeEach(() => {
    component = new HomeComponent(storeMock as any, rootStoreMock as any, gridDef as any);
    component.accountAccessActions = accountAccessActionsMock as any;
    component.fromRootStore = rootStoreMock as any;
    component.rootActions = rootActions as any;
    component.accountAccessSelectors = accountAccessSelectorsMock as any;
  });

  it('Component should be created',() => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit should be executed',() => {
    component.ngOnInit();
    expect(accountAccessActionsMock.getIntnetAccessInfoRecord).toBeCalledWith({intnetFinInstIdInqRequest: {} as any});
  });

  it('onGridSizeChanged should be executed',() => {
    const eventMock = {api: {sizeColumnsToFit: jest.fn()}};
    component.onGridSizeChanged(eventMock as any);
  });

  it('onRowSelected should be executed if selected node is group',() => {
    const eventMock = {node: {setSelected: jest.fn(()=> true), group: true, rowIndex: 1}, data: {} as any, rowIndex: 1};
    component.uidGrid = {uidApi: {selectRecord: jest.fn()}} as any;
    component.onRowSelected(eventMock as any);
    expect(accountAccessActionsMock.updateCurrentSelectedRecord).toBeCalledTimes(0);
  });

  it('onRowSelected should be executed if selected node is not a group',() => {
    const eventMock = {node: {isSelected: jest.fn(()=> true)}, data: {} as any, rowIndex: 1};
    component.onRowSelected(eventMock as any);
    expect(accountAccessActionsMock.updateCurrentSelectedRecord).toBeCalledWith({currentRecord: eventMock.data});
  });

  it('toggleSplitView should be executed',() => {
    component.toggleSplitView();
    expect(rootActions.toggleSplitViewAction).toBeCalled();
  });

  it('onGridReady should be executed if the event is valid',() => {
    const eventMock = {api: { sizeColumnsToFit: jest.fn(), expandAll: jest.fn() }};
    component.onGridReady(eventMock as any);
  });

  it('onGridReady should be executed if the event is invalid',() => {
    const eventMock = {} as any;
    component.onGridReady(eventMock as any);
  });

  it('mapGridButtons should be executed',() => {
    const gridDefMock = {buttonRendererList: [{iconType: 'preview'}]};
    component.mapGridButtons(gridDefMock as any);
  });

  it('detailButtonClick should be executed',() => {
    const eventMock = {rowIndex: 1} as any;
    component.uidGrid = {uidApi: {selectRecord: jest.fn()}} as any;
    component.detailButtonClick(eventMock);
    expect(accountAccessActionsMock.gridRowShowDetailButtonClicked).toBeCalled();
  });

  it('dialogBoxClose should be executed',()=> {
    component.dialogBoxClose({} as any);
    expect(component.showDialogBox).toBeFalsy();
  });

  it('returnToGridView should be executed',()=> {
    component.returnToGridView();
    expect(rootActions.gridViewAction).toBeCalled();
  });
});
