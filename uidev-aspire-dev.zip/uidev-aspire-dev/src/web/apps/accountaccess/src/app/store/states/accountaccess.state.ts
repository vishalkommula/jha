import { AccIdAccessInfoRecItemModel } from '../../models/account-id-access-info-record-item.model';
import { IntnetFinInstIdInqResponseModel } from '../../models/intnet-fin-inst-id-inq-response.model';

export interface AccountAccessState {
    intnetFinInstIdInqResponse: IntnetFinInstIdInqResponseModel;
    acctIdAccessRecord: AccIdAccessInfoRecItemModel;
}
