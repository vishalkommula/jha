import { AccountAccessGridColDef } from './account-access-grid-col.def';

let component: AccountAccessGridColDef;

describe('Account Access Grid Column Definition Component Test',() => {
    beforeEach(() => {
        component = new AccountAccessGridColDef();
    });

    it('Component should be created',() => {
        expect(component).toBeTruthy();
    });

    it('onPreview should be executed',()=> {
        component.onPreview({} as any);
    });
});
