import { createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromRootStore from '@uid/uid-root-store';
import { WatchColumnDefinitionModel } from '@uid/uid-directives';
import { SplitterViewEnum } from '@uid/uid-primary-detail';
import { AccountAccessState } from '../states/accountaccess.state';
import { PageMode } from '@uid/uid-models';
import { AccountAccessFormStateModel } from '../../models/account-access-formstate.model';

export const selectRoot = createFeatureSelector<AccountAccessState>('accountAccess');

export const selectAccountIdAccess = createSelector(selectRoot,(state) => state.intnetFinInstIdInqResponse.intnetAccessInfoRecord?.acctIdAccess);

export const selectAccountIdAccessArray = createSelector(selectRoot,(state) => state.intnetFinInstIdInqResponse.intnetAccessInfoRecord?.acctIdAccessArray);

export const selectRelationshipCodeAccessArray = createSelector(selectRoot,(state) => state.intnetFinInstIdInqResponse.intnetAccessInfoRecord?.relCodeAccessArray);

export const selectCurrentSelectedRecord = createSelector(selectRoot,(state) => ({...state.acctIdAccessRecord}));

export const selectIntnetAccessInfoRecord = createSelector(selectRoot,(state) => state.intnetFinInstIdInqResponse.intnetAccessInfoRecord);

export const selectIntnetFinInstId = createSelector(selectRoot,(state) => state.intnetFinInstIdInqResponse.intnetFinInstId);

export const selectGridWatchColumns = createSelector(
    fromRootStore.selectIsSplitView, (isSplit) => ({
        records: [
            {action: 'hide', fieldName: 'actionButtons', value: isSplit !== SplitterViewEnum.gridView}
        ]
    } as WatchColumnDefinitionModel)
);

export const selectFormState = createSelector(
    fromRootStore.selectIsSplitView, (splitView): AccountAccessFormStateModel => ({
        pageMode: PageMode.Inquiry, width: splitView === SplitterViewEnum.detailView ? 'medium' : 'full'
    })
);
