## Development server

Execute `npm run start` from a command line, or press `F6` in VS Code to build and serve the application shell. You should be asked to install a development certificate the first time, click Yes to install it.

To debug in VS Code, press `F5` or start the "Debug Shell" launch configuration. The application is served from https://localhost:4200/.

## Generate an application

Run `npx nx g @nrwl/angular:app myapp --mfe --mfeType=remote --port=PORT --host=shell --routing=true` to generate an application. Avoid hyphens, underscores, and proper case. Nx will replace with hyphens which don't play nice with module federation.

When using Nx, you can create multiple applications and libraries in the same workspace.

## Generate a library

Run `npx nx g @nrwl/angular:lib my-lib` to generate a library.

Libraries are shareable across libraries and applications. They can be imported from `@uid/mylib`.

## Code scaffolding

Run `npx nx g @nrwl/angular:component my-component --project=myapp` to generate a new component.

## Build

Run `npm run build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Build Docker image

Run `docker build -t myapp:latest --build-arg buildcommand=myapp:build:production .` to build the app into a production docker image.

## Running unit tests

If you're using VS Code, try the [Jest plugin](https://marketplace.visualstudio.com/items?itemName=Orta.vscode-jest) from Orta. It adds a nice test explorer, automatically runs all tests on save, and adds support for debugging your tests.

Run `npm run test` to execute the unit tests via [Jest](https://jestjs.io). This will also create code coverage reports under the `coverage` folder.

Run `npx nx affected:test` to only execute unit tests affected by your changes.


## Linting

VS Code should show linting errors while editing. To check for lint errors in all files and automatically fix them, run `npm run lint` from a command line.

## Understand your workspace

Run `npx nx dep-graph` to see a diagram of the dependencies of your projects.

## Adding capabilities to your workspace

Nx supports many plugins which add capabilities for developing different types of applications and different tools.

These capabilities include generating applications, libraries, etc as well as the devtools to test, and build projects as well.

Below are our core plugins:

- [React](https://reactjs.org)
  - `npm install --save-dev @nrwl/react`
- Web (no framework frontends)
  - `npm install --save-dev @nrwl/web`
- [Angular](https://angular.io)
  - `npm install --save-dev @nrwl/angular`
- [Nest](https://nestjs.com)
  - `npm install --save-dev @nrwl/nest`
- [Express](https://expressjs.com)
  - `npm install --save-dev @nrwl/express`
- [Node](https://nodejs.org)
  - `npm install --save-dev @nrwl/node`

There are also many [community plugins](https://nx.dev/community) you could add.

## Further help

Visit the [Nx Documentation](https://nx.dev) to learn more.

## References

This project was generated using [Nx](https://nx.dev).

<p style="text-align: center;"><img src="https://raw.githubusercontent.com/nrwl/nx/master/images/nx-logo.png" width="450"></p>

🔎 **Smart, Extensible Build Framework**

For specific steps, check the official nx guide, "[How to setup a Micro Frontend with Angular and Nx](https://nx.dev/l/a/guides/setup-mfe-with-angular)".
