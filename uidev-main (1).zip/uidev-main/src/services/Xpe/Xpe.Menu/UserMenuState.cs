﻿namespace Xpe.Menu;

public class UserMenuState
{
    public string InitialMenu { get; set; }

    public List<SystemMenuFolder> CoreMenuItems { get; set; } = new();

    public List<SystemMenuFolder> DisplayedMenuItems { get; set; } = new();    
}