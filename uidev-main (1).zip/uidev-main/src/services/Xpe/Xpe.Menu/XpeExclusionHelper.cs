﻿using JackHenry.Banking.IAdapter.Infrastructure.Models;
using JackHenry.JHAContractTypes;
using Xpe.Menu.Interfaces;

namespace Xpe.Menu;

public class XpeExclusionHelper : IXpeExclusionHelper
{
    private readonly string[] silhouetteMenuLinkItems =
        { "DOCIMAGE", "DOCIMGOPS", "DOCIMGPAR", "DOCIMGRENT", "DOCIMGRPT", "DOCIMGRR" };

    public XpeExclusionHelper()
    {
        PassportOptionsListResourceName = "JackHenry.Banking.XperienceMenu.XPExlusions.PassportOptions.xml";
        StreamlineListResourceName = "JackHenry.Banking.XperienceMenu.XPExlusions.StreamlineOptions.xml";
        VertexListResourceName = "JackHenry.Banking.XperienceMenu.XPExlusions.VertexOptions.xml";
        TimeTrackListResourceName = "JackHenry.Banking.XperienceMenu.XPExlusions.TimeTrackOptions.xml";
        NetTellerListResourceName = "JackHenry.Banking.XperienceMenu.XPExlusions.NetTellerOptions.xml";
    }

    public List<PrvdUsrOptInfo_CType> PassportOptionsList { get; set; }

    public List<PrvdUsrOptInfo_CType> StreamlineOptionsList { get; set; }

    public List<PrvdUsrOptInfo_CType> VertexOptionsList { get; set; }

    public List<PrvdUsrOptInfo_CType> TimeTrackOptionsList { get; set; }

    public List<PrvdUsrOptInfo_CType> NetTellerOptionsList { get; set; }

    public string PassportOptionsListResourceName { get; set; }

    public string StreamlineListResourceName { get; set; }

    public string VertexListResourceName { get; set; }

    public string TimeTrackListResourceName { get; set; }

    public string NetTellerListResourceName { get; set; }

    public virtual bool IsVertexOption(PrvdUsrOptInfo_CType menuOption)
    {
        if (VertexOptionsList == null)
        {
            LoadVertexOptionsList();
        }

        if (menuOption != null && menuOption.PrvdMenuCmd != null &&
            !string.IsNullOrEmpty(menuOption.PrvdMenuCmd.GetValueOrDefault()))
        {
            PrvdUsrOptInfo_CType found;

            if (menuOption.PrvdMenuCmd.GetValueOrDefault().Contains("/"))
            {
                var forwardSlashIndex = menuOption.PrvdMenuCmd.GetValueOrDefault().IndexOf('/');
                found = VertexOptionsList.FirstOrDefault(
                    m => m.PrvdMenuCmd != null &&
                         m.PrvdMenuCmd.GetValueOrDefault().Contains('/') &&
                         m.PrvdMenuCmd.GetValueOrDefault().Substring(m.PrvdMenuCmd.GetValueOrDefault().IndexOf('/')) ==
                         menuOption.PrvdMenuCmd.GetValueOrDefault().Substring(forwardSlashIndex));
            }
            else
            {
                // Sometimes the commands have a '?' at the beginning and sometimes they don't. We trim the start to catch both cases.
                found = VertexOptionsList.FirstOrDefault(
                    m => m.PrvdMenuCmd != null &&
                         m.PrvdMenuCmd.GetValueOrDefault().TrimStart('?') ==
                         menuOption.PrvdMenuCmd.GetValueOrDefault().TrimStart('?'));
            }

            return found != null;
        }

        if (menuOption != null && menuOption.PrvdMenuPgm != null &&
            !string.IsNullOrEmpty(menuOption.PrvdMenuPgm.GetValueOrDefault()))
        {
            var found = VertexOptionsList.FirstOrDefault(
                m => m.PrvdMenuPgm != null &&
                     m.PrvdMenuPgm.GetValueOrDefault() == menuOption.PrvdMenuPgm.GetValueOrDefault());

            return found != null;
        }

        return false;
    }

    public virtual bool IsSilloutteMenuOption(PrvdUsrOptInfo_CType option)
    {
        var found = (option.PrvdMenuDesc != null && option.PrvdMenuDesc.ToLower().Contains("silhouette")) ||
                    (!string.IsNullOrEmpty(option.PrvdMenuName.GetValueOrDefault()) &&
                     option.PrvdMenuName.ToLower().Contains("silhouette"));

        if (!found && option.PrvdMenuLink != null && silhouetteMenuLinkItems.Contains(option.PrvdMenuLink.Value))
        {
            found = true;
        }

        return found;
    }

    public virtual bool IsExclusion(PrvdUsrOptInfo_CType menuOption)
    {
        return IsPassportOption(menuOption) || IsStreamlineOption(menuOption) || IsVertexOption(menuOption) ||
               IsTimeTrackOption(menuOption);
    }

    public virtual bool IsPassportOption(PrvdUsrOptInfo_CType menuOption)
    {
        if (PassportOptionsList == null)
        {
            LoadPassportOptionsList();
        }

        if (menuOption != null && menuOption.PrvdMenuCmd != null &&
            !string.IsNullOrEmpty(menuOption.PrvdMenuCmd.GetValueOrDefault()))
        {
            PrvdUsrOptInfo_CType found;

            if (menuOption.PrvdMenuCmd.GetValueOrDefault().Contains("/"))
            {
                var forwardSlashIndex = menuOption.PrvdMenuCmd.GetValueOrDefault().IndexOf('/');
                found = PassportOptionsList.FirstOrDefault(
                    m => m.PrvdMenuCmd != null &&
                         m.PrvdMenuCmd.GetValueOrDefault().Contains('/') &&
                         m.PrvdMenuCmd.GetValueOrDefault().Substring(m.PrvdMenuCmd.GetValueOrDefault().IndexOf('/')) ==
                         menuOption.PrvdMenuCmd.GetValueOrDefault().Substring(forwardSlashIndex));
            }
            else
            {
                // Sometimes the commands have a '?' at the beginning and sometimes they don't. We trim the start to catch both cases.
                found = PassportOptionsList.FirstOrDefault(
                    m => m.PrvdMenuCmd != null &&
                         m.PrvdMenuCmd.GetValueOrDefault().TrimStart('?') ==
                         menuOption.PrvdMenuCmd.GetValueOrDefault().TrimStart('?'));
            }

            if ((!string.IsNullOrEmpty(menuOption.PrvdMenuName.GetValueOrDefault()) &&
                 menuOption.PrvdMenuName.GetValueOrDefault().ToLower().StartsWith("jhaatm")) ||
                (!string.IsNullOrEmpty(menuOption.PrvdMenuDesc.GetValueOrDefault()) &&
                 menuOption.PrvdMenuDesc.GetValueOrDefault().ToLower().Contains("atm transactions")))
            {
                return true;
            }

            return found != null;
        }

        if (menuOption != null && menuOption.PrvdMenuPgm != null &&
            !string.IsNullOrEmpty(menuOption.PrvdMenuPgm.GetValueOrDefault()))
        {
            var found = PassportOptionsList.FirstOrDefault(
                m => m.PrvdMenuPgm != null &&
                     m.PrvdMenuPgm.GetValueOrDefault() == menuOption.PrvdMenuPgm.GetValueOrDefault());

            return found != null;
        }

        return false;
    }

    public virtual bool IsPassportOption(string menu, string option)
    {
        if (PassportOptionsList == null)
        {
            LoadPassportOptionsList();
        }

        if (!string.IsNullOrEmpty(menu) && !string.IsNullOrEmpty(option))
        {
            return PassportOptionsList.Any(p =>
                p.PrvdMenuName != null &&
                p.PrvdMenuName.Value.IsCaseInsensativeTrimmedEqual(menu) &&
                p.PrvdMenuOpt != null &&
                p.PrvdMenuOpt.Value.IsCaseInsensativeTrimmedEqual(option));
        }

        return false;
    }

    public virtual bool IsStreamlineOption(PrvdUsrOptInfo_CType menuOption)
    {
        if (StreamlineOptionsList == null)
        {
            LoadStreamlineOptionsList();
        }

        if (menuOption != null && menuOption.PrvdMenuCmd != null &&
            !string.IsNullOrEmpty(menuOption.PrvdMenuCmd.GetValueOrDefault()))
        {
            PrvdUsrOptInfo_CType found;

            if (menuOption.PrvdMenuCmd.GetValueOrDefault().Contains("/"))
            {
                var forwardSlashIndex = menuOption.PrvdMenuCmd.GetValueOrDefault().IndexOf('/');
                found = StreamlineOptionsList.FirstOrDefault(
                    m => m.PrvdMenuCmd != null &&
                         m.PrvdMenuCmd.GetValueOrDefault().Contains('/') &&
                         m.PrvdMenuCmd.GetValueOrDefault().Substring(m.PrvdMenuCmd.GetValueOrDefault().IndexOf('/')) ==
                         menuOption.PrvdMenuCmd.GetValueOrDefault().Substring(forwardSlashIndex));
            }
            else
            {
                // Sometimes the commands have a '?' at the beginning and sometimes they don't. We trim the start to catch both cases.
                found = StreamlineOptionsList.FirstOrDefault(
                    m => m.PrvdMenuCmd != null &&
                         m.PrvdMenuCmd.GetValueOrDefault().TrimStart('?') ==
                         menuOption.PrvdMenuCmd.GetValueOrDefault().TrimStart('?'));
            }

            return found != null;
        }

        if (menuOption != null && menuOption.PrvdMenuPgm != null &&
            !string.IsNullOrEmpty(menuOption.PrvdMenuPgm.GetValueOrDefault()))
        {
            var found = StreamlineOptionsList.FirstOrDefault(
                m => m.PrvdMenuPgm != null &&
                     m.PrvdMenuPgm.GetValueOrDefault() == menuOption.PrvdMenuPgm.GetValueOrDefault());

            return found != null;
        }

        return false;
    }

    public virtual bool IsStreamlineOption(string menu, string option)
    {
        if (StreamlineOptionsList == null)
        {
            LoadStreamlineOptionsList();
        }

        if (!string.IsNullOrEmpty(menu) && !string.IsNullOrEmpty(option))
        {
            return StreamlineOptionsList.Any(p =>
                p.PrvdMenuName != null &&
                p.PrvdMenuName.Value.IsCaseInsensativeTrimmedEqual(menu) &&
                p.PrvdMenuOpt != null &&
                p.PrvdMenuOpt.Value.IsCaseInsensativeTrimmedEqual(option));
        }

        return false;
    }

    public virtual bool IsVertexOption(string menu, string option)
    {
        if (VertexOptionsList == null)
        {
            LoadVertexOptionsList();
        }

        if (!string.IsNullOrEmpty(menu) && !string.IsNullOrEmpty(option))
        {
            return VertexOptionsList.Any(p =>
                p.PrvdMenuName != null &&
                p.PrvdMenuName.Value.IsCaseInsensativeTrimmedEqual(menu) &&
                p.PrvdMenuOpt != null &&
                p.PrvdMenuOpt.Value.IsCaseInsensativeTrimmedEqual(option));
        }

        return false;
    }

    public virtual bool IsTimeTrackOption(PrvdUsrOptInfo_CType menuOption)
    {
        if (TimeTrackOptionsList == null)
        {
            LoadTimeTrackOptionsList();
        }

        if (menuOption != null && menuOption.PrvdMenuCmd != null &&
            !string.IsNullOrEmpty(menuOption.PrvdMenuCmd.GetValueOrDefault()))
        {
            PrvdUsrOptInfo_CType found;

            if (menuOption.PrvdMenuCmd.GetValueOrDefault().Contains("/"))
            {
                var forwardSlashIndex = menuOption.PrvdMenuCmd.GetValueOrDefault().IndexOf('/');
                found = TimeTrackOptionsList.FirstOrDefault(
                    m => m.PrvdMenuCmd != null &&
                         m.PrvdMenuCmd.GetValueOrDefault().Contains('/') &&
                         m.PrvdMenuCmd.GetValueOrDefault().Substring(m.PrvdMenuCmd.GetValueOrDefault().IndexOf('/')) ==
                         menuOption.PrvdMenuCmd.GetValueOrDefault().Substring(forwardSlashIndex));
            }
            else
            {
                // Sometimes the commands have a '?' at the beginning and sometimes they don't. We trim the start to catch both cases.
                found = TimeTrackOptionsList.FirstOrDefault(
                    m => m.PrvdMenuCmd != null &&
                         m.PrvdMenuCmd.GetValueOrDefault().TrimStart('?') ==
                         menuOption.PrvdMenuCmd.GetValueOrDefault().TrimStart('?'));
            }

            return found != null;
        }

        if (menuOption != null && menuOption.PrvdMenuPgm != null &&
            !string.IsNullOrEmpty(menuOption.PrvdMenuPgm.GetValueOrDefault()))
        {
            var found = TimeTrackOptionsList.FirstOrDefault(
                m => m.PrvdMenuPgm != null &&
                     m.PrvdMenuPgm.GetValueOrDefault() == menuOption.PrvdMenuPgm.GetValueOrDefault());

            return found != null;
        }

        return false;
    }

    public virtual bool IsTimeTrackOption(string menu, string option)
    {
        if (TimeTrackOptionsList == null)
        {
            LoadTimeTrackOptionsList();
        }

        if (!string.IsNullOrEmpty(menu) && !string.IsNullOrEmpty(option))
        {
            return TimeTrackOptionsList.Any(p =>
                p.PrvdMenuName != null &&
                p.PrvdMenuName.Value.IsCaseInsensativeTrimmedEqual(menu) &&
                p.PrvdMenuOpt != null &&
                p.PrvdMenuOpt.Value.IsCaseInsensativeTrimmedEqual(option));
        }

        return false;
    }

    public virtual bool IsNetTellerOption(PrvdUsrOptInfo_CType menuOption)
    {
        if (NetTellerOptionsList == null)
        {
            LoadNetTellerOptionsList();
        }

        if (menuOption != null && menuOption.PrvdMenuCmd != null &&
            !string.IsNullOrEmpty(menuOption.PrvdMenuCmd.GetValueOrDefault()))
        {
            PrvdUsrOptInfo_CType found;

            if (menuOption.PrvdMenuCmd.GetValueOrDefault().Contains("/"))
            {
                var forwardSlashIndex = menuOption.PrvdMenuCmd.GetValueOrDefault().IndexOf('/');
                found = NetTellerOptionsList.FirstOrDefault(
                    m => m.PrvdMenuCmd != null &&
                         m.PrvdMenuCmd.GetValueOrDefault().Contains('/') &&
                         m.PrvdMenuCmd.GetValueOrDefault().Substring(m.PrvdMenuCmd.GetValueOrDefault().IndexOf('/')) ==
                         menuOption.PrvdMenuCmd.GetValueOrDefault().Substring(forwardSlashIndex));
            }
            else
            {
                // Sometimes the commands have a '?' at the beginning and sometimes they don't. We trim the start to catch both cases.
                found = NetTellerOptionsList.FirstOrDefault(
                    m => m.PrvdMenuCmd != null &&
                         m.PrvdMenuCmd.GetValueOrDefault().TrimStart('?') ==
                         menuOption.PrvdMenuCmd.GetValueOrDefault().TrimStart('?'));
            }

            return found != null;
        }

        if (menuOption != null && menuOption.PrvdMenuPgm != null &&
            !string.IsNullOrEmpty(menuOption.PrvdMenuPgm.GetValueOrDefault()))
        {
            var found = NetTellerOptionsList.FirstOrDefault(
                m => m.PrvdMenuPgm != null &&
                     m.PrvdMenuPgm.GetValueOrDefault() == menuOption.PrvdMenuPgm.GetValueOrDefault());

            return found != null;
        }

        return false;
    }

    public virtual bool IsNetTellerOption(string menu, string option)
    {
        if (NetTellerOptionsList == null)
        {
            LoadNetTellerOptionsList();
        }

        if (!string.IsNullOrEmpty(menu) && !string.IsNullOrEmpty(option))
        {
            return NetTellerOptionsList.Any(p =>
                p.PrvdMenuName != null &&
                p.PrvdMenuName.Value.IsCaseInsensativeTrimmedEqual(menu) &&
                p.PrvdMenuOpt != null &&
                p.PrvdMenuOpt.Value.IsCaseInsensativeTrimmedEqual(option));
        }

        return false;
    }

    public virtual bool IsSilloutteMenuOption(string menu, string option)
    {
        ////Would like a second opinion
        if (!string.IsNullOrEmpty(menu) && !string.IsNullOrEmpty(option))
        {
            if (menu.ToLower().Contains("silhouette"))
            {
                return true;
            }
        }

        return false;
    }

    public virtual void LoadPassportOptionsList()
    {
        try
        {
            var list = GetResourceTextFile(PassportOptionsListResourceName);
            PassportOptionsList = JhaSerializer.XmlDeserialize<List<PrvdUsrOptInfo_CType>>(list);
        }
        catch (Exception)
        {
            PassportOptionsList = new List<PrvdUsrOptInfo_CType>();
        }
    }

    public virtual void LoadStreamlineOptionsList()
    {
        try
        {
            var list = GetResourceTextFile(StreamlineListResourceName);
            StreamlineOptionsList = JhaSerializer.XmlDeserialize<List<PrvdUsrOptInfo_CType>>(list);
        }
        catch (Exception)
        {
            StreamlineOptionsList = new List<PrvdUsrOptInfo_CType>();
        }
    }

    public virtual void LoadVertexOptionsList()
    {
        try
        {
            var list = GetResourceTextFile(VertexListResourceName);
            VertexOptionsList = JhaSerializer.XmlDeserialize<List<PrvdUsrOptInfo_CType>>(list);
        }
        catch (Exception)
        {
            VertexOptionsList = new List<PrvdUsrOptInfo_CType>();
        }
    }

    public virtual void LoadTimeTrackOptionsList()
    {
        try
        {
            var list = GetResourceTextFile(TimeTrackListResourceName);
            TimeTrackOptionsList = JhaSerializer.XmlDeserialize<List<PrvdUsrOptInfo_CType>>(list);
        }
        catch (Exception)
        {
            TimeTrackOptionsList = new List<PrvdUsrOptInfo_CType>();
        }
    }

    public virtual void LoadNetTellerOptionsList()
    {
        try
        {
            var list = GetResourceTextFile(NetTellerListResourceName);
            NetTellerOptionsList = JhaSerializer.XmlDeserialize<List<PrvdUsrOptInfo_CType>>(list);
        }
        catch (Exception)
        {
            NetTellerOptionsList = new List<PrvdUsrOptInfo_CType>();
        }
    }

    public virtual string GetResourceTextFile(string filename)
    {
        var result = string.Empty;

        using (var stream = GetType().Assembly.GetManifestResourceStream(filename))
        {
            using (var sr = new StreamReader(stream))
            {
                result = sr.ReadToEnd();
            }
        }

        return result;
    }

    public bool IsJwalkJump(PrvdUsrOptInfo_CType option, bool passportEnabled, bool vertexEnabled,
        bool timeTrackEnabled, bool streamLineEnabled = false)
    {
        var isJwalkJump = false;

        if (!passportEnabled && IsPassportOption(option))
        {
            isJwalkJump = true;
        }
        else if (!vertexEnabled && IsVertexOption(option))
        {
            isJwalkJump = true;
        }
        else if (!timeTrackEnabled && IsTimeTrackOption(option))
        {
            isJwalkJump = true;
        }
        else if (!streamLineEnabled && IsStreamlineOption(option))
        {
            isJwalkJump = true;
        }
        else if (IsSilloutteMenuOption(option))
        {
            isJwalkJump = true;
        }

        return isJwalkJump;
    }

    public bool IsJwalkJump(string menu, string option, bool passportEnabled, bool vertexEnabled, bool timeTrackEnabled,
        bool streamLineEnabled = false)
    {
        var isJwalkJump = false;

        if (!passportEnabled && IsPassportOption(menu, option))
        {
            isJwalkJump = true;
        }
        else if (!vertexEnabled && IsVertexOption(menu, option))
        {
            isJwalkJump = true;
        }
        else if (!timeTrackEnabled && IsTimeTrackOption(menu, option))
        {
            isJwalkJump = true;
        }
        else if (!streamLineEnabled && IsStreamlineOption(menu, option))
        {
            isJwalkJump = true;
        }
        else if (IsSilloutteMenuOption(menu, option))
        {
            isJwalkJump = true;
        }

        return isJwalkJump;
    }
}