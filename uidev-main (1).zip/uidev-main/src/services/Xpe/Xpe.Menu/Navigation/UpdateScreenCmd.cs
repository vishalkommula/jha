﻿using Xpe.Abstraction.Model;

using MediatR;

namespace Xpe.Menu.Navigation;

public record UpdateScreenCmd(string UserIdentifier, ScreenData ScreenData) : IRequest;