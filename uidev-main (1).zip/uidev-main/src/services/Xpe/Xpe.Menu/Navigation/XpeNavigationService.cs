﻿using System.Collections.Concurrent;

using JackHenry.JHAContractTypes;
using Xpe.Abstraction.Commands;
using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;
using Xpe.Abstraction.Model;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;
using MediatR;
using Microsoft.Extensions.Logging;
using Xpe.Cache;
using Xpe.Cache.Infrastructure;
using System.Collections.ObjectModel;
using JackHenry.Enterprise.Collections;
using System.Drawing;

namespace Xpe.Menu.Navigation;

public class XpeNavigationService : IXpeNavigationService
{
    public XpeNavigationService(
        ILogger<XpeNavigationService> logger,
        IUserCache cacheManager,
        IUserService userService,
        IXperienceEnabledService xperienceEnabledService,
        IScreenHandlerService screenHandlerService,
        IInquiryTypeProvider inquiryTypeProvider,
        IMediator mediator)
    {
        Logger = logger;
        CacheManager = cacheManager;
        UserService = userService;
        XperienceEnabledService = xperienceEnabledService;
        ScreenHandlerService = screenHandlerService;
        InquiryTypeProvider = inquiryTypeProvider;
        Mediator = mediator;
    }

    private ILogger<XpeNavigationService> Logger { get; }
    private IUserCache CacheManager { get; }
    private IUserService UserService { get; }
    private IXperienceEnabledService XperienceEnabledService { get; }
    private IScreenHandlerService ScreenHandlerService { get; }
    public IInquiryTypeProvider InquiryTypeProvider { get; }
    private IMediator Mediator { get; }
    private BlockingCollection<ScreenDataUpdatedCmd> ScreenCollection { get; } = new();
    private bool IsSendingPing { get; set; }
    private string UserIdentifier { get; set; }
    public ScreenData? CurrentScreenData { get; set; }
    private UnmappedScreen UnmappedScreenData { get; set; }
    private bool OpenAccountLookupInquiryInXpe { get; set; }
    public string Grid1Header { get; set; }
    public XpeGridData Grid1Items { get; set; }
    public ObservableCollection<IToolbarItem> Grid1ToolbarItems { get; set; } = new();
    public string Grid2Header { get; set; }
    public XpeGridData Grid2Items { get; set; }
    public ObservableCollection<IToolbarItem> Grid2ToolbarItems { get; set; } = new();
    public bool HasMultipleGrids { get; set; }
    public bool HasGridItems { get; set; }
    public List<IBannerMessage> BannerMessages { get; set; }
    public bool IsMappedView { get; set; }

    public void Navigate(XpeNavigationEventArgs parameters)
    {
        UserIdentifier = parameters.UserIdentifier;

        Task.Factory.StartNew(MonitorScreenCollection);

        var xpeContext = CacheManager
            .GetInMemoryCache<XpeConnectionContext>(UserIdentifier, CacheConstants.XpeContextKey);

        if (xpeContext == null)
        {
            throw new ApplicationException("Current User Info is not initialized.");
        }

        if (string.IsNullOrWhiteSpace(parameters.InstitutionNumber))
        {
            parameters.InstitutionNumber = xpeContext.Value?.InstitutionNumber;
        }

        if (string.IsNullOrWhiteSpace(parameters.BankName))
        {
            parameters.BankName = xpeContext.Value?.BankName;
        }

        if (!CheckMenuOption(parameters))
        {
            EndSession(parameters.UserIdentifier);

            ////if parameters provided a jump account then we need to gather data for printheaders
            // if (this.parameters?.Account != null && this.parameters.Account is IAccount)
            // {
            //     this.accountInquiryService.InquireAndCacheAccountAsync(this.CurrentUserInfo, this.parameters.Account as IAccount, ActivityIntention.ReadOnly, false, false, this.OnAccountRetrieved, AsyncCallbackThreadOption.BackgroundThread);
            // }
            // else if (this.parameters != null && !string.IsNullOrEmpty(this.parameters.AccountNum))
            // {
            //     this.accountInquiryService.InquireAndCacheAccountAsync(this.CurrentUserInfo, new MiniAccount(this.parameters.AccountNum, this.parameters.AccountType), ActivityIntention.ReadOnly, false, false, this.OnAccountRetrieved, AsyncCallbackThreadOption.BackgroundThread);
            // }
            // else if (this.parameters != null && !string.IsNullOrEmpty(this.parameters.CustId))
            // {
            //     this.customerService.GetCustomerAsync(this.CurrentUserInfo, this.parameters.CustId, ActivityIntention.ReadOnly, false, false, this.OnCustomerRetrieved, AsyncCallbackThreadOption.BackgroundThread);
            // }

            GoToInitialScreen(parameters.UserIdentifier);
        }
    }

    public void EndSession(string userIdentifier)
    {
        XperienceEnabledService.EndSession(userIdentifier, UserService.CurrentUserInfo);
    }

    public void GoToInitialScreen(string userIdentifier)
    {
        XperienceEnabledService.SignOn(userIdentifier, UserService.CurrentUserInfo);
    }

    public void OnUpdateView(ScreenDataUpdatedCmd args)
    {
        if (!ScreenCollection.IsAddingCompleted)
        {
            ScreenCollection.Add(args);
        }
    }

    public void SendCommand(string key, bool isMappedView, List<ScreenField5250> changedFields)
    {
        try
        {
            this.SetMappedViewForDurationOfClickEvent(isMappedView);

            ScreenField5250 imageIdField = null;

            if (CurrentScreenData?.NVPImageViewerOverrideKey == key &&
                ScreenFieldExtensions.IsValidRRCCC(CurrentScreenData?.NVPImageViewerIdRRCCC))
            {
                imageIdField = CurrentScreenData.ScreenInfo?.AllFields?.FirstOrDefault(f => f.RRCCC == CurrentScreenData.NVPImageViewerIdRRCCC);
            }

            ////If the current screen was mapped with an image override key (and image Id location), we use it to launch the appropriate image viewer.
            ////Else, we send the key command.
            if (!string.IsNullOrEmpty(imageIdField?.Data))
            {
                // OpenImageViewer(CurrentScreenData.CurrentAccount, new XPECheckImageModel(imageIdField.Data));
            }
            else
            {
                KeyConverter keyConverter = new KeyConverter();

                string[] keyWithModifier = key.Split('+');

                if (keyWithModifier.Length > 1)
                {
                    Key modifier = (Key)keyConverter.ConvertFromString(keyWithModifier[0]);
                    Key keyPress = (Key)keyConverter.ConvertFromString(keyWithModifier[1]);
                    XperienceEnabledService.SendCommand(new ScreenInfoRequest(new KeyPress(keyPress, modifier), CurrentScreenData.ScreenInfo?.CursorLocation, changedFields));
                }
                else
                {
                    XperienceEnabledService.SendCommand(new ScreenInfoRequest(new KeyPress((Key)keyConverter.ConvertFromString(key.Replace(" ", string.Empty)), Key.None), CurrentScreenData.ScreenInfo.CursorLocation, changedFields));
                }
            }
        }
        catch (Exception ex)
        {
            Logger.LogError(ex.Message, ex);
        }
    }

    private void SetMappedViewForDurationOfClickEvent(bool isMappedView)
    {
        this.IsMappedView = isMappedView;
    }

    public void SendCommand(ScreenInfoRequest screenInfoRequest)
    {
        try
        {
            if (!this.IsMappedView)
            {
                this.SendUnmappedData(screenInfoRequest);
            }
            else
            {
                if (this.IsKeyValid(screenInfoRequest.Key))
                {
                    this.SendMappedData(screenInfoRequest);
                }
            }
        }
        catch (Exception ex)
        {
            this.Logger.LogError("Error sending command", ex.Message, ex);
        }
    }

    public void SendPing(bool mappedScreenView)
    {
        if (CurrentScreenData != null && CurrentScreenData.ScreenInfo.ScreenId != ScreenIdentification.PendingProcess)
        {
            IsSendingPing = true;

            ScreenInfoRequest pingRequest = new ScreenInfoRequest(new KeyPress(Key.Enter, Key.None), new CursorLocation(0, 0))
            {
                SocketCommand = SocketCommand.PING
            };

            // When a user receives a break message, we are unable to execute a ping. We remain
            // on that screen until the user acknowledges the message. In order to avoid a
            // timeout when this occurs, we execute an F10 to display all messages. Then our
            // BreakMessageScreenHandler is able to
            //// handle the screen appropriately.
            if (CurrentScreenData.ScreenInfo.ScreenId == ScreenIdentification.WorkMessagesScreen)
            {
                pingRequest = new ScreenInfoRequest(new KeyPress(Key.F10, Key.None), CurrentScreenData.ScreenInfo.CursorLocation);
            }

            if (!mappedScreenView)
            {
                this.SendUnmappedData(pingRequest);
            }
            else
            {
                this.SendMappedData(pingRequest);
            }
        }
    }

    private bool IsKeyValid(KeyPress key)
    {
        // Always allow F4 for Prompting, Alt+F1 for Help, Escape for Attention, and Shift+Escape
        // for System Request.
        if ((key.Key == Key.Enter && key.Modifier == Key.None) ||
            (key.Key == Key.F4 && key.Modifier == Key.None) ||
            (key.Key == Key.F1 && key.Modifier == Key.LeftAlt) ||
            (key.Key == Key.Escape && (key.Modifier == Key.None || key.Modifier == Key.LeftShift)))
        {
            return true;
        }
        else
        {
            //// Figure out if the key is valid
            //TODO
            return false;
            //return this.validKeys.Any(k => k.IsEqual(key));
        }
    }

    public bool CheckMenuOption(XpeNavigationEventArgs args)
    {
        return ScreenHandlerService.MenuOptionSelected(args);
    }

    private void OpenImageViewer(IAccount account, IImageItem selectedImageItem, List<IImageItem> imageItems = null)
    {
        try
        {
            string uniqueId = string.Format("{0}_{1}", UIFunctionKey.ImageDetailViewer, selectedImageItem.ImgNum);

            //TODO: Open Image Viewer
        }
        catch (Exception ex)
        {
            Logger.LogError("Opening image viewer", ex);
        }
    }

    private void MonitorScreenCollection()
    {
        while (!ScreenCollection.IsCompleted)
        {
            ScreenDataUpdatedCmd viewEvent = null;

            // Blocks if number.Count == 0 IOE means that Take() was called on a completed
            // collection. Some other thread can call CompleteAdding after we pass the
            // IsCompleted check but before we call Take. In this example, we can simply catch
            // the exception since the loop will break on the next iteration.
            try
            {
                viewEvent = ScreenCollection.Take();
            }
            catch (InvalidOperationException)
            {
            }

            if (viewEvent != null)
            {
                OnScreenReturned(viewEvent.ScreenData);
            }
        }
    }

    private void OnScreenReturned(ScreenData response)
    {
        try
        {
            CurrentScreenData = response;

            if (response.IsStaticLayoutScreen && !IsSendingPing)
            {
                return;
            }

            response.IsPingMessage = IsSendingPing;
            var rq = ScreenHandlerService.HandleScreen(response, UserService.CurrentUserInfo,
                "SESSIONID", DeferredSendCommand, XperienceEnabledService);

            if (rq != null && rq.Key.Key != Key.None)
            {
                XperienceEnabledService.SendCommand(rq);

                return;
            }

            if (HandleXPScreens(response))
            {
                SendPreviousCommand(response);
                return;
            }

            SetScreenNameAndPageMode(response);
            SetBannerMessageContent(response);
            SetUIGridContent(response);
            SetNVPGridContent(response);
            //SetSentencePanelContent(response);
            SetUnmappedScreenContent(response);

            if (!string.IsNullOrEmpty(response.ScreenInfo.ScreenId))
            {
                if (response.ScreenActionItems?.Any() != null)
                {
                    response.ToolbarItems = this.GetToolbarItems(response);
                }

                if (response.ScreenInfo.ScreenId == ScreenIdentification.JumpScreen ||
                    response.ScreenInfo.ScreenId == ScreenIdentification.TimeTrackJumpScreen)
                {
                    Mediator.Send(new UpdateScreenCmd(UserIdentifier, null));
                }
                else
                {
                    Mediator.Send(new UpdateScreenCmd(UserIdentifier, response));
                }
            }
        }
        catch (Exception ex)
        {
            Logger.LogError("error in OnScreenReturned", ex);
        }
    }

    private List<InputField> GetInputFieldList(List<ScreenField5250> list)
    {
        var fields = new List<InputField>();

        foreach (var sf in list)
        {
            fields.Add(new InputField(sf));
        }

        return fields;
    }

    private void DeferredSendCommand(ScreenInfoRequest screenInfoRequest)
    {
        XperienceEnabledService.SendCommand(screenInfoRequest);
    }

    protected void SendMappedData(ScreenInfoRequest screenInfoRequest)
    {
        ScreenHandlerService.HandleInputAsync(CurrentScreenData, screenInfoRequest, UserService.CurrentUserInfo)
            .ContinueWith(
                t => { OnHandleInputResponse(t, screenInfoRequest); });
    }

    private void SendUnmappedData(ScreenInfoRequest screenInfoRequest)
    {
        ScreenHandlerService.HandleInputAsync(CurrentScreenData, screenInfoRequest, UserService.CurrentUserInfo)
            .ContinueWith(
                t => { OnHandleInputResponse(t, screenInfoRequest); });
    }

    private void OnHandleInputResponse(Task<bool> task, ScreenInfoRequest screenInfoRequest)
    {
        var inputHandled = false;

        if (task.IsFaulted)
        {
            Logger.LogError("on handle input response", task.Exception);
        }
        else if (!task.IsCanceled)
        {
            inputHandled = task.Result;
        }

        if (!inputHandled)
        {
            //// returns false if input was not handled already by the screen handler, true if handler handles the request and is done
            XperienceEnabledService.SendCommand(screenInfoRequest);
        }
    }

    private void SendPreviousCommand(ScreenData screenData)
    {
        if (!OpenAccountLookupInquiryInXpe)
        {
            XperienceEnabledService.SendCommand(new ScreenInfoRequest(new KeyPress(Key.F12, Key.None), screenData.ScreenInfo.CursorLocation));
        }
    }

    private bool HandleXPScreens(ScreenData screenData)
    {
        bool openedCustomerAndAcctInq = false;

        if (ScreenIdentification.InquiryScreens.Any(s => s == screenData.ScreenInfo.ScreenId))
        {
            openedCustomerAndAcctInq = HandleAccountInquiryScreens(screenData);
        }
        else
        {
            switch (screenData.ScreenInfo.ScreenId)
            {
                case ScreenIdentification.AccountPrompt:
                    openedCustomerAndAcctInq = /*OpenAccountLookupForAccount(screenData)*/false;
                    break;

                case ScreenIdentification.GLAccountPrompt:
                    openedCustomerAndAcctInq = /*OpenAccountLookup(InquiryTypeProvider.GLCode, screenData)*/false;
                    break;
                case ScreenIdentification.NettellerAccountPrompt:

                    if (!screenData.ScreenActionItems.Any(a => a.Action.IsCaseInsensativeTrimmedEqual("Add")))
                    {
                        openedCustomerAndAcctInq = /*OpenAccountLookup(InquiryTypeProvider.InternetCode, screenData)*/false;
                    }

                    break;

                case ScreenIdentification.MultipleAccountPrompt:
                    openedCustomerAndAcctInq = /*OpenAccountLookup(InquiryTypeProvider.AllTypes, screenData)*/false;
                    break;

                case ScreenIdentification.CreditLinePrompt:
                    openedCustomerAndAcctInq = /*OpenAccountLookup(InquiryTypeProvider.AllCreditLines, screenData)*/false;
                    break;

                case ScreenIdentification.PlanAccountPrompt:

                    if (screenData.ScreenName?.Contains("Inquiry") == true)
                    {
                        openedCustomerAndAcctInq = /*OpenAccountLookup(InquiryTypeProvider.IRACode, screenData)*/false;
                    }

                    break;
            }
        }

        return openedCustomerAndAcctInq;
    }

    private bool HandleAccountInquiryScreens(ScreenData screenData)
    {
        bool openedCustomerAndAcctInq = false;

        if (!XperienceEnabledService.IsCustomScreen(UserService.CurrentUserInfo, screenData.ScreenInfo.ScreenId, null, null, false))
        {
            switch (screenData.ScreenInfo.ScreenId)
            {
                case ScreenIdentification.DemandDepositsInquiry:
                    openedCustomerAndAcctInq = /*OpenDemandDepositInquiry(screenData)*/false;
                    break;

                case ScreenIdentification.LoanInquiry1:
                case ScreenIdentification.LoanInquiry2:
                    openedCustomerAndAcctInq = /*OpenLoanInquiry(screenData)*/false;
                    break;

                case ScreenIdentification.TimeDepositInquiry:
                    openedCustomerAndAcctInq = /*OpenAccountInquiry(screenData, InquiryTypeProvider.CDCode)*/false;
                    break;

                case ScreenIdentification.NonJHAInquiry:
                    openedCustomerAndAcctInq = /*OpenNonJHAAccountInquiry(screenData)*/false;
                    break;

                case ScreenIdentification.CustomerInquiry:
                    openedCustomerAndAcctInq = /*OpenCustomerInquiry(screenData)*/false;
                    break;

                case ScreenIdentification.GeneralLedgerInquiry:
                    openedCustomerAndAcctInq = /*OpenGLAccountInquiry(screenData)*/false;
                    break;

                case ScreenIdentification.PlanInquiry:
                    openedCustomerAndAcctInq = /*OpenPlanInquiry(screenData)*/false;
                    break;

                case ScreenIdentification.NettellerInquiry:
                    openedCustomerAndAcctInq = /*OpenNettellerInquiry(screenData)*/false;
                    break;

                case ScreenIdentification.CreditLineInquiry:
                    openedCustomerAndAcctInq = /*OpenCreditLineInquiry(screenData)*/false;
                    break;
            }
        }

        return openedCustomerAndAcctInq;
    }

    private void SetUIGridContent(ScreenData screenData)
    {
        if (screenData.Grids != null && screenData.Grids.Any())
        {
            var grid1Buttons = new List<IToolbarItem>();

            this.Grid1Items = screenData.Grids[0];
            this.Grid1Header = screenData.Grids[0].HeaderText;

            if (this.Grid1Items.DataTable != null)
            {
                this.HasGridItems = true;

                if (this.Grid1Items.DataTable.Rows != null && this.Grid1Items.DataTable.Rows.Count > 0)
                {
                    if (this.Grid1Items as XpeUIGridData != null ||
                        this.Grid1Items as NVPGridData != null)
                    {
                        grid1Buttons.Add(new PrintButtonToolbarItem("Grid1GroupBox", "Parent"));
                    }

                    grid1Buttons = this.AddGridNavButtons(grid1Buttons, this.Grid1Items, screenData.GridToolbarItems);
                }
                else if (screenData.GridToolbarItems != null && screenData.GridToolbarItems.Any(t => t is GridSearchToolbarItem))
                {
                    grid1Buttons = this.AddGridSearchFields(grid1Buttons, screenData.GridToolbarItems);
                }
            }

            this.Grid1ToolbarItems.AddRange(grid1Buttons);

            // There are a few screens that have 2 grids
            if (screenData.Grids.Count == 2)
            {
                var grid2Buttons = new List<IToolbarItem>();

                this.Grid2Items = screenData.Grids[1];
                this.Grid2Header = screenData.Grids[1].HeaderText;

                if (this.Grid2Items.DataTable != null)
                {
                    this.HasMultipleGrids = true;

                    if (this.Grid2Items.DataTable.Rows != null && this.Grid2Items.DataTable.Rows.Count > 0)
                    {
                        if (this.Grid2Items as XpeUIGridData != null ||
                            this.Grid2Items as NVPGridData != null)
                        {
                            grid2Buttons.Add(new PrintButtonToolbarItem("Grid2GroupBox", "Parent"));
                        }

                        grid2Buttons = this.AddGridNavButtons(grid2Buttons, this.Grid2Items, screenData.GridToolbarItems);
                    }
                    else if (screenData.GridToolbarItems != null && screenData.GridToolbarItems.Any(t => t is GridSearchToolbarItem))
                    {
                        grid2Buttons = this.AddGridSearchFields(grid2Buttons, screenData.GridToolbarItems);
                    }
                }

                this.Grid2ToolbarItems.AddRange(grid2Buttons);
            }
        }
    }

    private void SetUnmappedScreenContent(ScreenData screenData)
    {
        UnmappedScreenData = new UnmappedScreen(
            GetInputFieldList(screenData.ScreenInfo.InputFields),
            screenData.ScreenInfo.OutputFields, screenData.ScreenName, screenData.ScreenInfo.ScreenHeight,
            screenData.ScreenInfo.ScreenWidth, screenData.ScreenInfo.IsIBMScreen);
    }

    private void SetNVPGridContent(ScreenData screenData)
    {
        if (screenData.NVPGrids != null && screenData.NVPGrids.Any())
        {
            foreach (NVPGridData grid in screenData.NVPGrids)
            {
                if (grid.IsToolbarVisible)
                {
                    List<IToolbarItem> gridButtons = new List<IToolbarItem>();

                    // We only keep Next/Previous functionality if it's the last NVP grid
                    // and there are no UI Grids
                    if (grid != screenData.NVPGrids.LastOrDefault() || this.Grid1Items != null)
                    {
                        grid.NextDataCommand = null;
                        grid.PreviousDataCommand = null;
                    }

                    this.AddGridNavButtons(gridButtons, grid, screenData.GridToolbarItems);

                    if (gridButtons != null && gridButtons.Any())
                    {
                        grid.ToolbarItems.AddRange(gridButtons);
                    }
                }
            }
        }
    }

    private List<IToolbarItem> AddGridSearchFields(List<IToolbarItem> gridButtons, List<IToolbarItem> gridToolbarControls = null)
    {
        gridButtons.AddRange(gridToolbarControls);

        return gridButtons;
    }

    protected virtual List<IToolbarItem> AddGridNavButtons(List<IToolbarItem> gridButtons, XpeGridData gridItems, List<IToolbarItem> gridToolbarControls = null)
    {
        int btnCount = gridButtons.Count;

        if (gridItems.PreviousDataCommand != null)
        {
            gridButtons.Add(new ToolbarItem("previous", "Previous Records", JhaImageTypes.Previous.ToString(), true, false, "Get previous records"));
        }

        if (gridItems.NextDataCommand != null)
        {
            gridButtons.Add(new ToolbarItem("next", "Next Records", JhaImageTypes.Next.ToString(), true, false, "Get next records"));
        }

        if (gridItems.ExportGridDataCommand != null)
        {
            gridButtons.Add(
                new ToolbarItem(
                "exporttoexcel",
                "Export Records",
                JhaImageTypes.MicrosoftExcel.ToString(),
                true,
                false,
                "Export records"));
        }

        if (gridToolbarControls != null && gridToolbarControls.Any())
        {
            gridButtons.AddRange(gridToolbarControls);
        }

        if (gridItems.GridOptions != null && gridItems.GridOptions.Any())
        {
            foreach (ScreenMapGridArrayGridGridOption option in gridItems.GridOptions)
            {
                gridButtons.Add(new ToolbarItem(string.Format("Option{0}", Guid.NewGuid().ToString("N")), option.OptionAction, null, true, false, option.OptionAction));
            }
        }

        // If the original button count is greater than 1 and we've added more toolbar buttons,
        // add a separator in between
        if (btnCount > 0 && btnCount < gridButtons.Count)
        {
            gridButtons.Insert(btnCount, new ToolbarItem("seperator", null, null, true, false, null));
        }

        return gridButtons;
    }

    private List<ToolbarItem> GetToolbarItems(ScreenData screenData)
    {
        List<ToolbarItem> items = new List<ToolbarItem>();

        if (screenData.ScreenInfo.ScreenId != ScreenIdentification.JumpScreen)
        {
            foreach (ScreenMapActionKey key in screenData.ScreenActionItems)
            {
                if (key.Action != null)
                {
                    if (key.IsOK())
                    {
                        int count = 0;
                        // If the only input fields available are a grid option field and a
                        // search field, rename the 'OK' button to 'Enter'
                        count = this.Grid1ToolbarItems != null ? this.Grid1ToolbarItems.Count(x => x is GridSearchToolbarItem) : 0;

                        if (this.Grid1Items != null && this.Grid1Items.GridOptions != null && this.Grid1Items.GridOptions.Any())
                        {
                            count += this.Grid1Items.DataTable.Rows.Count;
                        }

                        if (screenData.ScreenInfo.InputFields.Count(x => x.IsInputField()) == count && !screenData.ScreenActionItems.Any(k => k.IsMappedSubmitKey))
                        {
                            key.Action = "Enter";
                        }
                    }

                    var icon = this.GetButtonIcon(key);

                    bool isFocused = key.IsFocused;

                    string toolTip = string.Format("{0} {1}", key.Action, key.Key.ToUpper() == "F13" ? string.Empty : string.Format("({0})", key.Key));

                    items.Add(new ToolbarItem(key.Key, key.Action, icon.ToString(), true, false, toolTip));

                    if (!string.IsNullOrWhiteSpace(key.Key))
                    {
                        try
                        {
                            KeyConverter keyConverter = new KeyConverter();
                        }
                        catch (Exception ex)
                        {
                            this.Logger.LogError(ex.Message, ex);
                        }
                    }
                }
            }

            //items.RemoveAll(t => t is ToolbarItem && (t as ToolbarItem).Text == "Exit");

            items.Add(new ToolbarItem("copy", "Copy", null, false, false, "Copy unmapped screen text"));

            //TODO
            //if (this.UserService.CurrentUserHasSupportOptions(this.userSettings))
            //{
            //    List<IToolbarItem> higherLevelItems = this.GetHigherLevelButtons(screenData);

            //    if (items.Any())
            //    {
            //        items.Add(new SeparatorToolbarItem("HigherSeparator"));
            //    }

            //    items.AddRange(higherLevelItems);

            //}
        }

        return items;
    }

    private JhaImageTypes GetButtonIcon(ScreenMapActionKey key)
    {
        JhaImageTypes icon = JhaImageTypes.None;

        if (key.Key.ToLower() == "f12")
        {
            icon = JhaImageTypes.ArrowLeft;
        }
        else if (key.Key.ToLower() == "f3")
        {
            icon = JhaImageTypes.Close;
        }

        return icon;
    }

    private void SetScreenNameAndPageMode(ScreenData screenData)
    {
        if (!string.IsNullOrWhiteSpace(screenData.PageMode))
        {
            screenData.ScreenName = string.Format("{0} - {1}", screenData.ScreenName.Trim(), screenData.PageMode.Trim());
        }
        else if (string.IsNullOrEmpty(screenData.ScreenName) && !screenData.IsMappedScreen)
        {
            screenData.ScreenName = "Unmapped Screen";
        }
        else
        {
            screenData.ScreenName = screenData.ScreenName;
        }
    }

    private void SetBannerMessageContent(ScreenData screenData)
    {
        if (screenData?.CurrentAccount != null &&
            screenData.BannerMessageType != MessageFilterType.None)
        {
            GetBannerInfo(screenData);
        }
    }

    private async void GetBannerInfo(ScreenData screenData)
    {
        try
        {
            IInquiryResponse<CustInfoMsgInqRs_MType> response = null;
            //TODO: Implement
            //response = await this.customerService.CustomerInfoMessageSearchAsync(UserService.CurrentUserInfo, screenData.CurrentAccount);
            OnBannerInfoRetrieved(response, screenData.BannerMessageType, screenData.CurrentAccount);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex.Message, ex);
        }
    }

    private void OnBannerInfoRetrieved(IInquiryResponse<CustInfoMsgInqRs_MType> messages, string filterType, IAccount currentAccount)
    {
        try
        {
            if (messages == null)
            {
                Logger.LogError("Messages result is null.");
                return;
            }

            InfoMsgInqRec_CType[]? messageArray = null;

            // check for errors
            if (messages.Payload_Rs == null || messages.Payload_Rs.InfoMsgInqRecArray == null || messages.Payload_Rs.InfoMsgInqRecArray.Length < 1)
            {
                Logger.LogError("No customer messages found");

                if (messages.Errors != null && messages.Errors.Any())
                {
                    foreach (IResultInfoMessage ir in messages.Errors)
                    {
                        Logger.LogError(ir.ToString());
                    }
                }
            }
            else
            {
                Logger.LogError(string.Format("{0} customer messages found.", messages.Payload_Rs.InfoMsgInqRecArray.Length));
                messageArray = messages.Payload_Rs.InfoMsgInqRecArray;
            }

            if (messageArray?.Any() == true)
            {
                IEnumerable<InfoMsgInqRec_CType> filteredMessages;

                switch (filterType)
                {
                    case MessageFilterType.Exception:
                        filteredMessages = messageArray.Where(m => m.InfoMsgType != MessageFilterType.Payoff && m.InfoMsgType == MessageFilterType.Exception);
                        break;

                    case MessageFilterType.Payoff:
                        filteredMessages = messageArray.Where(m => m.InfoMsgType == MessageFilterType.Payoff && m.InfoMsgType != MessageFilterType.Exception);
                        break;

                    default:
                        filteredMessages = messageArray.Where(m => m.InfoMsgType != MessageFilterType.Payoff && m.InfoMsgType != MessageFilterType.Exception);
                        break;
                }

                if (filteredMessages != null)
                {
                    List<IBannerMessage> list = new List<IBannerMessage>();

                    foreach (InfoMsgInqRec_CType singleMessage in filteredMessages)
                    {
                        if (singleMessage.InfoMsg != null)
                        {
                            //TODO
                            //IFunction function = this.functionService.GetFunctionForInfoMessage(singleMessage.InfoMsg.Value, currentAccount, null, this.ParentWindowIdentifier);
                            //JhaImageTypes iconType = function != null ? function.IconType : JhaImageTypes.StandardInformation;
                            //InfoMsgInqRecBannerMessageModel messageModel = new InfoMsgInqRecBannerMessageModel(singleMessage.InfoMsg, iconType);
                            //list.Add(messageModel);
                            //function?.Dispose();
                        }
                    }

                    if (list.Any())
                    {
                        this.BannerMessages = list;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Logger.LogError(ex.Message, ex);
        }
    }

    protected virtual List<IToolbarItem> GetHigherLevelButtons(ScreenData screenData)
    {
        List<IToolbarItem> items = new List<IToolbarItem>();

        try
        {
            //TODO
            //List<ContextMenuItem> dropdownMenuItems = new List<ContextMenuItem>();

            //if (screenData.IsStaticLayoutScreen)
            //{
            //    ContextMenuItem monitor = new ContextMenuItem("Display Monitor", JhaImageTypes.History, false, null, null, this.DisplayMonitorCommand);
            //    dropdownMenuItems.Add(monitor);

            //    DropDownButtonToolbarItem dropDownItem = new DropDownButtonToolbarItem("HigherLevelButton", "Options", JhaImageTypes.Settings, ImageNames.ParametersSmall, dropdownMenuItems, true, false);

            //    items.Add(dropDownItem);
            //}
            //else if (screenData.IsMappedScreen)
            //{
            //    ContextMenuItem mappedViewItem = new ContextMenuItem("Mapped View", JhaImageTypes.ViewMediumIcons, true, "MappedScreenView", this, null);
            //    dropdownMenuItems.Add(mappedViewItem);

            //    ContextMenuItem showmappedViewItem = new ContextMenuItem("Show Unmapped Dialog", JhaImageTypes.ViewMediumIcons, false, null, null, this.DisplayUnmappedDialogCommand);
            //    dropdownMenuItems.Add(showmappedViewItem);

            //    ContextMenuItem monitor = new ContextMenuItem("Display Monitor", JhaImageTypes.History, false, null, null, this.DisplayMonitorCommand);
            //    dropdownMenuItems.Add(monitor);

            //    DropDownButtonToolbarItem dropDownItem = new DropDownButtonToolbarItem("HigherLevelButton", "Options", JhaImageTypes.Settings, ImageNames.ParametersSmall, dropdownMenuItems, true, false);

            //    items.Add(dropDownItem);
            //}
            //else
            //{
            //    ContextMenuItem monitor = new ContextMenuItem("Display Monitor", JhaImageTypes.History, false, null, null, this.DisplayMonitorCommand);
            //    dropdownMenuItems.Add(monitor);

            //    if (this.UserService.CurrentUserHasSupportOptions(this.userSettings) && this.userSettings.IsScreenMapperUser)
            //    {
            //        ContextMenuItem addScreenMap = new ContextMenuItem("Add Screen Map", JhaImageTypes.AddNew, false, null, null, this.AddScreenMapCommand);
            //        dropdownMenuItems.Add(addScreenMap);
            //    }

            //    DropDownButtonToolbarItem dropDownItem = new DropDownButtonToolbarItem("HigherLevelButton", "Options", JhaImageTypes.Settings, ImageNames.ParametersSmall, dropdownMenuItems, true, false);

            //    items.Add(dropDownItem);
            //}
        }
        catch (Exception ex)
        {
            this.Logger.LogError(ex.Message, ex);
        }

        return items;
    }
}
