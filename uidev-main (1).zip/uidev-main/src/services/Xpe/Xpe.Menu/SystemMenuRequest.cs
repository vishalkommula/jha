namespace Xpe.Menu;

public class SystemMenuRequest
{
    public SystemMenuFolder Folder { get; set; }
    public bool IsTimeTrack { get; set; }
}