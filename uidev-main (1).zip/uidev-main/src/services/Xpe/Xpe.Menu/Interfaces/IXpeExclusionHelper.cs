﻿using JackHenry.JHAContractTypes;

namespace Xpe.Menu.Interfaces;

public interface IXpeExclusionHelper
{
    bool IsNetTellerOption(PrvdUsrOptInfo_CType menuOption);
    bool IsPassportOption(PrvdUsrOptInfo_CType menuOption);
    bool IsSilloutteMenuOption(PrvdUsrOptInfo_CType menuOpt);
    bool IsStreamlineOption(PrvdUsrOptInfo_CType menuOption);
    bool IsVertexOption(PrvdUsrOptInfo_CType menuOption);
}