﻿namespace Xpe.Menu.Interfaces;

public interface IMenuService
{
    MenuQueryResponse GetMenuItems(string userIdentifier);

    SelectMenuItemResponse SelectMenuItem(string connectionId, string menuId);
}