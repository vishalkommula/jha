﻿using System.Collections.ObjectModel;
using JackHenry.Banking.IAdapter.Infrastructure.Models;
using JackHenry.JHAContractTypes;
using Xpe.Abstraction.Model;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;
using Xpe.Menu.Interfaces;
using Microsoft.Extensions.Logging;
using Xpe.Cache;
using Xpe.Cache.Infrastructure;
using Xpe.Cache.Model;

namespace Xpe.Menu;

// TODO: look into using BackgroundService
public class MenuService : IMenuService
{
    private const string CustomerInquiryMenuOption = "UICustInq";
    private const string ExceptionItemProcessingMenuOption = "UIExceptionItemProcessing";
    private const string FieldDefinitionsMenuOption = "UIFieldDef";
    private const string InstitutionMaintenanceMenuOption = "UIInstMaint";
    private const string PerformanceTestingMenuOption = "UIPerfTest";
    private const string ProductDefinitionsMenuOption = "UIProdDef";
    private const string RealTimeMenuOption = "UIRealTime";
    private const string ReportsMenuOption = "UIReports";
    private const string ScreenMapperEntryOption = "ScreenMapperEntry";
    private const string XpeEntryOption = "UIXpeEntry";
    private const string SystemMaintenanceMenuOption = "UISysMaint";
    private const string TransactionEntryMenuOption = "UITransactionEntry";
    private const string DocMergeDestinationId = "SilverLakeDocMerge";
    private const string UserMaintenanceMenuOption = "UIUsrMaint";
    private const string DocMergeMenuOption = "UIDOCMERGE";
    private const string PowerOnConfigurationId = "PowerOnConfiguration";
    private const string EnterpriseLoggingDestinationId = "EnterpriseLoggingDestinationId";

    public MenuService(
        ILogger<MenuService> logger,
        IUserCache cacheManager,
        IUserService userService,
        IXpeExclusionHelper xperienceEnabledExclusionHelper,
        IXpeNavigationService xpeNavigationService)
    {
        Logger = logger;
        CacheManager = cacheManager;
        UserService = userService;
        XperienceEnabledExclusionHelper = xperienceEnabledExclusionHelper;
        XpeNavigationService = xpeNavigationService;

        PopulateOptions();
    }

    private ILogger<MenuService> Logger { get; }

    private IUserCache CacheManager { get; }

    private IUserService UserService { get; }

    private List<DiscoveryFunction> ProductOptions { get; } = new();

    private IXpeExclusionHelper XperienceEnabledExclusionHelper { get; }

    private IXpeNavigationService XpeNavigationService { get; }

    // private static List<SystemMenuFolder> CoreMenuItems { get; set; } = new();
    //
    // private static List<SystemMenuFolder> DisplayedMenuItems { get; set; } = new();
    //
    // private static List<IMenuItem> FilteredMenuItems { get; set; } = new();

    public SelectMenuItemResponse SelectMenuItem(string connectionId, string menuId)
    {
        try
        {
            var cacheResponse = GetMenuState(connectionId);

            var menuState = cacheResponse.Value;

            // IMenuItem selectedItem = systemMenuFolder as IMenuItem;
            var selectedItem = FindEquivalentItemInCollection(menuState.CoreMenuItems, menuId);

            SetMenuItemProduct(selectedItem);

            // selectedItem = menuState.DisplayedMenuItems.FirstOrDefault(m =>
            //     m.MenuOpt.PrvdMenuLink != null && string.Equals(m.MenuOpt.PrvdMenuLink.GetValueOrDefault(),
            //         selectedItem.MenuOpt.PrvdMenuLink.GetValueOrDefault(), StringComparison.CurrentCultureIgnoreCase));

            // if (selectedItem == null)
            // {
            //     return Array.Empty<IMenuItem>();
            // }

            var filteredItems = FilterMenu(selectedItem, menuState)
                .OrderByDescending(item => item.MenuType == MenuType.Folder)
                .ThenBy(item => item.Title);

            return new SelectMenuItemResponse(MenuQueryResponseStatus.Success, filteredItems);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            throw;
        }
    }

    public MenuQueryResponse GetMenuItems(string userIdentifier)
    {
        var menuCacheResponse = GetMenuState(userIdentifier);

        if (menuCacheResponse.IsFound && menuCacheResponse.Value != null)
        {
            return new MenuQueryResponse(
                MenuQueryResponseStatus.Success,
                menuCacheResponse.Value.InitialMenu,
                SortSystemMenuFolders(menuCacheResponse.Value.CoreMenuItems));
        }

        var menuFolders = new List<SystemMenuFolder>();
        var folder = new SystemMenuFolder();
        var subFolder = new SystemMenuFolder();
        var previousFolderName = string.Empty;
        var previousFolderMenu = string.Empty;
        const bool isSupportUser = false;

        var response = JhaSerializer.XmlDeserialize<PrvdUsrOptsSrchRs_MType>(
            File.ReadAllText("./SampleScreenMaps/PrvdUsrOptsSrchResponse.xml"));

        foreach (var menuOption in response.ItemsArray)
        {
            var menuOpt = menuOption;
            var folderName = menuOpt.PrvdMenuDesc.GetValueOrDefault();
            var folderMenu = menuOpt.PrvdMenuName.GetValueOrDefault();

            if (folderName != previousFolderName || folderMenu != previousFolderMenu)
            {
                //// we only ever loop through top level folders here
                var folderMenuOpt = new PrvdUsrOptInfo_CType
                {
                    PrvdMenuDesc = folderName,
                    PrvdMenuName = folderMenu,
                    PrvdMenuLink = folderMenu
                };

                folder = new SystemMenuFolder
                {
                    MenuOpt = folderMenuOpt, Title = folderName, MenuItems = new List<IMenuItem>(),
                    HasMenuItems = true
                };

                previousFolderName = folderName;
                previousFolderMenu = folderMenu;

                menuFolders.Add(folder);
            }

            if (menuOpt.PrvdMenuPgm == null && menuOpt.PrvdMenuCmd == null && menuOpt.PrvdMenuLink != null)
            {
                subFolder = new SystemMenuFolder
                {
                    MenuOpt = menuOpt,
                    Title = menuOpt.PrvdMenuTxt.GetValueOrDefault(),
                    MenuItems = new List<IMenuItem>(),
                    IsSubFolder = true
                };

                folder.MenuItems.Add(subFolder);
            }
            else if ((menuOpt.PrvdMenuCmd != null && ProductOptions
                         .All(p => p.ISeriesTag?.ToUpper() != menuOpt.PrvdMenuCmd.Value.ToUpper())) ||
                     menuOpt.PrvdMenuOpt != null)
            {
                try
                {
                    if (menuOpt.PrvdMenuOpt != null && menuOpt.PrvdMenuTxt != null)
                    {
                        ////this is a menu item, null out link, it shouldn't be set because this is not a folder
                        menuOpt.PrvdMenuLink = null;

                        var menuItem = new SystemMenuItem
                        {
                            ////InstituionKey = inst.SerializableKey,
                            ////Alias = userInfo.AliasName,
                            ////SecurityGroup = userInfo.SecurityGroup,
                            InstitutionKey = "2022510",
                            Alias = userIdentifier,
                            SecurityGroup = "No Group",
                            MenuOpt = menuOpt,
                            Title = menuOpt.PrvdMenuTxt.GetValueOrDefault(),
                            Product = string.Empty,
                            AdvancedToolTip = isSupportUser
                        };

                        folder.MenuItems.Add(menuItem);
                    }
                }
                catch (Exception ex)
                {
                    var errorMessage =
                        string.Format("Error adding a function to {0} {1} menu group : {2}",
                            folderMenu, folderName, ex.Message);
                }
            }
        }

        RemoveSillouteFolderAndMenuOptions(menuFolders);
        HandleSLUIMenu(menuFolders);
        HandleEPMenu(menuFolders);

        var initialMenu = string.Empty;

        if (!string.IsNullOrWhiteSpace(response?.UsrInfo?.InitialMenu))
        {
            initialMenu = response.UsrInfo.InitialMenu;
        }

        var menuState = new UserMenuState
        {
            CoreMenuItems = menuFolders.ToList(),
            DisplayedMenuItems = menuFolders.ToList(),
            InitialMenu = initialMenu
        };

        CacheMenuState(userIdentifier, menuState);

        return new MenuQueryResponse(
            MenuQueryResponseStatus.Success,
            initialMenu,
            SortSystemMenuFolders(menuState.CoreMenuItems));
    }

    private static IEnumerable<SystemMenuFolder> SortSystemMenuFolders(IEnumerable<SystemMenuFolder> menuFolders)
    {
        return menuFolders
            .OrderBy(item => item.MenuType == MenuType.Folder)
            .ThenBy(item => item.Title);
    }

    private void RemoveSillouteFolderAndMenuOptions(List<SystemMenuFolder> menuFolders)
    {
        //// remove all silloute folders and menu options
        //// also remove any folders that don't have menu options under them
        var removeFolders = new List<IMenuItem>();

        foreach (var f in menuFolders)
        {
            var remove = false;

            if (XperienceEnabledExclusionHelper.IsSilloutteMenuOption(f.MenuOpt))
            {
                removeFolders.Add(f);
                remove = true;
            }

            if (!remove)
            {
                var folderMenuItems = new ObservableCollection<IMenuItem>(f.MenuItems);

                f.MenuItems.Clear();
                f.MenuItems.AddRange(folderMenuItems);
            }
        }

        menuFolders.RemoveAll(f => removeFolders.Contains(f));
    }

    private void HandleSLUIMenu(List<SystemMenuFolder> menuFolders)
    {
        ////if (!this.UserSettings.MenuOptionsSecured)
        if (true)
        {
            menuFolders.RemoveAll(m => m.MenuName != null && m.MenuName.ToUpper().Contains("SLUIMENU"));
        }
    }

    private void HandleEPMenu(List<SystemMenuFolder> allMenus)
    {
        var removableMenus = new Dictionary<IMenuItem, SystemMenuFolder>();
        SystemMenuFolder workNSFFolder = null;
        SystemMenuFolder displayNSFFolder = null;
        SystemMenuFolder returnedItemFolder = null;
        SystemMenuFolder eipSearchFolder = null;
        IMenuItem workNSFItem = null;
        IMenuItem displayNSFItem = null;
        IMenuItem returnedItemItem = null;
        IMenuItem eipSearchItem = null;

        foreach (var singleMenuFolder in allMenus)
        {
            if (singleMenuFolder.MenuItems == null)
            {
                continue;
            }

            foreach (var singleMenuItem in singleMenuFolder.MenuItems)
            {
                if (singleMenuItem.MenuOpt != null && singleMenuItem.MenuOpt.PrvdMenuPgm != null &&
                    (singleMenuItem.MenuOpt.PrvdMenuPgm.Contains("EP0210") ||
                     singleMenuItem.MenuOpt.PrvdMenuPgm.Contains("EP0211") ||
                     singleMenuItem.MenuOpt.PrvdMenuPgm.Contains("EP0212")))
                {
                    workNSFFolder = singleMenuFolder;
                    workNSFItem = singleMenuItem;
                    if (!removableMenus.ContainsKey(singleMenuItem))
                    {
                        removableMenus.Add(singleMenuItem, singleMenuFolder);
                    }
                }

                if (singleMenuItem.MenuOpt != null &&
                    singleMenuItem.MenuOpt.PrvdMenuPgm != null &&
                    (singleMenuItem.MenuOpt.PrvdMenuPgm.Contains("EP0216") ||
                     singleMenuItem.MenuOpt.PrvdMenuPgm.Contains("EP0217") ||
                     singleMenuItem.MenuOpt.PrvdMenuPgm.Contains("EP0218") ||
                     singleMenuItem.MenuOpt.PrvdMenuPgm.Contains("EP0230")))
                {
                    displayNSFFolder = singleMenuFolder;
                    displayNSFItem = singleMenuItem;
                    if (!removableMenus.ContainsKey(singleMenuItem))
                    {
                        removableMenus.Add(singleMenuItem, singleMenuFolder);
                    }
                }

                if (singleMenuItem.MenuOpt != null &&
                    singleMenuItem.MenuOpt.PrvdMenuPgm != null &&
                    (singleMenuItem.MenuOpt.PrvdMenuPgm.Contains("EP0220") ||
                     singleMenuItem.MenuOpt.PrvdMenuPgm.Contains("EP0221")))
                {
                    returnedItemFolder = singleMenuFolder;
                    returnedItemItem = singleMenuItem;
                    if (!removableMenus.ContainsKey(singleMenuItem))
                    {
                        removableMenus.Add(singleMenuItem, singleMenuFolder);
                    }
                }

                if (singleMenuItem.MenuOpt == null || singleMenuItem.MenuOpt.PrvdMenuPgm == null ||
                    (!singleMenuItem.MenuOpt.PrvdMenuPgm.Contains("EP5551") &&
                     !singleMenuItem.MenuOpt.PrvdMenuPgm.Contains("EP5510")))
                {
                    continue;
                }

                eipSearchFolder = singleMenuFolder;
                eipSearchItem = singleMenuItem;
                if (!removableMenus.ContainsKey(singleMenuItem))
                {
                    removableMenus.Add(singleMenuItem, singleMenuFolder);
                }
            }
        }

        foreach (SystemMenuItem singleMenuItem in removableMenus.Keys)
        {
            removableMenus[singleMenuItem].MenuItems.Remove(singleMenuItem);
        }

        if (workNSFFolder != null)
        {
            workNSFItem.Title = "Work with NSF/UCF items";
            workNSFItem.MenuOpt.PrvdMenuPgm = "EP0210/EP0211/EP0212";
            workNSFItem.MenuOpt.PrvdMenuCmd = "WorkEIPNSFJump";
            workNSFFolder.MenuItems.Add(workNSFItem);
        }

        if (displayNSFFolder != null)
        {
            displayNSFItem.Title = "Display NSF/UCF Items";
            displayNSFItem.MenuOpt.PrvdMenuPgm = "EP0216/EP0217/EP0218/EP0230";
            displayNSFItem.MenuOpt.PrvdMenuCmd = "DisplayEIPNSFJump";
            displayNSFFolder.MenuItems.Add(displayNSFItem);
        }

        if (returnedItemFolder != null)
        {
            returnedItemItem.Title = "Returned Items";
            returnedItemItem.MenuOpt.PrvdMenuPgm = "EP0220/EP0221";
            returnedItemItem.MenuOpt.PrvdMenuCmd = "EIPReturnedItemJump";
            returnedItemFolder.MenuItems.Add(returnedItemItem);
        }

        if (eipSearchFolder != null)
        {
            eipSearchItem.Title = "EIP History Search";
            eipSearchItem.MenuOpt.PrvdMenuPgm = "EP5551/EP5510";
            eipSearchItem.MenuOpt.PrvdMenuCmd = "EIPHistorySearchJump";
            eipSearchFolder.MenuItems.Add(eipSearchItem);
        }
    }

    private IEnumerable<IMenuItem> FilterMenu(IMenuItem menuItem, UserMenuState menuState)
    {
        if (menuItem is not SystemMenuFolder folder)
        {
            return Array.Empty<IMenuItem>();
        }

        if (!folder.MenuItems.Any())
        {
            if (folder.MenuOpt is { PrvdMenuLink: { } } &&
                !string.IsNullOrWhiteSpace(folder.MenuOpt.PrvdMenuLink.GetValueOrDefault()))
            {
                folder = GetFolder(folder, menuState);
            }
        }

        //// Soft Phone menu items are always removed.
        folder.MenuItems.RemoveAll(m => m.Title.ToUpper().Contains("SOFT PHONE"));

        return folder.MenuItems;
    }

    private SystemMenuFolder GetFolder(SystemMenuFolder folder, UserMenuState menuState)
    {
        var menuItemFound = menuState.DisplayedMenuItems.FirstOrDefault(
            m => m.MenuType == MenuType.Folder &&
                 m?.MenuOpt?.PrvdMenuLink?.GetValueOrDefault()?.ToUpper() ==
                 folder?.MenuOpt?.PrvdMenuLink?.GetValueOrDefault()?.ToUpper()) ?? folder;

        if (menuItemFound?.MenuItems == null || !menuItemFound.MenuItems.Any())
        {
            menuItemFound.MenuItems = new List<IMenuItem>();
        }

        return menuItemFound;
    }

    private void SetMenuItemProduct(IMenuItem menuItem)
    {
        if (!string.IsNullOrEmpty(menuItem.Product))
        {
            return;
        }

        var product = string.Empty;

        if (XperienceEnabledExclusionHelper.IsPassportOption(menuItem.MenuOpt))
        {
            product = XpeProduct.PassPort;
        }
        else if (XperienceEnabledExclusionHelper.IsNetTellerOption(menuItem.MenuOpt))
        {
            product = XpeProduct.NetTellerSL;
        }
        else if (XperienceEnabledExclusionHelper.IsStreamlineOption(menuItem.MenuOpt))
        {
            product = XpeResourceStrings.StreamLine;
        }
        //else if (this.IsTimeTrackMenuDisplayed)
        //{
        //    product = XpeProduct.TimeTrack;
        //}
        else
        {
            //product = this.ProductInfo.ProductName;
            product = "SilverLake";
        }


        menuItem.Product = product;
    }

    private IMenuItem FindEquivalentItemInCollection(IEnumerable<IMenuItem> searchedCollection,
        string menuId)
    {
        if (searchedCollection?.Any() == false)
        {
            return null;
        }

        foreach (var menuItem in searchedCollection)
        {
            if (menuItem is not SystemMenuFolder folder)
            {
                continue;
            }

            if (folder.MenuId.Equals(menuId, StringComparison.OrdinalIgnoreCase))
            {
                return folder;
            }

            var foundItem = FindEquivalentItemInCollection(folder.MenuItems, menuId);
            if (foundItem != null)
            {
                return foundItem;
            }
        }

        return null;
    }

    private void PopulateOptions()
    {
        ProductOptions.Add(new DiscoveryFunction
        {
            ISeriesTag = CustomerInquiryMenuOption
        });

        ProductOptions.Add(
            new DiscoveryFunction
            {
                ISeriesTag = ProductDefinitionsMenuOption
            });

        ProductOptions.Add(
            new DiscoveryFunction
            {
                ISeriesTag = FieldDefinitionsMenuOption
            });

        ProductOptions.Add(
            new DiscoveryFunction
            {
                ISeriesTag = SystemMaintenanceMenuOption
            });

        ProductOptions.Add(
            new DiscoveryFunction
            {
                ISeriesTag = InstitutionMaintenanceMenuOption
            });

        ProductOptions.Add(
            new DiscoveryFunction
            {
                ISeriesTag = UserMaintenanceMenuOption
            });

        ProductOptions.Add(
            new DiscoveryFunction
            {
                ISeriesTag = XpeEntryOption
            });

        ProductOptions.Add(
            new DiscoveryFunction
            {
                ISeriesTag = ScreenMapperEntryOption
            });

        ProductOptions.Add(
            new DiscoveryFunction
            {
                ISeriesTag = ExceptionItemProcessingMenuOption
            });

        ProductOptions.Add(new DiscoveryFunction
        {
            ISeriesTag = ReportsMenuOption
        });

        ProductOptions.Add(
            new DiscoveryFunction
            {
                ISeriesTag = PowerOnConfigurationId
            });

        ProductOptions.Add(
            new DiscoveryFunction
            {
                ISeriesTag = DocMergeMenuOption
            });

        ProductOptions.Add(
            new DiscoveryFunction
            {
                ISeriesTag = EnterpriseLoggingDestinationId
            });
    }

    private UserCacheResponse<UserMenuState> GetMenuState(string userIdentifier)
    {
        return CacheManager.GetInMemoryCache<UserMenuState>(userIdentifier, CacheConstants.MenuStateKey);
    }

    private void CacheMenuState(string userIdentifier, UserMenuState menuState)
    {
        CacheManager.AddInMemoryCache(userIdentifier, CacheConstants.MenuStateKey, menuState,
            new UserCacheOptions { SlidingExpiration = TimeSpan.FromMinutes(5) });
    }
}