﻿using Xpe.Menu.Interfaces;

namespace Xpe.Menu;

public record MenuQueryResponse(
    MenuQueryResponseStatus Status,
    string? InitialMenu,
    IEnumerable<IMenuItem>? MenuItems, 
    string[]? Errors = null);