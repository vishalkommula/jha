﻿using JackHenry.JHAContractTypes;
using Xpe.Menu.Interfaces;
using Newtonsoft.Json;

namespace Xpe.Menu;

public class SystemMenuFolder : IMenuItem
{
    public bool HasMenuItems { get; set; }
    public bool IsSubFolder { get; set; }
    public string MenuName { get; set; }
    
    public List<IMenuItem> MenuItems { get; set; }
    
    public bool IsFavoriteMenuItem { get; set; }
    
    public bool IsPasswordRequired { get; set; }
    
    public string MenuId { get; set; } = Guid.NewGuid().ToString("N");
    public string Product { get; set; }
    public string Title { get; set; }
    public PrvdUsrOptInfo_CType MenuOpt { get; set; }
    public MenuType MenuType => MenuType.Folder;

    public bool IsSameMenuOpt<T>(T comparedItem)
        where T : IMenuItem
    {
        return comparedItem?.MenuOpt?.PrvdMenuLink != null &&
               MenuOpt?.PrvdMenuLink != null &&
               MenuType == MenuType.Folder &&
               comparedItem.MenuOpt.PrvdMenuLink.GetValueOrDefault().ToUpper() ==
               MenuOpt.PrvdMenuLink.GetValueOrDefault().ToUpper();
    }
}