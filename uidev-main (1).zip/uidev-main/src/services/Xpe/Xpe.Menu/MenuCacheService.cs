﻿using System.Collections.Concurrent;
using JackHenry.Banking.IAdapter.Infrastructure.Models;
using JackHenry.JHAContractTypes;
using Xpe.Menu.Interfaces;

namespace Xpe.Menu;

public class MenuCacheService : IMenuCacheService
{
    private PrvdUsrOptsSrchRs_MType? IAdapterResponseCache { get; set; }

    private ConcurrentDictionary<string, IMenuItem[]> CoreMenuItems { get; set; } = new();

    private ConcurrentDictionary<string, IMenuItem[]> DisplayedMenuItems { get; set; } = new();

    public MenuCacheService()
    {
    }

    public PrvdUsrOptsSrchRs_MType GetAllMenuItems()
    {
        return IAdapterResponseCache ?? 
               (IAdapterResponseCache = JhaSerializer.XmlDeserialize<PrvdUsrOptsSrchRs_MType>(
                   File.ReadAllText("./SampleScreenMaps/PrvdUsrOptsSrchResponse.xml")));
    }
    
    public IMenuItem[] GetCoreMenuItems(string user)
    {
        return CoreMenuItems[user];
    }

    public void UpdateCoreMenuItems(string user, IMenuItem[] items)
    {
        var menuItems = CoreMenuItems.GetOrAdd(user, items);

        if (menuItems != items)
        {
            CoreMenuItems.TryUpdate(user, items, menuItems);
        }
    }
    
    public IMenuItem[] GetDisplayedMenuItems(string user)
    {
        return DisplayedMenuItems[user];
    }

    public void UpdateDisplayedMenuItems(string user, IMenuItem[] items)
    {
        var menuItems = DisplayedMenuItems.GetOrAdd(user, items);

        if (menuItems != items)
        {
            DisplayedMenuItems.TryUpdate(user, items, menuItems);
        }
    }
}