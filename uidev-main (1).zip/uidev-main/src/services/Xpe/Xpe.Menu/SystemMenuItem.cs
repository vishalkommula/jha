﻿using JackHenry.Banking.IAdapter.Infrastructure.Extensions;
using JackHenry.JHAContractTypes;
using Xpe.Menu.Interfaces;

namespace Xpe.Menu;

public class SystemMenuItem : IMenuItem
{
    public string Alias { get; set; }

    public bool AdvancedToolTip { get; set; }

    public string InstitutionKey { get; set; }

    public string SecurityGroup { get; set; }

    public string MenuId { get; set; } = Guid.NewGuid().ToString("N");

    public bool IsFavoriteMenuItem { get; set; }

    public bool IsPasswordRequired => MenuOpt?.PrvdMenuPswdReq?.Value.ToUpper() == "*YES";

    public PrvdUsrOptInfo_CType MenuOpt { get; set; }

    public MenuType MenuType
    {
        get
        {
            if (MenuOpt != null && !string.IsNullOrWhiteSpace(MenuOpt.PrvdMenuLink.GetValueOrDefault()))
            {
                if (MenuOpt.PrvdMenuLink.GetValueOrDefault() == "Customize")
                {
                    return MenuType.Customize;
                }

                return MenuType.Folder;
            }

            return MenuType.Item;
        }
    }

    public string Product { get; set; }

    public string Title { get; set; }

    public bool IsSameMenuOpt<T>(T comparedItem)
        where T : IMenuItem
    {
        if (comparedItem is SystemMenuItem opt2 &&
            InstitutionKey == opt2.InstitutionKey
            && Alias.IsCaseInsensativeEqual(opt2.Alias) &&
            SecurityGroup == opt2.SecurityGroup)
        {
            if (MenuType == MenuType.Folder && opt2.MenuType == MenuType.Folder)
            {
                if (MenuOpt.PrvdMenuLink.GetValueOrDefault() == opt2.MenuOpt.PrvdMenuLink.GetValueOrDefault())
                {
                    return true;
                }
            }
            else if (MenuOpt != null && opt2.MenuOpt != null && MenuType == MenuType.Item &&
                     opt2.MenuType == MenuType.Item)
            {
                if (MenuOpt.PrvdMenuCmd.GetValueOrDefault() == opt2.MenuOpt.PrvdMenuCmd.GetValueOrDefault() &&
                    MenuOpt.PrvdMenuName.GetValueOrDefault() == opt2.MenuOpt.PrvdMenuName.GetValueOrDefault() &&
                    MenuOpt.PrvdMenuOpt.GetValueOrDefault() == opt2.MenuOpt.PrvdMenuOpt.GetValueOrDefault() &&
                    MenuOpt.PrvdMenuPgm.GetValueOrDefault() == opt2.MenuOpt.PrvdMenuPgm.GetValueOrDefault())
                {
                    return true;
                }
            }
        }

        return comparedItem is SystemMenuFolder folder && folder.IsSameMenuOpt(this);
    }

    public string Misc1 { get; set; }

    public string Misc2 { get; set; }

    public string Misc3 { get; set; }

    public string Misc4 { get; set; }
}