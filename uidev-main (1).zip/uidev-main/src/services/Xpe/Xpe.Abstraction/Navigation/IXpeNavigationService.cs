﻿using System.Collections.Generic;

using Xpe.Abstraction.Commands;
using Xpe.Abstraction.Model;

namespace Xpe.Abstraction.Navigation;

public interface IXpeNavigationService
{
    void Navigate(XpeNavigationEventArgs parameters);

    void GoToInitialScreen(string userIdentifier);

    void OnUpdateView(ScreenDataUpdatedCmd args);
    void SendCommand(string key, bool isMappedView, List<ScreenField5250> ChangedFields);
    void SendPing(bool mappedScreenView);
}