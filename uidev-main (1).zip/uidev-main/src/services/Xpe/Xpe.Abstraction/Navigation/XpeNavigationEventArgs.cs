﻿using System;
using Xpe.Abstraction.Enums;

namespace Xpe.Abstraction.Navigation;

[Serializable]
public class XpeNavigationEventArgs : ICloneable
{
    public XpeNavigationEventArgs()
    {
    }

    public XpeNavigationEventArgs(string headerText, string program, JhaImageTypes headerIconType)
        : this(headerText, program, Key.None, headerIconType)
    {
    }

    public XpeNavigationEventArgs(string headerText, string program, Key functionKey = Key.None,
        JhaImageTypes headerIconType = JhaImageTypes.None, string functionIdentifier = null)
    {
        HeaderText = headerText;
        HeaderIconType = headerIconType;
        Program = program;
        FunctionKey = functionKey;
        FunctionKey2 = Key.None;

        ////We set to null so that we overlay the previous event in case it was set...
        AccountNum = AccountType = CustId = Menu = Misc1 = Misc2 = Option = TIN = string.Empty;

        FunctionIdentifier = functionIdentifier;
    }

    public XpeNavigationEventArgs(
        string institutionNumber,
        string bankName,
        string headerText,
        string menu,
        string option,
        string program,
        string custId,
        string accountNum,
        string accountType,
        string tin,
        string misc1,
        string misc2,
        Key funcKey,
        string misc3 = null,
        string misc4 = null,
        JhaImageTypes headerIconType = JhaImageTypes.None,
        string command = null)
    {
        InstitutionNumber = institutionNumber;
        BankName = bankName;
        AccountNum = accountNum;
        AccountType = accountType;
        HeaderText = headerText;
        HeaderIconType = headerIconType;

        Menu = menu;
        Option = option;

        Program = program;
        Command = command;
        CustId = custId;
        AccountNum = accountNum;
        AccountType = accountType;
        TIN = tin;
        Misc1 = misc1;
        Misc2 = misc2;
        Misc3 = misc3;
        Misc4 = misc4;

        FunctionKey = funcKey;
        ImsUserSelectedSecurityGroup = string.Empty;
        FunctionKey2 = Key.None;
    }

    public XpeNavigationEventArgs(string institutionNumber, string bankName, string headerText, string menu,
        string option, JhaImageTypes headerIconType = JhaImageTypes.None)
    {
        HeaderText = headerText;
        HeaderIconType = headerIconType;
        InstitutionNumber = institutionNumber;
        BankName = bankName;
        Menu = menu;
        Option = option;
        FunctionKey2 = Key.None;

        ////We set to null so that we overlay the previous event in case it was set...
        AccountNum = AccountType =
            CustId = Program = Command = Misc1 = Misc2 = TIN = ImsUserSelectedSecurityGroup = string.Empty;
    }

    public string UserIdentifier { get; set; }

    public string FunctionIdentifier { get; set; }

    public object Account { get; set; }

    public string AccountNum { get; set; }

    public string AccountType { get; set; }

    public string BankName { get; set; }

    public string CustId { get; set; }

    public Key FunctionKey { get; set; }

    public Key FunctionKey2 { get; set; }

    public bool IsFunctionKeyJumping
    {
        get
        {
            if (FunctionKey != Key.None ||
                FunctionKey2 != Key.None)
            {
                return true;
            }

            return false;
        }
    }

    public JhaImageTypes HeaderIconType { get; set; }

    public string HeaderText { get; set; }

    public string InstitutionNumber { get; set; }

    public string Menu { get; set; }

    public string Misc1 { get; set; }

    public string Misc2 { get; set; }

    public string Misc3 { get; set; }

    public string Misc4 { get; set; }

    public string Option { get; set; }

    public string Program { get; set; }

    public string Command { get; set; }

    public string TIN { get; set; }

    public string ImsUserSelectedSecurityGroup { get; set; }

    public string Product { get; set; }

    public object Clone()
    {
        return MemberwiseClone();
    }

    public override string ToString()
    {
        try
        {
            return string.Format(
                "Institution: {0}, Account: {1}, Menu: {2}, Option: {3}, Program: {4}, CustId: {5}, TIN: {6}, Misc1: {7}, Misc2: {8}, FuncKey: {9}, ImsUserSelectedSecurityGroup: {10}",
                InstitutionNumber,
                AccountNum + "-" + AccountType,
                Menu,
                Option,
                Program,
                CustId,
                TIN,
                Misc1,
                Misc2,
                FunctionKey,
                ImsUserSelectedSecurityGroup);
        }
        catch
        {
            return base.ToString();
        }
    }
}