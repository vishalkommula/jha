﻿using Xpe.Abstraction.Model;
using Slc = JackHenry.JHAContractTypes;

namespace Xpe.Abstraction.Services;

public interface IUserService
{
    CurrentUserInfo CurrentUserInfo { get; set; }
    XpeConnectionContext XpeConnectionContext { get; }

    BankingAlias GetCurrentBankingAlias();
    void Initialize(string userIdentifier);
}