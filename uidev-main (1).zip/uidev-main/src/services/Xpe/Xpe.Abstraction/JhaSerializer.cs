﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Extensions.Logging;

namespace Xpe.Abstraction;

public class JhaSerializer
{
    private static readonly byte[] Salt =
    {
        0x26, 0xdc, 0xff, 0x00, 0xad, 0xed, 0x7a, 0xee, 0xc5, 0xfe, 0x07, 0xaf, 0x4d, 0x08, 0x22, 0x3c
    };

    private static readonly object LockObject = new();
    private static readonly Dictionary<string, XmlSerializer> Serializers = new();

    public static XmlSerializer GetSerializer(Type type)
    {
        lock (LockObject)
        {
            var key = string.Concat(type.Name, type.GetHashCode().ToString());

            if (Serializers.TryGetValue(key, out var serializer))
            {
                return serializer;
            }

            serializer = new XmlSerializer(type);

            Serializers.Add(key, serializer);

            return serializer;
        }
    }

    public static object DeserializeUnknownType(string filePath)
    {
        var fileInfo = new FileInfo(filePath);
        using var fileStream = fileInfo.Open(FileMode.Open);
        var binaryFormatter = new BinaryFormatter();
        return binaryFormatter.Deserialize(fileStream);
    }

    public static string Serialize<T>(T o)
    {
        return InternalSerialize(o);
    }

    public static string Serialize(object o)
    {
        return InternalSerialize(o);
    }

    public static void Serialize(object o, string filePath)
    {
        if (o == null)
        {
            return;
        }

        XmlSerialize(o, filePath);
    }

    public static string ToRawXmlString<T>(T obj, XmlQualifiedName[] namespaces = null)
    {
        return SerializeToStrippedXml(GetSerializer(typeof(T)), obj, namespaces);
    }

    public static T XmlDeserialize<T>(string xml)
    {
        if (string.IsNullOrEmpty(xml))
        {
            return default;
        }

        return (T) XmlDeserialize(xml, typeof(T));
    }

    public static object XmlDeserialize(string xml, Type type)
    {
        try
        {
            using var sr = new StringReader(xml);
            var xs = GetSerializer(type);
            return xs.Deserialize(sr);
        }
        catch (Exception ex)
        {
            throw new XmlException($"Error deserializing object: {type.Name}", ex);
        }
    }

    public static object XmlDeserializeFromFile(string filePath, Type type)
    {
        using var r = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Read, FileShare.ReadWrite);
        var xmls = GetSerializer(type);
        return xmls.Deserialize(r);
    }

    public static string XmlSerialize(object obj)
    {
        if (obj == null)
        {
            return string.Empty;
        }

        using var ms = new MemoryStream();
        var xs = GetSerializer(obj.GetType());
        xs.Serialize(ms, obj);
        ms.Seek(0, SeekOrigin.Begin);

        using var sr = new StreamReader(ms);
        var xd = new XmlDocument();

        xd.LoadXml(sr.ReadToEnd());


        foreach (var node in xd.Cast<XmlNode>().Where(node => node.NodeType == XmlNodeType.XmlDeclaration))
        {
            xd.RemoveChild(node);
        }

        return xd.OuterXml;
    }

    public static void XmlSerialize(object obj, string filePath)
    {
        if (obj == null)
        {
            return;
        }

        using var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.ReadWrite);
        var serializer = new XmlSerializer(obj.GetType());

        var osn = new XmlSerializerNamespaces();
        osn.Add(string.Empty, string.Empty);

        serializer.Serialize(fileStream, obj, osn);
    }

    public static bool EncryptAndSerialize(object obj, string fileName, ILogger loggingService)
    {
        try
        {
            using var fileStream = File.Open(fileName, FileMode.Create);
            EncryptAndSerialize(obj, fileStream);

            return true;
        }
        catch (Exception ex)
        {
            loggingService.LogError("Error exporting xml encrypted data", ex.Message, ex);
            return false;
        }
    }

    public static void EncryptAndSerialize(object obj, Stream outputStream)
    {
        const string magicStringThatCannotBeChanged = "3e28aa8b-3362-48c5-b923-fcd354ab25dd";
        using var crypto = new RijndaelManaged();
        using var bytes = new Rfc2898DeriveBytes(magicStringThatCannotBeChanged, Salt);
        crypto.Key = bytes.GetBytes(32);
        crypto.IV = bytes.GetBytes(16);

        using var cs = new CryptoStream(outputStream, crypto.CreateEncryptor(), CryptoStreamMode.Write);
        var serializer = new XmlSerializer(obj.GetType());
        serializer.Serialize(cs, obj);
    }

    public static T DecryptAndDeserialize<T>(string filename, ILogger loggingService, bool throwError = false)
    {
        try
        {
            const string magicStringThatCannotBeChanged = "3e28aa8b-3362-48c5-b923-fcd354ab25dd";

            var doc = new XmlDocument
            {
                PreserveWhitespace = true
            };

            var fs = new FileStream(filename, FileMode.Open);
            var crypto = new RijndaelManaged();

            var pdb = new Rfc2898DeriveBytes(magicStringThatCannotBeChanged, Salt);
            crypto.Key = pdb.GetBytes(32);
            crypto.IV = pdb.GetBytes(16);

            using var cryptoStream = new CryptoStream(
                fs, crypto.CreateDecryptor(), CryptoStreamMode.Read);
            using (XmlReader reader = new XmlTextReader(cryptoStream))
            {
                doc.Load(reader);
            }

            fs.Close();

            return XmlDeserialize<T>(doc.OuterXml);
        }
        catch (Exception ex)
        {
            loggingService.LogError("Error importing xml encrypted data", ex.Message, ex);

            if (throwError)
            {
                throw;
            }
        }

        return default;
    }

    public static T DecryptAndDeserialize<T>(Stream stream, ILogger loggingService, bool throwError = false)
    {
        try
        {
            const string magicStringThatCannotBeChanged = "3e28aa8b-3362-48c5-b923-fcd354ab25dd";

            var doc = new XmlDocument
            {
                PreserveWhitespace = true
            };

            var crypto = new RijndaelManaged();

            var pdb = new Rfc2898DeriveBytes(magicStringThatCannotBeChanged, Salt);
            crypto.Key = pdb.GetBytes(32);
            crypto.IV = pdb.GetBytes(16);

            using var cryptoStream = new CryptoStream(
                stream, crypto.CreateDecryptor(), CryptoStreamMode.Read);
            using var reader = new XmlTextReader(cryptoStream);
            doc.Load(reader);
            stream.Close();

            return XmlDeserialize<T>(doc.OuterXml);
        }
        catch (Exception ex)
        {
            loggingService.LogError("Error importing xml encrypted data", ex.Message, ex);

            if (throwError)
            {
                throw;
            }
        }

        return default;
    }

    private static string InternalSerialize(object o)
    {
        return o == null ? string.Empty : XmlSerialize(o);
    }

    private static string SerializeToStrippedXml(XmlSerializer serializer, object o, XmlQualifiedName[] namespaces)
    {
        var sb = new StringBuilder();
        var xmlWriterSettings = new XmlWriterSettings
        {
            OmitXmlDeclaration = true,
            NewLineChars = string.Empty,
            NewLineHandling = NewLineHandling.Replace
        };
        using var xmlWriter = XmlWriter.Create(sb, xmlWriterSettings);
        var ns = new XmlSerializerNamespaces();
        ns.Add(string.Empty, string.Empty);

        if (namespaces != null)
        {
            foreach (var name in namespaces)
            {
                ns.Add(name.Name, name.Namespace);
            }
        }

        serializer.Serialize(xmlWriter, o, ns);

        return sb.ToString();
    }
}