﻿using Xpe.Abstraction.Model;
using MediatR;

namespace Xpe.Abstraction.Commands;

public record ScreenDataUpdatedCmd(string UserIdentifier, ScreenData ScreenData) : IRequest;