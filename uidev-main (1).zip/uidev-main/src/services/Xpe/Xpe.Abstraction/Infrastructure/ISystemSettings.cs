﻿using System.Collections.ObjectModel;
using JackHenry.Banking.IAdapter.Infrastructure.Models;

namespace Xpe.Abstraction.Infrastructure;

public interface ISystemSettings : ICoreSetting
{
    ObservableCollection<IMasterAdapterSetting> MasterIAdapters { get; }

    int? MaxSearchRecords { get; set; }

    int? MaxSearchRecordsForGLAccountRecon { get; set; }

    int? MaxSearchRecordsReturned { get; set; }

    int? MaxSearchRecordsReturnedForGLAccountRecon { get; set; }

    int? MaxSearchRecordsReturnedForAllOtherFunctions { get; set; }

    int? MaxSearchRecordsReturnedForNameLookup { get; set; }

    string SharedCustomIdentifier { get; set; }

    string SystemMaintenanceAuditLogDocumentLocation { get; set; }

    bool UsersCanModifyAliasInformation { get; set; }

    bool AutomaticallyAllowCustAcctInquiry { get; set; }

    int? MinNameSearchChars { get; set; }

    CoreProductCode CoreProductCode { get; set; }

    int GetMaxRecordsReturned(string functionKey);
}