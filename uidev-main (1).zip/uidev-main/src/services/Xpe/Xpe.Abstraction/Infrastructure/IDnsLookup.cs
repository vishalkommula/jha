﻿using System.Net;
using System.Net.Sockets;

namespace Xpe.Abstraction.Infrastructure;

public interface IDnsLookup
{
    IPAddress[] GetHostAddress(string hostName);

    // ReSharper disable once InconsistentNaming
    bool OSSupportsIPv6();

    AddressFamily GetAddressFamily(IPAddress address);
}