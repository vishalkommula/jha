﻿// -----------------------------------------------------------------------
// <copyright file="IUserLevelSetting.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2013 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace Xpe.Abstraction.Infrastructure;

public interface IUserLevelSetting : IViewSettings
{
    string UserName { get; set; }
}