﻿using System;

namespace Xpe.Abstraction.Infrastructure;

public interface IISeriesConnectionCallbackStrategy
{
    void ConnectToServerCallback(IAsyncResult asyncResult);
}