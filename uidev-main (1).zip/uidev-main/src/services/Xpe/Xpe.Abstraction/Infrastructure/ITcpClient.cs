﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace Xpe.Abstraction.Infrastructure;

public interface ITcpClient
{
    bool IsConnected { get; }

    int ReceiveBufferSize { get; }

    void Initialize(AddressFamily addressFamily, int receiveBufferSize);

    void BeginConnect(
        IPAddress ipAddress,
        int port,
        Action<IAsyncResult> connectToServerCallback,
        IISeriesServer state);

    Stream GetStream();

    void Close();

    void EndConnect(IAsyncResult asyncResult);
}