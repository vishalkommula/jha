﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Model;

namespace Xpe.Abstraction.Extensions;

public static class ScreenField5250Extensions
{
    public static bool IsInputField(this ScreenField5250 field)
    {
        return field.FieldType == ScreenField5250Type.InputField &&
               (field.FieldFormatWord == null || !field.FieldFormatWord.Bypass);
    }

    public static bool IsAttributeField(this ScreenField5250 field)
    {
        return field.FieldType == ScreenField5250Type.Attribute;
    }

    public static bool IsMultiLineField(this ScreenField5250 field)
    {
        return field.FieldSize - field.Row > field.ScreenWidth;
    }

    public static bool IsOutputField(this ScreenField5250 field)
    {
        return field.FieldType == ScreenField5250Type.OutputField ||
               (field.FieldType == ScreenField5250Type.InputField && field.FieldFormatWord != null &&
                field.FieldFormatWord.Bypass);
    }

    public static bool IsVisible(this ScreenField5250 field)
    {
        // Display password fields that come in with a combination of NonDisplay27 attribute and no bypass
        if (field.IsPasswordField())
        {
            return true;
        }

        return !field.Att.ToString().Contains("NonDisplay");
    }

    public static bool IsErrorField(this ScreenField5250 field)
    {
        return field.FieldType == ScreenField5250Type.ErrorField;
    }

    public static bool IsPasswordField(this ScreenField5250 field)
    {
        return field != null &&
               field.IsInputField() &&
               (field.Att == FieldAttribute.NonDisplay27 || field.Att == FieldAttribute.NonDisplay37 ||
                field.Att == FieldAttribute.NonDisplay2F || field.Att == FieldAttribute.NonDisplay3f);
    }

    public static ScreenField5250 Get5250Field(ScreenField namePair, IEnumerable<ScreenField5250> fields)
    {
        return GetFieldByRRCCC(namePair.GetRRCCC(), fields);
    }

    public static ScreenField5250 GetFieldByRRCCC(string rrccc, IEnumerable<ScreenField5250> fields)
    {
        foreach (var entry in fields)
        {
            if (entry.RRCCC == rrccc)
            {
                return entry;
            }
        }

        return null;
    }

    public static ScreenField5250 GetFirstMatchingFieldInRange(string rangeLinkDataExpression,
        IEnumerable<ScreenField5250> fields)
    {
        var expression = rangeLinkDataExpression.Substring(rangeLinkDataExpression.IndexOf(':'))
            .Replace("}", string.Empty);
        var rangeValues = Regex.Split(expression, @":").ToList();

        if (rangeValues.Count >= 2)
        {
            // This is ugly but we get the row/column value in a string format (RRCCC) that's specified in the screen map LinkDataExpression.
            // So, we have to break it up here and assign to int so we can grab the first-matching 5250 field in the specified range.
            var startField = rangeValues.First(f => f.Length == 5);
            var endField = rangeValues.Last(f => f.Length == 5);

            if (startField != null && endField != null)
            {
                var startRow = Convert.ToInt32(startField.Substring(0, 2));
                var startColumn = Convert.ToInt32(startField.Substring(2));
                var endRow = Convert.ToInt32(endField.Substring(0, 2));
                var endColumn = Convert.ToInt32(endField.Substring(2));

                return fields.FirstOrDefault(f =>
                    f.Col >= startColumn && f.Col <= endColumn && f.Row >= startRow && f.Row <= endRow);
            }
        }

        return null;
    }
}