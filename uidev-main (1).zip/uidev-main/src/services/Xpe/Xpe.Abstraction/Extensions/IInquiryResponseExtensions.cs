﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using JackHenry.JHAContractTypes;
using Xpe.Abstraction.Model;

namespace Xpe.Abstraction.Extensions;

public static class IInquiryResponseExtensions
{
    public static IInquiryResponse<IAccountResponse> WrapAsIAccountResponse<TResponseType>(
        IInquiryResponse<TResponseType> responseToClone)
    {
        var newResponse = new InquiryResponse<IAccountResponse>();

        if (responseToClone.Payload_Rs as IAccountResponse != null)
        {
            newResponse.Payload_Rs = responseToClone.Payload_Rs as IAccountResponse;
        }
        else if (responseToClone.Payload_Rs as IAccount != null)
        {
            newResponse.Payload_Rs = (responseToClone.Payload_Rs as IAccount)?.ToIAccountResponse();
        }

        newResponse.AllMessages.AddRange(responseToClone.AllMessages);
        newResponse.Exception = responseToClone.Exception;

        return newResponse;
    }

    public static ITypedResponse<IAccountResponse> WrapAsITypedIAccountResponse<TResponseType>(
        IInquiryResponse<TResponseType> responseToClone)
    {
        var newResponse = new GenericResponseImpl<IAccountResponse>();

        if (responseToClone.Payload_Rs as IAccountResponse != null)
        {
            newResponse.Payload_Rs = responseToClone.Payload_Rs as IAccountResponse;
        }
        else if (responseToClone.Payload_Rs as IAccount != null)
        {
            newResponse.Payload_Rs = (responseToClone.Payload_Rs as IAccount).ToIAccountResponse();
        }

        newResponse.AllMessages.AddRange(responseToClone.AllMessages);

        if (responseToClone.HasException)
        {
            newResponse.Exception = new GenericException(responseToClone.Exception.Message, responseToClone.Exception);
        }

        return newResponse;
    }

    public static bool CheckFieldLevelWarnings(this ITypedResponse<IAccountResponse> accountResponse)
    {
        if (accountResponse != null && accountResponse.HasWarnings)
        {
            if (accountResponse.Warnings
                    .Where(e => e.ErrElem != null && (e.ErrCode == "300054" || e.ErrCode == "100024")).Count() >= 0)
            {
                return true;
            }
        }

        return false;
    }

    public static IResultInfoMessage CheckForFieldWarnings(this ITypedResponse<IAccountResponse> accountResponse,
        string errCode)
    {
        if (accountResponse != null && accountResponse.Warnings.Where(e => e.ErrCode == errCode).Count() > 0)
        {
            return accountResponse.Warnings.Where(e => e.ErrCode == errCode).First();
        }

        return null;
    }

    public static void ThrowIfInvalid<TPayload>(this IInquiryResponse<TPayload> response)
    {
        if (response == null)
        {
            throw new ArgumentNullException(nameof(response));
        }

        if (response.HasException)
        {
            throw response.Exception;
        }

        if (response.HasResultErrors)
        {
            throw new Exception(response.ErrorsToString());
        }

        if (response.HasUndefinedErrors)
        {
            throw new Exception(response.UndefinedErrorsToString());
        }

        if (response.HasFaults)
        {
            throw new Exception(response.FaultsToString());
        }

        if (response.Payload_Rs == null)
        {
            throw new Exception($"Unable to retrieve '{typeof(TPayload).Name}'. The response is null.");
        }
    }

    public static void Dispose<TPayload>(this IInquiryResponse<TPayload> response)
    {
        try
        {
            response.AllMessages?.DisposeCollection();

            if (response.Payload_Rs is IDisposable)
            {
                (response.Payload_Rs as IDisposable).Dispose();
            }

            response.Payload_Rs = default;
            response.Exception = null;
        }
        catch
        {
        }
    }

    public static string MessagesToString(this IEnumerable<IResultInfoMessage> messages)
    {
        if (messages == null || !messages.Any())
        {
            return string.Empty;
        }

        var message = new StringBuilder();

        foreach (var result in messages)
        {
            var searchRegex = new Regex(Regex.Escape(result.ErrDesc));

            if (!searchRegex.IsMatch(message.ToString()))
            {
                message.AppendLine(result.ErrDesc);
            }
        }

        return message.ToString();
    }
}