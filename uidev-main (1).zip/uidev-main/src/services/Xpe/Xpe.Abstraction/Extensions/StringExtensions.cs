﻿using System;

namespace Xpe.Abstraction.Extensions;

public static class StringExtensions
{
    public static bool IsCaseInsensitiveEqual(this string s, string value)
    {
        return string.Compare(s, value, StringComparison.OrdinalIgnoreCase) == 0;
    }

    public static bool IsCaseInsensitiveTrimmedEqual(this string s, string value)
    {
        if (s == null && value == null)
        {
            return true;
        }

        if (s == null || value == null)
        {
            return false;
        }

        return string.Compare(s.Trim(), value.Trim(), true) == 0;
    }
}