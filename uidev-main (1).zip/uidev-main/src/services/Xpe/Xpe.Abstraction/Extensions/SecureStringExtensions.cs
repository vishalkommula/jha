﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace Xpe.Abstraction.Extensions;

public static class SecureStringExtensions
{
    public static string GetDecryptedValue(this SecureString source)
    {
        string result = null;
        var length = source.Length;
        var pointer = IntPtr.Zero;
        var chars = new char[length];

        try
        {
            pointer = Marshal.SecureStringToBSTR(source);
            Marshal.Copy(pointer, chars, 0, length);
            result = string.Join(string.Empty, chars);
        }
        finally
        {
            if (pointer != IntPtr.Zero)
            {
                Marshal.ZeroFreeBSTR(pointer);
            }
        }

        return result;
    }

    public static SecureString ToSecureString(this string source)
    {
        if (string.IsNullOrWhiteSpace(source))
        {
            return null;
        }

        var result = new SecureString();
        foreach (var c in source.ToCharArray())
        {
            result.AppendChar(c);
        }

        return result;
    }
}