﻿namespace Xpe.Abstraction.Model;

public class PrintButtonToolbarItem : ToolbarItem, IToolbarItem
{
    private string dataSourceElementName;
    private string path;

    public PrintButtonToolbarItem(string dataSourceElementName, string path = null)
    {
        this.dataSourceElementName = dataSourceElementName;
        this.path = path;
    }
}