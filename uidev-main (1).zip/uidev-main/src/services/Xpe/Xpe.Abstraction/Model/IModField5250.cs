﻿// -----------------------------------------------------------------------
// <copyright file="IModField5250.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model;

public interface IModField5250
{
}