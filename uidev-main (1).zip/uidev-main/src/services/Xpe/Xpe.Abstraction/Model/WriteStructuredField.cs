﻿using System.Collections.Generic;

namespace Xpe.Abstraction.Model;

public class WriteStructuredField
{
    public WriteStructuredField()
    {
        CursorRow = 0;
        CursorColumn = 0;
        InboundWriteStructuredFieldAid = 0x88;
        Length = 5;
        CommandClass = 0xd9; // 5250 Class of Structured Field
        CommandType = 0x70; // 5250 Query
        QueryReply = 0x80; // Query Reply
        ControllerHardwareClass1 = 0x06;
        ControllerHardwareClass2 = 0x00;
        ControlUnitCustomization = 0x00;
        ReservedByte = 0x00;
        DisplayCapability0 = 0x00; // No support
        DisplayCapability1 = 0x31; // 24x80 and 27x132 Capable, No light pen, No mag stripe, 5292/3179 style color
        DisplayCapability2 = 0x00; // No support
        DisplayCapability3 = 0x00; // No support
        DisplayCapability4 = 0x21; // 5292 Style Graphics
        DisplayCapability5 = 0x00; // No support
    }

    public int CursorRow { get; }

    public int CursorColumn { get; }

    public byte InboundWriteStructuredFieldAid { get; }

    public int Length { get; }

    public byte CommandClass { get; }

    public byte CommandType { get; }

    public byte QueryReply { get; }

    public byte ControllerHardwareClass1 { get; }

    public byte ControllerHardwareClass2 { get; }

    public byte ReservedByte { get; }

    public byte ControlUnitCustomization { get; }

    public byte DisplayCapability0 { get; }

    public byte DisplayCapability1 { get; }

    public byte DisplayCapability2 { get; }

    public byte DisplayCapability3 { get; }

    public byte DisplayCapability4 { get; }

    public byte DisplayCapability5 { get; }

    public List<byte> GetReply()
    {
        var reply = new List<byte>();

        reply.Add((byte) CursorRow);
        reply.Add((byte) CursorColumn);
        reply.Add(InboundWriteStructuredFieldAid);
        reply.Add(0x00); // Place holder for length
        reply.Add(0x00); // Place holder for length
        reply.Add(CommandClass);
        reply.Add(CommandType);
        reply.Add(QueryReply);
        reply.Add(ControllerHardwareClass1);
        reply.Add(ControllerHardwareClass2);
        reply.AddRange(ControllerCodeLevel());
        reply.AddRange(GetReserved(16));
        reply.AddRange(DeviceType());
        reply.AddRange(KeyboardID());
        reply.Add(ReservedByte);
        reply.AddRange(DisplaySerialNumber());
        reply.AddRange(MaximumInputFields());
        reply.Add(ControlUnitCustomization);
        reply.AddRange(GetReserved(2));
        reply.Add(DisplayCapability0);
        reply.Add(DisplayCapability1);
        reply.Add(DisplayCapability2);
        reply.Add(DisplayCapability3);
        reply.Add(DisplayCapability4);
        reply.Add(DisplayCapability5);
        reply.AddRange(GetReserved(16));

        reply[4] = (byte) reply.Count;

        return reply;
    }

    private List<byte> ControllerCodeLevel()
    {
        return new List<byte> { 0x03, 0x02, 0x00 };
    }

    private List<byte> DeviceType()
    {
        return new List<byte> { 0x01, 0xf3, 0xf4, 0xf7, 0xf7, 0x40, 0xc6, 0xc3 };
    }

    private List<byte> DisplaySerialNumber()
    {
        return new List<byte> { 0x00, 0x00, 0x00, 0x00 };
    }

    private List<byte> KeyboardID()
    {
        return new List<byte> { 0x00, 0x00 };
    }

    private List<byte> MaximumInputFields()
    {
        return new List<byte> { 0x01, 0x00 };
    }

    private List<byte> GetReserved(int count)
    {
        var reserved = new List<byte>();

        for (var i = 0; i < count; i++) reserved.Add(0x00);

        return reserved;
    }
}