﻿namespace Xpe.Abstraction.Model;

public enum RecordType : ushort
{
    GeneralDataStream = 0x12A0
}

// These aren't supported by the virtual terminal.
// http://www-01.ibm.com/support/knowledgecenter/ssw_ibm_i_71/apis/QTVRDVT.htm
// ReadModImmediateAlt = 0x37,
// InternallyGeneratedPut = 0x39,
// ReadScreenWithExtendedAttributes = 0x44,
// ReadScreenToPrint = 0x45,
// ReadScreenToPrintWithExtendedAttributes = 0x46,
// ReadScreenToPrintWithGridlines = 0x47,
// ReadScreenToPrintWithGridlinesAndExtendedAttributes = 0x48

public enum OperationCode : byte
{
    None = 0x00,
    Invite = 0x31,
    Put = 0x32,
    PutOrGet = 0x33,
    SaveScreen = 0x34,
    RestoreScreen = 0x35,
    ReadImmediate = 0x36,
    ReadScreen = 0x38,
    CancelInvite = 0x41,
    TurnOnMessageLight = 0x42,
    TurnOffMessageLight = 0x43
}

// 000A 12A0 0000 0400 000B FFEF
// |    |    |    | |    |  |
// |    |    |    | |    |  End Of Record marker
// |    |    |    | |    |
// |    |    |    | |    Opcode = Turn On Message Light (’0B’X)
// |    |    |    | |
// |    |    |    | Flags = ’0000’X
// |    |    |    |
// |    |    |    Variable Header Length = ’04’X
// |    |    |
// |    |    Reserved - Set to ’0000’X
// |    |
// |    Record Type = General Data Stream (’12A0’X)
// |
// Logical Record Length = ’000A’X for this record

public class RecordHeader
{
    public int LogicalRecordLength { get; set; }

    public RecordType RecordType { get; set; }

    public SSLHeader SSLHeader { get; set; }

    public int VariableHeaderLength { get; set; }

    public OperationCode OperationCode { get; set; }
}