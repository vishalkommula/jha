﻿using System;
using System.Collections.Generic;
using System.Linq;
using JackHenry.Enterprise.BusinessObjects.Tpg;
using Xpe.Abstraction.Extensions;
using SL = JackHenry.JHAContractTypes;

namespace Xpe.Abstraction.Model;

public class InquiryResponse<TPayload> : IInquiryResponse<TPayload>
{
    private bool disposedValue;
    private List<SL.IResultInfoMessage> resultMessages;

    public InquiryResponse()
    {
        resultMessages = new List<SL.IResultInfoMessage>();
    }

    public InquiryResponse(IEnumerable<SL.IResultInfoMessage> messages)
    {
        resultMessages = new List<SL.IResultInfoMessage>(messages);
    }

    public InquiryResponse(TPayload payload)
    {
        Payload_Rs = payload;
        resultMessages = new List<SL.IResultInfoMessage>();

        if (Payload_Rs != null)
        {
            AddMessages();
        }

        SetSuccess();
    }

    public InquiryResponse(TPayload payload, IEnumerable<SL.IResultInfoMessage> messages)
    {
        Payload_Rs = payload;
        resultMessages = new List<SL.IResultInfoMessage>(messages);
        ResponseStatSuccess = true;
    }

    public InquiryResponse(Exception exception)
        : this()
    {
        Exception = exception;
    }

    public List<SL.IResultInfoMessage> AllMessages => resultMessages.ToList();

    public IEnumerable<SL.IResultInfoMessage> Errors
    {
        get { return resultMessages.Where(m => m.ErrCat.IsCaseInsensitiveEqual("error")); }
    }

    public Exception Exception { get; set; }

    public IEnumerable<SL.IResultInfoMessage> Faults
    {
        get { return resultMessages.Where(m => m.ErrCat.IsCaseInsensitiveEqual("fault")); }
    }

    public bool HasException => Exception != null;

    public bool HasFaults => Faults.Any();

    public bool HasMalady => HasException || AllMessages.Any();

    public bool HasMaladyExcludeWarnings
    {
        get
        {
            return HasException ||
                   AllMessages.Any(m => !m.ErrCat.IsCaseInsensitiveEqual("warning") &&
                                        !m.ErrCat.IsCaseInsensitiveEqual("override"));
        }
    }

    public bool HasOverrides => Overrides.Any();

    public bool HasResultErrors => Errors.Any();

    public bool HasUndefinedErrors => UndefinedErrors.Any();

    public bool HasWarnings => Warnings.Any();

    public bool MoreRecords { get; private set; }

    public string Cursor { get; private set; }

    public int TotalRecords { get; private set; }

    public bool ResponseStatSuccess { get; private set; }

    public IEnumerable<SL.IResultInfoMessage> Overrides
    {
        get { return resultMessages.Where(m => m.ErrCat.IsCaseInsensitiveEqual("override")); }
    }

    public TPayload Payload_Rs { get; set; }

    public IEnumerable<SL.IResultInfoMessage> UndefinedErrors
    {
        get { return resultMessages.Where(m => m.ErrCat.IsCaseInsensitiveEqual("undefined")); }
    }

    public IEnumerable<SL.IResultInfoMessage> Warnings
    {
        get { return resultMessages.Where(m => m.ErrCat.IsCaseInsensitiveEqual("warning")); }
    }

    public string MessageId { get; set; }

    public string ErrorsToString()
    {
        return Errors.MessagesToString();
    }

    public string FaultsToString()
    {
        return Faults.MessagesToString();
    }

    public string OverridesToString()
    {
        return Overrides.MessagesToString();
    }

    public string UndefinedErrorsToString()
    {
        return UndefinedErrors.MessagesToString();
    }

    public string WarningsToString()
    {
        return Warnings.MessagesToString();
    }

    public string AllMessagesToString()
    {
        return resultMessages.MessagesToString();
    }

    public void AddMessages(IEnumerable<SL.IResultInfoMessage> messages)
    {
        resultMessages.AddRange(messages);
    }

    public static InquiryResponse<TPayload> CreateExceptionResponse(Exception exception)
    {
        return new InquiryResponse<TPayload>
        {
            Exception = exception
        };
    }

    public static InquiryResponse<TPayload> CreateFaultResponse(IEnumerable<SL.IResultInfoMessage> messages)
    {
        return new InquiryResponse<TPayload>(messages);
    }

    public void AddMessages()
    {
        if (Payload_Rs == null)
        {
            return;
        }

        object[] messages = null;

        if (Payload_Rs is SL.IJhaiAdapterMsgResponse iAdapterMsgResponse)
        {
            var messageHeader = iAdapterMsgResponse.MsgRsHdr;
            messages = messageHeader.MsgRecInfoArray;
        }

        if (Payload_Rs is SL.IJhaiAdapterSearchResponse iadapterSearchResponse)
        {
            var searchHeader = iadapterSearchResponse.SrchMsgRsHdr;
            if (searchHeader != null)
            {
                if ("true".Equals(searchHeader.MoreRec, StringComparison.CurrentCultureIgnoreCase) ||
                    "y".Equals(searchHeader.MoreRec, StringComparison.CurrentCultureIgnoreCase))
                {
                    MoreRecords = true;
                }

                Cursor = searchHeader.Cursor;

                if (searchHeader.TotRec != null)
                {
                    TotalRecords = searchHeader.TotRec;
                }

                messages = searchHeader.MsgRecInfoArray;
            }
        }

        if (messages != null)
        {
            // Until we get SL using TPG I put in the following hack.
            if (messages is MsgRec_CType[])
            {
                foreach (MsgRec_CType messageRec in messages)
                {
                    resultMessages.Add(new ResultMessage(messageRec));
                }
            }
            else
            {
                foreach (SL.MsgRec_CType messageRec in messages)
                {
                    resultMessages.Add(new ResultMessage(messageRec));
                }
            }
        }
    }

    private void SetSuccess()
    {
        if (Payload_Rs == null)
        {
            return;
        }

        var rsStat = Payload_Rs.GetType().GetProperty("RsStat");
        var isRsStat = rsStat != null;
        var rsStatVal = rsStat?.GetValue(Payload_Rs).ToString() ?? string.Empty;

        if (isRsStat && string.IsNullOrWhiteSpace(rsStatVal) == false)
        {
            ResponseStatSuccess = "Success".Equals(rsStatVal, StringComparison.CurrentCultureIgnoreCase);
        }
        else if (isRsStat && string.IsNullOrWhiteSpace(rsStatVal))
        {
            ResponseStatSuccess = true;
        }
        else if (!isRsStat)
        {
            ResponseStatSuccess = true;
        }
    }
}