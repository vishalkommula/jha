﻿namespace Xpe.Abstraction.Model;

public interface IDeviceLookupItem
{
    string DeviceName { get; set; }
    string DeviceSequence { get; set; }
    string ISeriesPrinter { get; set; }
    string MachineName { get; set; }
    string NetworkPrinter { get; set; }
    string PcPrinter { get; set; }
    bool IsEmpty { get; }
    string GetConnectionParameters();
}