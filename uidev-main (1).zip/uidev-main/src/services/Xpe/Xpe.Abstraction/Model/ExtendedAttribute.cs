namespace Xpe.Abstraction.Model;

public enum ExtendedAttribute : byte
{
    DisplayScreen = 0x00,
    ExtendedPrimaryAttributes = 0x01,
    ExtendedTextAttributes = 0x02,
    ExtendedForegroundColorAttributes = 0x03,
    ExtendedIdeographicAttributes = 0x05,
    AllAttributes = 0xFF
}