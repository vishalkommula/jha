﻿using System;
using System.Linq;

namespace Xpe.Abstraction.Model;

public class DeviceFileItem : IDeviceFileItem
{
    private const string OFF = "OFF";
    private const string GDEVN = "/gdevn=";
    private const string GDEVNS = "/gdevns=";
    private const string GDEFP = "/gdefp=";
    private const string GEMUT5250AP = "/gemut5250ap=";
    private readonly int incrementationLimit = 9;
    private int incrementations;
    private string incrementationValue;

    public DeviceFileItem(string fileLine)
    {
        if (fileLine == null)
        {
            throw new ArgumentNullException("The file line is null.");
        }

        ParseLine(fileLine);
    }

    public DeviceFileItem(DeviceLookupItem lookupItem)
    {
        MachineName = lookupItem.MachineName?.ToLower();
        ConnectionParameters = lookupItem.GetConnectionParameters()?.ToLower();
    }

    public string MachineName { get; protected set; }

    public string ConnectionParameters { get; protected set; }

    public string JWalkParameters { get; protected set; }

    public string Device
    {
        get
        {
            if (DeviceSequence.ToUpper() == "OFF")
            {
                return $"{DeviceName,-10}".ToUpper();
            }

            var localDeviceName = DeviceName;

            var deviceNameLengthLimit = 10 - DeviceSequence.Length;

            if (localDeviceName.Length > deviceNameLengthLimit)
            {
                localDeviceName = DeviceName[..deviceNameLengthLimit];
            }

            return $"{localDeviceName + DeviceSequence,-10}".ToUpper();
        }
    }

    public string Printer
    {
        get
        {
            var networkPrinter = NetworkPrinter;

            if (networkPrinter.Length > 10)
            {
                networkPrinter = networkPrinter[..10];
            }

            return $"{networkPrinter,-10}".ToUpper();
        }
    }

    public string DeviceName { get; set; }

    public string DeviceSequence { get; set; }

    public string ISeriesPrinter { get; set; }

    public PrinterFileItem PrinterConfiguration { get; set; }

    public string NetworkPrinter { get; set; }

    public string PCPrinter { get; protected set; }

    public bool IsInvalidDeviceItem { get; protected set; }

    public void SetProperties()
    {
        SetProperties(true, false, false, true);
    }

    public void SetProperties(bool jWalkUseBaseDeviceSequencing, bool reserveBaseDeviceForVertex, bool isVertexJump,
        bool skipSequencing = false)
    {
        // Device.txt example lines:
        // The DeviceName and DeviceNameSequence is required. The Printer and PCPrinter is optional.
        // COMPUTERNAME,/gdevn=DEVICE /gdevns=1
        // COMPUTERNAME,/gdevn=DEVICE /gdevns=A /gdefp=PRT01
        // COMPUTERNAME,/gdevn=DEVICE /gdevns=off /gdefp=PRT01 /gemut5250ap=NetworkPrinterDevice /pcprinter=LOCALPrinter
        SetAndRemovePCPrinter();

        ParseConnectionParameters();

        // If Device Name Sequencing is turned off, then there is no need to modify the device entry.
        // Therefore, just return the device entry as is.
        if (DeviceSequence?.ToUpper() == OFF || skipSequencing)
        {
            JWalkParameters = ConnectionParameters;
        }
        else
        {
            if (!string.IsNullOrEmpty(DeviceSequence))
            {
                incrementationValue = DeviceSequence.Last().ToString();
            }

            // Base Device Sequencing means that the device sequencing starts at DEVICE
            // Otherwise the device sequencing starts at DEVICE1
            if (jWalkUseBaseDeviceSequencing)
            {
                // If the jump is a Vertex jump, we know the user has access to Vertex and we allocate the base device to the session. We
                // send in OFF for device name sequencing so that the iSeries doesn't keep track of this session, which would throw off
                // sequencing of the devices for the SilverLake Browser/XPE sessions when device sequencing is used. Without sending OFF, the
                // first SilverLake Browser/XPE session would get DEVICE2 even though DEVICE1 would be the next device in the sequence.
                if (isVertexJump)
                {
                    JWalkParameters = ConnectionParameters?.Replace(GDEVNS + DeviceSequence, GDEVNS + OFF);
                    DeviceSequence = OFF;
                }
                else
                {
                    JWalkParameters = ConnectionParameters;
                }
            }
            else
            {
                // With normal sequencing, we use the first device for Vertex and all subsequent devices for other Browser/XPE sessions. SilverLake
                // Browser/XPE sessions will all start at the second device in the sequence so that the first device will be saved for the Vertex
                // session. To accomplish this, the Vertex session has to use the sequencing value as part of the device name so that the device
                // name sequence value can be turned to OFF so the SilverLake Browser/XPE sessions don't get their sequence thrown off one device as
                // explained above.
                if (isVertexJump)
                {
                    // The device name and the device name sequence need to be appended into the device name so that the device name sequencing
                    // on the iSeries doesn't consider the vertex session as one of the devices in the sequence.
                    JWalkParameters = ConnectionParameters?.Replace(GDEVNS + DeviceSequence, GDEVNS + OFF);
                    JWalkParameters = JWalkParameters?.Replace(GDEVN + DeviceName, GDEVN + Device);
                }
                else
                {
                    if (reserveBaseDeviceForVertex)
                    {
                        var previousDeviceSequence = DeviceSequence;
                        IncrementDeviceSequence(string.Empty);

                        JWalkParameters =
                            ConnectionParameters?.Replace(GDEVNS + previousDeviceSequence, GDEVNS + DeviceSequence);
                    }
                    else
                    {
                        JWalkParameters = ConnectionParameters;
                    }
                }
            }
        }
    }

    public bool IncrementDeviceSequence(string startupResponse)
    {
        var deviceIncremented = false;

        if (!string.IsNullOrEmpty(DeviceSequence))
        {
            if (incrementations < incrementationLimit || startupResponse == StartupResponse.I8901 ||
                startupResponse == StartupResponse.I8902)
            {
                // Remove the incrmentation value
                DeviceSequence = DeviceSequence.TrimEnd(incrementationValue.ToCharArray());

                int devNSLastInt;
                if (int.TryParse(incrementationValue, out devNSLastInt))
                {
                    devNSLastInt++;
                    incrementationValue = devNSLastInt.ToString();
                    DeviceSequence = DeviceSequence + incrementationValue;
                }
                else
                {
                    var devNSLastCharacter = incrementationValue.Last();
                    devNSLastCharacter++;
                    incrementationValue = devNSLastCharacter.ToString();
                    DeviceSequence = DeviceSequence + incrementationValue;
                }

                incrementations++;
                deviceIncremented = true;
            }
        }

        return deviceIncremented;
    }

    private void SetAndRemovePCPrinter()
    {
        if (ConnectionParameters.Contains("/pcprinter="))
        {
            var pcprinterIndex = ConnectionParameters.IndexOf("/pcprinter=");
            PCPrinter = ConnectionParameters.Substring(pcprinterIndex + 11).Trim();
            ConnectionParameters = ConnectionParameters.Remove(pcprinterIndex);
        }
        else
        {
            PCPrinter = "Default";
        }
    }

    protected void ParseLine(string line)
    {
        var parms = line.Split(',');

        if (parms.Length != 2)
        {
            IsInvalidDeviceItem = true;
            MachineName = string.Empty;
            ConnectionParameters = string.Empty;
            JWalkParameters = string.Empty;
            DeviceName = string.Empty;
            DeviceSequence = string.Empty;
        }
        else
        {
            MachineName = parms[0].ToLower();
            ConnectionParameters = parms[1].ToLower();
        }
    }

    private void ParseConnectionParameters()
    {
        DeviceName = string.Empty;
        DeviceSequence = string.Empty;
        ISeriesPrinter = string.Empty;
        NetworkPrinter = string.Empty;

        if (ConnectionParameters.Contains(GDEVN))
        {
            var index = ConnectionParameters.IndexOf(GDEVN) + GDEVN.Length;
            var nextIndex = ConnectionParameters.IndexOf(' ', index);

            if (nextIndex == -1)
            {
                DeviceName = ConnectionParameters.Substring(index).Trim();
                return;
            }

            DeviceName = ConnectionParameters.Substring(index, nextIndex - index);
        }

        if (ConnectionParameters.Contains(GDEVNS))
        {
            var index = ConnectionParameters.IndexOf(GDEVNS) + GDEVNS.Length;
            var nextIndex = ConnectionParameters.IndexOf(' ', index);

            if (nextIndex == -1)
            {
                DeviceSequence = ConnectionParameters.Substring(index).Trim();
                return;
            }

            DeviceSequence = ConnectionParameters.Substring(index, nextIndex - index);
        }

        if (ConnectionParameters.Contains(GDEFP))
        {
            var index = ConnectionParameters.IndexOf(GDEFP) + GDEFP.Length;
            var nextIndex = ConnectionParameters.IndexOf(' ', index);

            if (nextIndex == -1)
            {
                ISeriesPrinter = ConnectionParameters.Substring(index).Trim();
                return;
            }

            ISeriesPrinter = ConnectionParameters.Substring(index, nextIndex - index);
        }

        if (ConnectionParameters.Contains(GEMUT5250AP))
        {
            var index = ConnectionParameters.IndexOf(GEMUT5250AP) + GEMUT5250AP.Length;
            var nextIndex = ConnectionParameters.IndexOf(' ', index);

            if (nextIndex == -1)
            {
                NetworkPrinter = ConnectionParameters.Substring(index).Trim();
                return;
            }

            NetworkPrinter = ConnectionParameters.Substring(index, nextIndex - index);
        }
    }
}