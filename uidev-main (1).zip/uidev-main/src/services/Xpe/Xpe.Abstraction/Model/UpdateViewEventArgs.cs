﻿namespace Xpe.Abstraction.Model;

public class UpdateViewEventArgs
{
    public ScreenData ScreenData { get; set; }
}