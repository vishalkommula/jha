﻿namespace Xpe.Abstraction.Model;

public class ScreenField5250Type
{
    public const string InputField = "IF";
    public const string OutputField = "OF";
    public const string ErrorField = "EF";
    public const string Attribute = "AT";
}