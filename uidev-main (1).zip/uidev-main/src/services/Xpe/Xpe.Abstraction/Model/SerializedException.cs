﻿using System;

namespace Xpe.Abstraction.Model;

public class SerializedException
{
    public SerializedException()
    {
        ExceptionTime = DateTime.Now;
    }

    public SerializedException(Exception ex)
        : this()
    {
        SafeExceptionInformation = ex.Message;
        Stack = ex.StackTrace;
        Source = ex.Source;
        InnerException = ex.InnerException?.ToString();
    }

    public DateTime ExceptionTime { get; set; }

    public string ExceptionType { get; set; }

    public string ExtraInformation { get; set; }

    public string InnerException { get; set; }

    public string SafeExceptionInformation { get; set; }

    public string Source { get; set; }

    public string Stack { get; set; }

    public override string ToString()
    {
        return string.Format("Date/Time: {0} Message: {1} Stack: {2} Source: {3} InnerException: {4}",
            ExceptionTime.ToLongDateString(), SafeExceptionInformation, Stack, Source, InnerException);
    }
}