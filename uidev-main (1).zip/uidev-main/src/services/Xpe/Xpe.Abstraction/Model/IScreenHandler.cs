﻿namespace Xpe.Abstraction.Model;

using System;
using System.Threading.Tasks;

using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

public interface IScreenHandler
{
    bool IsScreenHandler(string screenId);

    bool IsInputObserver(string screenId);

    bool IsMenuOptionObserver();

    HandleScreenInfoRequest HandleScreen(
        ScreenData screenData,
        ICurrentUserInfo userInfo,
        string sessionId,
        Action<ScreenInfoRequest> defferredCommand,
        IXperienceEnabledService xperienceEnabledService);

    Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo);

    bool MenuOptionSelected(XpeNavigationEventArgs args);
}
