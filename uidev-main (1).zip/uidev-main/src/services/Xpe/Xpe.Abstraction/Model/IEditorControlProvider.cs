﻿using System;
namespace Xpe.Abstraction.Model;

public interface IEditorControlProvider
{

    string BindingPath
    {
        get;
    }

    string EditorMask
    {
        get;
    }

    int MaxLength
    {
        get;
    }

    bool IsPromptable
    {
        get;
    }
}