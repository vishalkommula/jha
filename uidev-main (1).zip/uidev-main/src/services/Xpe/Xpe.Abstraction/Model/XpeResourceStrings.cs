namespace Xpe.Abstraction.Model;

public class XpeResourceStrings
{
    public const string FavoritesMenu = "Favorites Menu";
    public const string FavoritesToggleText = "Favorites";
    public const string FavoritesToggleToolTip = "Click to view Favorites";
    public const string SystemToggleText = "System";
    public const string SystemToggleToolTip = "Click to view System Menu";
    public const string DepositInquiryText = "Deposit Inquiry";
    public const string TimeDepositInquiryText = "Time Deposit Inquiry";
    public const string LoanInquiryText = "Loan Inquiry";
    public const string SafeDepositInquiryText = "Safe Deposit Inquiry";
    public const string NonJHAInquiryText = "Non JHA Application Inquiry";
    public const string IRAInquiryText = "IRA Inquiry";
    public const string LoanCreditInquiryText = "Loan Credit Line Inquiry";
    public const string StreamLine = nameof(StreamLine);

    public const string ReverseJumpServiceCustomerAccountLookup = "cfcustsrch";
    public const string ReverseJumpServiceLoanAccountLookup = "lnacctsrch";
    public const string ReverseJumpServiceInstDefFldSrch = "instdeffldsrch";
    public const string ReverseJumpServicePDBeneAdd = "pdbeneadd";
    public const string ReverseJumpServicePDBeneMod = "pdbenemod";
    public const string ReverseJumpServiceCDIBenAdd = "cdibenadd";
    public const string ReverseJumpServiceCDIBenMod = "cdibenmod";
    public const string ReverseJumpServiceEscrwInq = "escrwinq";

    public const string ShareHolderSharesBalanceFormatString = "##,###,##0.00000;(##,###,##0.00000)";
}