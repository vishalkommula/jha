﻿namespace Xpe.Abstraction.Model;

public class NVPColumnInfo
{
    public string ColumnLabel { get; set; }

    public string ColumnName { get; set; }

    public string Alignment { get; set; }

    public bool IsLabelField { get; set; }
}