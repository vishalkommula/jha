﻿using JackHenry.JHAContractTypes;
using FaultMsgRec_CType = JackHenry.Enterprise.BusinessObjects.Tpg.FaultMsgRec_CType;
using MsgRec_CType = JackHenry.Enterprise.BusinessObjects.Tpg.MsgRec_CType;

namespace Xpe.Abstraction.Model;

public class ResultMessage : IResultInfoMessage
{
    public ResultMessage(MsgRec_CType message)
    {
        ErrCat = message.ErrCat;
        ErrCode = message.ErrCode;
        ErrDesc = message.ErrDesc;
        ErrElem = message.ErrElem;
        ErrElemVal = message.ErrElemVal;
        ErrLoc = message.ErrLoc;
    }

    public ResultMessage(JackHenry.Enterprise.BusinessObjects.Jes.MsgRec_CType message)
    {
        ErrCat = message.ErrCat;
        ErrCode = message.ErrCode;
        ErrDesc = message.ErrDesc;
        ErrElem = message.ErrElem;
        ErrElemVal = message.ErrElemVal;
        ErrLoc = message.ErrLoc;
    }

    public ResultMessage(JackHenry.JHAContractTypes.MsgRec_CType message)
    {
        ErrCat = message.ErrCat;
        ErrCode = message.ErrCode;
        ErrDesc = message.ErrDesc;
        ErrElem = message.ErrElem;
        ErrElemVal = message.ErrElemVal;
        ErrLoc = message.ErrLoc;
    }

    public ResultMessage(FaultMsgRec_CType message)
    {
        ErrCat = message.ErrCat;
        ErrCode = message.ErrCode;
        ErrDesc = message.ErrDesc;
        ErrElem = message.ErrElem;
        ErrElemVal = message.ErrElemVal;
        ErrLoc = message.ErrLoc;
    }

    public ResultMessage(JackHenry.Enterprise.BusinessObjects.Jes.FaultMsgRec_CType message)
    {
        ErrCat = message.ErrCat;
        ErrCode = message.ErrCode;
        ErrDesc = message.ErrDesc;
        ErrElem = message.ErrElem;
        ErrElemVal = message.ErrElemVal;
        ErrLoc = message.ErrLoc;
    }

    public ResultMessage(JackHenry.JHAContractTypes.FaultMsgRec_CType message)
    {
        ErrCat = message.ErrCat;
        ErrCode = message.ErrCode;
        ErrDesc = message.ErrDesc;
        ErrElem = message.ErrElem;
        ErrElemVal = message.ErrElemVal;
        ErrLoc = message.ErrLoc;
    }

    public string ErrCat { get; }

    public string ErrCode { get; }

    public string ErrDesc { get; }

    public string ErrElem { get; }

    public string ErrElemVal { get; }

    public string ErrLoc { get; }
}