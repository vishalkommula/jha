﻿using System;

using Xpe.Abstraction.Enums;

namespace Xpe.Abstraction.Model;

public interface IBannerMessage : IDisposable
{
    object ClickCommandParameter
    {
        get;
    }

    JhaImageTypes IconType
    {
        get;
    }

    bool IsClickable
    {
        get;
    }

    bool IsError
    {
        get;
    }

    bool IsHighLighted
    {
        get;
    }

    bool IsPlainText
    {
        get;
    }

    string Message
    {
        get;
    }

    string ToolTip
    {
        get;
    }
}