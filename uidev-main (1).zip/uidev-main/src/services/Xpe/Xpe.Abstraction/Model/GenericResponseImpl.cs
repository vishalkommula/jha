﻿using System;
using System.Collections.Generic;
using System.Linq;
using JackHenry.JHAContractTypes;
using Xpe.Abstraction.Extensions;

namespace Xpe.Abstraction.Model;

public class GenericResponseImpl<T> : ITypedResponse<T>
{
    private bool disposedValue;

    public GenericResponseImpl()
    {
    }

    public GenericResponseImpl(T payload_rs)
    {
        Payload_Rs = payload_rs;

        if (payload_rs is IJhaiAdapterMsgResponse { MsgRsHdr: { } } msgResponse)

        {
            AddMessages(msgResponse.MsgRsHdr.MsgRecInfoArray);
        }

        if (payload_rs is IJhaiAdapterSearchResponse { SrchMsgRsHdr: { } } searchResponse)

        {
            AddMessages(searchResponse.SrchMsgRsHdr.MsgRecInfoArray);

            MoreRecords = searchResponse
                .SrchMsgRsHdr.MoreRec.GetValueOrDefault().IsCaseInsensitiveEqual("true");
        }

        ResponseStatSuccess = false;

        if (payload_rs is IJhaiAdapterAddModResponse response)
        {
            ResponseStatSuccess = response?.RsStat == "Success";
        }
    }

    public GenericResponseImpl(IAccount account, T payload_rs)
        : this(payload_rs)
    {
        Account = account;
    }

    public GenericResponseImpl(IEnumerable<IResultInfoMessage> allMessages)
    {
        AddMessages(allMessages);
    }

    public bool Delete { get; set; }

    public bool DoOverrideErrors { get; set; }

    public GenericException Exception { get; set; }

    public bool HasException => Exception != null;

    public List<IResultInfoMessage> OverrideErrors { get; set; } = new();

    public IAccount Account { get; set; }

    public List<IResultInfoMessage> AllMessages { get; private set; } = new();

    public IEnumerable<IResultInfoMessage> Errors
    {
        get { return AllMessages.Where(m => m.ErrCat.IsCaseInsensitiveEqual("error")); }
    }

    public IEnumerable<IResultInfoMessage> Faults
    {
        get { return AllMessages.Where(m => m.ErrCat.IsCaseInsensitiveEqual("fault")); }
    }

    public bool HasFaults => Faults != null && Faults.Any();

    public bool HasMalady => HasException || AllMessages.Count > 0;

    public bool HasMaladyExcludeWarnings => HasException || AllMessages
        .Any(m => !m.ErrCat.IsCaseInsensitiveEqual("warning"));

    public bool HasOverrides => Overrides != null && Overrides.Any();

    public bool HasResultErrors => Errors != null && Errors.Any();

    public bool HasUndefinedErrors => UndefinedErrors != null && UndefinedErrors.Any();

    public bool HasWarnings => Warnings != null && Warnings.Any();

    public bool MoreRecords { get; set; }

    public IEnumerable<IResultInfoMessage> Overrides
    {
        get { return AllMessages.Where(m => m.ErrCat.IsCaseInsensitiveEqual("override")); }
    }

    public T Payload_Rs { get; set; }

    public bool ResponseStatSuccess { get; set; }

    public object ReturnValue { get; set; }

    public IEnumerable<IResultInfoMessage> UndefinedErrors
    {
        get { return AllMessages.Where(m => m.ErrCat.IsCaseInsensitiveEqual("undefined")); }
    }

    public IEnumerable<IResultInfoMessage> Warnings
    {
        get { return AllMessages.Where(m => m.ErrCat.IsCaseInsensitiveEqual("warning")); }
    }

    public void AddMessage(string errCode, string errCat, string errElemVal, string errElem, string errLoc,
        string errDesc)
    {
        AddMessage(new InternalImpl
        {
            ErrCode = errCode,
            ErrCat = errCat,
            ErrElemVal = errElemVal,
            ErrElem = errElem,
            ErrLoc = errLoc,
            ErrDesc = errDesc
        });
    }

    public void AddMessage(IResultInfoMessage message)
    {
        if (message == null)
        {
            return;
        }

        AllMessages.Add(message);
    }

    public void AddMessages(IEnumerable<IResultInfoMessage> messages)
    {
        if (messages?.Any() != true)
        {
            return;
        }

        AllMessages.AddRange(messages);
    }

    public GenericResponseImpl<IAccountResponse> CloneAsIAccountResponse()
    {
        var newReturn = new GenericResponseImpl<IAccountResponse>();
        if (Payload_Rs is IAccountResponse rs)
        {
            newReturn.Payload_Rs = rs;
        }
        else if (Payload_Rs is IAccount account)
        {
            newReturn.Payload_Rs = account.ToIAccountResponse();
        }

        newReturn.AllMessages.AddRange(AllMessages);
        newReturn.Exception = Exception;
        newReturn.Account = Account;
        newReturn.MoreRecords = MoreRecords;

        return newReturn;
    }

    public GenericResponseImpl<IPrvdUsrOptRs> CloneAsIPrvdUsrOptRsInterface()
    {
        var newReturn = new GenericResponseImpl<IPrvdUsrOptRs>();
        if (Payload_Rs is IPrvdUsrOptRs rs)
        {
            newReturn.Payload_Rs = rs;
        }

        newReturn.AllMessages.AddRange(AllMessages);
        newReturn.Exception = Exception;
        if (Account != null)
        {
            newReturn.Account = Account;
        }

        newReturn.MoreRecords = MoreRecords;

        return newReturn;
    }

    public GenericResponseImpl<IAccountSearchResponse> CloneAsISearchResponse()
    {
        var newReturn = new GenericResponseImpl<IAccountSearchResponse>();
        if (Payload_Rs is IAccountSearchResponse rs)
        {
            newReturn.Payload_Rs = rs;
        }
        else if (Payload_Rs is IAccount)
        {
            newReturn.Payload_Rs = (Payload_Rs as IAccountSearchResponse)?.ToIAccountSearchResponse();
        }

        newReturn.AllMessages.AddRange(AllMessages);
        newReturn.Exception = Exception;
        newReturn.Account = Account;
        newReturn.MoreRecords = MoreRecords;

        return newReturn;
    }

    public string ErrorsToString()
    {
        return InternalMessageHandler(Errors);
    }

    public string FaultsToString()
    {
        return InternalMessageHandler(Faults);
    }

    public IResultInfoMessage MessageByCode(string code)
    {
        return AllMessages.FirstOrDefault(p => code.Contains(p.ErrCode));
    }

    public string OverridesToString()
    {
        return InternalMessageHandler(Overrides);
    }

    public string UndefinedErrorsToString()
    {
        return InternalMessageHandler(UndefinedErrors);
    }

    public string WarningsToString()
    {
        return InternalMessageHandler(Warnings);
    }

    public static GenericResponseImpl<T> CreateExceptionResponse(GenericException ex)
    {
        return new GenericResponseImpl<T>
        {
            Exception = ex
        };
    }

    public static GenericResponseImpl<T> CreateExceptionResponse(string endUserSafeMessage, string detailedMessage,
        Exception innerException)
    {
        return CreateExceptionResponse(new GenericException(detailedMessage, endUserSafeMessage, innerException));
    }

    public static GenericResponseImpl<T> CreateExceptionResponse(string endUserSafeMessage, string detailedMessage)
    {
        return CreateExceptionResponse(new GenericException(detailedMessage, endUserSafeMessage));
    }

    public static GenericResponseImpl<T> CreateFaultedResponse(IEnumerable<IResultInfoMessage> messages)
    {
        var response = new GenericResponseImpl<T>();
        response.AllMessages.AddRange(messages);

        return response;
    }

    public void IgnoreMessagesByCode(string code)
    {
        AllMessages.RemoveAll(p => code.Contains(p.ErrCode));
    }

    private static string InternalMessageHandler(IEnumerable<IResultInfoMessage> messages)
    {
        return messages.MessagesToString();
    }

    private class InternalImpl : IResultInfoMessage
    {
        public string ErrCat { get; internal set; }

        public string ErrCode { get; internal set; }

        public string ErrDesc { get; internal set; }

        public string ErrElem { get; internal set; }

        public string ErrElemVal { get; internal set; }

        public string ErrLoc { get; internal set; }
    }
}