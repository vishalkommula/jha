﻿using System.Collections.Generic;
using System.Globalization;
using System.Linq;

using Xpe.Abstraction.Extensions;
using Xpe.Abstraction.Model.XpeFields;

namespace Xpe.Abstraction.Model
{
    public class DynamicGridFieldItemProvider : IFieldItemProvider
    {
        public DynamicGridFieldItemProvider()
        {
        }

        public CultureInfo GetCultureInfo(ICurrentUserInfo userInfo)
        {
            // Not supporting two digit date conversions in Dynamic Grids for now. Just need to figure out how to get
            // the bank parm service in here or need to do something with the SilverlakeFieldItemProvider.cs.
            return CultureInfo.InvariantCulture;
        }

        public XpeField GetFieldItem(ScreenField screenField, ScreenField5250 screenField5250, IEnumerable<ScreenField> screenFields, ScreenInfoResponse screenInfo, ICurrentUserInfo userInfo, ScreenMapGridArrayGrid screenMapGrid)
        {
            List<ScreenField> mappedGridScreenFields = screenFields.Where(f => f.IsCategoryField()).ToList();

            ////Notice maintenance screens are mapped as dynamic grids so that the content lines up exactly with the header.
            ////This indicator identifies when the grid contains only fields that span the width of the screen (within a couple of chars).
            ////When these conditions are met, any input fields are formatted to disable insert mode (allowing char replacement as users type)

            bool disableInsertMode = screenMapGrid?.DynamicGridInsertMode == "Disabled" ||
                (mappedGridScreenFields?.Any() == false && mappedGridScreenFields.All(f => screenInfo.ScreenWidth - f.Length < 2));

            if (screenField.IsLinkTypeCombined())
            {
                return this.GetCombinedField(screenField, screenField5250, screenInfo.OutputFields, screenInfo.InputFields, userInfo, disableInsertMode);
            }
            else if (screenField.IsLinkTypeValue())
            {
                return this.GetValueExpressionField(screenField, screenField5250, screenInfo.OutputFields, screenInfo.InputFields, userInfo, disableInsertMode);
            }
            else
            {
                return new DynamicGridScreenFieldItem(screenField5250, screenField, this.GetCultureInfo(userInfo), screenInfo.OutputFields, disableInsertMode);
            }
        }

        public bool IsFieldBestMatch(ScreenField screenField, IEnumerable<ScreenField> screenFields, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields)
        {
            return true;
        }

        protected virtual XpeField GetCombinedField(ScreenField screenField, ScreenField5250 screenField5250, IEnumerable<ScreenField5250> outputFields, IEnumerable<ScreenField5250> inputFields, ICurrentUserInfo userInfo, bool isNoticeMaintenanceScreen)
        {
            if (!string.IsNullOrEmpty(screenField.LinkDataExpression) && !string.IsNullOrEmpty(screenField5250.Data))
            {
                return new CombinedOutputScreenFieldItem(screenField5250, screenField, outputFields.Union(inputFields));
            }

            return new DynamicGridScreenFieldItem(screenField5250, screenField, this.GetCultureInfo(userInfo), outputFields, isNoticeMaintenanceScreen);
        }

        protected virtual XpeField GetValueExpressionField(ScreenField screenField, ScreenField5250 screenField5250, IEnumerable<ScreenField5250> outputFields, IEnumerable<ScreenField5250> inputFields, ICurrentUserInfo userInfo, bool isNoticeMaintenanceScreen)
        {
            if (screenField.ReadOnly &&
                !string.IsNullOrEmpty(screenField.LinkDataExpression))
            {
                return new ValueExpressionScreenFieldItem(screenField, outputFields.Union(inputFields));
            }

            return new DynamicGridScreenFieldItem(screenField5250, screenField, this.GetCultureInfo(userInfo), outputFields, isNoticeMaintenanceScreen);
        }
    }
}
