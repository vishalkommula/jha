// -----------------------------------------------------------------------
// <copyright file="BannerMessageFields.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace Xpe.Abstraction.Model;

public class BannerMessageFields // : IFrameworkElementProvider
{
    public BannerMessageFields()
    {
    }

    public BannerMessageFields(ScreenField5250 messageLine, ScreenField5250 currentLine, ScreenField5250 totalLines)
    {
        MessageLine = messageLine;
        CurrentLine = new ModField5250(currentLine);
        TotalLines = totalLines;
    }

    public ScreenField5250 MessageLine { get; set; }

    public ModField5250 CurrentLine { get; set; }

    public ScreenField5250 TotalLines { get; set; }
}