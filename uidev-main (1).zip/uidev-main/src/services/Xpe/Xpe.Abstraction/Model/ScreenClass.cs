﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Xpe.Abstraction.Model;

[GeneratedCode("System.Xml", "4.6.79.0")]
[Serializable]
[DesignerCategory("code")]
[XmlType(AnonymousType = true)]
public class FieldValue
{
    private static XmlSerializer serializer;

    public string Value { get; set; }

    public string Description { get; set; }

    private static XmlSerializer Serializer
    {
        get
        {
            if (serializer == null)
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(FieldValue));
            }

            return serializer;
        }
    }

    public virtual bool ShouldSerializeValue()
    {
        return !string.IsNullOrEmpty(Value);
    }

    public virtual bool ShouldSerializeDescription()
    {
        return !string.IsNullOrEmpty(Description);
    }

    public virtual bool SaveToFile(string fileName, out Exception exception)
    {
        exception = null;

        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (Exception e)
        {
            exception = e;
            return false;
        }
    }

    public virtual void SaveToFile(string fileName)
    {
        StreamWriter streamWriter = null;

        try
        {
            var xmlString = Serialize();
            var xmlFile = new FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if (streamWriter != null)
            {
                streamWriter.Dispose();
            }
        }
    }

    public static bool LoadFromFile(string fileName, out FieldValue obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool LoadFromFile(string fileName, out FieldValue obj)
    {
        Exception exception = null;
        return LoadFromFile(fileName, out obj, out exception);
    }

    public static FieldValue LoadFromFile(string fileName)
    {
        FileStream file = null;
        StreamReader sr = null;

        try
        {
            file = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new StreamReader(file);
            var xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();

            return Deserialize(xmlString);
        }
        finally
        {
            if (file != null)
            {
                file.Dispose();
            }

            if (sr != null)
            {
                sr.Dispose();
            }
        }
    }

    #region Serialize/Deserialize

    public virtual string Serialize()
    {
        var serializedData = string.Empty;

        try
        {
            using (var streamReader = new StreamReader(new MemoryStream()))
            {
                var xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                var xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                Serializer.Serialize(xmlWriter, this);
                streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                serializedData = streamReader.ReadToEnd();
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    public static bool Deserialize(string input, out FieldValue obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool Deserialize(string input, out FieldValue obj)
    {
        Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    public static FieldValue Deserialize(string input)
    {
        StringReader stringReader = null;
        try
        {
            stringReader = new StringReader(input);
            return (FieldValue) Serializer.Deserialize(XmlReader.Create(stringReader));
        }
        finally
        {
            if (stringReader != null)
            {
                stringReader.Dispose();
            }
        }
    }

    public static FieldValue Deserialize(Stream s)
    {
        return (FieldValue) Serializer.Deserialize(s);
    }

    #endregion
}

[GeneratedCode("System.Xml", "4.6.79.0")]
[Serializable]
[DesignerCategory("code")]
[XmlType(AnonymousType = true)]
[XmlRoot(Namespace = "", IsNullable = false)]
public class ScreenMap
{
    private static XmlSerializer serializer;
    private bool _isLine24MessageIgnored;
    private bool _shouldSerializeScreenHeight;
    private bool _shouldSerializeScreenWidth;
    private bool _shouldSerializeWinHeight;
    private bool _shouldSerializeWinLeft;
    private bool _shouldSerializeWinTop;

    private bool _shouldSerializeWinWidth;

    public ScreenMap()
    {
        GridArray = new ObservableCollection<ScreenMapGridArray>();
        NamePairArray = new ObservableCollection<ScreenField>();
        NamePairDetails = new ScreenMapNamePairDetails();
        ScreenActionKeyArray = new ObservableCollection<ScreenMapActionKey>();
    }

    public string ScreenType { get; set; }

    public string ScreenDesign { get; set; }

    public string ScreenId { get; set; }

    public string FunctionKeyParsingRange { get; set; }

    public bool IsLine24MessageIgnored { get; set; }

    public string Title { get; set; }

    public int ScreenHeight { get; set; }

    [XmlIgnore] public bool ScreenHeightSpecified { get; set; }

    public int ScreenWidth { get; set; }

    [XmlIgnore] public bool ScreenWidthSpecified { get; set; }

    public int WinTop { get; set; }

    [XmlIgnore] public bool WinTopSpecified { get; set; }

    public int WinLeft { get; set; }

    [XmlIgnore] public bool WinLeftSpecified { get; set; }

    public int WinHeight { get; set; }

    [XmlIgnore] public bool WinHeightSpecified { get; set; }

    public int WinWidth { get; set; }

    [XmlIgnore] public bool WinWidthSpecified { get; set; }

    public string ScreenSource { get; set; }

    public string ScreenVersion { get; set; }

    [XmlArrayItem("ActionKey", IsNullable = false)]
    public ObservableCollection<ScreenMapActionKey> ScreenActionKeyArray { get; set; }

    public ScreenMapNamePairDetails NamePairDetails { get; set; }

    [XmlArrayItem("Field", IsNullable = false)]
    public ObservableCollection<ScreenField> NamePairArray { get; set; }

    [XmlElement("GridArray")] public ObservableCollection<ScreenMapGridArray> GridArray { get; set; }

    private static XmlSerializer Serializer
    {
        get
        {
            if (serializer == null)
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(ScreenMap));
            }

            return serializer;
        }
    }

    public virtual bool ShouldSerializeScreenActionKeyArray()
    {
        return ScreenActionKeyArray != null && ScreenActionKeyArray.Count > 0;
    }

    public virtual bool ShouldSerializeNamePairArray()
    {
        return NamePairArray != null && NamePairArray.Count > 0;
    }

    public virtual bool ShouldSerializeGridArray()
    {
        return GridArray != null && GridArray.Count > 0;
    }

    public virtual bool ShouldSerializeScreenHeight()
    {
        if (_shouldSerializeScreenHeight)
        {
            return true;
        }

        return ScreenHeight != default;
    }

    public virtual bool ShouldSerializeScreenWidth()
    {
        if (_shouldSerializeScreenWidth)
        {
            return true;
        }

        return ScreenWidth != default;
    }

    public virtual bool ShouldSerializeWinTop()
    {
        if (_shouldSerializeWinTop)
        {
            return true;
        }

        return WinTop != default;
    }

    public virtual bool ShouldSerializeWinLeft()
    {
        if (_shouldSerializeWinLeft)
        {
            return true;
        }

        return WinLeft != default;
    }

    public virtual bool ShouldSerializeWinHeight()
    {
        if (_shouldSerializeWinHeight)
        {
            return true;
        }

        return WinHeight != default;
    }

    public virtual bool ShouldSerializeWinWidth()
    {
        if (_shouldSerializeWinWidth)
        {
            return true;
        }

        return WinWidth != default;
    }

    public virtual bool ShouldSerializeNamePairDetails()
    {
        return NamePairDetails != null;
    }

    public virtual bool ShouldSerializeScreenType()
    {
        return !string.IsNullOrEmpty(ScreenType);
    }

    public virtual bool ShouldSerializeScreenDesign()
    {
        return !string.IsNullOrEmpty(ScreenDesign);
    }

    public virtual bool ShouldSerializeScreenId()
    {
        return !string.IsNullOrEmpty(ScreenId);
    }

    public virtual bool ShouldSerializeIsMessageIgnored()
    {
        if (_isLine24MessageIgnored)
        {
            return true;
        }

        return _isLine24MessageIgnored != default;
    }

    public virtual bool ShouldSerializeTitle()
    {
        return !string.IsNullOrEmpty(Title);
    }

    public virtual bool ShouldSerializeScreenSource()
    {
        return !string.IsNullOrEmpty(ScreenSource);
    }

    public virtual bool ShouldSerializeScreenVersion()
    {
        return !string.IsNullOrEmpty(ScreenVersion);
    }

    public virtual bool SaveToFile(string fileName, out Exception exception)
    {
        exception = null;
        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (Exception e)
        {
            exception = e;
            return false;
        }
    }

    public virtual void SaveToFile(string fileName)
    {
        StreamWriter streamWriter = null;

        try
        {
            var xmlString = Serialize();
            var xmlFile = new FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if (streamWriter != null)
            {
                streamWriter.Dispose();
            }
        }
    }

    public static bool LoadFromFile(string fileName, out ScreenMap obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool LoadFromFile(string fileName, out ScreenMap obj)
    {
        Exception exception = null;

        return LoadFromFile(fileName, out obj, out exception);
    }

    public static ScreenMap LoadFromFile(string fileName)
    {
        FileStream file = null;
        StreamReader sr = null;

        try
        {
            file = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new StreamReader(file);
            var xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();

            return Deserialize(xmlString);
        }
        finally
        {
            if (file != null)
            {
                file.Dispose();
            }

            if (sr != null)
            {
                sr.Dispose();
            }
        }
    }

    public ScreenField GetMatchingField(ScreenField5250 screenField5250)
    {
        var screenField =
            NamePairArray.FirstOrDefault(f => f.Col == screenField5250.Col && f.Row == screenField5250.Row);

        if (screenField != null)
        {
            return screenField;
        }

        foreach (var grid in GridArray)
        {
            screenField =
                grid.Grid.GridFields.FirstOrDefault(f => f.Col == screenField5250.Col && f.Row == screenField5250.Row);

            if (screenField != null)
            {
                return screenField;
            }
        }

        return null;
    }

    #region Serialize/Deserialize

    public virtual string Serialize()
    {
        var serializedData = string.Empty;

        try
        {
            using (var ms = new MemoryStream())
            {
                using (var streamReader = new StreamReader(ms))
                {
                    var xmlWriterSettings = new XmlWriterSettings();
                    xmlWriterSettings.Indent = true;
                    var xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                    Serializer.Serialize(xmlWriter, this);
                    streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                    serializedData = streamReader.ReadToEnd();
                }
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    public static bool Deserialize(string input, out ScreenMap obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool Deserialize(string input, out ScreenMap obj)
    {
        Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    public static ScreenMap Deserialize(string input)
    {
        StringReader stringReader = null;
        try
        {
            stringReader = new StringReader(input);

            return (ScreenMap) Serializer.Deserialize(XmlReader.Create(stringReader));
        }
        finally
        {
            if (stringReader != null)
            {
                stringReader.Dispose();
            }
        }
    }

    public static ScreenMap Deserialize(Stream s)
    {
        return (ScreenMap) Serializer.Deserialize(s);
    }

    #endregion
}

[GeneratedCode("System.Xml", "4.6.79.0")]
[Serializable]
[DesignerCategory("code")]
[XmlType(AnonymousType = true)]
public class ScreenMapActionKey
{
    private static XmlSerializer serializer;

    public string Key { get; set; }

    public string Action { get; set; }

    [XmlIgnore] public bool IsFocused { get; set; }

    public bool IsMappedSubmitKey { get; set; }

    private static XmlSerializer Serializer
    {
        get
        {
            if (serializer == null)
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(ScreenMapActionKey));
            }

            return serializer;
        }
    }

    public virtual bool ShouldSerializeKey()
    {
        return !string.IsNullOrEmpty(Key);
    }

    public virtual bool ShouldSerializeAction()
    {
        return !string.IsNullOrEmpty(Action);
    }

    public virtual bool SaveToFile(string fileName, out Exception exception)
    {
        exception = null;

        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (Exception e)
        {
            exception = e;
            return false;
        }
    }

    public virtual void SaveToFile(string fileName)
    {
        StreamWriter streamWriter = null;

        try
        {
            var xmlString = Serialize();
            var xmlFile = new FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if (streamWriter != null)
            {
                streamWriter.Dispose();
            }
        }
    }

    public static bool LoadFromFile(string fileName, out ScreenMapActionKey obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool LoadFromFile(string fileName, out ScreenMapActionKey obj)
    {
        Exception exception = null;
        return LoadFromFile(fileName, out obj, out exception);
    }

    public static ScreenMapActionKey LoadFromFile(string fileName)
    {
        FileStream file = null;
        StreamReader sr = null;

        try
        {
            file = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new StreamReader(file);
            var xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();

            return Deserialize(xmlString);
        }
        finally
        {
            if (file != null)
            {
                file.Dispose();
            }

            if (sr != null)
            {
                sr.Dispose();
            }
        }
    }

    #region Serialize/Deserialize

    public virtual string Serialize()
    {
        var serializedData = string.Empty;

        try
        {
            using (var streamReader = new StreamReader(new MemoryStream()))
            {
                var xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                var xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                Serializer.Serialize(xmlWriter, this);
                streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                serializedData = streamReader.ReadToEnd();
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    public static bool Deserialize(string input, out ScreenMapActionKey obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool Deserialize(string input, out ScreenMapActionKey obj)
    {
        Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    public static ScreenMapActionKey Deserialize(string input)
    {
        StringReader stringReader = null;

        try
        {
            stringReader = new StringReader(input);

            return (ScreenMapActionKey) Serializer.Deserialize(XmlReader.Create(stringReader));
        }
        finally
        {
            if (stringReader != null)
            {
                stringReader.Dispose();
            }
        }
    }

    public static ScreenMapActionKey Deserialize(Stream s)
    {
        return (ScreenMapActionKey) Serializer.Deserialize(s);
    }

    #endregion
}

[GeneratedCode("System.Xml", "4.6.79.0")]
[Serializable]
[DesignerCategory("code")]
public class ScreenField
{
    private static XmlSerializer serializer;

    private bool _shouldSerializeCol;

    private bool _shouldSerializeDecimalScale;

    private bool _shouldSerializeLength;
    private bool _shouldSerializeOptionField;

    private bool _shouldSerializeReadOnly;

    private bool _shouldSerializeRow;

    private bool _shouldSerializeSequence;

    public ScreenField()
    {
        FieldValueArray = new List<FieldValue>();
    }

    public string FieldId { get; set; }

    public string FieldCategory { get; set; }

    public string FieldLabel { get; set; }

    public List<FieldValue> FieldValueArray { get; set; }

    [XmlIgnore] public string FieldValuesString { get; set; }

    public string DataType { get; set; }

    public int Length { get; set; }

    [XmlIgnore] public bool LengthSpecified { get; set; }

    public int Row { get; set; }

    [XmlIgnore] public bool RowSpecified { get; set; }

    public int Col { get; set; }

    [XmlIgnore] public bool ColSpecified { get; set; }

    public int DecimalScale { get; set; }

    [XmlIgnore] public bool DecimalScaleSpecified { get; set; }

    public int Sequence { get; set; }

    [XmlIgnore] public bool SequenceSpecified { get; set; }

    public string FieldRefId { get; set; }

    public string HelpId { get; set; }

    public bool ReadOnly { get; set; }

    [XmlIgnore] public bool ReadOnlySpecified { get; set; }

    public bool OptionField { get; set; }

    [XmlIgnore] public bool OptionFieldSpecified { get; set; }

    public string DispFormat { get; set; }

    public string PromptKey { get; set; }

    public string LinkType { get; set; }

    public string LinkDataExpression { get; set; }

    public string Indicators { get; set; }

    public string EditCodes { get; set; }

    public string EditMask { get; set; }

    public string HorizontalAlignment { get; set; }

    private static XmlSerializer Serializer
    {
        get
        {
            if (serializer == null)
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(ScreenField));
            }

            return serializer;
        }
    }

    public virtual bool ShouldSerializeLength()
    {
        if (_shouldSerializeLength)
        {
            return true;
        }

        return Length != default;
    }

    public virtual bool ShouldSerializeRow()
    {
        if (_shouldSerializeRow)
        {
            return true;
        }

        return Row != default;
    }

    public virtual bool ShouldSerializeCol()
    {
        if (_shouldSerializeCol)
        {
            return true;
        }

        return Col != default;
    }

    public virtual bool ShouldSerializeDecimalScale()
    {
        if (_shouldSerializeDecimalScale)
        {
            return true;
        }

        return DecimalScale != default;
    }

    public virtual bool ShouldSerializeSequence()
    {
        if (_shouldSerializeSequence)
        {
            return true;
        }

        return Sequence != default;
    }

    public virtual bool ShouldSerializeReadOnly()
    {
        if (_shouldSerializeReadOnly)
        {
            return true;
        }

        return ReadOnly != default;
    }

    public virtual bool ShouldSerializeOptionField()
    {
        if (_shouldSerializeOptionField)
        {
            return true;
        }

        return OptionField != default;
    }

    public virtual bool ShouldSerializeFieldId()
    {
        return !string.IsNullOrEmpty(FieldId);
    }

    public virtual bool ShouldSerializeFieldCategory()
    {
        return !string.IsNullOrEmpty(FieldCategory);
    }

    public virtual bool ShouldSerializeFieldLabel()
    {
        return !string.IsNullOrEmpty(FieldLabel);
    }

    public virtual bool ShouldSerializeFieldValueArray()
    {
        return FieldValueArray?.Any() ?? false;
    }

    public virtual bool ShouldSerializeDataType()
    {
        return !string.IsNullOrEmpty(DataType);
    }

    public virtual bool ShouldSerializeFieldRefId()
    {
        return !string.IsNullOrEmpty(FieldRefId);
    }

    public virtual bool ShouldSerializeHelpId()
    {
        return !string.IsNullOrEmpty(HelpId);
    }

    public virtual bool ShouldSerializeDispFormat()
    {
        return !string.IsNullOrEmpty(DispFormat);
    }

    public virtual bool ShouldSerializePromptKey()
    {
        return !string.IsNullOrEmpty(PromptKey);
    }

    public virtual bool ShouldSerializeLinkType()
    {
        return !string.IsNullOrEmpty(LinkType);
    }

    public virtual bool ShouldSerializeLinkDataExpression()
    {
        return !string.IsNullOrEmpty(LinkDataExpression);
    }

    public virtual bool ShouldSerializeIndicators()
    {
        return !string.IsNullOrEmpty(Indicators);
    }

    public virtual bool ShouldSerializeEditCodes()
    {
        return !string.IsNullOrEmpty(EditCodes);
    }

    public virtual bool SaveToFile(string fileName, out Exception exception)
    {
        exception = null;

        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (Exception e)
        {
            exception = e;
            return false;
        }
    }

    public virtual void SaveToFile(string fileName)
    {
        StreamWriter streamWriter = null;

        try
        {
            var xmlString = Serialize();
            var xmlFile = new FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if (streamWriter != null)
            {
                streamWriter.Dispose();
            }
        }
    }

    public static bool LoadFromFile(string fileName, out ScreenField obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool LoadFromFile(string fileName, out ScreenField obj)
    {
        Exception exception = null;

        return LoadFromFile(fileName, out obj, out exception);
    }

    public static ScreenField LoadFromFile(string fileName)
    {
        FileStream file = null;
        StreamReader sr = null;

        try
        {
            file = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new StreamReader(file);
            var xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();

            return Deserialize(xmlString);
        }
        finally
        {
            if (file != null)
            {
                file.Dispose();
            }

            if (sr != null)
            {
                sr.Dispose();
            }
        }
    }

    #region Serialize/Deserialize

    public virtual string Serialize()
    {
        var serializedData = string.Empty;

        try
        {
            using (var streamReader = new StreamReader(new MemoryStream()))
            {
                var xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                var xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                Serializer.Serialize(xmlWriter, this);
                streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                serializedData = streamReader.ReadToEnd();
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    public override string ToString()
    {
        var fieldString = new StringBuilder();
        fieldString.Append("Screen Field:");

        fieldString.Append("  Row:" + Row);
        fieldString.Append("  Col:" + Col);
        fieldString.Append("  Length:" + Length);
        fieldString.Append("  R/O:" + ReadOnly);

        if (FieldLabel != null && FieldLabel != string.Empty)
        {
            fieldString.Append("  Label:" + FieldLabel);
        }

        if (FieldCategory != null && FieldCategory != string.Empty)
        {
            fieldString.Append("  Category:" + FieldCategory);
        }

        fieldString.Append("  Seq:" + Sequence);

        if (DataType != null && DataType != string.Empty)
        {
            fieldString.Append("  Type:" + DataType);
        }

        fieldString.Append("  Decimal Scale:" + DecimalScale);

        if (DispFormat != null && DispFormat != string.Empty)
        {
            fieldString.Append("  Display Format" + DispFormat);
        }

        if (FieldRefId != null && FieldRefId != string.Empty)
        {
            fieldString.Append("  Field Ref:" + FieldRefId);
        }

        if (LinkType != null && LinkType != string.Empty)
        {
            fieldString.Append("  Link Type:" + LinkType);
        }

        if (LinkDataExpression != null && LinkDataExpression != string.Empty)
        {
            fieldString.Append("  Link Data Exp:" + LinkDataExpression);
        }

        return fieldString.ToString();
    }

    public static bool Deserialize(string input, out ScreenField obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool Deserialize(string input, out ScreenField obj)
    {
        Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    public static ScreenField Deserialize(string input)
    {
        StringReader stringReader = null;
        try
        {
            stringReader = new StringReader(input);

            return (ScreenField) Serializer.Deserialize(XmlReader.Create(stringReader));
        }
        finally
        {
            if (stringReader != null)
            {
                stringReader.Dispose();
            }
        }
    }

    public static ScreenField Deserialize(Stream s)
    {
        return (ScreenField) Serializer.Deserialize(s);
    }

    #endregion
}

[GeneratedCode("System.Xml", "4.6.79.0")]
[Serializable]
[DesignerCategory("code")]
[XmlType(AnonymousType = true)]
public class ScreenMapNamePairDetails
{
    private static XmlSerializer serializer;

    public string HeaderText { get; set; }

    private static XmlSerializer Serializer
    {
        get
        {
            if (serializer == null)
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(ScreenMapNamePairDetails));
            }

            return serializer;
        }
    }

    public virtual bool ShouldSerializeHeaderText()
    {
        return !string.IsNullOrEmpty(HeaderText);
    }

    public virtual bool SaveToFile(string fileName, out Exception exception)
    {
        exception = null;

        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (Exception e)
        {
            exception = e;
            return false;
        }
    }

    public virtual void SaveToFile(string fileName)
    {
        StreamWriter streamWriter = null;

        try
        {
            var xmlString = Serialize();
            var xmlFile = new FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if (streamWriter != null)
            {
                streamWriter.Dispose();
            }
        }
    }

    public static bool LoadFromFile(string fileName, out ScreenMapNamePairDetails obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool LoadFromFile(string fileName, out ScreenMapNamePairDetails obj)
    {
        Exception exception = null;
        return LoadFromFile(fileName, out obj, out exception);
    }

    public static ScreenMapNamePairDetails LoadFromFile(string fileName)
    {
        FileStream file = null;
        StreamReader sr = null;

        try
        {
            file = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new StreamReader(file);
            var xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();

            return Deserialize(xmlString);
        }
        finally
        {
            if (file != null)
            {
                file.Dispose();
            }

            if (sr != null)
            {
                sr.Dispose();
            }
        }
    }

    #region Serialize/Deserialize

    public virtual string Serialize()
    {
        var serializedData = string.Empty;

        try
        {
            using (var streamReader = new StreamReader(new MemoryStream()))
            {
                var xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                var xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                Serializer.Serialize(xmlWriter, this);
                streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                serializedData = streamReader.ReadToEnd();
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    public static bool Deserialize(string input, out ScreenMapNamePairDetails obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool Deserialize(string input, out ScreenMapNamePairDetails obj)
    {
        Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    public static ScreenMapNamePairDetails Deserialize(string input)
    {
        StringReader stringReader = null;
        try
        {
            stringReader = new StringReader(input);
            return (ScreenMapNamePairDetails) Serializer.Deserialize(XmlReader.Create(stringReader));
        }
        finally
        {
            if (stringReader != null)
            {
                stringReader.Dispose();
            }
        }
    }

    public static ScreenMapNamePairDetails Deserialize(Stream s)
    {
        return (ScreenMapNamePairDetails) Serializer.Deserialize(s);
    }

    #endregion
}

[GeneratedCode("System.Xml", "4.6.79.0")]
[Serializable]
[DesignerCategory("code")]
[XmlType(AnonymousType = true)]
public class ScreenMapGridArray
{
    private static XmlSerializer serializer;

    public ScreenMapGridArray()
    {
        Grid = new ScreenMapGridArrayGrid();
    }

    public ScreenMapGridArrayGrid Grid { get; set; }

    private static XmlSerializer Serializer
    {
        get
        {
            if (serializer == null)
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(ScreenMapGridArray));
            }

            return serializer;
        }
    }

    public virtual bool ShouldSerializeGrid()
    {
        return Grid != null;
    }

    public virtual bool SaveToFile(string fileName, out Exception exception)
    {
        exception = null;

        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (Exception e)
        {
            exception = e;
            return false;
        }
    }

    public virtual void SaveToFile(string fileName)
    {
        StreamWriter streamWriter = null;

        try
        {
            var xmlString = Serialize();
            var xmlFile = new FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if (streamWriter != null)
            {
                streamWriter.Dispose();
            }
        }
    }

    public static bool LoadFromFile(string fileName, out ScreenMapGridArray obj, out Exception exception)
    {
        exception = null;
        obj = default;
        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool LoadFromFile(string fileName, out ScreenMapGridArray obj)
    {
        Exception exception = null;
        return LoadFromFile(fileName, out obj, out exception);
    }

    public static ScreenMapGridArray LoadFromFile(string fileName)
    {
        FileStream file = null;
        StreamReader sr = null;

        try
        {
            file = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new StreamReader(file);
            var xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();

            return Deserialize(xmlString);
        }
        finally
        {
            if (file != null)
            {
                file.Dispose();
            }

            if (sr != null)
            {
                sr.Dispose();
            }
        }
    }

    #region Serialize/Deserialize

    public virtual string Serialize()
    {
        var serializedData = string.Empty;

        try
        {
            using (var streamReader = new StreamReader(new MemoryStream()))
            {
                var xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                var xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                Serializer.Serialize(xmlWriter, this);
                streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                serializedData = streamReader.ReadToEnd();
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    public static bool Deserialize(string input, out ScreenMapGridArray obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool Deserialize(string input, out ScreenMapGridArray obj)
    {
        Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    public static ScreenMapGridArray Deserialize(string input)
    {
        StringReader stringReader = null;

        try
        {
            stringReader = new StringReader(input);
            return (ScreenMapGridArray) Serializer.Deserialize(XmlReader.Create(stringReader));
        }
        finally
        {
            if (stringReader != null)
            {
                stringReader.Dispose();
            }
        }
    }

    public static ScreenMapGridArray Deserialize(Stream s)
    {
        return (ScreenMapGridArray) Serializer.Deserialize(s);
    }

    #endregion
}

[GeneratedCode("System.Xml", "4.6.79.0")]
[Serializable]
[DesignerCategory("code")]
[XmlType(AnonymousType = true)]
public class ScreenMapGridArrayGrid
{
    private static XmlSerializer serializer;

    private string _dynamicGridInsertMode;

    private bool _shouldSerializeAutoUnfoldGrid;

    private bool _shouldSerializeGridColCount;
    private bool _shouldSerializeGridColOffset;

    private bool _shouldSerializeGridPageSize;

    private bool _shouldSerializeGridRowCount;

    private bool _shouldSerializeGridRowsPerRec;

    private bool _shouldSerializeIsDynamicGrid;

    public ScreenMapGridArrayGrid()
    {
        GridFields = new ObservableCollection<ScreenField>();
        GridOptionArray = new ObservableCollection<ScreenMapGridArrayGridGridOption>();
    }

    public string GridUnfoldKey { get; set; }

    public bool AutoUnfoldGrid { get; set; }

    public string GridSortKey { get; set; }

    public int GridPageSize { get; set; }

    [XmlIgnore] public bool GridPageSizeSpecified { get; set; }

    public int GridRowsPerRec { get; set; }

    [XmlIgnore] public bool GridRowsPerRecSpecified { get; set; }

    public int GridRowCount { get; set; }

    [XmlIgnore] public bool GridRowCountSpecified { get; set; }

    public int GridColCount { get; set; }

    [XmlIgnore] public bool GridColCountSpecified { get; set; }

    public int GridColOffset { get; set; }

    [XmlIgnore] public bool GridColOffsetSpecified { get; set; }

    public string GridHeader { get; set; }

    public string HeaderText { get; set; }

    public string NextPageDirection { get; set; }

    public bool IsDynamicGrid { get; set; }

    public string DynamicGridInsertMode { get; set; }

    [XmlArrayItem("GridOption", IsNullable = false)]
    public ObservableCollection<ScreenMapGridArrayGridGridOption> GridOptionArray { get; set; }

    [XmlArrayItem("Field", IsNullable = false)]
    public ObservableCollection<ScreenField> GridFields { get; set; }

    private static XmlSerializer Serializer
    {
        get
        {
            if (serializer == null)
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(ScreenMapGridArrayGrid));
            }

            return serializer;
        }
    }

    public virtual bool ShouldSerializeGridOptionArray()
    {
        return GridOptionArray != null && GridOptionArray.Count > 0;
    }

    public virtual bool ShouldSerializeGridFields()
    {
        return GridFields != null && GridFields.Count > 0;
    }

    public virtual bool ShouldSerializeGridPageSize()
    {
        if (_shouldSerializeGridPageSize)
        {
            return true;
        }

        return GridPageSize != default;
    }

    public virtual bool ShouldSerializeGridRowsPerRec()
    {
        if (_shouldSerializeGridRowsPerRec)
        {
            return true;
        }

        return GridRowsPerRec != default;
    }

    public virtual bool ShouldSerializeGridRowCount()
    {
        if (_shouldSerializeGridRowCount)
        {
            return true;
        }

        return GridRowCount != default;
    }

    public virtual bool ShouldSerializeGridColCount()
    {
        if (_shouldSerializeGridColCount)
        {
            return true;
        }

        return GridColCount != default;
    }

    public virtual bool ShouldSerializeGridColOffset()
    {
        if (_shouldSerializeGridColOffset)
        {
            return true;
        }

        return GridColOffset != default;
    }

    public virtual bool ShouldSerializeGridUnfoldKey()
    {
        return !string.IsNullOrEmpty(GridUnfoldKey);
    }

    public virtual bool ShouldSerializeGridHeader()
    {
        return !string.IsNullOrEmpty(GridHeader);
    }

    public virtual bool ShouldSerializeHeaderText()
    {
        return !string.IsNullOrEmpty(HeaderText);
    }

    public virtual bool ShouldSerializeNextPageDirection()
    {
        return !string.IsNullOrEmpty(NextPageDirection);
    }

    public virtual bool ShouldSerializeIsDynamicGrid()
    {
        if (_shouldSerializeIsDynamicGrid)
        {
            return true;
        }

        return IsDynamicGrid != default;
    }

    public virtual bool ShouldSerializeAutoUnfoldGrid()
    {
        if (_shouldSerializeAutoUnfoldGrid)
        {
            return true;
        }

        return AutoUnfoldGrid != default;
    }

    public virtual bool SaveToFile(string fileName, out Exception exception)
    {
        exception = null;

        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (Exception e)
        {
            exception = e;
            return false;
        }
    }

    public virtual void SaveToFile(string fileName)
    {
        StreamWriter streamWriter = null;

        try
        {
            var xmlString = Serialize();
            var xmlFile = new FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if (streamWriter != null)
            {
                streamWriter.Dispose();
            }
        }
    }

    public static bool LoadFromFile(string fileName, out ScreenMapGridArrayGrid obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool LoadFromFile(string fileName, out ScreenMapGridArrayGrid obj)
    {
        Exception exception = null;
        return LoadFromFile(fileName, out obj, out exception);
    }

    public static ScreenMapGridArrayGrid LoadFromFile(string fileName)
    {
        FileStream file = null;
        StreamReader sr = null;
        try
        {
            file = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new StreamReader(file);
            var xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();
            return Deserialize(xmlString);
        }
        finally
        {
            if (file != null)
            {
                file.Dispose();
            }

            if (sr != null)
            {
                sr.Dispose();
            }
        }
    }

    #region Serialize/Deserialize

    public virtual string Serialize()
    {
        var serializedData = string.Empty;

        try
        {
            using (var streamReader = new StreamReader(new MemoryStream()))
            {
                var xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                var xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                Serializer.Serialize(xmlWriter, this);
                streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                serializedData = streamReader.ReadToEnd();
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    public static bool Deserialize(string input, out ScreenMapGridArrayGrid obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool Deserialize(string input, out ScreenMapGridArrayGrid obj)
    {
        Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    public static ScreenMapGridArrayGrid Deserialize(string input)
    {
        StringReader stringReader = null;

        try
        {
            stringReader = new StringReader(input);
            return (ScreenMapGridArrayGrid) Serializer.Deserialize(XmlReader.Create(stringReader));
        }
        finally
        {
            if (stringReader != null)
            {
                stringReader.Dispose();
            }
        }
    }

    public static ScreenMapGridArrayGrid Deserialize(Stream s)
    {
        return (ScreenMapGridArrayGrid) Serializer.Deserialize(s);
    }

    #endregion
}

[GeneratedCode("System.Xml", "4.6.79.0")]
[Serializable]
[DesignerCategory("code")]
[XmlType(AnonymousType = true)]
public class ScreenMapGridArrayGridGridOption
{
    private static XmlSerializer serializer;
    private bool _shouldSerializeCol;

    private bool _shouldSerializeDefault;

    private bool _shouldSerializeRow;

    public string OptionValue { get; set; }

    public string OptionAction { get; set; }

    public bool Default { get; set; }

    [XmlIgnore] public bool DefaultSpecified { get; set; }

    public int Row { get; set; }

    [XmlIgnore] public bool RowSpecified { get; set; }

    public int Col { get; set; }

    [XmlIgnore] public bool ColSpecified { get; set; }

    private static XmlSerializer Serializer
    {
        get
        {
            if (serializer == null)
            {
                serializer = new XmlSerializerFactory().CreateSerializer(typeof(ScreenMapGridArrayGridGridOption));
            }

            return serializer;
        }
    }

    public virtual bool ShouldSerializeDefault()
    {
        if (_shouldSerializeDefault)
        {
            return true;
        }

        return Default != default;
    }

    public virtual bool ShouldSerializeRow()
    {
        if (_shouldSerializeRow)
        {
            return true;
        }

        return Row != default;
    }

    public virtual bool ShouldSerializeCol()
    {
        if (_shouldSerializeCol)
        {
            return true;
        }

        return Col != default;
    }

    public virtual bool ShouldSerializeOptionValue()
    {
        return !string.IsNullOrEmpty(OptionValue);
    }

    public virtual bool ShouldSerializeOptionAction()
    {
        return !string.IsNullOrEmpty(OptionAction);
    }

    public virtual bool SaveToFile(string fileName, out Exception exception)
    {
        exception = null;

        try
        {
            SaveToFile(fileName);
            return true;
        }
        catch (Exception e)
        {
            exception = e;
            return false;
        }
    }

    public virtual void SaveToFile(string fileName)
    {
        StreamWriter streamWriter = null;

        try
        {
            var xmlString = Serialize();
            var xmlFile = new FileInfo(fileName);
            streamWriter = xmlFile.CreateText();
            streamWriter.WriteLine(xmlString);
            streamWriter.Close();
        }
        finally
        {
            if (streamWriter != null)
            {
                streamWriter.Dispose();
            }
        }
    }

    public static bool LoadFromFile(string fileName, out ScreenMapGridArrayGridGridOption obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = LoadFromFile(fileName);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool LoadFromFile(string fileName, out ScreenMapGridArrayGridGridOption obj)
    {
        Exception exception = null;
        return LoadFromFile(fileName, out obj, out exception);
    }

    public static ScreenMapGridArrayGridGridOption LoadFromFile(string fileName)
    {
        FileStream file = null;
        StreamReader sr = null;
        try
        {
            file = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            sr = new StreamReader(file);
            var xmlString = sr.ReadToEnd();
            sr.Close();
            file.Close();
            return Deserialize(xmlString);
        }
        finally
        {
            if (file != null)
            {
                file.Dispose();
            }

            if (sr != null)
            {
                sr.Dispose();
            }
        }
    }

    #region Serialize/Deserialize

    public virtual string Serialize()
    {
        var serializedData = string.Empty;

        try
        {
            using (var streamReader = new StreamReader(new MemoryStream()))
            {
                var xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                var xmlWriter = XmlWriter.Create(streamReader.BaseStream, xmlWriterSettings);
                Serializer.Serialize(xmlWriter, this);
                streamReader.BaseStream.Seek(0, SeekOrigin.Begin);
                serializedData = streamReader.ReadToEnd();
            }

            return serializedData;
        }
        catch
        {
            return serializedData;
        }
    }

    public static bool Deserialize(string input, out ScreenMapGridArrayGridGridOption obj, out Exception exception)
    {
        exception = null;
        obj = default;

        try
        {
            obj = Deserialize(input);
            return true;
        }
        catch (Exception ex)
        {
            exception = ex;
            return false;
        }
    }

    public static bool Deserialize(string input, out ScreenMapGridArrayGridGridOption obj)
    {
        Exception exception = null;
        return Deserialize(input, out obj, out exception);
    }

    public static ScreenMapGridArrayGridGridOption Deserialize(string input)
    {
        StringReader stringReader = null;

        try
        {
            stringReader = new StringReader(input);
            return (ScreenMapGridArrayGridGridOption) Serializer.Deserialize(XmlReader.Create(stringReader));
        }
        finally
        {
            if (stringReader != null)
            {
                stringReader.Dispose();
            }
        }
    }

    public static ScreenMapGridArrayGridGridOption Deserialize(Stream s)
    {
        return (ScreenMapGridArrayGridGridOption) Serializer.Deserialize(s);
    }

    #endregion
}