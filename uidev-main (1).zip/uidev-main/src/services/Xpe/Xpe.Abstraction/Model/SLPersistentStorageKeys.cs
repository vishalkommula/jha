namespace Xpe.Abstraction.Model;

public class SLPersistentStorageKeys
{
    public const string ADGroupTemplates = "ADGroupTemplates";
    public const string ADGroupPreferenceTemplateSettings = "ADPreferenceTemplateSettings";
    public const string ADGroupTemplatesEnabled = "ADGroupTemplatesEnabled";
    public const string ATMFields = "ATMFields";

    public const string Banking = "Banking";
    public const string BOXFields = "BOXFields";
    public const string BoxInquiryToolbar = "BoxInquiryToolbar";
    public const string BrowserProductName = "JWalk";
    public const string CDFields = "CDFields";
    public const string CIFFields = "CIFFields";
    public const string CreditCardInquiryToolbar = "CreditCardInquiryToolbar";

    public const string CustomerInquiryToolbar = "CustomerInquiryToolbar";
    public const string DDAFields = "DDAFields";
    public const string DemandDepositInquiryToolbar = "DemandDepositInquiryToolbar";

    public const string FavoriteAccountInquiries = "UserFavorites";

    public const string GridSettings = "GridSettings_";
    public const string HelpInfoImport = "HelpInfoImport";

    public const string InstitutionSettings = "InstitutionSettings";
    public const string TeSignSettings = "TeSignSettings";
    public const string InstLastModTimeStamps = "InstLastModTimeStamps";
    public const string INTERNETFields = "INTERNETFields";
    public const string IRAFields = "IRAFields";
    public const string GLFields = "GLFields";
    public const string GLInquiryToolbar = "GLInquiryToolbar";
    public const string IRAInquiryToolbar = "IRAInquiryToolbar";
    public const string LineOfCreditInquiryToolbar = "LineOfCreditInquiryToolbar";
    public const string LoanInquiryToolbar = "LoanInquiryToolbar";
    public const string ClubInquiryToolbar = "ClubInquiryToolbar";
    public const string CheckingInquiryToolbar = "CheckingInquiryToolbar";
    public const string SavingsInquiryToolbar = "SavingsInquiryToolbar";
    public const string LOCFields = "LOCFields";
    public const string LtrOfCreditFields = "LtrOfCreditFields";
    public const string LONFields = "LONFields";
    public const string REVLONFields = "REVLONFields";

    public const string NetTellerInquiryKey = "NetTellerInquiryKey";
    public const string NetTellerInquiryToolbar = "NetTellerInquiryToolbar";
    public const string NetTellerXferKey = "NetTellerXferKey";
    public const string NONJHAFields = "NONJHAFields";
    public const string NonJhaInquiryToolbar = "NonJhaInquiryToolbar";
    public const string PassportInquiryToolbar = "PassportInquiryToolbar";
    public const string PreferenceTemplateSettings = "UserPreferenceTemplateSettings";
    public const string GeneralLedgerInquiryToolbar = "GeneralLedgerInquiryToolbar";

    public const string ProductAllDDA = "AllDDA";
    public const string ProductAllLoans = "AllLoans";
    public const string ProductATM = "ATM";
    public const string ProductChecking = "Checking";
    public const string ProductClub = "Club";
    public const string ProductCustomer = "Customer";
    public const string ProductInternet = "Internet";
    public const string ProductLoan = "Loan";
    public const string ProductNonJHA = "NonJha";
    public const string ProductNonJHACustom = "NonJhaCustom";
    public const string ProductRevolvingLoan = "RevLoan";
    public const string ProductSafeBox = "SafeBox";
    public const string ProductSavings = "Savings";
    public const string ProductShare = "Share";
    public const string ProductTime = "Time";
    public const string ProductVendor = "Vendor";
    public const string ProductGeneralLedger = "GeneralLedger";
    public const string ProductCreditCard = "CreditCard";

    public const string RecentSearches = "UserRecentSearches";
    public const string ScreenMapperDefaultProduct = "ScreenMapperDefaultProduct";
    public const string SHAREFields = "SHAREFields";
    public const string SystemSettings = "SystemSettings";
    public const string TimeDepositInquiryToolbar = "TimeDepositInquiryToolbar";
    public const string UserFieldSettings = "UserFieldSettings";
    public const string InstitutionTranslationsKey = "InstitutionTranslationsKey";
    public const string TrustedCertificateKey = "TrustedCertificateKey";

    public const string VertexDeviceSequenceSettings = "VertexDeviceSequenceSettings";
    public const string UserSettings = "UserSettings";
    public const string UserToolbarKey = "UserToolbarSettings";
    public const string VENDORFields = "VENDORFields";

    public const string ProductConversion = "ProductConversion";

    public const string EnterpriseLoggingProductInformationPSKey = "EnterpriseLoggingProductInformation";

    public const string FavoriteSystemMenuOptions = "FavoriteSystemMenuOptions";
    public const string PerformanceAuditSettings = "PerformanceAuditSettings";
    public const string DeviceLookupSettings = "DeviceLookupSettings";
    public const string PrinterConfigurationSettings = "PrinterConfigurationSettings";

    public const string GLReconTransactionSearchFitlerKeys = "GLReconTransactionSearchFitlerKeys";
    public const string GLReconTransactionSearchFilter = "GLReconTransactionSearchFilter";
    public const string TempSettingEnableGLReconEnhancements202111 = "TempSettingEnableGLReconEnhancements202111";
}