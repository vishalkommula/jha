namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using System;

public class CFMLIDFMScreenHandler : CustomerRelatedFunctionHandler
{
    private bool custIdMenuSelected = false;

    public CFMLIDFMScreenHandler(/*IInquiryTypeProvider inquiryTypeProvider*/)
        : base(/*, inquiryTypeProvider*/)
    {
        this.ScreenId = ScreenIdentification.CustomerIdMaintenance;
        this.RelatedFunction = UIFunctionKey.CustomerIdentification;
        this.PreviousScreenWhenHandled = true;
    }

    public override bool IsScreenHandler(string screenId)
    {
        if (this.custIdMenuSelected)
        {
            return base.IsScreenHandler(screenId);
        }
        else
        {
            return false;
        }
    }

    public override bool IsMenuOptionObserver()
    {
        return true;
    }

    public override bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        if (args != null && args.Program == "CFMLIDC")
        {
            this.custIdMenuSelected = true;
        }
        else
        {
            this.custIdMenuSelected = false;
        }

        return false;
    }

    public override HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        HandleScreenInfoRequest rq = null;

        if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId))
        {
            //    TagEventArguments tagEventArgs = new TagEventArguments(null, Constants.RegionNames.AlternateViewRegion);
            //    RelatedFunctionArgs<TagEventArguments> relatedFunctionArgs = new RelatedFunctionArgs<TagEventArguments>(this.GetAccountFromScreenField(screenData), tagEventArgs, screenData.ScreenName, windowIdentifier);

            //    this.EventService.Publish<ShowAlternateViewEvent, ShowAlternateViewEventArgs>(new ShowAlternateViewEventArgs() { RelatedFunctionArgs = relatedFunctionArgs, WindowIdentifier = windowIdentifier, ViewIdentifier = UIFunctionKey.CustomerIdentification });

            //    rq = new HandleScreenInfoRequest(new KeyPress(Key.F12, Key.None), screenData.ScreenInfo.CursorLocation);
        }

        return rq;
    }
}
