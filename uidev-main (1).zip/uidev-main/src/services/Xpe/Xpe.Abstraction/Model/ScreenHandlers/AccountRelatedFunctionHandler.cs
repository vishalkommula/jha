﻿namespace Xpe.Abstraction.Model.ScreenHandlers;

using JackHenry.JHAContractTypes;

public class AccountRelatedFunctionHandler : BaseRelatedFunctionHandler
{
    public AccountRelatedFunctionHandler() : base()
    {
    }

    public override IAccount GetAccountFromScreenField(ScreenData screenData)
    {
        ////Find the account in the screen data, and open customer inquiry with the specified related function
        if (screenData != null && screenData.FieldItems != null)
        {
            //TODO: Implement
            //AccountNumberScreenFieldItem accountField = screenData.FieldItems.FirstOrDefault(f => f is AccountNumberScreenFieldItem) as AccountNumberScreenFieldItem;

            //if (accountField != null && accountField.Account != null)
            //{
            //    return accountField.Account;
            //}
        }

        return null;
    }
}
