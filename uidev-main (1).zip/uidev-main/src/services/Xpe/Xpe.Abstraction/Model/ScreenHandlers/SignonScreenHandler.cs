namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using System;
using System.Text;
using System.Threading.Tasks;

public class SignonScreenHandler : IScreenHandler
{
    public SignonScreenHandler()
    {
        this.SessionId = Guid.NewGuid().ToString("N");
    }

    protected string SessionId { get; set; }
    protected string ScreenId { get; set; }
    protected XpeNavigationEventArgs Args { get; set; }
    protected bool IsSignonHandled { get; set; }
    protected bool HasJumpExecuted { get; set; }

    public virtual HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        HandleScreenInfoRequest screenInfoRequest = null;

        if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId))
        {
            if (screenData.ScreenInfo.ScreenId == ScreenIdentification.JumpScreen)
            {
                if (this.Args.Product == XpeProduct.TimeTrack)
                {
                    screenInfoRequest = this.GoToTimeTrackJumpScreen(screenData, userInfo, sessionId);
                }
                else
                {
                    screenInfoRequest = this.HandleJumpScreen(screenData, userInfo, sessionId);

                    this.HasJumpExecuted = true;

                    if (this.Args != null && this.Args.FunctionKey == Key.None)
                    {
                        this.IsSignonHandled = true;
                    }
                }
            }
            else if (screenData.ScreenInfo.ScreenId == ScreenIdentification.TimeTrackJumpScreen)
            {
                screenInfoRequest = this.HandleJumpScreen(screenData, userInfo, sessionId);

                this.HasJumpExecuted = true;

                if (this.Args != null && this.Args.FunctionKey == Key.None)
                {
                    this.IsSignonHandled = true;
                }
            }
            else if (screenData.ScreenInfo.ScreenId == ScreenIdentification.SignonScreen ||
                screenData.ScreenInfo.ScreenId == ScreenIdentification.DisplayMessagesScreen)
            {
                screenInfoRequest = new HandleScreenInfoRequest(new KeyPress(Key.Enter, Key.None), new CursorLocation(1, 1));
            }
            else if (this.Args != null && this.Args.FunctionKey != Key.None && this.HasJumpExecuted)
            {
                screenInfoRequest = new HandleScreenInfoRequest(new KeyPress(this.Args.FunctionKey, Key.None), new CursorLocation(1, 1));
                this.IsSignonHandled = true;
            }
        }

        return screenInfoRequest;
    }

    public virtual HandleScreenInfoRequest HandleJumpScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId)
    {
        HandleScreenInfoRequest screenInfoRequest = null;
        bool useProgram = true;
        StringBuilder log = new StringBuilder();
        log.Append(Environment.NewLine);
        log.Append("***********Using the jump program with the following values" + "***********");

        //IInstitutionTranslationService institutionTranslationService = this.UnityContainer.ResolveWithWindowIdentifier<IInstitutionTranslationService>("No window ID");
        //string instNumber = institutionTranslationService.GetRealInstitutionNumber(this.Args.InstitutionNumber);

        string instNumber = this.Args.InstitutionNumber;
        instNumber = "510";

        screenInfoRequest = new HandleScreenInfoRequest(new KeyPress(Key.Enter, Key.None), new CursorLocation(7, 19));
        screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 7, 19, FieldAttribute.Green, 1, instNumber, 80, null, null));

        log.Append(Environment.NewLine + "Institution: " + string.Format("^[07][019][{0}]", instNumber));

        if (this.Args.Product != XpeProduct.TimeTrack && !string.IsNullOrEmpty(this.Args.ImsUserSelectedSecurityGroup) && this.Args.ImsUserSelectedSecurityGroup != JackHenry.JHAContractTypes.Saml.SecurityGroupContants.NoSecurityGroup)
        {
            screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 8, 19, FieldAttribute.Green, 1, this.Args.ImsUserSelectedSecurityGroup, 80, null, null));
            log.Append(Environment.NewLine + "Group: " + string.Format("^[08][019][{0}]", this.Args.ImsUserSelectedSecurityGroup));
        }

        if (!string.IsNullOrEmpty(this.Args.Menu))
        {
            screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 11, 19, FieldAttribute.Green, 1, this.Args.Menu, 80, null, null));
            log.Append(Environment.NewLine + "Menu: " + string.Format("^[11][019][{0}]", this.Args.Menu));
        }

        if (!string.IsNullOrEmpty(this.Args.Option))
        {
            screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 12, 19, FieldAttribute.Green, 1, this.Args.Option, 80, null, null));
            log.Append(Environment.NewLine + "Option: " + string.Format("^[12][019][{0}]", this.Args.Option));
            useProgram = false;
        }

        if (this.Args.Product == XpeProduct.TimeTrack)
        {
            // We send this value to the TimeTrack jump screen so TimeTrack knows which bank to select.
            // For example, a FI can have a SilverLake bank 1. The FI can then have many different TimeTrack banks for holding companies, subsidiaries, etc...
            // When the TimeTrack jump program sees a new Session Id for the first time, it prompts the user to select the TimeTrack bank.
            // Then every subsequent jump that uses that Session Id will use the TimeTrack bank that the user previously selected.
            screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 13, 19, FieldAttribute.Green, 1, this.SessionId, 80, null, null));
            log.Append(Environment.NewLine + "Session Id: " + string.Format("^[13][019][{0}]", this.SessionId));
            useProgram = false;
        }

        if (useProgram && !string.IsNullOrEmpty(this.Args.Program))
        {
            screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 15, 19, FieldAttribute.Green, 1, this.Args.Program, 80, null, null));
            log.Append(Environment.NewLine + "Program: " + string.Format("^[15][019][{0}]", this.Args.Program));
        }

        if (!string.IsNullOrEmpty(this.Args.CustId))
        {
            screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 16, 19, FieldAttribute.Green, 1, this.Args.CustId, 80, null, null));
            log.Append(Environment.NewLine + "Cust Id: " + string.Format("^[16][019][{0}]", this.Args.CustId));
        }

        if (!string.IsNullOrEmpty(this.Args.AccountNum))
        {
            screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 17, 19, FieldAttribute.Green, 1, this.Args.AccountNum, 80, null, null));
            log.Append(Environment.NewLine + "Account Number: " + string.Format("^[17][019][{0}]", this.Args.AccountNum));
        }

        if (!string.IsNullOrEmpty(this.Args.AccountType))
        {
            screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 18, 19, FieldAttribute.Green, 1, this.Args.AccountType, 80, null, null));
            log.Append(Environment.NewLine + "Account Type: " + string.Format("^[18][019][{0}]", this.Args.AccountType));
        }

        if (!string.IsNullOrEmpty(this.Args.TIN))
        {
            screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 19, 19, FieldAttribute.Green, 1, this.Args.TIN, 80, null, null));
            log.Append(Environment.NewLine + "Tax Id: ^[19][019][<hidden>]");
        }

        if (!string.IsNullOrEmpty(this.Args.Misc1))
        {
            screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 20, 19, FieldAttribute.Green, 1, this.Args.Misc1, 80, null, null));
            log.Append(Environment.NewLine + "Misc 1: " + string.Format("^[20][019][{0}]", this.Args.Misc1));
        }

        if (!string.IsNullOrEmpty(this.Args.Misc2))
        {
            screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 21, 19, FieldAttribute.Green, 1, this.Args.Misc2, 80, null, null));
            log.Append(Environment.NewLine + "Misc 2: " + string.Format("^[21][019][{0}]", this.Args.Misc2));
        }

        return screenInfoRequest;
    }

    public virtual HandleScreenInfoRequest GoToTimeTrackJumpScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId)
    {
        HandleScreenInfoRequest screenInfoRequest = null;
        StringBuilder log = new StringBuilder();
        log.Append(Environment.NewLine);
        log.Append("***********Using the jump program with the following values to go to the TimeTrack Jump Screen" + "***********");

        //IInstitutionTranslationService institutionTranslationService = this.UnityContainer.ResolveWithWindowIdentifier<IInstitutionTranslationService>("No window ID");
        //string instNumber = institutionTranslationService.GetRealInstitutionNumber(this.Args.InstitutionNumber);

        string instNumber = this.Args.InstitutionNumber;

        screenInfoRequest = new HandleScreenInfoRequest(new KeyPress(Key.Enter, Key.None), new CursorLocation(7, 19));
        screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 7, 19, FieldAttribute.Green, 1, instNumber, 80, null, null));

        log.Append(Environment.NewLine + "Institution: " + string.Format("^[07][019][{0}]", instNumber));

        if (!string.IsNullOrEmpty(this.Args.ImsUserSelectedSecurityGroup) && this.Args.ImsUserSelectedSecurityGroup != JackHenry.JHAContractTypes.Saml.SecurityGroupContants.NoSecurityGroup)
        {
            screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 8, 19, FieldAttribute.Green, 1, this.Args.ImsUserSelectedSecurityGroup, 80, null, null));
            log.Append(Environment.NewLine + "Group: " + string.Format("^[08][019][{0}]", this.Args.ImsUserSelectedSecurityGroup));
        }

        // Send TIMETRACK menu
        screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 11, 19, FieldAttribute.Green, 1, "TIMETRACK", 80, null, null));
        log.Append(Environment.NewLine + "Menu: " + string.Format("^[11][019][{0}]", XpeProduct.TimeTrack));

        // Send Option 1
        screenInfoRequest.ChangedFields.Add(new ScreenField5250(null, ScreenField5250Type.InputField, 12, 19, FieldAttribute.Green, 1, "1", 80, null, null));
        log.Append(Environment.NewLine + "Option: " + string.Format("^[12][019][{0}]", "1"));

        return screenInfoRequest;
    }

    public bool IsInputObserver(string screenId)
    {
        return false;
    }

    public bool IsMenuOptionObserver()
    {
        return true;
    }

    public virtual bool IsScreenHandler(string screenId)
    {
        bool isScreenHandler = false;

        if (!this.IsSignonHandled)
        {
            if (screenId == ScreenIdentification.JumpScreen ||
                screenId == ScreenIdentification.SignonScreen ||
                screenId == ScreenIdentification.DisplayMessagesScreen ||
                screenId == ScreenIdentification.TimeTrackJumpScreen ||
                (this.Args != null && this.Args.FunctionKey != Key.None && this.HasJumpExecuted))
            {
                isScreenHandler = true;
            }
        }

        return isScreenHandler;
    }

    public virtual bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        this.Args = args;
        this.IsSignonHandled = false;
        this.HasJumpExecuted = false;
        return false;
    }

    public virtual Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        return null;
    }
}
