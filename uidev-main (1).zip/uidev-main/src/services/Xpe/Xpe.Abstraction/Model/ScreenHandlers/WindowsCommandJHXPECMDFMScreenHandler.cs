﻿namespace Xpe.Abstraction.Model.ScreenHandlers;

using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using Microsoft.Extensions.Logging;

public class WindowsCommandJHXPECMDFMScreenHandler : IScreenHandler
{
    public WindowsCommandJHXPECMDFMScreenHandler(ILogger<WindowsCommandJHXPECMDFMScreenHandler> logger)
    {
        Logger = logger;
    }

    public ILogger<WindowsCommandJHXPECMDFMScreenHandler> Logger { get; }

    public bool IsScreenHandler(string screenId) => screenId == ScreenIdentification.WindowsCommandScreen;

    public HandleScreenInfoRequest HandleScreen(
        ScreenData screenData,
        ICurrentUserInfo userInfo,
        string sessionId,
        Action<ScreenInfoRequest> defferredCommand,
        IXperienceEnabledService xperienceEnabledService)
    {
        string commandText = screenData.ScreenInfo.OutputFields?.FirstOrDefault()?.Data?.Trim();

        if (!string.IsNullOrEmpty(commandText))
        {
            //TODO: Implement
            //this.eventService.Publish<XpeHistoryEvent, XpeHistoryEventArgs>(
            //    new XpeHistoryEventArgs()
            //    {
            //        LogText = $"Executing Windows Command: '{commandText}'",
            //        MonitorType = MonitorType.CommandData,
            //        SessionId = sessionId
            //    });

            string fileName, arguments;
            this.ParseCommandText(commandText, out fileName, out arguments);

            Process process = new Process()
            {
                EnableRaisingEvents = true,
                StartInfo = new ProcessStartInfo()
                {
                    FileName = fileName,
                    Arguments = arguments,
                    RedirectStandardError = true,
                    CreateNoWindow = true,
                    UseShellExecute = false
                }
            };

            object processLock = new object();
            StringBuilder standardError = new StringBuilder();
            DataReceivedEventHandler errorDataHandler = null;
            EventHandler exitHandler = null;

            errorDataHandler = (s, e) =>
            {
                lock (processLock)
                {
                    if (e.Data != null)
                    {
                        standardError.AppendLine(e.Data);
                    }
                }
            };

            exitHandler = (s, e) =>
            {
                lock (processLock)
                {
                    // Log errors
                    if (standardError.Length != 0)
                    {
                        this.LogFailedCommand(new Exception(standardError.ToString()), commandText);
                    }

                    this.DisposeProcess(ref process, ref exitHandler, ref errorDataHandler);
                }
            };

            process.ErrorDataReceived += errorDataHandler;
            process.Exited += exitHandler;

            try
            {
                process.Start();
                process.BeginErrorReadLine();
            }
            catch (Exception ex)
            {
                this.LogFailedCommand(ex, commandText);
                this.DisposeProcess(ref process, ref exitHandler, ref errorDataHandler);
            }
        }

        return new HandleScreenInfoRequest(
            new KeyPress(Key.F3, Key.None),
            screenData.ScreenInfo.CursorLocation,
            ignoreMaxConsecutiveScreensHandled: true);
    }

    public bool IsInputObserver(string screenId) => false;

    public Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo) => null;

    public bool IsMenuOptionObserver() => false;

    public bool MenuOptionSelected(XpeNavigationEventArgs args) => false;

    private void ParseCommandText(string commandText, out string fileName, out string arguments)
    {
        fileName = commandText;
        arguments = null;

        if (string.IsNullOrEmpty(commandText) || File.Exists(commandText) || Directory.Exists(commandText))
        {
            return;
        }

        int pos = commandText.StartsWith("\"")
            ? commandText.IndexOf("\"", 1)
            : commandText.IndexOf(" ");

        if (pos > 0 && commandText.Length > pos + 1)
        {
            fileName = commandText.Substring(0, pos + 1).Trim();
            arguments = commandText.Substring(pos + 1).Trim();
        }
    }

    private void LogFailedCommand(Exception exception, string commandText)
    {
        Logger.LogError(
            $"A windows command initiated from Xperience Enabled ended abnormally. Command text: '{commandText}'",
            exception);
    }

    private void DisposeProcess(ref Process process, ref EventHandler exitHandler, ref DataReceivedEventHandler errorDataHandler)
    {
        process.Exited -= exitHandler;
        process.ErrorDataReceived -= errorDataHandler;
        process.Dispose();
        process = null;
        exitHandler = null;
        errorDataHandler = null;
    }
}