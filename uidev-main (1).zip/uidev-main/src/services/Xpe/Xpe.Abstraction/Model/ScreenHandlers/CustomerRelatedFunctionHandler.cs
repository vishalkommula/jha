﻿namespace Xpe.Abstraction.Model.ScreenHandlers;

using JackHenry.JHAContractTypes;

using System.Linq;

public class CustomerRelatedFunctionHandler : BaseRelatedFunctionHandler
{
    //private IInquiryTypeProvider InquiryTypeProvider { get; }

    public CustomerRelatedFunctionHandler(/*, IInquiryTypeProvider inquiryTypeProvider*/)
        : base()
    {
        //this.InquiryTypeProvider = inquiryTypeProvider;
    }

    public override IAccount GetAccountFromScreenField(ScreenData screenData)
    {
        //TODO: Implement
        //Find the cust id in the screen data, and open customer inquiry with the specified related function
        //if (screenData != null && screenData.FieldItems != null)
        //{
        //    CustomerNumberScreenFieldItem customerField = screenData.FieldItems.FirstOrDefault(f => f is CustomerNumberScreenFieldItem) as CustomerNumberScreenFieldItem;

        //    if (customerField != null)
        //    {
        //        IAccount account = new MiniAccount(customerField.Customer.Value, this.inquiryTypeProvider.CustomerType);
        //        account.CustId = customerField.Customer.Value;

        //        return account;
        //    }
        //}

        return null;
    }
}
