﻿namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Services;

using System.Collections.Generic;
using System.Linq;

public class CF5000FMScreenHandler : AccountPromptHandler
{
    public CF5000FMScreenHandler(IXperienceEnabledService xperienceEnabledService/*, IInquiryTypeProvider inquiryTypeProvider*/)
        : base(xperienceEnabledService, ScreenIdentification.CustomerAccountPrompt/*, inquiryTypeProvider.CustomerType*/)
    {
        this.ProgramNameExclusionList = new List<string>() { "WT9400", "WX9400" };
    }

    private List<string> ProgramNameExclusionList { get; set; }

    public override bool IsScreenHandler(string screenId)
    {
        bool returnValue = base.IsScreenHandler(screenId);

        if (returnValue)
        {
            if (this.Args != null && this.ProgramNameExclusionList.Any(s => s == this.Args.Program))
            {
                returnValue = false;
            }
        }

        return returnValue;
    }
}
