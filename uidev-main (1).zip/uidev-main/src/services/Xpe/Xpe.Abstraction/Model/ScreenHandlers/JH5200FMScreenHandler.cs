﻿namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class JH5200FMScreenHandler : IScreenHandler
{
    public JH5200FMScreenHandler(/*IInquiryTypeProvider inquiryTypeProvider*/)
    {
        //this.InquiryTypeProvider = inquiryTypeProvider;
        this.MessagesScreenList = new List<string>() { "JH5250FM-SFLMC-SFLM-SFLOPT", "JH5250FM-SFLCMC-SFLCM-SFLOPC", "JH5200FM-SFLMC-SFLM-SFLOPT", "JH5200FM-SFLCMC-SFLCM-SFLOPC" };
        this.ValidProgramList = new List<string>() { "JH5250C", "JH5200C" };
        this.RelatedFunction = UIFunctionKey.AccountMessages;
    }

    private List<string> MessagesScreenList { get; set; }

    private List<string> ValidProgramList { get; set; }

    private string CurrentMenuProgram { get; set; }

    private string RelatedFunction { get; set; }

    //private IInquiryTypeProvider InquiryTypeProvider { get; set; }

    public HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        HandleScreenInfoRequest rq = null;

        if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId))
        {
            //TODO: Implement
            //if (screenData != null && screenData.FieldItems != null)
            //{
            //    string messagesFilter = "Alerts";

            //    if (this.CurrentMenuProgram == "JH5200C")
            //    {
            //        messagesFilter = "Special";
            //    }

            //    AccountNumberScreenFieldItem accountField = screenData.FieldItems.FirstOrDefault(f => f is AccountNumberScreenFieldItem) as AccountNumberScreenFieldItem;

            //    if (accountField != null && accountField.Account != null)
            //    {
            //        AccountRequestedEventArgs args = new AccountRequestedEventArgs(accountField.Account, null, true, this.RelatedFunction, null, windowIdentifier);
            //        args.RelatedFunctionByPassUserSettingsForAutoStart = true;
            //        args.RelatedFunctionParameter = messagesFilter;

            //        this.EventService.Publish<AccountRequestedEvent, AccountRequestedEventArgs>(args);
            //        rq = new HandleScreenInfoRequest(new KeyPress(Key.F12, Key.None), screenData.ScreenInfo.CursorLocation);
            //    }
            //    else
            //    {
            //        CustomerNumberScreenFieldItem customerField = screenData.FieldItems.FirstOrDefault(f => f is CustomerNumberScreenFieldItem) as CustomerNumberScreenFieldItem;

            //        if (customerField != null)
            //        {
            //            IAccount account = new MiniAccount(customerField.Customer.Value, this.InquiryTypeProvider.CustomerType);
            //            account.CustId = customerField.Customer.Value;

            //            AccountRequestedEventArgs args = new AccountRequestedEventArgs(account, null, true, this.RelatedFunction, null, windowIdentifier);
            //            args.RelatedFunctionByPassUserSettingsForAutoStart = true;
            //            args.RelatedFunctionParameter = messagesFilter;

            //            this.EventService.Publish<AccountRequestedEvent, AccountRequestedEventArgs>(args);

            //            rq = new HandleScreenInfoRequest(new KeyPress(Key.F12, Key.None), screenData.ScreenInfo.CursorLocation);
            //        }
            //    }
            //}
        }

        return rq;
    }

    public bool IsInputObserver(string screenId)
    {
        return false;
    }

    public bool IsMenuOptionObserver()
    {
        return true;
    }

    public bool IsScreenHandler(string screenId)
    {
        if (this.CurrentMenuProgram != null && this.MessagesScreenList.Contains(screenId))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        if (args.Program != null && this.ValidProgramList.Contains(args.Program))
        {
            this.CurrentMenuProgram = args.Program;
        }
        else
        {
            this.CurrentMenuProgram = null;
        }

        return false;
    }

    public Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        return null;
    }
}
