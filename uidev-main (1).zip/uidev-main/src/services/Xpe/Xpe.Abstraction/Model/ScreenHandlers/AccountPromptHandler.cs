namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using System;
using System.Threading.Tasks;

public class AccountPromptHandler : IScreenHandler
{
    public AccountPromptHandler(IXperienceEnabledService xperienceEnabledService, string screenId/*, string accountLookupType*/)
    {
        this.XperienceEnabledService = xperienceEnabledService;
        this.ScreenId = screenId;
        //this.AccountLookupType = accountLookupType;
    }

    public XpeNavigationEventArgs Args { get; set; }

    private IXperienceEnabledService XperienceEnabledService { get; set; }

    private string ScreenId { get; set; }

    private string AccountLookupType { get; set; }

    public virtual HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        HandleScreenInfoRequest rq = null;

        if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId))
        {
            if (this.OpenAccountLookup(userInfo, this.AccountLookupType, screenData.ScreenInfo.ScreenId))
            {
                if (!this.XperienceEnabledService.IsCustomScreen(userInfo, screenData.ScreenInfo.ScreenId, null, this.AccountLookupType, false))
                {
                    rq = new HandleScreenInfoRequest(new KeyPress(Key.F12, Key.None), screenData.ScreenInfo.CursorLocation);
                }
            }
        }

        return rq;
    }

    public virtual bool IsInputObserver(string screenId)
    {
        return false;
    }

    public virtual bool IsMenuOptionObserver()
    {
        return true;
    }

    public virtual bool IsScreenHandler(string screenId)
    {
        return screenId == this.ScreenId;
    }

    public virtual bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        this.Args = args;
        return false;
    }

    public virtual Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        return null;
    }

    private bool OpenAccountLookup(ICurrentUserInfo userInfo, string accountType, string screenId)
    {
        //TODO: Implement
        //// if the account inquiry screen for this account prompt is custom
        //// don't open the account lookup screen, keep in xpe so they can
        //// just open the account inquiry here, then account inquiry will open in account lookup and xpe
        //// that way they will be able to see the custom inquiry screens in xpe and C&A account inquiry
        //bool isCustomAccountInquiryForPromptScreen = this.XperienceEnabledService.IsCustomAccountInquiryForPromptScreen(userInfo, screenId, accountType);

        //if (isCustomAccountInquiryForPromptScreen)
        //{
        //    return false;
        //}

        //this.XperienceProxyService.OpenAccountLookup(userInfo, accountType);

        return true;
    }
}
