namespace Xpe.Abstraction.Model.ScreenHandlers;
using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using System;
using System.Threading.Tasks;

public class AccountInquiryScreenHandler : IScreenHandler
{
    public AccountInquiryScreenHandler(
        string screenId,
        IUserService userService,
        IXperienceEnabledService xperienceEnabledService)
    {
        this.ScreenId = screenId;
        this.UserService = userService;
        this.XperienceEnabledService = xperienceEnabledService;
    }

    public XpeNavigationEventArgs Args { get; set; }

    private bool OpenAccountLookupInquiryInXpe { get; set; }

    private IUserService UserService { get; set; }

    private IXperienceEnabledService XperienceEnabledService { get; set; }

    private string ScreenId { get; set; }

    public virtual HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        HandleScreenInfoRequest rq = null;

        if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId))
        {
            if (this.OpenAccountInquiry(screenData))
            {
                if (!OpenAccountLookupInquiryInXpe)
                {
                    rq = new HandleScreenInfoRequest(new KeyPress(Key.F12, Key.None), screenData.ScreenInfo.CursorLocation);
                }
            }
        }

        return rq;
    }

    public virtual bool IsInputObserver(string screenId)
    {
        return false;
    }

    public virtual bool IsMenuOptionObserver()
    {
        return true;
    }

    public virtual bool IsScreenHandler(string screenId)
    {
        return this.ScreenId == screenId;
    }

    public virtual bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        this.Args = args;
        return false;
    }

    public virtual Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        return null;
    }

    private bool OpenAccountInquiry(ScreenData screenData)
    {

        //Only open C & A for the account if we're on a standard screen.  If the bank has a custom screen map in place, we stay in XPE.
        if (!this.XperienceEnabledService.IsCustomScreen(UserService.CurrentUserInfo, screenData.ScreenInfo.ScreenId, null, null, false))
        {
            //TODO: Implement
            //if (screenData != null && screenData.CurrentAccount != null &&
            //    !string.IsNullOrEmpty(screenData.CurrentAccount.AcctId) &&
            //    !string.IsNullOrEmpty(screenData.CurrentAccount.AcctType))
            //{
            //    this.AccountRequested(screenData.CurrentAccount, windowIdentifier);
            //    return true;
            //}

            //////Passing in account type because these screens don't necessarily have an account type.
            //////However, we know the account type because the screen id is specific to an account type.
            //bool accountRequested = false;

            //if (screenData != null && screenData.FieldItems != null && screenData.FieldItems.Where(f => f is AccountNumberScreenFieldItem).Any())
            //{
            //    AccountNumberScreenFieldItem accountField = screenData.FieldItems.FirstOrDefault(f => f is AccountNumberScreenFieldItem) as AccountNumberScreenFieldItem;

            //    MiniAccount miniAccount = new MiniAccount(accountField.Account.AcctId, accountField.Account.AcctType);

            //    this.AccountRequested(miniAccount, windowIdentifier);

            //    accountRequested = true;
            //}

            //return accountRequested;
        }

        return false;
    }
}
