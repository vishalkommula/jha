namespace Xpe.Abstraction.Model.ScreenHandlers;

using Xpe.Abstraction.Enums;

using Microsoft.Extensions.Logging;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using JHA = JackHenry.JHAContractTypes;
using TPG = JackHenry.Enterprise.BusinessObjects.Tpg;

public class ImageSearchParmJHXPEIMGFMScreenHandler : BaseScreenHandler
{
    public ImageSearchParmJHXPEIMGFMScreenHandler(ILogger<ImageSearchParmJHXPEIMGFMScreenHandler> logger)
    {
        Logger = logger;
    }

    private ILogger<ImageSearchParmJHXPEIMGFMScreenHandler> Logger { get; }

    public override bool IsInputObserver(string screenId) => screenId == ScreenIdentification.ImageSearchParmScreen;

    public override async Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        if (screenInfoRq?.Key?.Key == Key.Enter &&
            screenInfoRq?.SocketCommand != SocketCommand.PING)
        {
            //TODO: Implement
            //await this.OpenImageSearchViewerAsync(screenData, screenInfoRq, windowIdentifier, userInfo);
            return true;
        }

        return false;
    }

    private async Task OpenImageSearchViewerAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        string windowIdentifier,
        ICurrentUserInfo userInfo)
    {
        //TODO: Implement
        //try
        //{
        //    IInquiryResponse<InstitutionSettings> instSettingsRs =
        //        await this.ViewSettingsService.RetrieveInstitutionSettingAsync<InstitutionSettings>(
        //            userInfo.InstitutionNumber, true, false);

        //    instSettingsRs.ThrowIfInvalid();

        //    if (instSettingsRs.Payload_Rs.GetPersistedWsSettingsByType(WebServiceType.Statement)?.IsWebServiceEnabled != true)
        //    {
        //        DialogService.ShowErrorNotificationDialog(windowIdentifier, "The Check and Statement Image service is not configured for this institution.");
        //        return;
        //    }

        //    this.GetSearchCriteria(screenData, screenInfoRq, out SearchCriteria sc, out string acctId, out string acctType);

        //    IInquiryResponse<TPG.ChkImgSrchRs_MType> chkImgSrchRs =
        //        await this.ImageService.JxCheckImageSearchAsync(
        //            userInfo, acctId, acctType, "0", sc);

        //    chkImgSrchRs.ThrowIfInvalid();

        //    if (chkImgSrchRs.Payload_Rs.ChkImgSrchArray?.Any() != true)
        //    {
        //        DialogService.ShowErrorNotificationDialog(windowIdentifier, "No images found for provided search criteria");
        //        return;
        //    }

        //    List<JHA.IImageItem> imageItems = new List<JHA.IImageItem>(
        //        chkImgSrchRs.Payload_Rs.ChkImgSrchArray.Select(i => new CheckImageModel(i, null)));

        //    string warningMessage = null;
        //    if (chkImgSrchRs.MoreRecords)
        //    {
        //        warningMessage = string.Format(
        //            GenericExceptions.PartialResultsDisplayed,
        //            imageItems.Count,
        //            chkImgSrchRs.Payload_Rs.SrchMsgRsHdr.TotRec.Value);
        //    }

        //    JHA.IImageItem selectedImageItem = imageItems.FirstOrDefault();

        //    this.EventService.Publish<ShowImageViewerDialogEvent, ShowImageViewerDialogEventArgs>(
        //        new ShowImageViewerDialogEventArgs(
        //            $"{UIFunctionKey.ImageDetailViewer}_{selectedImageItem.ImgNum}",
        //            windowIdentifier,
        //            null,
        //            selectedImageItem,
        //            null,
        //            imageItems,
        //            false,
        //            true,
        //            warningMessage));
        //}
        //catch (Exception ex)
        //{
        //    this.LoggingService.LogException("Opening the image viewer", null, ex);
        //    DialogService.ShowErrorNotificationDialog(windowIdentifier, "An error occurred opening the image viewer", ex.Message);
        //}
        //finally
        //{
        //    this.EventService.Publish<SendXPEScreenCommandEvent, SendXPEScreenCommandEventArgs>(
        //        new SendXPEScreenCommandEventArgs(
        //            windowIdentifier,
        //            new ScreenInfoRequest(
        //                new KeyPress(Key.F12, Key.None),
        //                screenInfoRq.CursorLocation)));
        //}
    }

    //private void GetSearchCriteria(
    //    ScreenData screenData,
    //    ScreenInfoRequest screenInfoRequest,
    //    out SearchCriteria searchCriteria,
    //    out string acctId,
    //    out string acctType)
    //{
    //    searchCriteria = new SearchCriteria();
    //    acctId = screenData.ScreenInfo.AllFields.Single(f => f.RRCCC == "02002").Data;
    //    acctType = screenData.ScreenInfo.AllFields.Single(f => f.RRCCC == "02019").Data;

    //    foreach (ScreenField5250 field in screenInfoRequest.ChangedFields)
    //    {
    //        switch (field.RRCCC)
    //        {
    //            case "02021":
    //                searchCriteria.TranCodeCode = field.Data;
    //                break;
    //            case "02027":
    //                searchCriteria.TranType = field.Data;
    //                break;
    //            case "02029":
    //                if (!string.IsNullOrEmpty(field.Data))
    //                {
    //                    searchCriteria.StartDate = DateTime.ParseExact(field.Data, "MMddyyyy", null);
    //                }

    //                break;
    //            case "02040":
    //                if (!string.IsNullOrEmpty(field.Data))
    //                {
    //                    searchCriteria.EndDate = DateTime.ParseExact(field.Data, "MMddyyyy", null);
    //                }

    //                break;
    //            case "02051":
    //                searchCriteria.CheckStart = Convert.ToInt64(field.Data);
    //                break;
    //            case "02062":
    //                searchCriteria.CheckEnd = Convert.ToInt64(field.Data);
    //                break;
    //            case "02073":
    //                searchCriteria.AmountLow = Convert.ToDecimal(field.Data) / 100;
    //                break;
    //            case "02086":
    //                searchCriteria.AmountHigh = Convert.ToDecimal(field.Data) / 100;
    //                break;
    //        }
    //    }
    //}
}
