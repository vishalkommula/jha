namespace Xpe.Abstraction.Model.ScreenHandlers;

using JackHenry.JHAContractTypes;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class LNC500FMScreenHandler : IScreenHandler
{
    public LNC500FMScreenHandler(/*IInquiryTypeProvider inquiryTypeProvider*/)
    {
        //this.InquiryTypeProvider = inquiryTypeProvider;
        this.ScreenList = new List<string>() { "LNC500FM-SFLBC-SFLB-SFOPT", "LNC500FM-SFLAC-SFLA-SFOPT", "LNC500FM-SFLOC-SFLO-SFLOPO", "LNC500FM-SF02" };
        this.PromptScreenId = "LNC500FM-PROMPT";

        this.RelatedFunction = UIFunctionKey.CollateralTracking;
        this.AccountSearch = false;
        this.Account = null;
    }

    //private IInquiryTypeProvider InquiryTypeProvider { get; set; }

    private string RelatedFunction { get; set; }

    private string PromptScreenId { get; set; }

    private List<string> ScreenList { get; set; }

    private bool AccountSearch { get; set; }

    private MiniAccount Account { get; set; }

    public HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        HandleScreenInfoRequest rq = null;

        if (this.IsScreenHandler(screenData.ScreenInfo.ScreenId))
        {
            //TODO: Implement
            //if (screenData != null)
            //{
            //    if (this.AccountSearch && this.Account != null)
            //    {
            //        AccountRequestedEventArgs args = new AccountRequestedEventArgs(this.Account, null, true, this.RelatedFunction, null, windowIdentifier);
            //        args.RelatedFunctionByPassUserSettingsForAutoStart = true;

            //        this.EventService.Publish<AccountRequestedEvent, AccountRequestedEventArgs>(args);
            //        rq = new HandleScreenInfoRequest(new KeyPress(Key.F12, Key.None), screenData.ScreenInfo.CursorLocation);
            //    }
            //    else if (!this.AccountSearch && screenData.FieldItems != null)
            //    {
            //        ////Find the cust id in the screen data, and open customer inquiry with the specified related function
            //        CustomerNumberScreenFieldItem customerField = screenData.FieldItems.FirstOrDefault(f => f is CustomerNumberScreenFieldItem) as CustomerNumberScreenFieldItem;

            //        if (customerField != null)
            //        {
            //            IAccount account = new MiniAccount(customerField.Customer.Value, this.InquiryTypeProvider.CustomerType);
            //            account.CustId = customerField.Customer.Value;

            //            AccountRequestedEventArgs args = new AccountRequestedEventArgs(account, null, true, this.RelatedFunction, null, windowIdentifier);
            //            args.RelatedFunctionByPassUserSettingsForAutoStart = true;

            //            this.EventService.Publish<AccountRequestedEvent, AccountRequestedEventArgs>(args);
            //            rq = new HandleScreenInfoRequest(new KeyPress(Key.F12, Key.None), screenData.ScreenInfo.CursorLocation);
            //        }
            //    }
            //}
        }

        return rq;
    }

    public bool IsInputObserver(string screenId)
    {
        return this.PromptScreenId == screenId;
    }

    public bool IsMenuOptionObserver()
    {
        return false;
    }

    public bool IsScreenHandler(string screenId)
    {
        return this.ScreenList.Contains(screenId);
    }

    public bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        return false;
    }

    public Task<bool> ObserveInputAsync(
        ScreenData screenData,
        ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        this.AccountSearch = false;
        this.Account = null;

        // look at value for account to determine if its an account search or customer search
        if (this.IsInputObserver(screenData.ScreenInfo.ScreenId))
        {
            if (screenData.ScreenInfo.ScreenMapData != null && screenData.ScreenInfo.AllFields != null)
            {
                try
                {
                    var screenMap = ScreenMap.Deserialize(screenData.ScreenInfo.ScreenMapData);

                    if (screenMap != null && screenMap.NamePairArray != null)
                    {
                        var acct = screenMap.NamePairArray.FirstOrDefault(s => s.FieldRefId != null && s.FieldRefId.Contains("ACCTNO"));
                        var acctTypeField = screenMap.NamePairArray.FirstOrDefault(s => s.FieldRefId != null && s.FieldRefId.Contains("ACTYPE"));
                        string accountNumber = string.Empty;

                        if (acct != null)
                        {
                            var acctValue = screenData.ScreenInfo.AllFields.FirstOrDefault(f => f.Col == acct.Col && f.Row == acct.Row);

                            if (acctValue != null)
                            {
                                accountNumber = acctValue.Data;

                                var changedAccount = screenInfoRq.ChangedFields.FirstOrDefault(f => f.Col == acct.Col && f.Row == acct.Row);

                                if (changedAccount != null)
                                {
                                    accountNumber = changedAccount.Data;
                                }
                            }

                            if (accountNumber != null)
                            {
                                accountNumber = accountNumber.Trim();
                            }

                            if (!string.IsNullOrWhiteSpace(accountNumber) && accountNumber != "0")
                            {
                                this.AccountSearch = true;
                            }
                        }

                        if (acctTypeField != null)
                        {
                            string accountType = string.Empty;

                            var acctTypeValue = screenData.ScreenInfo.AllFields.FirstOrDefault(f => f.Col == acctTypeField.Col && f.Row == acctTypeField.Row);

                            if (acctTypeValue != null)
                            {
                                accountType = acctTypeValue.Data;

                                var changedAccountType = screenInfoRq.ChangedFields.FirstOrDefault(f => f.Col == acctTypeField.Col && f.Row == acctTypeField.Row);

                                if (changedAccountType != null)
                                {
                                    accountType = changedAccountType.Data;
                                }
                            }

                            if (accountType != null)
                            {
                                accountType = accountType.Trim();
                            }

                            if (!string.IsNullOrWhiteSpace(accountType))
                            {
                                if (accountType == "C")
                                {
                                    //TODO: Implement
                                    //accountType = this.InquiryTypeProvider.LineOfCreditCode;
                                }

                                this.Account = new MiniAccount(accountNumber, accountType);
                            }
                        }
                    }
                }
                catch
                {
                }
            }
        }

        return Task.FromResult(false);
    }
}
