namespace Xpe.Abstraction.Model;

using System;
using System.Collections.Generic;
using System.Linq;
using JackHenry.JHAContractTypes;

using Xpe.Abstraction.Enums;

public class InquiryTypeProvider : IInquiryTypeProvider
{
    private Dictionary<string, string> appCodes = new Dictionary<string, string>();

    public InquiryTypeProvider()
    {
        this.AllDDA = "*DDA";
        this.AllLoans = "*Loans";
        this.AllTypes = "*All";
        this.ATMCode = "*A";
        this.CDCode = "T";
        this.AllCreditLines = "*LOCALL";
        this.CheckingCode = "D";
        this.ClubCode = "X";
        this.CustomerType = "$";
        this.CustomerCIFIdCode = "*CIF";
        this.CustomerTaxIdCode = "*TAX";
        this.GLCode = "G";
        this.InternetCode = "#";
        this.IRACode = "*IRA";
        this.LineOfCreditCode = "*LOC";
        this.LetterOfCreditCode = "*LOCL";
        this.LIPCode = "W";
        this.LoanCode = "L";
        this.LoanTypeOCode = "O";
        this.NonJhaType = "**";
        this.SafeDepositCode = "B";
        this.SavingsCode = "S";
        this.ShareHolderCode = "H";
        this.VendorCode = "A";
        this.CreditCardCode = "CC";

        this.NonJhaTypes = new string[50] { "C", "E", "F", "I", "J", "M", "N", "P", "Q", "R", "U", "V", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };

        this.appCodes.Add(this.LoanCode, BankAppCodes.LN.ToString());
        this.appCodes.Add(this.LoanTypeOCode, BankAppCodes.LN.ToString());
        this.appCodes.Add(this.CustomerType, BankAppCodes.CF.ToString());
        this.appCodes.Add(this.SafeDepositCode, BankAppCodes.SD.ToString());
    }

    public string AllCreditLines
    {
        get;
        protected set;
    }

    public string AllDDA
    {
        get;
        protected set;
    }

    public string AllLoans
    {
        get;
        protected set;
    }

    public string AllTypes
    {
        get;
        protected set;
    }

    public virtual Dictionary<string, string> AppCodes
    {
        get
        {
            return this.appCodes;
        }
    }

    public string ATMCode
    {
        get;
        protected set;
    }

    public string CDCode
    {
        get;
        protected set;
    }

    public string CheckingCode
    {
        get;
        protected set;
    }

    public string ClubCode
    {
        get;
        protected set;
    }

    public string CreditCardCode
    {
        get;
        protected set;
    }

    public string CustomerCIFIdCode
    {
        get;
        protected set;
    }

    public string CustomerTaxIdCode
    {
        get;
        protected set;
    }

    public string CustomerType
    {
        get;
        protected set;
    }

    public string GLCode
    {
        get;
        protected set;
    }

    public string InternetCode
    {
        get;
        protected set;
    }

    public string IRACode
    {
        get;
        protected set;
    }

    public string LetterOfCreditCode
    {
        get;
        protected set;
    }

    public string LineOfCreditCode
    {
        get;
        protected set;
    }

    public string LIPCode
    {
        get;
        protected set;
    }

    public string LoanCode
    {
        get;
        protected set;
    }

    public string LoanTypeOCode
    {
        get;
        protected set;
    }

    public string NonJhaType
    {
        get;
        protected set;
    }

    public string[] NonJhaTypes
    {
        get;
        protected set;
    }

    public string SafeDepositCode
    {
        get;
        protected set;
    }

    public string SavingsCode
    {
        get;
        protected set;
    }

    public string ShareHolderCode
    {
        get;
        protected set;
    }

    public string VendorCode
    {
        get;
        protected set;
    }

    public string GetAccountTypeByCompAcctType(string compAcctType)
    {
        if (compAcctType == "PL")
        {
            return this.IRACode;
        }
        else if (compAcctType == "LI")
        {
            return this.LineOfCreditCode;
        }
        else if (compAcctType == "LE")
        {
            return this.LetterOfCreditCode;
        }
        else if (compAcctType == "AT")
        {
            return this.ATMCode;
        }

        return null;
    }

    ////[Obsolete("Use method on AccountExtensionMethod class")]
    public virtual string GetBigAccountType(IAccount ia)
    {
        if (this.IsDDA(ia))
        {
            return this.AllDDA;
        }

        if (this.IsLoan(ia))
        {
            return this.AllLoans;
        }

        if (this.IsNonJha(ia))
        {
            return this.NonJhaType;
        }

        if (this.IsCustomer(ia))
        {
            return this.CustomerType;
        }

        if (this.IsLetterOfCredit(ia) || this.IsLineOfCredit(ia))
        {
            return this.AllCreditLines;
        }

        return ia.AcctType;
    }

    ////[Obsolete("Use method on AccountExtensionMethod class")]
    public virtual string[] GetLikeTypeCodes(IAccount ia)
    {
        List<string> returnTypes = new List<string>();

        if (this.IsAllLoan(ia) || this.IsLoan(ia))
        {
            ////Loans and AllLoans should now act the same
            returnTypes.Add(this.LoanCode);
            returnTypes.Add(this.LoanTypeOCode);
        }
        else if (this.IsAllDDA(ia))
        {
            returnTypes.Add(this.CheckingCode);
            returnTypes.Add(this.ClubCode);
            returnTypes.Add(this.SavingsCode);
        }
        else if (this.IsAllNonJha(ia))
        {
            returnTypes.AddRange(this.NonJhaTypes);
        }
        else if (this.IsAllTypes(ia))
        {
            returnTypes.Add(this.CheckingCode);
            returnTypes.Add(this.ClubCode);
            returnTypes.Add(this.LoanCode);
            returnTypes.Add(this.LoanTypeOCode);
            returnTypes.Add(this.SafeDepositCode);
            returnTypes.Add(this.CDCode);
            returnTypes.Add(this.SavingsCode);
            returnTypes.Add(this.ShareHolderCode);
            returnTypes.Add(this.VendorCode);
            returnTypes.Add(this.ATMCode);
            returnTypes.Add(this.InternetCode);
            returnTypes.Add(this.LIPCode);
            returnTypes.Add(this.CreditCardCode);

            returnTypes.AddRange(this.NonJhaTypes);
        }
        else
        {
            returnTypes.Add(ia.AcctType);
        }

        return returnTypes.ToArray();
    }

    public virtual bool IsAcctMod(IAccount account)
    {
        return this.IsDDA(account) || this.IsLoan(account) || this.IsSafeDeposit(account) || this.IsCD(account) || this.IsNonJha(account);
    }

    public virtual bool IsAllCreditLines(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.AllCreditLines);
    }

    public virtual bool IsAllDDA(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.AllDDA);
    }

    public virtual bool IsAllLoan(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.AllLoans);
    }

    public virtual bool IsAllNonJha(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.NonJhaType);
    }

    public virtual bool IsAllTypes(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.AllTypes);
    }

    public virtual bool IsATM(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.ATMCode);
    }

    public virtual bool IsCD(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.CDCode);
    }

    public virtual bool IsCDIRA(IAccount ia)
    {
        if (this.IsCD(ia))
        {
            AcctInqRs_MType account = ia as AcctInqRs_MType;

            if (account != null && account.TimeDepAcctInqRec != null &&
                    account.TimeDepAcctInqRec.x_TimeDepAcctInfo != null &&
                    account.TimeDepAcctInqRec.x_TimeDepAcctInfo.TimeDepAcctInfo != null &&
                    account.TimeDepAcctInqRec.x_TimeDepAcctInfo.TimeDepAcctInfo.SvcPrvdInfo != null &&
                    account.TimeDepAcctInqRec.x_TimeDepAcctInfo.TimeDepAcctInfo.SvcPrvdInfo.Core != null &&
                    account.TimeDepAcctInqRec.x_TimeDepAcctInfo.TimeDepAcctInfo.SvcPrvdInfo.Core.IndividualRetirementAcct.GetValueOrDefault() == "Y")
            {
                return true;
            }
        }

        return false;
    }

    public virtual bool IsChecking(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.CheckingCode);
    }

    public virtual bool IsClub(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.ClubCode);
    }

    public virtual bool IsCreditCard(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.CreditCardCode);
    }

    public virtual bool IsCustMod(IAccount account)
    {
        return this.IsCustomer(account);
    }

    public virtual bool IsCustomer(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.CustomerType);
    }

    public bool IsCustomerBeneficialOwner(IAccount account)
    {
        if (this.IsCustomer(account))
        {
            CustInqRs_MType customer = account as CustInqRs_MType;

            ////check field CustBenflOwnType for Y
            return customer?.CustRec?.CustBenflOwnType?.Value == "true";
        }

        //// return false instead once field is mapped
        return false;
    }

    public virtual bool IsDDA(IAccount ia)
    {
        return this.IsChecking(ia) || this.IsClub(ia) || this.IsSavings(ia) || this.IsAllDDA(ia);
    }

    public bool IsDealerLoan(IAccount account)
    {
        bool isMPLOC = false;

        if (this.IsLoan(account))
        {
            AcctInqRs_MType loanAccount = account as AcctInqRs_MType;

            if (loanAccount != null && loanAccount.LnAcctInqRec != null && loanAccount.LnAcctInqRec.x_LnAcctInfo != null &&
               loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo != null && loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo != null &&
               loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo.Core != null && loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo.Core.UnitPricedRptMthd.GetValueOrDefault() == "D")
            {
                isMPLOC = true;
            }
        }

        return isMPLOC;
    }

    public virtual bool IsEFTCardMod(IAccount account)
    {
        return this.IsATM(account);
    }

    public virtual bool IsGL(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.GLCode);
    }

    public virtual bool IsInternet(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.InternetCode);
    }

    public virtual bool IsIRA(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.IRACode);
    }

    public virtual bool IsITalkInquiry(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.CheckingCode) ||
            this.IsAccountTypeThis(ia, this.LoanCode) ||
            this.IsAccountTypeThis(ia, this.LoanTypeOCode) ||
            this.IsAccountTypeThis(ia, this.SavingsCode) ||
            this.IsAccountTypeThis(ia, this.CDCode) ||
            this.IsAccountTypeThis(ia, this.ClubCode) ||
            this.IsAccountTypeThis(ia, this.CustomerType);
    }

    public virtual bool IsJwalkInquiry(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.ShareHolderCode) ||
            this.IsAccountTypeThis(ia, this.VendorCode) ||
            this.IsAccountTypeThis(ia, this.LIPCode);
    }

    public virtual bool IsLetterOfCredit(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.LetterOfCreditCode);
    }

    public virtual bool IsLineOfCredit(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.LineOfCreditCode);
    }

    public virtual bool IsLIP(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.LIPCode);
    }

    public virtual bool IsLoan(IAccount ia)
    {
        return this.IsStandardLoan(ia) || this.IsRevolvingLoan(ia);
    }

    public virtual bool IsLOCMod(IAccount account)
    {
        return this.IsLineOfCredit(account);
    }

    public virtual bool IsMiscellaneous(IAccount ia)
    {
        ////Add any NEW types above to this list or IsMiscellaneous will return true!
        ////Some are purposely omitted since IsDDA and IsLoan are umbrellas covering several types

        return !this.IsCustomer(ia) && !this.IsDDA(ia) && !this.IsLoan(ia) && !this.IsSafeDeposit(ia) &&
               !this.IsCD(ia) && !this.IsShareholder(ia) && !this.IsVendor(ia) &&
               !this.IsInternet(ia) && !this.IsATM(ia) && !this.IsLIP(ia) && !this.IsIRA(ia) && !this.IsLineOfCredit(ia);
    }

    public virtual bool IsMiscellaneousForCustomerHeader(IAccount ia)
    {
        ////Miscellaneous in the header view is not the same as an empirical Miscellaneous.
        ////We know of the type we just dont care to break it out.  Could go in the header view
        ////but I put it here so it doesnt escape maintenance when someone edits account types...
        return !this.IsCustomer(ia) && !this.IsDDA(ia) && !this.IsLoan(ia) && !this.IsCD(ia) && !this.IsIRA(ia) && !this.IsLineOfCredit(ia);
    }

    public bool IsMPLOCLoan(IAccount account)
    {
        bool isMPLOC = false;

        if (this.IsLoan(account))
        {
            AcctInqRs_MType loanAccount = account as AcctInqRs_MType;

            if (loanAccount != null && loanAccount.LnAcctInqRec != null && loanAccount.LnAcctInqRec.x_LnAcctInfo != null &&
               loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo != null && loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo != null &&
               loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo.Core != null && loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo.Core.UnitPricedRptMthd.GetValueOrDefault() == "M")
            {
                isMPLOC = true;
            }
        }

        return isMPLOC;
    }

    public virtual bool IsNonJha(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.NonJhaType) ||
            this.IsAccountTypeOneOfThese(ia, this.NonJhaTypes);
    }

    public virtual bool IsNonJha(AccountId_CType accountId)
    {
        return this.IsAccountTypeThis(accountId.AcctType, this.NonJhaType) ||
            this.IsAccountTypeOneOfThese(accountId.AcctType, this.NonJhaTypes);
    }

    public virtual bool IsParticipationLoan(IAccount account)
    {
        bool isParticipationLoan = false;

        if (this.IsLoan(account))
        {
            AcctInqRs_MType loanAccount = account as AcctInqRs_MType;

            if (loanAccount.LnAcctInqRec != null &&
                    loanAccount.LnAcctInqRec.x_LnAcctInfo != null &&
                    loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo != null &&
                    loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.PrtcpCode != null &&
                    loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.PrtcpCode.Value == "P")
            {
                isParticipationLoan = true;
            }
        }

        return isParticipationLoan;
    }

    [Obsolete("Use method on AccountExtensionMethod class")]
    public virtual bool IsRevolvingLoan(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.LoanTypeOCode);
    }

    public virtual bool IsSafeDeposit(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.SafeDepositCode);
    }

    public virtual bool IsSavings(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.SavingsCode);
    }

    public virtual bool IsShadowLoan(IAccount account)
    {
        bool isShadowLoan = false;

        if (this.IsLoan(account))
        {
            AcctInqRs_MType loanAccount = account as AcctInqRs_MType;

            if (loanAccount.LnAcctInqRec != null &&
                    loanAccount.LnAcctInqRec.x_LnAcctInfo != null &&
                    loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo != null &&
                     loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo != null &&
                      loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo.Core != null &&
                       loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo.Core.ShadowProcFlg != null &&
                    loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo.Core.ShadowProcFlg == "Y")
            {
                isShadowLoan = true;
            }
        }

        return isShadowLoan;
    }

    public virtual bool IsShareholder(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.ShareHolderCode);
    }

    public bool IsSpecialityLendingLoan(IAccount account)
    {
        bool isSpecialityLending = false;

        if (this.IsLoan(account))
        {
            AcctInqRs_MType loanAccount = account as AcctInqRs_MType;

            if (loanAccount != null && loanAccount.LnAcctInqRec != null && loanAccount.LnAcctInqRec.x_LnAcctInfo != null &&
               loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo != null && loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo != null &&
               loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo.Core != null && loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo.Core.SpecLndingFlg.GetValueOrDefault() == "Y")
            {
                isSpecialityLending = true;
            }
        }

        return isSpecialityLending;
    }

    public virtual bool IsStandardLoan(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.LoanCode);
    }

    public bool IsUnitPricedLoan(IAccount account)
    {
        bool isUnitPriced = false;

        if (this.IsLoan(account))
        {
            AcctInqRs_MType loanAccount = account as AcctInqRs_MType;

            if (loanAccount != null && loanAccount.LnAcctInqRec != null && loanAccount.LnAcctInqRec.x_LnAcctInfo != null &&
               loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo != null && loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo != null &&
               loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo.Core != null && loanAccount.LnAcctInqRec.x_LnAcctInfo.LnAcctInfo.SvcPrvdInfo.Core.UnitPricedRptMthd.GetValueOrDefault() == "U")
            {
                isUnitPriced = true;
            }
        }

        return isUnitPriced;
    }

    public virtual bool IsUnoccupiedOrUnavailableSafeDeposit(IAccount ia)
    {
        if (this.IsSafeDeposit(ia))
        {
            AcctSrchRec_CType search = ia as AcctSrchRec_CType;

            if (search != null)
            {
                return search.AcctStat == "U" || search.AcctStat == "N";
            }

            AcctInqRs_MType account = ia as AcctInqRs_MType;

            if (account != null
                && account.SafeDepAcctInqRec != null
                && account.SafeDepAcctInqRec.x_SafeDepInfoRec != null
                && account.SafeDepAcctInqRec.x_SafeDepInfoRec.SafeDepInfoRec != null
                && (account.SafeDepAcctInqRec.x_SafeDepInfoRec.SafeDepInfoRec.AcctStat.GetValueOrDefault() == "U" ||
                account.SafeDepAcctInqRec.x_SafeDepInfoRec.SafeDepInfoRec.AcctStat.GetValueOrDefault() == "N"))
            {
                return true;
            }
        }

        return false;
    }

    public virtual bool IsVendor(IAccount ia)
    {
        return this.IsAccountTypeThis(ia, this.VendorCode);
    }

    public bool IsAccountAppCode(string appCode)
    {
        return this.AppCodes.ContainsValue(appCode);
    }

    public string GetAccountAppCode(string acctType)
    {
        if (this.AppCodes.ContainsKey(acctType))
        {
            return this.AppCodes[acctType];
        }

        return null;
    }

    public virtual decimal GetAcctSrchRecBalance(AcctSrchRec_CType acct)
    {
        if (acct.AcctType == this.ShareHolderCode)
        {
            if (acct.SvcPrvdInfo?.Core?.ShareholderSharesNum != null)
            {
                return acct.SvcPrvdInfo.Core.ShareholderSharesNum.GetValueOrDefault();
            }
            else
            {
                return acct.DisplayAmt;
            }
        }
        else if (acct.AcctType == this.CreditCardCode)
        {
            return default(decimal);
        }

        return acct.DisplayAmt;
    }

    public virtual string FormatAcctSrchRecBalance(AcctSrchRec_CType acct, decimal balance)
    {
        if (acct.AcctType == this.ShareHolderCode)
        {
            if (acct.SvcPrvdInfo?.Core?.ShareholderSharesNum != null)
            {
                return balance.ToString(XpeResourceStrings.ShareHolderSharesBalanceFormatString);
            }
            else
            {
               return balance.ToString(XpeResourceStrings.ShareHolderSharesBalanceFormatString);
            }
        }
        else if (acct.AcctType == this.CreditCardCode)
        {
            return string.Empty;
        }
        else
        {
           return balance.ToString("C");
        }
    }

    protected bool IsAccountTypeOneOfThese(IAccount ia, string[] types)
    {
        if (ia == null)
        {
            return false;
        }

        if (types == null || types.Length == 0)
        {
            return false;
        }

        return types.Contains(ia.AcctType);
    }

    protected bool IsAccountTypeOneOfThese(string accountType, string[] types)
    {
        if (types == null || types.Length == 0)
        {
            return false;
        }

        return types.Contains(accountType);
    }

    protected bool IsAccountTypeThis(IAccount ia, string type)
    {
        if (ia == null)
        {
            return false;
        }

        return string.Compare(ia.AcctType, type, true) == 0;
    }

    protected bool IsAccountTypeThis(string accountType, string type)
    {
        return string.Compare(accountType, type, true) == 0;
    }
}