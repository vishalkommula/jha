namespace Xpe.Abstraction.Model;

using System.Collections.Generic;
using System.Linq;

public class UnmappedScreen
{
    public UnmappedScreen(List<InputField> inputFields, List<ScreenField5250> outputFields, string screenName, int screenHeight, int screenWidth, bool isIBMScreen)
    {
        this.InputFields = inputFields;
        this.SetOutputFields(outputFields, isIBMScreen);
        this.ScreenHeight = screenHeight;
        this.ScreenWidth = screenWidth;
        this.IsIBMScreen = isIBMScreen;
    }

    public List<InputField> InputFields { get; set; }
    public List<ScreenField5250> OutputFields { get; set; }
    public bool IsIBMScreen { get; set; }
    public int ScreenWidth { get; set; }
    public int ScreenHeight { get; set; }

    private void SetOutputFields(List<ScreenField5250> outputFields, bool isIBMScreen)
    {
        if (outputFields != null && outputFields.Any())
        {
            outputFields = ScreenField5250.Reorder(outputFields);

            ////Filter out the title on IBM screens....we display it in the form of a display block header instead
            if (isIBMScreen)
            {
                ScreenField5250 titleField = outputFields.FirstOrDefault(f => !string.IsNullOrWhiteSpace(f.Data) && !f.Data.ToLower().Contains("copyright ibm"));
                titleField.Data = string.Empty;
            }
        }

        this.OutputFields = outputFields;
    }
}
