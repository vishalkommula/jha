﻿using System.Collections.Generic;
using System.Globalization;

namespace Xpe.Abstraction.Model
{
    public interface IFieldItemProvider
    {
        CultureInfo GetCultureInfo(ICurrentUserInfo userInfo);
        XpeField GetFieldItem(ScreenField screenField, ScreenField5250 screenField5250, IEnumerable<ScreenField> screenFields, ScreenInfoResponse screenInfo, ICurrentUserInfo userInfo, ScreenMapGridArrayGrid screenMapGrid = null);
        bool IsFieldBestMatch(ScreenField screenField, IEnumerable<ScreenField> screenFields, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields);
    }
}
