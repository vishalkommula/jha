﻿namespace Xpe.Abstraction.Model;

public interface IToolbarItem
{
    string Text { get; set; }
    string Key { get; set; }
    bool IsVisible { get; set; }
    bool AutoHide { get; set; }
    string IconType { get; set; }
    string ToolTip { get; set; }
}
