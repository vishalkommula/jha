// -----------------------------------------------------------------------
// <copyright file="PhoneNumberScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System.Collections.Generic;
using JackHenry.JHAContractTypes;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;

public class PhoneNumberScreenFieldItem : XpeField, IFieldItem
{
    private string fieldLabel;
    private string fieldValue;
    //private JHARecordDetail.DataTypes fieldValueType = JHARecordDetail.DataTypes.Text;
    private bool isReadOnly = true;
    //private JHARecordDetailFieldItem recordDetailFieldItem;
    private ScreenField screenField;
    private ScreenField5250 screenField5250;

    public PhoneNumberScreenFieldItem(ScreenField5250 screenField5250, ScreenField screenField, IEnumerable<ScreenField5250> outputFields, ScreenField5250 prefixField5250 = null, ScreenField5250 lineNumberField5250 = null)
    {
        this.screenField = screenField;
        this.screenField5250 = screenField5250;
        this.isReadOnly = true;
        this.fieldLabel = this.GetFieldLabel(outputFields);
        this.FieldID = string.Format("{0}-{1}", this.screenField.Sequence.ToString(), this.fieldLabel);

        this.fieldValue = screenField5250.Data != null ? screenField5250.Data.Trim() : null;

        if (prefixField5250 != null && !string.IsNullOrEmpty(prefixField5250.Data) && lineNumberField5250 != null && !string.IsNullOrEmpty(lineNumberField5250.Data))
        {
            this.fieldValue = string.Format("{0}{1}{2}", this.fieldValue, prefixField5250.Data.Trim(), lineNumberField5250.Data.Trim());
        }

        decimal decimalValue;

        if (decimal.TryParse(this.fieldValue, out decimalValue))
        {
            //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
        }

        this.IsItemDisplayed = !this.screenField.IsDisplayFormatIgnored();
        this.IsHighlightedStandard = this.screenField5250.Att == FieldAttribute.GreenReverse;
    }

    public string FieldValue { get; set; }

    public override bool IsCustomDataGridCellRequired
    {
        get
        {
            return true;
        }
    }

    public override bool IsItemDisplayed { get; protected set; }

    public override bool IsReadOnly
    {
        get
        {
            return this.isReadOnly;
        }
    }

    public string UnFormattedPhoneNumber
    {
        get
        {
            return this.FieldValue != null ? this.FieldValue.ToString().Replace("(", string.Empty).Replace(")", string.Empty).Replace("-", string.Empty) : null;
        }
    }

    public override string ToString()
    {
        return this.FieldValue;
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.screenField.FormatDynamicLabelText(outputFields);
    }
}
