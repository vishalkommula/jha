﻿// -----------------------------------------------------------------------
// <copyright file="PasswordScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System;
using System.Collections.Generic;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;

public class PasswordScreenFieldItem : XpeField, IModField5250, IEditorControlProvider
{
    private ScreenField5250 screenField5250;
    private ScreenField screenField;
    private string fieldValue;
    private bool isReadOnly = true;
    private string linkTitle;
    private string fieldLabel;

    public PasswordScreenFieldItem(ScreenField5250 screenField5250, ScreenField screenField, IEnumerable<ScreenField5250> outputFields)
    {
        this.ScreenField = screenField;
        this.fieldLabel = this.GetFieldLabel(outputFields);
        this.FieldID = string.Format("{0}-{1}", this.screenField.Sequence.ToString(), this.fieldLabel);
        this.FieldLength = screenField.Length;

        this.ScreenField5250 = screenField5250;
        this.isReadOnly = true;
        this.FieldValue = this.linkTitle = string.Format("Input Masked {0}", this.fieldLabel);
        this.IsItemDisplayed = !this.screenField.IsDisplayFormatIgnored();
        this.IsHighlightedStandard = this.ScreenField5250.Att == FieldAttribute.GreenReverse;
    }

    public override bool IsItemDisplayed
    {
        get;
        protected set;
    }

    public ScreenField ScreenField { get; set; }

    public ScreenField5250 ScreenField5250 { get; set; }

    public int FieldLength { get; set; }

    public override bool IsCustomDataGridCellRequired
    {
        get
        {
            return true;
        }
    }

    public string FieldValue { get; set; }

    public override bool IsReadOnly
    {
        get
        {
            return this.isReadOnly;
        }
    }

    public string DataStreamValue
    {
        get
        {
            if (this.FieldValue != null &&
                this.ScreenField5250.FieldFormatWord != null &&
                this.ScreenField5250.FieldFormatWord.Monocase == true)
            {
                return this.FieldValue.ToString().ToUpper();
            }

            return this.FieldValue;
        }
    }

    public string BindingPath { get; set; }

    public string EditorMask { get; set; }

    public int MaxLength { get; set; }

    public bool IsPromptable { get; set; }

    public override string ToString()
    {
        return this.FieldValue;
    }

    public void AddToChangedList(List<ScreenField5250> changedList, bool includeModifiedDataTagField)
    {
        //// Don't set the value if it still contains the link title that we set....only send if user changes the password/PIN value
        if (this.FieldValue != this.linkTitle)
        {
            this.ScreenField5250.Data = this.DataStreamValue;
            changedList.Add(this.ScreenField5250);
        }
        else if (includeModifiedDataTagField)
        {
            if (this.ScreenField5250.FieldFormatWord != null && this.ScreenField5250.FieldFormatWord.ModifiedDataTag)
            {
                changedList.Add(this.ScreenField5250);
            }
        }
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.ScreenField.FormatDynamicLabelText(outputFields);
    }
}