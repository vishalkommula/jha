﻿// -----------------------------------------------------------------------
// <copyright file="GLAccountNumberScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System;
using System.Collections.Generic;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;
using Xpe.Abstraction.Services;

public class GLAccountNumberScreenFieldItem : XpeField, IComparable, IEditorControlProvider
{
    private string fieldValue;
    //private JHARecordDetail.DataTypes fieldValueType = JHARecordDetail.DataTypes.Text;
    private bool isClickable = false;
    private bool isReadOnly = true;
    private ScreenField screenField;
    private ScreenField5250 screenField5250;
    private string fieldLabel;
    //private JHARecordDetailFieldItem recordDetailFieldItem;

    public GLAccountNumberScreenFieldItem()
    {
        //this.account = new GLMiniAccount(string.Empty, string.Empty, string.Empty, string.Empty, string.Empty);
    }

    public GLAccountNumberScreenFieldItem(
        ScreenField5250 screenField5250,
        ScreenField screenField,
        string branchCode,
        string costCenter,
        string prodCode,
        string accountType,
        IInquiryTypeProvider inquiryTypeProvider,
        IUserService userService,
        ICurrentUserInfo userInfo,
        IEnumerable<ScreenField5250> outputFields)
    {
        this.screenField = screenField;
        this.screenField5250 = screenField5250;
        this.IsItemDisplayed = !this.screenField.IsDisplayFormatIgnored();
        this.IsHighlightedStandard = this.screenField5250.Att == FieldAttribute.GreenReverse;
        this.fieldLabel = this.GetFieldLabel(outputFields);

        string value = screenField5250.Data != null ? screenField5250.Data.Trim() : null;

        //TODO
        //GLMiniAccount glAcct = new GLMiniAccount(value, branchCode, costCenter, prodCode, null);
        //glAcct.GLInqType = GLInqType.Cur.ToString();

        //this.account = glAcct;
        //this.account.AcctType = accountType;

        //this.fieldValue = this.account.GetFormattedAccountNumber(true, true);
        //this.isClickable = true;
    }

    public string BindingPath { get; protected set; }

    public string EditorMask { get; protected set; }

    public string FieldValue { get; set; }

    //public GLMiniAccount GLAccount
    //{
    //    get
    //    {
    //        return this.account;
    //    }
    //}

    public override bool IsCustomDataGridCellRequired
    {
        get
        {
            return true;
        }
    }

    public override bool IsItemDisplayed { get; protected set; }

    public bool IsPromptable
    {
        get
        {
            return false;
        }
    }

    public override bool IsReadOnly
    {
        get
        {
            return this.isReadOnly;
        }
    }

    public int MaxLength { get; protected set; }

    public int CompareTo(object obj)
    {
        GLAccountNumberScreenFieldItem other = obj as GLAccountNumberScreenFieldItem;
        string otherValue = obj.ToString();

        if (other != null)
        {
            otherValue = other.FieldValue;
        }

        long thisIntValue;

        if (!long.TryParse(this.FieldValue, out thisIntValue))
        {
            thisIntValue = 0;
        }

        long thatIntVlaue;

        if (!long.TryParse(otherValue, out thatIntVlaue))
        {
            return 1;
        }

        return thisIntValue.CompareTo(thatIntVlaue);
    }

    public override string ToString()
    {
        return this.FieldValue;
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.screenField.FormatDynamicLabelText(outputFields);
    }
}