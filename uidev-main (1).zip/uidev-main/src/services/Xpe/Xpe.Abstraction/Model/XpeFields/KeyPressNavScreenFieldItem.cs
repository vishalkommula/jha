﻿// -----------------------------------------------------------------------
// <copyright file="KeyPressNavScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2016 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System;
using System.Collections.Generic;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;

public class KeyPressNavScreenFieldItem : XpeField, IEditorControlProvider
{
    private ScreenField5250 screenField5250;
    private ScreenField screenField;
    private string fieldValue;
    private bool isReadOnly = true;
    //private JHARecordDetail.DataTypes fieldValueType = JHARecordDetail.DataTypes.Text;
    private KeyPress key;
    private string fieldLabel;
    //private JHARecordDetailFieldItem recordDetailFieldItem;

    public KeyPressNavScreenFieldItem(ScreenField5250 screenField5250, ScreenField screenField, KeyPress key, IEnumerable<ScreenField5250> outputFields)
    {
        this.screenField = screenField;
        this.screenField5250 = screenField5250;
        this.key = key;
        this.isReadOnly = true;
        this.fieldValue = screenField5250.Data != null ? screenField5250.Data.Trim() : null;
        this.IsItemDisplayed = !this.screenField.IsDisplayFormatIgnored();
        this.IsHighlightedStandard = this.screenField5250.Att == FieldAttribute.GreenReverse;
        this.CursorLocation = new CursorLocation(screenField.Row, screenField.Col);
        this.fieldLabel = this.GetFieldLabel(outputFields);
    }

    public override bool IsCustomDataGridCellRequired
    {
        get
        {
            return true;
        }
    }

    public string FieldValue { get; set; }

    public KeyPress Key { get; set; }

    public override bool IsReadOnly
    {
        get
        {
            return this.isReadOnly;
        }
    }

    public override bool IsItemDisplayed { get; protected set; }

    public string BindingPath { get; protected set; }

    public string EditorMask { get; protected set; }

    public int MaxLength { get; protected set; }

    public bool IsPromptable { get; protected set; }

    public override string ToString()
    {
        return this.FieldValue;
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.screenField.FormatDynamicLabelText(outputFields);
    }
}