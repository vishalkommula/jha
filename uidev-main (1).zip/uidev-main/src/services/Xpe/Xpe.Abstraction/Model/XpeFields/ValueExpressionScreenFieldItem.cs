﻿// -----------------------------------------------------------------------
// <copyright file="ValueExpressionScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

using Xpe.Abstraction.Extensions;

public class ValueExpressionScreenFieldItem : XpeField
{
    private object fieldValue;
    private bool isReadOnly = true;
    //private JHARecordDetail.DataTypes fieldValueType = JHARecordDetail.DataTypes.Text;
    private ScreenField screenField;
    private IEnumerable<ScreenField5250> allFields;
    private string fieldLabel;
    //private JHARecordDetailFieldItem recordDetailFieldItem;

    public ValueExpressionScreenFieldItem(ScreenField screenField, IEnumerable<ScreenField5250> allFields)
    {
        this.IsItemDisplayed = !screenField.IsDisplayFormatIgnored();
        this.IsHighlightedStandard = false;
        this.screenField = screenField;
        this.allFields = allFields;
        this.fieldLabel = this.GetFieldLabel(allFields);

        this.fieldValue = screenField.FormatLinkDataExpression(allFields, false);
        this.SetFieldValueFromDisplayFormat(this.fieldValue.ToString());
    }

    public override bool IsItemDisplayed { get; protected set; }

    //public JHARecordDetail.DataTypes FieldValueType { get; set; }

    public object FieldValue { get; set; }

    public override bool IsReadOnly
    {
        get
        {
            return this.isReadOnly;
        }
    }

    public override bool IsCustomDataGridCellRequired
    {
        get
        {
            return false;
        }
    }

    public override string ToString()
    {
        return this.FieldValue.ToString();
    }

    public void SetFieldValueFromDisplayFormat(string stringValue)
    {
        bool converted = false;

        if (this.screenField.IsDisplayFormatCurrency())
        {
            stringValue = this.FormatWholeNumberStringAsDecimal(stringValue);

            decimal decimalValue;

            if (string.IsNullOrEmpty(stringValue))
            {
                this.fieldValue = new decimal?();
                //this.fieldValueType = JHARecordDetail.DataTypes.Currency;
                converted = true;
            }
            else if (decimal.TryParse(stringValue, out decimalValue))
            {
                this.fieldValue = (decimal?)decimalValue;
                //this.fieldValueType = JHARecordDetail.DataTypes.Currency;
                converted = true;
            }
        }
        else if (this.screenField.IsDisplayFormatRate())
        {
            stringValue = this.FormatWholeNumberStringAsDecimal(stringValue);

            decimal decimalValue;

            ////need to display rate values for output fields with the % sign
            //// you can't use the Rate datatype on record detail because it multiplies the value by 100
            //// green screen is already display values as they are so we just need to set type to number and let it be edited as a number
            //// as it is on the green screen
            if (string.IsNullOrEmpty(stringValue) || stringValue.Replace(".", string.Empty).Replace("%", string.Empty).All(d => d == '0'))
            {
                this.fieldValue = null;
                //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
                converted = true;
            }
            else if (decimal.TryParse(stringValue.Replace("%", string.Empty), out decimalValue))
            {
                this.fieldValue = (decimal?)decimalValue;
                //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;

                converted = true;
            }
        }

        if (!converted)
        {
            this.fieldValue = stringValue;
            //this.fieldValueType = JHARecordDetail.DataTypes.Text;
        }
    }

    private string FormatWholeNumberStringAsDecimal(string stringValue)
    {
        // Some of the incoming decimal values include underscores. Remove them here so we can
        // successfully parse the values.
        stringValue = Regex.Replace(stringValue, @"[_]", string.Empty);

        // Factor the incoming raw data string using the specified number of decimal places
        if (!stringValue.Contains(".") && !string.IsNullOrEmpty(stringValue) && this.screenField.DecimalScale > 0)
        {
            decimal denominator = (decimal)Math.Pow(10, this.screenField.DecimalScale);
            decimal decimalValue;

            if (decimal.TryParse(stringValue, out decimalValue))
            {
                stringValue = (decimalValue / denominator).ToString();
            }
        }

        return stringValue;
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.screenField.FormatDynamicLabelText(outputFields);
    }
}