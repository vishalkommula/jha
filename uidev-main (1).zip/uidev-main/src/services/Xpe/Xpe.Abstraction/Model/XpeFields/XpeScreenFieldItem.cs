// -----------------------------------------------------------------------
// <copyright file="SLLiteScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;

public class XpeScreenFieldItem : XpeField, IModField5250, IEditorControlProvider
{
    private ScreenField screenField;
    private ScreenField5250 screenField5250;
    private CultureInfo cultureInfo;
    private bool isReadOnly = true;
    private bool isConvertedDecimal = false;
    private object fieldValue;
    private bool isDirty = false;
    //private JHARecordDetail.DataTypes fieldValueType = JHARecordDetail.DataTypes.Text;
    private bool isNegativeCurrency;
    private Key promptKey;
    private bool isConvertedHyphenDate = false;
    private bool isNumericMask = false;
    //private MaskMode? maskedValueDisplayMode = null;
    //private MaskMode? maskedValueDataMode = null;
    private bool stripLiteralsFromOutput = false;
    private string fieldLabel;
    public XpeScreenFieldItem(ScreenField5250 screenField5250, ScreenField screenField, CultureInfo cultureInfo, IEnumerable<ScreenField5250> outputFields)
    {
        this.screenField = screenField;
        this.screenField5250 = screenField5250;
        this.cultureInfo = cultureInfo;
        this.fieldLabel = this.GetFieldLabel(outputFields);

        this.IsItemDisplayed = !this.screenField.IsDisplayFormatIgnored();
        this.FieldID = string.Format("{0}-{1}", this.screenField.Sequence.ToString(), this.fieldLabel);

        if (this.screenField5250 != null && this.screenField5250.IsInputField())
        {
            this.isReadOnly = false;
        }

        this.CursorLocation = new CursorLocation(screenField5250.Row, screenField5250.Col);
        this.IsFocused = this.screenField5250.IsFocused;

        switch (this.screenField5250.Att)
        {
            case FieldAttribute.GreenReverse:
            case FieldAttribute.GreenUnderscoreReverse:
                this.IsHighlightedStandard = true;
                break;
        }

        string stringValue = string.Empty;

        ////We are no longer trimming the beginning of the incoming string here due to issues with various fields that required leading spaces to persist.
        ////If this change causes issues with other fields not formatting correctly, we may have to add a new Display Format in Screen Mapper to allow banks
        ////to indicate when field data should not be trimmed.
        if (this.screenField5250 != null && !string.IsNullOrEmpty(this.screenField5250.Data))
        {
            stringValue = this.screenField.DataType == "String" ? this.screenField5250.Data.TrimEnd() : this.screenField5250.Data.Trim();
        }

        this.SetFieldValue(stringValue);
        this.ScreenFieldHelpId = this.screenField.HelpId;
        this.SetFieldPromptFunctionKey();
    }

    public bool IsPromptable { get; protected set; }

    public string EditorMask { get; protected set; }

    public int MaxLength { get; protected set; }

    public override bool IsCustomDataGridCellRequired
    {
        get
        {
            return true;
        }
    }

    //public JHARecordDetail.DataTypes FieldValueType { get; set; }

    public override bool IsReadOnly
    {
        get
        {
            return this.isReadOnly;
        }
    }

    public object FieldValue { get; set; }

    public string DataStreamValue
    {
        get
        {
            if (this.FieldValue != null && (this.FieldValue is DateTime || this.FieldValue is DateTime?))
            {
                if (this.screenField.IsDisplayFormatAMonthDayYearDate())
                {
                    if (this.FieldValue != null)
                    {
                        ////The screens that format dates with hyphens in Core expect hyphens in the return value
                        if (this.isConvertedHyphenDate)
                        {
                            switch (this.screenField.DispFormat)
                            {
                                case ScreenFieldDisplayFormat.DateDDMMYY:
                                    return ((DateTime)this.FieldValue).ToString("dd-MM-yy");
                                case ScreenFieldDisplayFormat.DateMMDDYY:
                                    return ((DateTime)this.FieldValue).ToString("MM-dd-yy");
                                case ScreenFieldDisplayFormat.DateMMDDYYYY:
                                    return ((DateTime)this.FieldValue).ToString("MM-dd-yyyy");
                                case ScreenFieldDisplayFormat.DateYYDDD:
                                    return ((DateTime)this.FieldValue).ToString("yy-ddd");
                                case ScreenFieldDisplayFormat.DateYYMMDD:
                                    return ((DateTime)this.FieldValue).ToString("yy-MM-dd");
                                case ScreenFieldDisplayFormat.DateYYYYMMDD:
                                    return ((DateTime)this.FieldValue).ToString("yyyy-MM-dd");
                            }
                        }

                        return ((DateTime)this.FieldValue).ToString(this.screenField.GetDateFormatFromDisplayFormat());
                    }
                    else
                    {
                        return null;
                    }
                }
                else if (this.screenField.IsDisplayFormatJulianDate())
                {
                    if (this.FieldValue != null)
                    {
                        //TODO
                        //return StaticUtilities.ConvertToJulianDate((DateTime)this.FieldValue);
                    }
                    else
                    {
                        return null;
                    }
                }
            }

            // There is a race condition and the "-" for zip is not always being removed by the control
            if (this.FieldValue != null && this.screenField.IsDisplayFormatZip() && this.FieldValue is string value)
            {
                this.FieldValue = value.Replace("-", string.Empty);
            }

            bool isDecimalType = this.FieldValue != null && (this.FieldValue.GetType() == typeof(decimal?) || this.FieldValue.GetType() == typeof(decimal));

            if (isDecimalType || (this.FieldValue != null && this.FieldValue.GetType() == typeof(double)))
            {
                return this.GetDecimalDataStreamValue(this.FieldValue, isDecimalType);
            }

            //TODO
            //if ((this.screenField5250.IsMultiLineField() || this.recDetFieldItem?.DataType == JHARecordDetail.DataTypes.LongText) && this.screenField5250.FieldFormatWord != null && this.screenField5250.FieldFormatWord.Monocase)
            //{
            //    return this.FieldValue != null ? this.FieldValue.ToString().ToUpper() : null;
            //}

            if (this.FieldValue == null && this.screenField.LinkDataExpression != null)
            {
                if (this.screenField.LinkDataExpression.Contains("CLEARNINE"))
                {
                    int fieldLength = this.screenField.Length - this.screenField.DecimalScale;

                    return new string('9', fieldLength);
                }
            }

            return this.FieldValue != null ? this.FieldValue.ToString() : null;
        }
    }

    public string BindingPath
    {
        get
        {
            return "FieldValue";
        }
    }

    public override bool IsItemDisplayed
    {
        get;
        protected set;
    }

    protected CultureInfo CultureInfo
    {
        get
        {
            // Only use the date limit when the year is a two-digit year.
            if (this.screenField.IsDisplayFormatATwoDigitYear())
            {
                return this.cultureInfo;
            }
            else
            {
                return CultureInfo.InvariantCulture;
            }
        }
    }

    public void SetFieldValueFromDisplayFormat(string stringValue)
    {
        bool converted = false;

        if (this.screenField.IsDisplayFormatCurrency())
        {
            stringValue = this.FormatWholeNumberStringAsDecimal();

            decimal decimalValue;

            if (string.IsNullOrEmpty(stringValue))
            {
                this.fieldValue = new decimal?();
                //this.fieldValueType = JHARecordDetail.DataTypes.Currency;
                converted = true;
            }
            else if (decimal.TryParse(stringValue, out decimalValue))
            {
                this.fieldValue = (decimal?)decimalValue;
                //this.fieldValueType = JHARecordDetail.DataTypes.Currency;
                this.isNegativeCurrency = decimalValue < 0;
                converted = true;
            }
        }
        else if (this.screenField.IsDisplayFormatRate())
        {
            stringValue = this.FormatWholeNumberStringAsDecimal();

            decimal decimalValue;

            ////need to display rate values for output fields with the % sign
            //// you can't use the Rate datatype on record detail because it multiplies the value by 100
            //// green screen is already display values as they are so we just need to set type to number and let it be edited as a number
            //// as it is on the green screen
            if (string.IsNullOrEmpty(stringValue) || stringValue.Replace(".", string.Empty).Replace("%", string.Empty).All(d => d == '0'))
            {
                this.fieldValue = null;
                //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
                converted = true;
                this.isNumericMask = true;
            }
            else if (decimal.TryParse(stringValue.Replace("%", string.Empty), out decimalValue))
            {
                this.fieldValue = (decimal?)decimalValue;
                //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
                this.isNumericMask = true;
                converted = true;
            }
        }
        else if (this.screenField.IsDisplayFormatAMonthDayYearDate())
        {
            if (string.IsNullOrEmpty(stringValue) || stringValue.Trim().Replace("/", string.Empty).Replace("-", string.Empty).All(d => d == '0'))
            {
                DateTime? dateValue = null;
                this.fieldValue = dateValue;
                //this.fieldValueType = JHARecordDetail.DataTypes.Date;
                converted = true;
            }
            else
            {
                DateTime dateValue;
                stringValue = stringValue.Trim();

                if (stringValue.Length == this.screenField.Length - 1)
                {
                    stringValue = stringValue.PadLeft(this.screenField.Length, '0');
                }

                string rawValue = stringValue.Replace("/", string.Empty).Replace("-", string.Empty);

                // If the incoming string is already formatted with slashes, we need to change the month to 2-digit format for it to parse correctly.
                if (stringValue.Contains("/"))
                {
                    if (stringValue.Substring(0, stringValue.IndexOf('/')).Length == 1)
                    {
                        rawValue = string.Format("0{0}", rawValue);
                    }
                }

                // If the incoming string is already formatted with hyphens, we need to change the month to 2-digit format for it to parse correctly.
                if (stringValue.Contains("-"))
                {
                    if (stringValue.Substring(0, stringValue.IndexOf('-')).Length == 1)
                    {
                        rawValue = string.Format("0{0}", rawValue);
                    }

                    this.isConvertedHyphenDate = true;
                }

                if (DateTime.TryParseExact(rawValue, this.screenField.GetDateFormatFromDisplayFormat(), this.CultureInfo, DateTimeStyles.None, out dateValue))
                {
                    this.fieldValue = (DateTime?)dateValue;
                    //this.fieldValueType = JHARecordDetail.DataTypes.Date;
                    converted = true;
                }
            }
        }
        else if (this.screenField.IsDisplayFormatJulianDate() && this.screenField5250.IsInputField())
        {
            DateTime? dateValue;
            int intValue;

            if (string.IsNullOrEmpty(stringValue) || stringValue.All(d => d == '0'))
            {
                dateValue = null;
                //this.fieldValueType = JHARecordDetail.DataTypes.Date;
                this.fieldValue = dateValue;
                converted = true;
            }
            else if (stringValue.Length == 5 && int.TryParse(stringValue, out intValue))
            {
                //dateValue = StaticUtilities.ConvertFromJulianDate(intValue);
                //this.fieldValueType = JHARecordDetail.DataTypes.Date;
                //this.fieldValue = dateValue;
                converted = true;
            }
        }
        else if (this.screenField.IsDisplayFormatZip() || this.screenField.IsDisplayFormatPhone())
        {
            //// Strip the hyphens to avoid issues with our input mask.  Confirmed we can send the value back without hyphens and GS retains the value.
            if (!string.IsNullOrEmpty(stringValue) && stringValue.Contains("-"))
            {
                stringValue = stringValue.Replace("-", string.Empty);
            }

            if (string.IsNullOrEmpty(stringValue) || stringValue.All(d => d == '0'))
            {
                this.fieldValue = this.screenField.IsDisplayFormatPhone() ? "0000000000" : "000000000";
                //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
                converted = true;
            }
            else
            {
                //// If our phone # value is > 10, grab the last 10 chars.  Confirmed with Core devs that most phone # fields are 10 digits but there are a
                //// fiew that are 11.  We force 10 to match Rich XP and because 11 digits causes issues with Streamline (they only support 10).
                if (stringValue.Length > 10)
                {
                    stringValue = stringValue.Substring(stringValue.Length - 10);
                }

                //// remove the code to convert to decimal so it doesn't strip the leading zeros on phone numbers or zip codes
                //// zip codes especially need to see leading zeros as those are valid in zip codes
                this.fieldValue = stringValue;
                //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
                converted = true;
            }

            this.isNumericMask = false;

            this.stripLiteralsFromOutput = true;

            if (this.screenField.IsDisplayFormatPhone())
            {
                //this.maskedValueDisplayMode = MaskMode.IncludeLiterals;
            }
        }
        else if (this.screenField.IsDisplayFormatTime())
        {
            DateTime dateValue;
            decimal decimalValue;
            string rawValue = stringValue.Replace(":", string.Empty);

            ////Time values can come in as a formatted string with colons or a decimal type.  Attempt to parse here and set the FieldValue so it works with the EditMask applied to the control.
            if (DateTime.TryParse(stringValue, out dateValue))
            {
                this.fieldValue = rawValue.All(d => d == '0') ? string.Empty : rawValue;
                //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
                converted = true;
            }
            else if (decimal.TryParse(stringValue, out decimalValue))
            {
                this.fieldValue = stringValue;
                //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
                converted = true;
            }

            this.isNumericMask = true;
        }

        if (!converted)
        {
            this.fieldValue = stringValue;
            //this.fieldValueType = JHARecordDetail.DataTypes.Text;
        }
    }

    public void SetFieldValue(string stringValue)
    {
        ////We aren't using the Negative prefix right now, so set the dispformat to null if it is set.
        if (this.screenField.IsDisplayFormatNegativePrefix())
        {
            this.screenField.DispFormat = null;
        }

        if (!string.IsNullOrWhiteSpace(this.screenField.DispFormat))
        {
            this.SetFieldValueFromDisplayFormat(stringValue);
        }
        else if (this.screenField.IsDecimal() || this.screenField.IsInt())
        {
            stringValue = this.FormatWholeNumberStringAsDecimal();

            decimal decimalValue;

            if (string.IsNullOrEmpty(stringValue))
            {
                if (this.screenField5250.FieldFormatWord != null &&
                    (this.screenField5250.FieldFormatWord.FieldShiftEditSpecification == FieldShiftEditSpecification.SignedNumeric ||
                     this.screenField5250.FieldFormatWord.FieldShiftEditSpecification == FieldShiftEditSpecification.NumericOnly))
                {
                    if (this.screenField.DecimalScale > 0)
                    {
                        ////This has to allow for negatives, cannot be set to code
                        //this.fieldValueType = JHARecordDetail.DataTypes.Number;
                    }
                    else
                    {
                        //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
                        this.isNumericMask = true;
                    }
                }
                else if (this.screenField.DecimalScale > 0)
                {
                    ////This has to allow for decimal places, cannot be set to code
                    //this.fieldValueType = JHARecordDetail.DataTypes.Number;
                }
                else
                {
                    //// change to code which is a number without commas
                    ////this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
                    //// changed to Code to fix issue with app shut down using backspace
                    //this.fieldValueType = JHARecordDetail.DataTypes.Code;
                }

                if (this.screenField5250.IsInputField())
                {
                    ////Set this to zero, the record detail field item sets it to zero anyway on field exit,
                    ////this will prevent it from thinking the field has changed and sending the value to the iSeries when sending the command
                    this.fieldValue = 0m;
                }
                else
                {
                    this.fieldValue = new decimal?();
                }
            }
            else if (decimal.TryParse(stringValue, out decimalValue))
            {
                if (this.screenField5250.FieldFormatWord != null &&
                   (this.screenField5250.FieldFormatWord.FieldShiftEditSpecification == FieldShiftEditSpecification.SignedNumeric ||
                    this.screenField5250.FieldFormatWord.FieldShiftEditSpecification == FieldShiftEditSpecification.NumericOnly))
                {
                    if (this.screenField.DecimalScale > 0)
                    {
                        ////This has to allow for negatives, cannot be set to code
                        ////this.fieldValueType = JHARecordDetail.DataTypes.Number;
                    }
                    else
                    {
                        //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
                        this.isNumericMask = true;
                    }
                }
                else if (this.screenField.DecimalScale > 0)
                {
                    ////This has to allow for decimal places, cannot be set to code
                    //this.fieldValueType = JHARecordDetail.DataTypes.Number;
                }
                else
                {
                    ////this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
                    //// changed to Code to fix issue with app shut down using backspace
                    //this.fieldValueType = JHARecordDetail.DataTypes.Code;
                }

                this.fieldValue = (decimal?)decimalValue;
            }
            else
            {
                this.fieldValue = stringValue;
                //this.fieldValueType = JHARecordDetail.DataTypes.Text;
            }
        }
        else if (this.screenField.DataType == ScreenFieldDataType.Time)
        {
            DateTime dateValue;

            if (DateTime.TryParse(stringValue, out dateValue))
            {
                if (this.screenField5250.IsOutputField())
                {
                    this.fieldValue = dateValue as DateTime?;
                    //this.fieldValueType = JHARecordDetail.DataTypes.Time;
                }
                else
                {
                    string rawValue = stringValue.Replace(":", string.Empty);
                    this.fieldValue = rawValue.All(d => d == '0') ? string.Empty : rawValue;
                    //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
                }
            }
            else
            {
                //this.fieldValueType = JHARecordDetail.DataTypes.Text;
            }

            this.fieldValue = stringValue;
        }
        else
        {
            // This is going to be a string
            this.fieldValue = stringValue;
            //this.fieldValueType = JHARecordDetail.DataTypes.Text;
        }
    }

    public override string ToString()
    {
        //TODO
        // Used for NVP grid, when its just output field
        //if (this.fieldValueType == JHARecordDetail.DataTypes.Currency)
        //{
        //    if (this.FieldValue != null)
        //    {
        //        string currencyString = ((decimal)this.FieldValue).ToString("C");

        //        return currencyString;
        //    }
        //    else
        //    {
        //        return null;
        //    }
        //}
        //else if (this.fieldValueType == JHARecordDetail.DataTypes.Date)
        //{
        //    if (this.FieldValue != null)
        //    {
        //        return ((DateTime)this.FieldValue).ToString("MM/dd/yyyy");
        //    }
        //    else
        //    {
        //        return null;
        //    }
        //}
        //else if (this.fieldValueType == JHARecordDetail.DataTypes.MaskedText && ScreenFieldDisplayFormat.IsRate(this.screenField.DispFormat))
        //{
        //    if (this.FieldValue != null)
        //    {
        //        return string.Format("{0}%", this.FieldValue.ToString());
        //    }
        //    else
        //    {
        //        return null;
        //    }
        //}
        //else if (this.fieldValueType == JHARecordDetail.DataTypes.Time)
        //{
        //    if (this.FieldValue != null)
        //    {
        //        return ((DateTime)this.FieldValue).ToString("hh:mm:ss tt");
        //    }
        //    else
        //    {
        //        return null;
        //    }
        //}
        //else if (this.FieldValue != null)
        //{
        //    return this.FieldValue.ToString();
        //}
        //else
        //{
        //    return null;
        //}

        return null;
    }

    private string FormatWholeNumberStringAsDecimal()
    {
        string stringValue = this.screenField5250.Data.Trim();

        // Some of the incoming decimal values include underscores.  Remove them here so we can successfully parse the values.
        stringValue = Regex.Replace(stringValue, @"[_]", string.Empty);

        // Factor the incoming raw data string using the specified number of decimal places
        if (!stringValue.Contains(".") && !string.IsNullOrEmpty(stringValue) && this.screenField.DecimalScale > 0)
        {
            decimal denominator = (decimal)Math.Pow(10, this.screenField.DecimalScale);
            decimal decimalValue;

            if (decimal.TryParse(stringValue, out decimalValue))
            {
                stringValue = (decimalValue / denominator).ToString();
                this.isConvertedDecimal = true;
            }
        }

        // Decimal values that need to be converted back to whole num can come in with an empty value.  Flag these to convert to whole num so we send values
        // back in the correct format
        if (string.IsNullOrEmpty(stringValue) && this.screenField.DecimalScale > 0)
        {
            this.isConvertedDecimal = true;
        }

        return stringValue;
    }

    private void SetEditorStyle()
    {
        //TODO
        //if (this.fieldValueType == JHARecordDetail.DataTypes.Date)
        //{
        //    this.EditorMask = "mm/dd/yyyy";
        //}
        //else if (this.fieldValueType == JHARecordDetail.DataTypes.Currency ||
        //         this.fieldValueType == JHARecordDetail.DataTypes.Number ||
        //         this.fieldValueType == JHARecordDetail.DataTypes.MaskedText ||
        //         this.fieldValueType == JHARecordDetail.DataTypes.Code)
        //{
        //    int mappedWholeNumberLength = this.screenField.Length - this.screenField.DecimalScale;
        //    this.EditorMask = string.Format("{0}{1}{2}{3}{4}", "{double:-", mappedWholeNumberLength, ".", this.screenField.DecimalScale, "}");


        //    if (this.screenField.IsDisplayFormatRate())
        //    {
        //        this.EditorMask = string.Format("{0}{1}{2}{3}{4}{5}", "{double:", mappedWholeNumberLength, ".", this.screenField.DecimalScale, "}", "%");
        //    }
        //    else if (this.screenField.IsDisplayFormatCurrency())
        //    {
        //        this.EditorMask = string.Format("{0}{1}{2}{3}{4}", "{currency:-", mappedWholeNumberLength, ".", this.screenField.DecimalScale, "}");
        //    }
        //    else if (this.screenField.IsDisplayFormatZip())
        //    {
        //        this.EditorMask = "#####-9999";
        //    }
        //    else if (this.screenField.IsDisplayFormatPhone())
        //    {
        //        this.EditorMask = FormatStrings.PhoneNumber2;
        //    }
        //    else if (this.screenField.IsDisplayFormatTime() || this.screenField.DataType == ScreenFieldDataType.Time)
        //    {
        //        this.EditorMask = this.screenField.DispFormat == ScreenFieldDisplayFormat.TimeMilitaryHHMM ? "99:99" : "99:99:99";
        //    }
        //    else if (this.screenField5250.FieldFormatWord != null && this.screenField5250.FieldFormatWord.FieldShiftEditSpecification == FieldShiftEditSpecification.SignedNumeric)
        //    {
        //        ////it needs to allow negatives, but not commas
        //        if (this.screenField.DecimalScale == 0)
        //        {
        //            this.EditorMask = string.Format("{0}-{1}-{2}{3}", "{number:", new string('9', mappedWholeNumberLength), new string('9', mappedWholeNumberLength), "}");
        //        }
        //    }
        //    else if (this.screenField5250.FieldFormatWord != null && this.screenField5250.FieldFormatWord.FieldShiftEditSpecification == FieldShiftEditSpecification.NumericOnly)
        //    {
        //        ////it needs to allow negatives, but not commas
        //        if (this.screenField.DecimalScale == 0)
        //        {
        //            this.EditorMask = string.Format("{0}-{1}-{2}{3}", "{number:", new string('9', mappedWholeNumberLength), new string('9', mappedWholeNumberLength), "}");
        //        }
        //    }
        //    else if (this.screenField.DecimalScale == 0 && mappedWholeNumberLength > 0)
        //    {
        //        this.EditorMask = new string('9', mappedWholeNumberLength);
        //    }
        //}
        //else
        //{
        //    if (this.FieldValue is string && this.screenField.Length > 0)
        //    {
        //        this.MaxLength = this.screenField.Length;
        //    }

        //    // For some reason we get input fields back that say they should always be upper case, but then the value returned is lower cased and a lower case value
        //    // must be entered. WIRES -> Option 35.
        //    if (this.screenField5250.FieldFormatWord != null && this.screenField5250.FieldFormatWord.Monocase && this.screenField5250.Data.ToUpper() == this.screenField5250.Data)
        //    {
        //        this.EditorMask = string.Format(">{0}", new string('C', this.screenField.Length));
        //    }
        //}
    }

    private void SetFieldPromptFunctionKey()
    {
        try
        {
            if (!string.IsNullOrWhiteSpace(this.screenField.PromptKey) && !this.isReadOnly)
            {
                this.IsPromptable = true;

                if (this.screenField.PromptKey.ToUpper() == "TRUE")
                {
                    this.promptKey = Key.F4;
                }
                else
                {
                    string key = this.screenField.PromptKey.Replace("{", string.Empty).Replace("}", string.Empty);

                    KeyConverter keyConverter = new KeyConverter();

                    this.promptKey = (Key)keyConverter.ConvertFromString(key.Trim());
                }
            }
        }
        catch
        {
            this.promptKey = Key.F4;
        }
    }

    private string GetDecimalDataStreamValue(object fieldValue, bool isDecimalType)
    {
        ////If the value had to be converted to decimal/double format, we need to convert it back to whole number format
        ////before we send it back.  We also have to format negative numbers if it's a SignedNumeric field.
        if (this.isConvertedDecimal)
        {
            double factor = Math.Pow(10, this.screenField.DecimalScale);
            bool isNegative = false;

            string stringValue = fieldValue.ToString();

            if (isDecimalType)
            {
                decimal wholeNumValue = (decimal)factor * (decimal)this.FieldValue;
                stringValue = wholeNumValue.ToString("#");
                isNegative = wholeNumValue < 0;
            }
            else if (fieldValue.GetType() == typeof(double))
            {
                double wholeNumValue = factor * (double)this.FieldValue;
                stringValue = wholeNumValue.ToString("#");
                isNegative = wholeNumValue < 0;
            }

            if (isNegative &&
                this.screenField5250.FieldFormatWord != null &&
                (this.screenField5250.FieldFormatWord.FieldShiftEditSpecification == FieldShiftEditSpecification.SignedNumeric ||
                 this.screenField5250.FieldFormatWord.FieldShiftEditSpecification == FieldShiftEditSpecification.NumericOnly))
            {
                stringValue = this.GetFormattedNegativeNumberString(stringValue, this.screenField5250.FieldFormatWord.FieldShiftEditSpecification);
            }

            return stringValue;
        }

        if (fieldValue != null &&
            this.screenField5250.FieldFormatWord != null &&
            (this.screenField5250.FieldFormatWord.FieldShiftEditSpecification == FieldShiftEditSpecification.SignedNumeric ||
             this.screenField5250.FieldFormatWord.FieldShiftEditSpecification == FieldShiftEditSpecification.NumericOnly))
        {
            if (fieldValue is decimal || fieldValue is decimal?)
            {
                if ((decimal)fieldValue < 0m)
                {
                    return this.GetFormattedNegativeNumberString(fieldValue.ToString(), this.screenField5250.FieldFormatWord.FieldShiftEditSpecification);
                }
            }
            else if (fieldValue is double || fieldValue is double?)
            {
                if ((double)fieldValue < 0d)
                {
                    return this.GetFormattedNegativeNumberString(fieldValue.ToString(), this.screenField5250.FieldFormatWord.FieldShiftEditSpecification);
                }
            }
        }

        return fieldValue.ToString();
    }

    private string GetFormattedNegativeNumberString(string negativeNumString, FieldShiftEditSpecification fieldEditSpec)
    {
        if (fieldEditSpec == FieldShiftEditSpecification.SignedNumeric)
        {
            ////GS negative numbers are formatted to return '-' at the end of the field by default. GS has it's own interpretation for negative values when setting values in the data stream.
            ////For example, '1-' is the equivalent of 'J'.  We have to pad the value here and replace the last number included in the value with the appropriate GS equivalent.
            negativeNumString = negativeNumString.Replace("-", string.Empty);
            negativeNumString = negativeNumString.PadLeft(this.screenField5250.FieldSize - 1);

            if (this.screenField.FieldRefId.Contains("CFBTCH"))
            {
                return negativeNumString;
            }

            //TODO
            //string signedNumericCode = SignedNumericCodes.NumberDictionary[negativeNumString.Last()];
            //negativeNumString = negativeNumString.Substring(0, negativeNumString.Length - 1);
            //negativeNumString = string.Format("{0}{1}", negativeNumString, signedNumericCode);
        }
        else if (fieldEditSpec == FieldShiftEditSpecification.NumericOnly)
        {
            ////Put the negative at the end
            negativeNumString = negativeNumString.Replace("-", string.Empty);
            negativeNumString = string.Format("{0}-", negativeNumString);
        }

        return negativeNumString;
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        ////When initial mapping efforts were made for XPE, these fields with prompts were mapped with valid field values
        ////included in parenthesis (on the field label).  This was causing confusion in the field so strip that portion of the field label.
        if (this.IsPromptable)
        {
            if (!string.IsNullOrEmpty(this.screenField.FieldLabel) && this.screenField.FieldLabel.EndsWith(")"))
            {
                Regex regex = new Regex("\\([^\\(]*\\)");
                return regex.Replace(this.screenField.FieldLabel, string.Empty);
            }
        }

        return this.screenField.FormatDynamicLabelText(outputFields);
    }
}
