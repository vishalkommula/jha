﻿// -----------------------------------------------------------------------
// <copyright file="DecimalScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System;
using System.Collections.Generic;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;

public class DecimalScreenFieldItem : XpeField, IModField5250, IEditorControlProvider
{
    private ScreenField5250 wholeNumberScreenField5250;
    private ScreenField wholeNumberScreenField;
    private ScreenField5250 decimalScreenField5250;
    private ScreenField decimalScreenField;
    private bool isReadOnly = true;
    private object fieldValue;
    private bool isDirty = false;
    //private JHARecordDetail.DataTypes fieldValueType = JHARecordDetail.DataTypes.Text;
    private bool isNegativeDecimal = false;
    private int decimalLength = 0;
    private int wholeNumberLength = 0;
    private string fieldLabel;
    //private JHARecordDetailFieldItem recordDetailFieldItem;

    public DecimalScreenFieldItem(ScreenField5250 wholeNumberScreenField5250, ScreenField wholeNumberScreenField, ScreenField5250 decimalScreenField5250, ScreenField decimalScreenField, IEnumerable<ScreenField5250> outputFields)
    {
        this.wholeNumberScreenField5250 = wholeNumberScreenField5250;
        this.wholeNumberScreenField = wholeNumberScreenField;
        this.decimalScreenField5250 = decimalScreenField5250;
        this.decimalScreenField = decimalScreenField;
        this.IsItemDisplayed = !this.wholeNumberScreenField.IsDisplayFormatIgnored();
        string stringLeftValue = !string.IsNullOrEmpty(wholeNumberScreenField5250.Data.Trim()) ? wholeNumberScreenField5250.Data.Trim() : "0";
        string stringRightValue = !string.IsNullOrEmpty(decimalScreenField5250.Data.Trim()) ? decimalScreenField5250.Data.Trim() : "0";
        this.fieldLabel = this.GetFieldLabel(outputFields);

        if (this.wholeNumberScreenField5250 != null &&
            this.wholeNumberScreenField5250.IsInputField() &&
            this.decimalScreenField5250 != null &&
            this.decimalScreenField5250.IsInputField())
        {
            this.isReadOnly = false;
        }

        if (this.wholeNumberScreenField5250.Att == FieldAttribute.GreenUnderscoreReverse
            || this.decimalScreenField5250.Att == FieldAttribute.GreenUnderscoreReverse)
        {
            this.IsHighlightedStandard = true;
        }

        this.CursorLocation = new CursorLocation(wholeNumberScreenField5250.Row, wholeNumberScreenField5250.Col);
        this.IsFocused = this.wholeNumberScreenField5250.IsFocused || this.decimalScreenField5250.IsFocused;

        this.SetFieldValueAndStyle(stringLeftValue, stringRightValue);
    }

    public bool IsPromptable { get; protected set; }

    public bool IsDirty { get; set; }

    public override bool IsReadOnly
    {
        get
        {
            return this.isReadOnly;
        }
    }

    public object FieldValue { get; set; }

    public string DataStreamValue
    {
        get
        {
            return this.FieldValue != null ? this.FieldValue.ToString() : string.Empty;
        }
    }

    public override bool IsCustomDataGridCellRequired
    {
        get
        {
            return !this.IsReadOnly;
        }
    }

    public string BindingPath
    {
        get
        {
            return "FieldValue";
        }
    }

    public string EditorMask { get; protected set; }

    public int MaxLength { get; protected set; }

    public override bool IsItemDisplayed { get; protected set; }

    public override string ToString()
    {
        //TODO
        //if (this.fieldValueType == JHARecordDetail.DataTypes.Currency)
        //{
        //    string currencyString = ((decimal)this.FieldValue).ToString("C");

        //    if (this.isNegativeDecimal)
        //    {
        //        currencyString.Replace("-", string.Empty);
        //        currencyString = string.Format("({0})", currencyString);
        //    }

        //    return currencyString;
        //}
        //else if (this.fieldValueType == JHARecordDetail.DataTypes.MaskedText && this.wholeNumberScreenField.IsDisplayFormatRate())
        //{
        //    return string.Format("{0}%", this.FieldValue.ToString());
        //}
        //else if (this.FieldValue != null)
        //{
        //    return this.FieldValue.ToString();
        //}
        //else
        //{
            return null;
        //}
    }

    private void SetFieldValueAndStyle(string stringLeftValue, string stringRightValue)
    {
        string stringValue = string.Format("{0}.{1}", stringLeftValue, stringRightValue);

        if (string.IsNullOrWhiteSpace(this.wholeNumberScreenField5250.Data) && string.IsNullOrWhiteSpace(this.decimalScreenField5250.Data))
        {
            stringValue = null;
        }

        decimal decimalValue;

        bool parsed = decimal.TryParse(stringValue, out decimalValue);

        this.wholeNumberLength = this.wholeNumberScreenField.Length;

        if (this.decimalScreenField != null)
        {
            this.decimalLength = this.decimalScreenField.Length;
        }
        else if (this.decimalScreenField5250 != null)
        {
            this.decimalLength = this.decimalScreenField5250.FieldSize;
        }

        //TODO
        //if (string.IsNullOrEmpty(stringValue) || parsed)
        //{
        //    if (parsed)
        //    {
        //        this.fieldValue = decimalValue as decimal?;
        //        this.isNegativeDecimal = decimalValue < 0 ? true : false;
        //    }
        //    else
        //    {
        //        this.fieldValue = new decimal?();
        //    }

        //    string wholeNumberString = this.wholeNumberLength < 1 ? string.Empty : this.wholeNumberLength.ToString();
        //    this.EditorMask = string.Format("{0}{1}{2}{3}{4}", "{double:-", this.wholeNumberLength, ".", this.decimalLength, ":c}");

        //    if (this.wholeNumberScreenField.IsDisplayFormatCurrency())
        //    {
        //        this.fieldValueType = JHARecordDetail.DataTypes.Currency;
        //        this.EditorMask = this.EditorMask.Replace("double", "currency");
        //    }
        //    else if (this.wholeNumberScreenField.IsDisplayFormatRate())
        //    {
        //        this.EditorMask = string.Format("{0}{1}{2}{3}{4}{5}", "{double:", this.wholeNumberLength, ".", this.decimalLength, "}", "%");
        //        this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
        //    }
        //    else
        //    {
        //        this.fieldValueType = JHARecordDetail.DataTypes.Number;
        //    }
        //}
        //else
        //{
        //    this.MaxLength = this.wholeNumberScreenField.Length + this.decimalLength;
        //    this.fieldValue = stringValue;
        //    this.fieldValueType = JHARecordDetail.DataTypes.Text;
        //}
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.wholeNumberScreenField.FormatDynamicLabelText(outputFields);
    }
}