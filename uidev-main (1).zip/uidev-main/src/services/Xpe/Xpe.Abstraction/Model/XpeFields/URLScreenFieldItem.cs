// -----------------------------------------------------------------------
// <copyright file="URLScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System.Collections.Generic;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;

public class URLScreenFieldItem : XpeField, IFieldItem
{
    private string fieldLabel;
    private string fieldValue;
    //private JHARecordDetail.DataTypes fieldValueType = JHARecordDetail.DataTypes.Text;
    private bool isReadOnly = true;
    private ScreenField screenField;
    private ScreenField5250 screenField5250;
    //private JHARecordDetailFieldItem recordDetailFieldItem;

    public URLScreenFieldItem(ScreenField5250 screenField5250, ScreenField screenField, IEnumerable<ScreenField5250> outputFields)
    {
        this.screenField = screenField;
        this.screenField5250 = screenField5250;
        this.isReadOnly = true;
        this.fieldValue = screenField5250.Data != null ? screenField5250.Data.Trim() : null;
        this.IsItemDisplayed = !this.screenField.IsDisplayFormatIgnored();
        this.IsHighlightedStandard = this.screenField5250.Att == FieldAttribute.GreenReverse;
        this.fieldLabel = this.GetFieldLabel(outputFields);
    }

    public string FieldValue { get; set; }

    public override bool IsCustomDataGridCellRequired
    {
        get
        {
            return true;
        }
    }

    public override bool IsItemDisplayed { get; protected set; }

    public override bool IsReadOnly
    {
        get
        {
            return this.isReadOnly;
        }
    }

    public override string ToString()
    {
        return this.FieldValue;
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.screenField.FormatDynamicLabelText(outputFields);
    }
}