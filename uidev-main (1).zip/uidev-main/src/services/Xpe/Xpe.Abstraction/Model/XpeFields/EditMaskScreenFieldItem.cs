// -----------------------------------------------------------------------
// <copyright file="EditMaskScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using JackHenry.JHAContractTypes;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;

public class EditMaskScreenFieldItem : XpeField, IModField5250, IEditorControlProvider
{
    //// When a field is defined in DDS with an Edit Mask, the field is returned differently in
    //// the data stream. For example if a date field is defined at Row 1, Column 1, Length of 8,
    //// and an Edit Mask of ('  &  &    '), then the field is returned as multiple fields that
    //// have to be combined at runtime.
    //// First Field:  Row 1, Column 1, Length 2, Value "01"
    //// Second Field: Row 1, Column 3, Length 1, Value "/"
    //// Third Field:  Row 1, Column 4, Length 2, Value "01"
    //// Fourth Field: Row 1, Column 6, Length 1, Value "/"
    //// Fifth Field:  Row 1, Column 7, Length 4, Value "2016"
    private ScreenField screenField;

    private ScreenField5250 screenField5250;
    private CultureInfo cultureInfo;
    private bool isReadOnly = false;
    private object fieldValue;
    private bool isDirty = false;
    //private JHARecordDetail.DataTypes fieldValueType = JHARecordDetail.DataTypes.Text;
    private string fieldLabel;
    //private JHARecordDetailFieldItem recordDetailFieldItem;

    public EditMaskScreenFieldItem(ScreenField screenField, ScreenField5250 screenField5250, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields, CultureInfo cultureInfo)
    {
        this.screenField = screenField;
        this.screenField5250 = screenField5250;
        this.cultureInfo = cultureInfo;
        this.CursorLocation = new CursorLocation(screenField5250.Row, screenField5250.Col);
        this.fieldLabel = this.GetFieldLabel(outputFields);

        this.IsItemDisplayed = !this.screenField.IsDisplayFormatIgnored();
        this.isReadOnly = !screenField5250.IsInputField();
        this.IsFocused = screenField5250.IsFocused;

        if (this.screenField5250.Att == FieldAttribute.GreenUnderscoreReverse)
        {
            this.IsHighlightedStandard = true;
        }

        string stringValue = this.ParseMaskedFields(inputFields, outputFields).Trim();

        bool parsed = false;

        if (this.screenField.IsDisplayFormatAMonthDayYearDate())
        {
            //TODO
            //this.fieldValueType = JHARecordDetail.DataTypes.Date;
            this.EditorMask = "mm/dd/yyyy";

            DateTime dateValue;

            if (stringValue.Length != this.MaxLength)
            {
                stringValue = stringValue.PadLeft(this.MaxLength, '0');
            }

            if (DateTime.TryParseExact(stringValue, this.screenField.GetDateFormatFromDisplayFormat(), this.CultureInfo, DateTimeStyles.None, out dateValue))
            {
                this.fieldValue = (DateTime?)dateValue;
                //this.fieldValueType = JHARecordDetail.DataTypes.Date;
                parsed = true;
            }
        }
        else if (this.screenField.IsDisplayFormatPhone())
        {
            //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
            this.EditorMask = FormatStrings.PhoneNumber2;

            decimal decimalValue = 0;
            parsed = decimal.TryParse(stringValue, out decimalValue);

            if (string.IsNullOrEmpty(stringValue) || stringValue.All(d => d == '0'))
            {
                stringValue = "0000000000";
            }

            this.fieldValue = stringValue;
        }

        if (!parsed)
        {
            //this.fieldValueType = JHARecordDetail.DataTypes.Text;
            this.fieldValue = stringValue;
        }
    }

    public string BindingPath
    {
        get
        {
            return "FieldValue";
        }
    }

    public string DataStreamValue
    {
        get
        {
            string value = string.Empty;

            if (this.FieldValue != null)
            {
                if (this.FieldValue.GetType() == typeof(DateTime))
                {
                    var dateValue = Convert.ToDateTime(this.FieldValue);
                    value = dateValue.ToString(this.screenField.GetDateFormatFromDisplayFormat());
                }
                else
                {
                    value = this.FieldValue.ToString();
                }
            }

            return value;
        }
    }

    public string EditorMask { get; protected set; }

    public object FieldValue { get; set; }

    public override bool IsCustomDataGridCellRequired
    {
        get
        {
            return !this.IsReadOnly;
        }
    }

    public override bool IsItemDisplayed { get; protected set; }

    public bool IsPromptable { get; protected set; }

    public override bool IsReadOnly
    {
        get
        {
            return this.isReadOnly;
        }
    }

    public int MaxLength
    {
        get
        {
            return this.screenField.Length;
        }
    }

    protected CultureInfo CultureInfo
    {
        get
        {
            // Only use the date limit when the year is a two-digit year.
            if (this.screenField.IsDisplayFormatATwoDigitYear())
            {
                return this.cultureInfo;
            }
            else
            {
                return CultureInfo.InvariantCulture;
            }
        }
    }

    private string ParseMaskedFields(IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields)
    {
        string stringValue = string.Empty;

        // If the screenField5250 already has AssociatedMaskedFields, then we have already
        // processed this field, sent a command to the iSeries, and are restoring a screen that
        // we have already processed. In this case, the data has been saved off in the first
        // AssociatedMaskedField. Therefore, set the stringValue to the data in the first AssociatedMaskedField.
        if (this.screenField5250.AssociatedMaskedFields != null && this.screenField5250.AssociatedMaskedFields.Any())
        {
            stringValue = this.screenField5250.AssociatedMaskedFields.FirstOrDefault().Data;
        }
        else
        {
            // Else create and populate the AssociatedMaskedFields list.
            this.screenField5250.AssociatedMaskedFields = new List<ScreenField5250>();

            // Edit Mask example: (' & & ') The edit mask will always start with (' and end with
            // )' The ampersands designate where the separators will reside in the string.
            // Therefore, we can programatically determine where the mask fields reside.
            string editMask = this.screenField.EditMask.Trim(new char[3] { '(', ')', '\'' });

            // Only add the data of the first screenField5250 if the EditMask doesn't start with
            // a '&'. If it does start with an ampersand, then it means that the first field is
            // actually a separator of some kind and we don't want separators added to field values.
            if (!editMask.StartsWith("&"))
            {
                stringValue = this.screenField5250.Data;
                this.screenField5250.AssociatedMaskedFields.Add(this.screenField5250);
            }

            int ampersandIndex = editMask.IndexOf('&');
            int currentIndex = 0;

            while (ampersandIndex != -1)
            {
                currentIndex = ampersandIndex + 1;

                string nextMaskedFieldRRCCC = string.Format("{0:00}{1:000}", this.screenField.Row, this.screenField.Col + currentIndex);
                ScreenField5250 nextMaskedField = ScreenField5250Extensions.GetFieldByRRCCC(nextMaskedFieldRRCCC, inputFields.Concat(outputFields));

                // Get the location of the next ampersand.
                ampersandIndex = editMask.IndexOf('&', currentIndex);

                if (nextMaskedField != null)
                {
                    stringValue = string.Format("{0}{1}", stringValue, nextMaskedField.Data);
                    this.screenField5250.AssociatedMaskedFields.Add(nextMaskedField);
                }
                ////else
                ////{
                ////    // If we don't find a field, then add an empty string for a placeholder. This shouldn't
                ////    // ever happen, but in the event that it does I think this is the correct thing to do.
                ////    if (ampersandIndex != -1)
                ////    {
                ////        stringValue += new string(' ', ampersandIndex - currentIndex);
                ////    }
                ////    else
                ////    {
                ////        stringValue += new string(' ', editMask.Length - currentIndex);
                ////    }
                ////}
            }
        }

        // Set field properties based on the masked fields.
        foreach (ScreenField5250 maskedField in this.screenField5250.AssociatedMaskedFields)
        {
            if (maskedField.IsInputField())
            {
                this.isReadOnly = false;
            }

            if (maskedField.IsFocused)
            {
                this.IsFocused = true;
            }

            if (maskedField.Att == FieldAttribute.GreenUnderscoreReverse)
            {
                this.IsHighlightedStandard = true;
            }
        }

        return stringValue;
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.screenField.FormatDynamicLabelText(outputFields);
    }
}
