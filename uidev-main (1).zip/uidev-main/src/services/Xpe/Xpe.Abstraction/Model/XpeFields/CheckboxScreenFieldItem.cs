﻿// -----------------------------------------------------------------------
// <copyright file="CheckboxScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2017 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System.Collections.Generic;
using System.Linq;

public class CheckboxScreenFieldItem : ListOptionsValuesScreenFieldItem
{
    private ScreenField screenField;
    private ScreenField5250 screenField5250;
    private string originalValue = string.Empty;
    private bool validValue = false;
    private FieldValue checkedValue;
    private FieldValue uncheckedValue;

    public CheckboxScreenFieldItem(ScreenField5250 screenField5250, ScreenField screenField, IEnumerable<ScreenField5250> outputFields)
        : base(screenField5250, screenField, outputFields)
    {
        this.screenField = screenField;
        this.screenField5250 = screenField5250;

        this.checkedValue = this.screenField.FieldValueArray.FirstOrDefault(f => f.Description.ToLower() == "checked");
        this.uncheckedValue = this.screenField.FieldValueArray.FirstOrDefault(f => f.Description.ToLower() == "unchecked");

        //// This need to be string fields, so option values are same type
        //TODO
        //this.FieldValueType = JHARecordDetail.DataTypes.Text;

        string stringValue = screenField5250 != null && !string.IsNullOrEmpty(screenField5250.Data) ? screenField5250.Data.Trim() : string.Empty;

        List<FieldValue> blankValues = new List<FieldValue>();

        if (this.screenField.FieldValueArray != null)
        {
            // Check to see if descriptions are just copies of values
            foreach (FieldValue singleFieldValue in this.screenField.FieldValueArray)
            {
                if (singleFieldValue.Value == null)
                {
                    singleFieldValue.Value = "{Blank}";
                }

                if (singleFieldValue.Description == null)
                {
                    singleFieldValue.Description = string.Empty;
                }

                if (singleFieldValue.Value.Trim() == string.Empty || singleFieldValue.Value.Trim().ToLower() == "{blank}")
                {
                    singleFieldValue.Value = string.Empty;
                    blankValues.Add(singleFieldValue);
                }
            }

            // Force the blanks to the top.
            if (blankValues.Any())
            {
                foreach (FieldValue singleBlankValue in blankValues)
                {
                    this.screenField.FieldValueArray.Remove(singleBlankValue);
                    this.screenField.FieldValueArray.Insert(0, singleBlankValue);
                }
            }
        }

        this.FieldValue = stringValue;
        this.originalValue = stringValue;

        if (string.IsNullOrEmpty(stringValue) || (this.screenField.FieldValueArray != null && this.screenField.FieldValueArray.Any(v => v.Value.ToLower() == stringValue.ToLower())))
        {
            this.validValue = true;
        }
    }
}