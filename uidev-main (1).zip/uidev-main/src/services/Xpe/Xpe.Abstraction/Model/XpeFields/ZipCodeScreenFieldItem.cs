﻿// -----------------------------------------------------------------------
// <copyright file="ZipCodeScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;

public class ZipCodeScreenFieldItem : XpeField, IModField5250, IEditorControlProvider
{
    private ScreenField5250 zipScreenField5250;
    private ScreenField zipScreenField;
    private ScreenField5250 plusFourScreenField5250;
    private ScreenField plusFourScreenField;
    private bool isReadOnly = false;
    private object fieldValue;
    private bool isDirty = false;
    //private JHARecordDetail.DataTypes fieldValueType = JHARecordDetail.DataTypes.Text;
    private string fieldLabel;
    //private JHARecordDetailFieldItem recordDetailFieldItem;

    public ZipCodeScreenFieldItem(ScreenField5250 zipScreenField5250, ScreenField zipScreenField, ScreenField5250 plusFourScreenField5250, ScreenField plusFourScreenField, IEnumerable<ScreenField5250> outputFields)
    {
        this.zipScreenField5250 = zipScreenField5250;
        this.zipScreenField = zipScreenField;
        this.fieldLabel = this.GetFieldLabel(outputFields);
        this.plusFourScreenField5250 = plusFourScreenField5250;
        this.plusFourScreenField = plusFourScreenField;
        this.IsItemDisplayed = !this.zipScreenField.IsDisplayFormatIgnored();
        string stringLeftValue = !string.IsNullOrEmpty(zipScreenField5250.Data.Trim()) ? zipScreenField5250.Data.Trim() : "00000";
        string stringRightValue = !string.IsNullOrEmpty(plusFourScreenField5250.Data.Trim()) ? plusFourScreenField5250.Data.Trim() : "0000";

        if (!zipScreenField5250.IsInputField())
        {
            this.isReadOnly = true;
        }

        string stringValue = string.Format("{0}{1}", stringLeftValue, stringRightValue);

        if (stringValue.All(a => a == '0') || string.IsNullOrEmpty(stringValue))
        {
            stringValue = "000000000";
        }

        if (this.zipScreenField5250.Att == FieldAttribute.GreenUnderscoreReverse
            || this.plusFourScreenField5250.Att == FieldAttribute.GreenUnderscoreReverse)
        {
            this.IsHighlightedStandard = true;
        }

        this.CursorLocation = new CursorLocation(this.zipScreenField5250.Row, this.zipScreenField5250.Col);
        this.IsFocused = this.zipScreenField5250.IsFocused || this.plusFourScreenField5250.IsFocused;

        this.EditorMask = "#####-9999";
        //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;

        int intValue;
        bool parsed = int.TryParse(stringValue, out intValue);

        if (!parsed)
        {
            this.MaxLength = this.zipScreenField.Length + this.plusFourScreenField.Length;
            //this.fieldValueType = JHARecordDetail.DataTypes.Text;
        }

        this.fieldValue = stringValue;
    }

    public override bool IsReadOnly
    {
        get
        {
            return this.isReadOnly;
        }
    }

    public object FieldValue
    {
        get
        {
            return this.fieldValue;
        }

        set
        {
            if (this.fieldValue != value)
            {
                string valueString = Regex.Replace(value.ToString(), @"[^\d]", string.Empty);

                if (valueString.All(d => d == '0'))
                {
                    this.fieldValue = "00000-0000";
                }
                else
                {
                    this.fieldValue = value;
                }
            }
        }
    }

    public override bool IsCustomDataGridCellRequired
    {
        get
        {
            return true;
        }
    }

    public string BindingPath
    {
        get
        {
            return "FieldValue";
        }
    }

    public string DataStreamValue
    {
        get
        {
            ////Every ZIP field that we've tested that displays as 2 separate fields on GS does not support a hyphen so we strip it here (if one exists).
            return this.FieldValue != null ? this.FieldValue.ToString().Replace("-", string.Empty) : string.Empty;
        }
    }

    public string EditorMask
    {
        get;
        protected set;
    }

    public int MaxLength
    {
        get;
        protected set;
    }

    public override bool IsItemDisplayed
    {
        get;
        protected set;
    }

    public bool IsPromptable
    {
        get;
        protected set;
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.zipScreenField.FormatDynamicLabelText(outputFields);
    }
}