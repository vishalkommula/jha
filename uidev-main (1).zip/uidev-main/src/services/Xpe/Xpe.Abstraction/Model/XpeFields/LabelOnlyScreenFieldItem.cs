﻿// -----------------------------------------------------------------------
// <copyright file="LabelOnlyScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System.Collections.Generic;

using Xpe.Abstraction.Extensions;

public class LabelOnlyScreenFieldItem : IFieldItem
{
    private ScreenField screenField;
    private IEnumerable<ScreenField5250> allFields;
    private string fieldLabel;
    //private JHARecordDetailNoteItem recordDetailNoteItem;

    public LabelOnlyScreenFieldItem(ScreenField screenField, IEnumerable<ScreenField5250> allFields)
    {
        this.screenField = screenField;
        this.allFields = allFields;
        this.fieldLabel = this.GetFieldLabel(allFields);

        if (this.screenField != null)
        {
            this.IsItemDisplayed = !this.screenField.IsDisplayFormatIgnored();
        }
    }

    public bool IsItemDisplayed
    {
        get;
        protected set;
    }

    public bool IsFocused
    {
       get
        {
            return false;
        }
    }

    public string FieldID
    {
        get;
        private set;
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.screenField.FormatDynamicLabelText(outputFields);
    }
}