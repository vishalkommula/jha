﻿// -----------------------------------------------------------------------
// <copyright file="DateScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;

public class DateScreenFieldItem : XpeField, IModField5250, IEditorControlProvider
{
    private ScreenField firstScreenField;
    private ScreenField5250 firstScreenField5250;
    private ScreenField5250 secondScreenField5250;
    private ScreenField5250 thirdScreenField5250;
    private bool isThreeFieldDateField;
    private bool isReadOnly = false;
    private object fieldValue;
    private bool isDirty = false;
    private string fieldLabel;

    public DateScreenFieldItem(ScreenField firstScreenField, ScreenField5250 firstScreenField5250, ScreenField5250 secondScreenField5250, ScreenField5250 thirdScreenField5250, IEnumerable<ScreenField5250> outputFields)
    {
        this.firstScreenField = firstScreenField;
        this.firstScreenField5250 = firstScreenField5250;
        this.secondScreenField5250 = secondScreenField5250;
        this.thirdScreenField5250 = thirdScreenField5250;
        this.FieldID = string.Format("{0}-{1}", this.firstScreenField.Sequence.ToString(), this.firstScreenField.FieldLabel);
        this.fieldLabel = this.GetFieldLabel(outputFields);

        // Third value could be null. Date fields can be composed of 2 or 3 fields.
        this.isThreeFieldDateField = thirdScreenField5250 != null;

        this.IsItemDisplayed = !this.firstScreenField.IsDisplayFormatIgnored();

        string stringLeftValue = !string.IsNullOrEmpty(firstScreenField5250.Data.Trim()) ? firstScreenField5250.Data.Trim() : null;
        string stringMiddleValue = !string.IsNullOrEmpty(secondScreenField5250.Data.Trim()) ? secondScreenField5250.Data.Trim() : null;
        string stringRightValue = this.isThreeFieldDateField && !string.IsNullOrEmpty(thirdScreenField5250.Data.Trim()) ? thirdScreenField5250.Data.Trim() : null;

        string stringValue = string.Format("{0}{1}{2}", stringLeftValue, stringMiddleValue, stringRightValue);

        int length = 0;

        if (this.isThreeFieldDateField)
        {
            length = this.firstScreenField5250.FieldSize + this.secondScreenField5250.FieldSize + this.thirdScreenField5250.FieldSize;

            if (this.firstScreenField5250.Att == FieldAttribute.GreenUnderscoreReverse
            || this.secondScreenField5250.Att == FieldAttribute.GreenUnderscoreReverse
            || this.thirdScreenField5250.Att == FieldAttribute.GreenUnderscoreReverse)
            {
                this.IsHighlightedStandard = true;
            }

            this.IsFocused = this.firstScreenField5250.IsFocused || this.secondScreenField5250.IsFocused || this.thirdScreenField5250.IsFocused;
        }
        else
        {
            length = this.firstScreenField5250.FieldSize + this.secondScreenField5250.FieldSize;

            if (this.firstScreenField5250.Att == FieldAttribute.GreenUnderscoreReverse
            || this.secondScreenField5250.Att == FieldAttribute.GreenUnderscoreReverse)
            {
                this.IsHighlightedStandard = true;
            }

            this.IsFocused = this.firstScreenField5250.IsFocused || this.secondScreenField5250.IsFocused;
        }

        if (stringValue.Length != length)
        {
            stringValue = stringValue.PadLeft(length, '0');
        }

        this.CursorLocation = new CursorLocation(firstScreenField5250.Row, firstScreenField5250.Col);

        //TODO
        //this.fieldValueType = JHARecordDetail.DataTypes.Date;
        this.EditorMask = "mm/dd/yyyy";

        DateTime dateValue;

        bool parsed = DateTime.TryParseExact(stringValue, "MMddyyyy", System.Globalization.CultureInfo.InvariantCulture, DateTimeStyles.None, out dateValue);

        if (string.IsNullOrEmpty(stringValue) || stringValue.Replace("/", string.Empty).All(d => d == '0'))
        {
            DateTime? nullDateValue = null;
            this.fieldValue = nullDateValue;
        }
        else if (parsed)
        {
            this.fieldValue = (DateTime?)dateValue;
        }
        else
        {
            this.MaxLength = length;
            this.fieldValue = stringValue;
            //TODO
            //this.fieldValueType = JHARecordDetail.DataTypes.Text;
        }
    }

    public bool IsPromptable { get; set; }

    public override bool IsReadOnly
    {
        get
        {
            return this.isReadOnly;
        }
    }

    public object FieldValue { get; set; }

    public override bool IsCustomDataGridCellRequired
    {
        get
        {
            return !this.IsReadOnly;
        }
    }

    public string BindingPath
    {
        get
        {
            return "FieldValue";
        }
    }

    public string DataStreamValue
    {
        get
        {
            string value = string.Empty;

            if (this.FieldValue != null)
            {
                if (this.FieldValue.GetType() == typeof(DateTime))
                {
                    var dateValue = Convert.ToDateTime(this.FieldValue);
                    value = dateValue.ToString("MMddyyyy");
                }
                else
                {
                    value = this.FieldValue.ToString();
                }
            }

            return value;
        }
    }

    public string EditorMask { get; set; }

    public int MaxLength { get; set; }

    public override bool IsItemDisplayed { get; protected set; }

    private string GetFieldValue(string value, int fieldSize, int startIndex)
    {
        int valueLength = value.Length - startIndex;

        if (valueLength <= 0)
        {
            return string.Empty;
        }

        if (fieldSize <= valueLength)
        {
            return value.Substring(startIndex, fieldSize);
        }
        else
        {
            return value.Substring(startIndex);
        }
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.firstScreenField.FormatDynamicLabelText(outputFields);
    }

    private int GetFieldSize(ScreenField5250 screenField5250)
    {
        ////The signed numeric field sizes end up being a digit too long....it messes up our substring when we go to return the values in the data stream.
        ////Return the appropriate sizes here...
        if (screenField5250.FieldFormatWord.FieldShiftEditSpecification == FieldShiftEditSpecification.SignedNumeric)
        {
            if (screenField5250.FieldSize == 3)
            {
                return 2;
            }

            if (screenField5250.FieldSize == 5)
            {
                return 4;
            }
        }

        return screenField5250.FieldSize;
    }
}