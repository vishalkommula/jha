﻿// -----------------------------------------------------------------------
// <copyright file="NavigationScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2016 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace Xpe.Abstraction.Model.XpeFields;

using System.Collections.Generic;

using Xpe.Abstraction.Extensions;

public class NavigationScreenFieldItem : XpeField, IModField5250
{
    private string fieldValue;
    private bool isReadOnly = true;
    //private JHARecordDetail.DataTypes fieldValueType = JHARecordDetail.DataTypes.Text;
    private string fieldLabel;
    //private JHARecordDetailFieldItem recordDetailFieldItem;

    public NavigationScreenFieldItem(ScreenField displayScreenField, ScreenField5250 displayField, ScreenField5250 inputField, string selectedValue, string fieldValue, IEnumerable<ScreenField5250> outputFields)
    {
        this.DisplayScreenField = displayScreenField;
        this.fieldValue = fieldValue;
        this.IsItemDisplayed = !displayScreenField.IsDisplayFormatIgnored();
        this.SelectedValue = selectedValue;
        this.InputField = inputField;
        this.fieldLabel = this.GetFieldLabel(outputFields);
    }

    public string SelectedValue { get; protected set; }

    public override bool IsCustomDataGridCellRequired
    {
        get
        {
            return true;
        }
    }

    public bool Selected { get; set; }

    public string FieldValue { get; set; }

    public override bool IsReadOnly
    {
        get
        {
            return this.isReadOnly;
        }
    }

    public override bool IsItemDisplayed { get; protected set; }

    protected ScreenField5250 InputField { get; set; }

    protected ScreenField DisplayScreenField { get; set; }

    public override string ToString()
    {
        return this.FieldValue;
    }

    public void AddToChangedList(List<ScreenField5250> changedList, bool includeModifiedDataTagField)
    {
        if (this.Selected)
        {
            this.InputField.Data = this.SelectedValue;
            changedList.Add(this.InputField);
        }
        else if (includeModifiedDataTagField)
        {
            if (this.InputField.FieldFormatWord != null && this.InputField.FieldFormatWord.ModifiedDataTag)
            {
                changedList.Add(this.InputField);
            }
        }
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.DisplayScreenField.FormatDynamicLabelText(outputFields);
    }
}