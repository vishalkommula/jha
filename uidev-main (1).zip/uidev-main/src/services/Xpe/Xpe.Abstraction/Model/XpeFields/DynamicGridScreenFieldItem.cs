// -----------------------------------------------------------------------
// <copyright file="DynamicGridScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System.Collections.Generic;
using System.Globalization;
using JackHenry.JHAContractTypes;

using Xpe.Abstraction.Extensions;

public class DynamicGridScreenFieldItem : XpeScreenFieldItem
{
    private bool disableInsertMode;
    private string fieldLabel;
    private ScreenField screenField;
    private ScreenField5250 screenField5250;

    public DynamicGridScreenFieldItem(ScreenField5250 screenField5250, ScreenField screenField, CultureInfo cultureInfo, IEnumerable<ScreenField5250> outputFields, bool disableInsertMode)
        : base(screenField5250, screenField, cultureInfo, outputFields)
    {
        this.screenField = screenField;
        this.screenField5250 = screenField5250;
        this.IsFocused = this.screenField5250.IsFocused;
        this.fieldLabel = this.GetFieldLabel(outputFields);
        this.disableInsertMode = disableInsertMode;

        string stringValue = this.screenField5250 != null && !string.IsNullOrEmpty(this.screenField5250.Data) ? this.screenField5250.Data.TrimEnd() : string.Empty;
        this.SetFieldValue(stringValue);
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.screenField.FormatDynamicLabelText(outputFields);
    }
}
