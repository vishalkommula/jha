// -----------------------------------------------------------------------
// <copyright file="ContinuedFieldScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2017 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System;
using System.Collections.Generic;
using System.Linq;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;

public class ContinuedFieldScreenFieldItem : XpeField, IModField5250, IEditorControlProvider
{
    private ScreenField screenField;
    private ScreenField5250 screenField5250;
    private List<ScreenField5250> continuedInputFields;
    private object fieldValue;
    private bool isDirty = false;
    private string fieldLabel;

    public ContinuedFieldScreenFieldItem(ScreenField5250 screenField5250, ScreenField screenField, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields)
    {
        this.screenField = screenField;
        this.screenField5250 = screenField5250;
        this.continuedInputFields = inputFields.ToList();

        this.IsItemDisplayed = true;
        this.IsHighlightedStandard = this.continuedInputFields.Any(f => f.Att == FieldAttribute.GreenUnderscoreReverse);
        this.CursorLocation = new CursorLocation(this.screenField5250.Row, this.screenField5250.Col);
        this.IsFocused = this.continuedInputFields.Any(f => f.IsFocused);

        this.fieldLabel = this.GetFieldLabel(outputFields);
        this.SetFieldValue();
    }

    public override bool IsCustomDataGridCellRequired
    {
        get
        {
            return true;
        }
    }

    public override bool IsItemDisplayed
    {
        get;
        protected set;
    }

    public override bool IsReadOnly
    {
        get
        {
            return false;
        }
    }

    public string BindingPath
    {
        get
        {
            return "FieldValue";
        }
    }

    public string EditorMask { get; protected set; }

    public int MaxLength
    {
        get
        {
            int length = 0;
            this.continuedInputFields.ForEach(f => length += f.FieldSize);

            return length;
        }
    }

    public bool IsPromptable { get; protected set; }

    public object FieldValue { get; set; }

    private void SetFieldValue()
    {
        if (this.continuedInputFields.Any())
        {
            this.FieldValue = string.Join(" ", this.continuedInputFields.Select(c => c.Data));
        }
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.screenField.FormatDynamicLabelText(outputFields);
    }
}
