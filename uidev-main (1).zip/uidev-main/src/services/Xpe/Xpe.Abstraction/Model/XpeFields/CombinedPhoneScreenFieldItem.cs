// -----------------------------------------------------------------------
// <copyright file="CombinedPhoneScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text.RegularExpressions;
    using JackHenry.JHAContractTypes;

    using Xpe.Abstraction.Enums;
    using Xpe.Abstraction.Extensions;

    public class CombinedPhoneScreenFieldItem : XpeField, IModField5250, IEditorControlProvider
    {
        private ScreenField5250 areaCodeScreenField5250;
        private ScreenField areaCodeScreenField;
        private ScreenField5250 prefixScreenField5250;
        private ScreenField prefixScreenField;
        private ScreenField5250 lineNumberScreenField5250;
        private ScreenField lineNumberScreenField;
        private bool isReadOnly = false;
        private object fieldValue;
        private string fieldLabel;

        public CombinedPhoneScreenFieldItem(
                ScreenField5250 areaCodeScreenField5250,
                ScreenField areaCodeScreenField,
                ScreenField5250 prefixScreenField5250,
                ScreenField prefixScreenField,
                ScreenField5250 lineNumberScreenField5250,
                ScreenField lineNumberScreenField,
                IEnumerable<ScreenField5250> outputFields)
        {
            this.areaCodeScreenField5250 = areaCodeScreenField5250;
            this.areaCodeScreenField = areaCodeScreenField;
            this.prefixScreenField5250 = prefixScreenField5250;
            this.prefixScreenField = prefixScreenField;
            this.lineNumberScreenField5250 = lineNumberScreenField5250;
            this.lineNumberScreenField = lineNumberScreenField;
            this.IsItemDisplayed = !this.areaCodeScreenField.IsDisplayFormatIgnored();
            this.IsFocused = areaCodeScreenField5250.IsFocused || prefixScreenField5250.IsFocused || lineNumberScreenField5250.IsFocused;
            this.fieldLabel = this.GetFieldLabel(outputFields);

            if (this.areaCodeScreenField5250.Att == FieldAttribute.GreenUnderscoreReverse
                || this.prefixScreenField5250.Att == FieldAttribute.GreenUnderscoreReverse
                || this.lineNumberScreenField5250.Att == FieldAttribute.GreenUnderscoreReverse)
            {
                this.IsHighlightedStandard = true;
            }

            string stringLeftValue = !string.IsNullOrEmpty(areaCodeScreenField5250.Data.Trim()) ? areaCodeScreenField5250.Data.Trim() : null;
            string stringCenterValue = !string.IsNullOrEmpty(prefixScreenField5250.Data.Trim()) ? prefixScreenField5250.Data.Trim() : null;
            string stringRightValue = !string.IsNullOrEmpty(lineNumberScreenField5250.Data.Trim()) ? lineNumberScreenField5250.Data.Trim() : null;

            string stringValue = string.Format("{0}{1}{2}", stringLeftValue, stringCenterValue, stringRightValue);

            if (string.IsNullOrEmpty(stringValue) || stringValue.All(d => d == '0'))
            {
                stringValue = "0000000000";
            }

            this.fieldValue = stringValue;
            //TODO
            //this.fieldValueType = JHARecordDetail.DataTypes.MaskedText;
            this.EditorMask = FormatStrings.PhoneNumber2;
            //TODO

            decimal decimalValue = 0;
            bool parsed = decimal.TryParse(stringValue, out decimalValue);

            if (!parsed)
            {
                this.MaxLength = this.areaCodeScreenField.Length + this.prefixScreenField.Length + this.lineNumberScreenField.Length;
                //TODO
                //this.fieldValueType = JHARecordDetail.DataTypes.Text;
            }
        }

        public bool IsPromptable { get; protected set; }

        public override bool IsItemDisplayed { get; protected set; }

        public override bool IsReadOnly { get; } = false;

        public object FieldValue
        {
            get
            {
                return this.fieldValue;
            }

            set
            {
                if (this.fieldValue != value)
                {
                    string valueString = Regex.Replace(value.ToString(), @"[^\d]", string.Empty);

                    if (valueString.All(d => d == '0'))
                    {
                        this.fieldValue = "(000) 000-0000";
                    }
                    else
                    {
                        this.fieldValue = value;
                    }
                }
            }
        }

        public override bool IsCustomDataGridCellRequired { get; } = true; 

        public string BindingPath
        {
            get
            {
                return "FieldValue";
            }
        }

        public string DataStreamValue
        {
            get
            {
                return this.FieldValue != null ? this.FieldValue.ToString() : string.Empty;
            }
        }

        public string EditorMask
        {
            get;
            protected set;
        }

        public int MaxLength
        {
            get;
            protected set;
        }

        private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
        {
            return this.areaCodeScreenField.FormatDynamicLabelText(outputFields);
        }
    }
}
