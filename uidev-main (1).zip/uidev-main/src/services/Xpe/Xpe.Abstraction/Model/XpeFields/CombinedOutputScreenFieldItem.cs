﻿// -----------------------------------------------------------------------
// <copyright file="CombinedOutputScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System.Collections.Generic;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;

public class CombinedOutputScreenFieldItem : ValueExpressionScreenFieldItem
{
    private ScreenField screenField;

    public CombinedOutputScreenFieldItem(ScreenField5250 screenField5250, ScreenField screenField, IEnumerable<ScreenField5250> allFields)
        : base(screenField, allFields)
    {
        this.screenField = screenField;
        this.IsHighlightedStandard = screenField5250.Att == FieldAttribute.GreenReverse;

        string stringValue = string.Format("{0}{1}", screenField5250.Data, screenField.FormatLinkDataExpression(allFields, true));
        this.FieldValue = stringValue;
        //TODO
        //this.FieldValueType = JHARecordDetail.DataTypes.Text;

        if (this.screenField.IsDisplayFormatCurrency())
        {
            decimal decimalValue;

            if (decimal.TryParse(stringValue, out decimalValue))
            {
                //TODO
                //this.FieldValueType = JHARecordDetail.DataTypes.Currency;
            }
        }
        else if (this.screenField.IsDisplayFormatRate())
        {
            decimal decimalValue;

            if (decimal.TryParse(stringValue, out decimalValue))
            {
                //TODO
                //this.FieldValueType = JHARecordDetail.DataTypes.Rate;
            }
        }
    }
}