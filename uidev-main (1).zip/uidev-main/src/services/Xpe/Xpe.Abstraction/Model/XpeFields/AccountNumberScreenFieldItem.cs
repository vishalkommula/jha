// -----------------------------------------------------------------------
// <copyright file="AccountNumberScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System;
using System.Collections.Generic;
using JackHenry.JHAContractTypes;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;
using Xpe.Abstraction.Services;

public class AccountNumberScreenFieldItem : XpeField, IComparable, IEditorControlProvider
{
    //private readonly IInquiryTypeService inquiryTypeService;
    private readonly ICurrentUserInfo userInfo;
    private ScreenField5250 screenField5250;
    private ScreenField screenField;
    private string fieldValue;
    private bool isReadOnly = true;
    private bool printing = false;
    private bool isClickable = false;
    private string fieldLabel;

    public AccountNumberScreenFieldItem()
    {
        this.Account = new MiniAccount(string.Empty, string.Empty);
    }

    public AccountNumberScreenFieldItem(
        ScreenField5250 screenField5250,
        ScreenField screenField,
        string accountTypeValue,
        IInquiryTypeProvider inquiryTypeProvider,
        IUserService userService,
        ICurrentUserInfo userInfo,
        IEnumerable<ScreenField5250> outputFields)
    {
        this.userInfo = userInfo;
        this.InquiryTypeProvider = inquiryTypeProvider;
        this.screenField = screenField;
        this.screenField5250 = screenField5250;

        this.IsItemDisplayed = !screenField.IsDisplayFormatIgnored();
        this.IsHighlightedStandard = this.screenField5250.Att == FieldAttribute.GreenReverse;
        this.fieldLabel = this.GetFieldLabel(outputFields);

        if (screenField5250 != null && screenField5250.Data != null)
        {
            this.FieldValue = screenField5250.Data.Trim();
        }

        this.SetAccount(accountTypeValue);
    }

    public IInquiryTypeProvider InquiryTypeProvider { get; set; }

    public override bool IsItemDisplayed { get; protected set; }

    public string FieldValue { get; set; }

    public IAccount Account { get; set; }

    public override bool IsReadOnly { get; } = true;

    public override bool IsCustomDataGridCellRequired { get; } = true;

    public bool IsClickable { get; set; }

    public string BindingPath { get; set; }

    public string EditorMask { get; set; }

    public int MaxLength { get; set; }

    public bool IsPromptable { get; set; }

    public virtual void SetGLAccount()
    {
        //TODO
        //this.Account = AccountExtensionsHelper.ParseGLAccount(this.FieldValue);
    }

    public override string ToString()
    {
        return this.FieldValue;
    }

    public override bool Equals(object obj)
    {
        return this.CompareTo(obj) == 0;
    }

    public override int GetHashCode()
    {
        return this.FieldValue == null ? 0 : this.FieldValue.GetHashCode();
    }

    public int CompareTo(object obj)
    {
        if (obj == null)
        {
            return 1;
        }

        AccountNumberScreenFieldItem other = obj as AccountNumberScreenFieldItem;
        string otherValue = obj.ToString();

        if (other != null)
        {
            otherValue = other.FieldValue;
        }

        long thisIntValue;

        if (!long.TryParse(this.FieldValue, out thisIntValue))
        {
            thisIntValue = 0;
        }

        long thatIntVlaue;

        if (!long.TryParse(otherValue, out thatIntVlaue))
        {
            return 1;
        }

        return thisIntValue.CompareTo(thatIntVlaue);
    }

    private void SetAccount(string accountTypeValue)
    {
        if (!string.IsNullOrWhiteSpace(accountTypeValue))
        {
            string accountType = accountTypeValue.Trim();

            if (this.InquiryTypeProvider != null &&
                accountType != this.InquiryTypeProvider.VendorCode &&
                accountType != this.InquiryTypeProvider.ShareHolderCode)
            {
                ////Remove the leading 0's for accounts or it will cause issues when verifying acct authorization during acct inquiry
                string acctId = this.FieldValue.ToString().TrimStart('0');
                this.Account = new MiniAccount(acctId, accountType);

                if (accountType == this.InquiryTypeProvider.GLCode)
                {
                    this.SetGLAccount();
                }

                this.isClickable = true;
            }
        }
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.screenField.FormatDynamicLabelText(outputFields);
    }
}
