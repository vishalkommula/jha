﻿// -----------------------------------------------------------------------
// <copyright file="ListOptionsValuesScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2016 Jack Henry &amp; Associates, Inc. All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

using Xpe.Abstraction.Extensions;

public class ListOptionsValuesScreenFieldItem : XpeScreenFieldItem
{
    private ScreenField screenField;
    private bool validValue = false;
    private string originalValue = string.Empty;
    private string fieldLabel;
    //private JHARecordDetailFieldItem recordDetailFieldItem;

    public ListOptionsValuesScreenFieldItem(ScreenField5250 screenField5250, ScreenField screenField, IEnumerable<ScreenField5250> outputFields)
        : base(screenField5250, screenField, CultureInfo.InvariantCulture, outputFields)
    {
        this.screenField = screenField;
        this.fieldLabel = this.GetFieldLabel(outputFields);

        //// This need to be string fields, so option values are same type
        //TODO
        //this.FieldValueType = JHARecordDetail.DataTypes.Text;

        string stringValue = screenField5250 != null && !string.IsNullOrEmpty(screenField5250.Data) ? screenField5250.Data.Trim() : string.Empty;

        this.FieldValue = stringValue;
        this.originalValue = stringValue;

        if (string.IsNullOrEmpty(stringValue) || (this.screenField.FieldValueArray != null && this.screenField.FieldValueArray.Any(v => v.Value == stringValue)))
        {
            this.validValue = true;
        }
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        ////When initial mapping efforts were made for XPE, these fields were mapped with valid field values included in parenthesis (on the field label).
        ////This was causing confusion in the field so strip that portion of the field label.
        if (!string.IsNullOrEmpty(this.screenField.FieldLabel) && this.screenField.FieldLabel.EndsWith(")"))
        {
            Regex regex = new Regex("\\([^\\(]*\\)");
            return regex.Replace(this.screenField.FieldLabel, string.Empty);
        }

        return this.screenField.FormatDynamicLabelText(outputFields);
    }
}