﻿// -----------------------------------------------------------------------
// <copyright file="CustomerNumberScreenFieldItem.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace Xpe.Abstraction.Model.XpeFields;

using System;
using System.Collections.Generic;
using JackHenry.JHAContractTypes;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;

public class CustomerNumberScreenFieldItem : XpeField, IEditorControlProvider
{
    private string fieldValue;
    private string fieldLabel;

    public CustomerNumberScreenFieldItem()
    {
        this.Customer = new CustId_Type();
    }

    public CustomerNumberScreenFieldItem(ScreenField5250 screenField5250, ScreenField screenField, IEnumerable<ScreenField5250> allFields)
    {
        this.ScreenField = screenField;
        this.ScreenField5250 = screenField5250;

        if (!string.IsNullOrEmpty(screenField.LinkDataExpression))
        {
            this.FieldValue = this.ScreenField.FormatLinkDataExpression(allFields, false);
        }
        else
        {
            this.FieldValue = screenField5250.Data != null ? screenField5250.Data.Trim() : null;
        }

        this.Customer = new CustId_Type() { Value = this.FieldValue };
        this.IsItemDisplayed = !this.ScreenField.IsDisplayFormatIgnored();
        this.IsHighlightedStandard = this.ScreenField5250.Att == FieldAttribute.GreenReverse;
        this.ScreenFieldHelpId = screenField.HelpId;
        this.fieldLabel = this.GetFieldLabel(allFields);
    }

    public string FieldValue { get; set; }

    public override bool IsReadOnly
    {
        get
        {
            return true;
        }
    }

    public CustId_Type Customer { get; protected set; }

    public override bool IsCustomDataGridCellRequired
    {
        get
        {
            return true;
        }
    }

    public override bool IsItemDisplayed { get; protected set; }

    public string BindingPath { get; protected set; }

    public string EditorMask { get; protected set; }

    public int MaxLength { get; protected set; }

    public bool IsPromptable { get; protected set; }

    protected ScreenField5250 ScreenField5250 { get; set; }

    protected ScreenField ScreenField { get; set; }

    public override string ToString()
    {
        return this.FieldValue;
    }

    private string GetFieldLabel(IEnumerable<ScreenField5250> outputFields)
    {
        return this.ScreenField.FormatDynamicLabelText(outputFields);
    }
}