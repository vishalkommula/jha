﻿// -----------------------------------------------------------------------
// <copyright file="MessageFilterType.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2014 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace Xpe.Abstraction.Model;

public class MessageFilterType
{
    public const string Exception = "Exc";
    public const string EIP = "EIP";
    public const string ChargeBack = "ChgBack";
    public const string CreditBack = "CrBack";
    public const string ExceptionSuspect = "ExcSus";
    public const string Special = "NonClsf";
    public const string Collateral = "Collat";
    public const string Alert = "Alert";
    public const string ODComment = "ODPrvlg";
    public const string Collection = "Col";
    public const string MaintenanceComment = "Main";
    public const string AllMessageTypes = "ALL";
    public const string AllAccounts = "ShowAll";
    public const string CurrentAccount = "Current";
    public const string PlanMessages = "Plan";
    public const string Payoff = "Payo";
    public const string None = "None";
}