﻿using System.Collections.Generic;

namespace Xpe.Abstraction.Model;

public class StartupResponse
{
    public const string I901 = "I901";

    public const string I902 = "I902";

    public const string I906 = "I906";

    public const string I2702 = "2702";

    public const string I2703 = "2703";

    public const string I2777 = "2777";

    public const string I8901 = "8901";

    public const string I8902 = "8902";

    public const string I8903 = "8903";

    public const string I8906 = "8906";

    public const string I8907 = "8907";

    public const string I8910 = "8910";

    public const string I8916 = "8916";

    public const string I8917 = "8917";

    public const string I8918 = "8918";

    public const string I8920 = "8920";

    public const string I8921 = "8921";

    public const string I8922 = "8922";

    public const string I8923 = "8923";

    public const string I8925 = "8925";

    public const string I8928 = "8928";

    public const string I8929 = "8929";

    public const string I8930 = "8930";

    public const string I8934 = "8934";

    public const string I8935 = "8935";

    public const string I8936 = "8936";

    public const string I8937 = "8937";

    public const string I8940 = "8940";

    public const string II904 = "I904";

    public const string I0004 = "0004";

    public const string Success = "SUCCESS";

    public static readonly Dictionary<string, string> StartupResponseDescription = new()
    {
        { Success, "Successfully created session with device. " },
        { I901, "Virtual device has less function than source device. " },
        { I902, "Session successfully started. " },
        {
            I906,
            "Automatic sign-on requested, but not allowed. Session still allowed; a sign-on screen will becoming. "
        },
        { I2702, "Device description not found. " },
        { I2703, "Controller description not found." },
        { I2777, "Damaged device description. " },
        { I8901, "Device not varied on. " },
        { I8902, "Device not available. " },
        { I8903, "Device not valid for session. " },
        { I8906, "Session initiation failed. " },
        { I8907, "Session failure. " },
        { I8910, "Controller not valid for session. " },
        { I8916, "No matching device found. " },
        { I8917, "Not authorized to object. " },
        { I8918, "Job canceled. " },
        { I8920, "Object partially damaged. " },
        { I8921, "Communications error. " },
        { I8922, "Negative response received. " },
        { I8923, "Start-up record built incorrectly. " },
        { I8925, "Creation of device failed. " },
        { I8928, "Change of device failed. " },
        { I8929, "Vary on or vary off failed. " },
        { I8930, "Message queue does not exist. " },
        { I8934, "Start-up for S/36 WSF received. " },
        { I8935, "Session rejected. " },
        { I8936, "Security failure on session attempt. " },
        { I8937, "Automatic sign-on rejected. " },
        { I8940, "Automatic configuration failed or not allowed. " },
        { II904, "Source system at incompatible release. " },
        { I0004, "No user token returned. " }
    };
}