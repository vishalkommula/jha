namespace Xpe.Abstraction.Model;

public enum StructuredField : byte
{
    DefineSelectionField = 0x50,
    CreateWindow = 0x51,
    UnrestrictedWindowCursorMovement = 0x52,
    DefineScrollBarField = 0x53,
    WriteData = 0x54,
    ProgrammableMouseButtons = 0x55,
    RemoveGUISelectionField = 0x58,
    RemoveGUIWindow = 0x59,
    RemoveGUIScrollBarField = 0x5B,
    RemoveAllGUIConstructs = 0x5F,
    DrawEraseGridLines = 0x60,
    ClearGridLineBuffer = 0x61
}