﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Xpe.Abstraction.Model;

[XmlRoot(Namespace = "JackHenry.Banking")]
public class UserFieldSettings
{
    public UserFieldSettings()
    {
        Fields = Fields ?? new SerializableDictionary<string, List<UserFieldSetting>>();
    }

    public SerializableDictionary<string, List<UserFieldSetting>> Fields { get; set; }
}