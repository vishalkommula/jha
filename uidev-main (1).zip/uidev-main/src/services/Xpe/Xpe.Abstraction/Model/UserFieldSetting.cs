﻿using System.Xml.Serialization;

namespace Xpe.Abstraction.Model;

[XmlRoot(Namespace = "JackHenry.Banking")]
public class UserFieldSetting
{
    public double Height { get; set; }

    public int LayoutIndex { get; set; }

    public string Name { get; set; }

    public double Width { get; set; }

    public int Position { get; set; }
}