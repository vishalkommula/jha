﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;
using Xpe.Abstraction.Model.XpeFields;

namespace Xpe.Abstraction.Model;

public class XpeUIGridData : XpeGridData
{
    private readonly IFieldItemProvider fieldItemProvider;
    private List<IModField5250> gridFieldItems;
    private ScreenMap screenMap;
    private ICurrentUserInfo userInfo;

    public XpeUIGridData(
        ScreenMapGridArray table,
        ScreenInfoResponse screenInfo,
        IFieldItemProvider fieldItemProvider,
        ICurrentUserInfo userInfo,
        ScreenMap screenMap)
    {
        this.fieldItemProvider = fieldItemProvider;
        this.gridFieldItems = new List<IModField5250>();
        XpeDataTable dataTable = new XpeDataTable(this);
        int columnNum = 0;
        int firstFieldRow = 0;
        this.screenMap = screenMap;
        this.userInfo = userInfo;

        //// Add all of the columns to the dataTable.

        foreach (ScreenField column in table.Grid.GridFields)
        {
            if (column.OptionField || column.IsDisplayFormatIgnored())
            {
                continue;
            }

            DataColumn dataColumn = new DataColumn(string.Format("Field{0}", columnNum.ToString()), typeof(XpeField));
            dataColumn.Caption = column.FieldLabel;

            if (firstFieldRow == 0)
            {
                firstFieldRow = column.Row;
            }

            ScreenField5250 field5250 = ScreenField5250Extensions.Get5250Field(column, screenInfo.AllFields);

            ColumnInfo field = new ColumnInfo(string.Format("Field{0}", columnNum.ToString()));

            if (column.IsLinkTypeLabel() && !string.IsNullOrEmpty(column.LinkDataExpression))
            {
                column.FieldLabel = column.FormatLinkDataExpression(screenInfo.AllFields, false).Trim();
            }
            else
            {
                column.FieldLabel = column.FormatDynamicLabelText(screenInfo.AllFields);
            }

            if (string.IsNullOrWhiteSpace(column.FieldLabel))
            {
                //TODO: Implement
                // hide columns where field label is not returned
                //field.Visibility = Visibility.Collapsed;
            }

            if (column.IsLinkTypeColumnTotal() && !string.IsNullOrEmpty(column.LinkDataExpression))
            {
                field.SummaryText = column.FormatLinkDataExpression(screenInfo.AllFields, false);
            }

            if (field5250 != null)
            {
                if (field5250.IsInputField())
                {
                    field.AllowEdit = true;
                }
                else
                {
                    field.AllowEdit = false;
                }

                XpeField item = this.GetColumnFieldItem(column, field5250, table.Grid.GridFields, screenInfo, userInfo);
                //TODO: Implement
                //IEditorControlProvider controlProvider = item as IEditorControlProvider;

                //if (controlProvider != null)
                //{
                //    field.BindingPath = controlProvider.BindingPath;
                //    field.EditorMask = controlProvider.EditorMask;
                //    field.MaxLength = controlProvider.MaxLength;
                //    field.IsPromptable = controlProvider.IsPromptable;
                //}

                if (column.IsLinkTypeCustomer())
                {
                    field.CellValuePresenterStyleKey = "XpeCustomerHyperLink";
                }
                else if (column.IsLinkTypeAccount())
                {
                    field.CellValuePresenterStyleKey = "XpeAccountHyperLink";
                }
            }

            //TODO: Implement
            //if (!string.IsNullOrWhiteSpace(column.HorizontalAlignment))
            //{
            //    if (column.HorizontalAlignment.Equals("Right", StringComparison.InvariantCultureIgnoreCase))
            //    {
            //        field.HorizontalAlignment = HorizontalAlignment.Right;
            //    }
            //    else if (column.HorizontalAlignment.Equals("Left", StringComparison.InvariantCultureIgnoreCase))
            //    {
            //        field.HorizontalAlignment = HorizontalAlignment.Left;
            //    }
            //}

            field.Label = column.FieldLabel;

            dataTable.Columns.Add(dataColumn);
            columnNum++;
        }

        int count = 0;
        while (count < table.Grid.GridPageSize)
        {
            XpeDataRow dataRow = null;
            columnNum = 0;
            foreach (ScreenField column in table.Grid.GridFields)
            {
                if (column.IsDisplayFormatIgnored())
                {
                    continue;
                }

                string dataValue = string.Empty;

                int dataLocationRow = column.Row + (count * table.Grid.GridRowsPerRec);
                string dataLocation = string.Format("{0:00}{1:000}", dataLocationRow, column.Col);
                bool isOptionField = column.OptionField;

                ScreenField5250 screenField = ScreenField5250Extensions.GetFieldByRRCCC(dataLocation, screenInfo.AllFields);

                if (screenField != null)
                {
                    if (dataRow == null)
                    {
                        dataRow = dataTable.NewRow() as XpeDataRow;
                    }

                    if (dataRow.LocationRow5250 == 0)
                    {
                        dataRow.LocationRow5250 = dataLocationRow;
                    }

                    if (isOptionField)
                    {
                        if (screenField.IsInputField())
                        {
                            var modField = new ModField5250(screenField);
                            dataRow.OptionField = modField;
                            this.gridFieldItems.Add(modField);
                        }
                    }
                    else
                    {
                        var adjustedColumnField = column.Clone();

                        // Fix the rows in linkdata expression to the current row we are on
                        if (!string.IsNullOrWhiteSpace(adjustedColumnField.LinkDataExpression))
                        {
                            string[] expressionValues = Regex.Split(adjustedColumnField.LinkDataExpression, "{SPACE:[1-9]?[0-9]}");

                            for (int i = 0; i < expressionValues.Length; i++)
                            {
                                if (!expressionValues[i].StartsWith("{SPACE:"))
                                {
                                    expressionValues[i] = expressionValues[i].Replace(string.Format("{0}{1}", "{", adjustedColumnField.Row.ToString("00")), string.Format("{0}{1}", "{", dataLocationRow.ToString("00")));
                                    expressionValues[i] = expressionValues[i].Replace(string.Format(":{0}", adjustedColumnField.Row.ToString("00")), string.Format(":{0}", dataLocationRow.ToString("00")));
                                }
                            }

                            adjustedColumnField.LinkDataExpression = string.Join(string.Empty, expressionValues);
                        }

                        var item = fieldItemProvider.GetFieldItem(adjustedColumnField, screenField, table.Grid.GridFields, screenInfo, userInfo);
                        dataRow[columnNum] = item;

                        XpeField xpeField = item as XpeField;

                        if (xpeField != null)
                        {
                            if (screenField.Att == FieldAttribute.Red)
                            {
                                xpeField.IsHighlightedRed = true;

                                ////if the field has the red attribute but it's negative currency, don't apply a highlight
                                decimal currencyValue;
                                if (column.IsDisplayFormatCurrency() && !string.IsNullOrEmpty(screenField.Data) && decimal.TryParse(screenField.Data, out currencyValue) && currencyValue < 0)
                                {
                                    xpeField.IsHighlightedRed = false;
                                }
                            }

                            xpeField.IsHighlightedBlue = screenField.Att == FieldAttribute.Blue;
                        }

                        if (item is IModField5250)
                        {
                            this.gridFieldItems.Add(item as IModField5250);
                        }

                        columnNum++;
                    }
                }
                else if (!isOptionField)
                {
                    columnNum++;
                }
            }

            if (dataRow != null)
            {
                dataTable.Rows.Add(dataRow);
            }

            count++;
        }

        if (!string.IsNullOrEmpty(table.Grid.HeaderText))
        {
            this.HeaderText = this.FormatGridHeader(table.Grid.HeaderText.Trim(), screenInfo.OutputFields);
        }

        if (!string.IsNullOrWhiteSpace(this.screenMap.Title) && (string.IsNullOrEmpty(this.HeaderText) || this.HeaderText == "Items"))
        {
            this.HeaderText = string.Format("{0} Items", this.screenMap.Title);
        }

        this.DataTable = dataTable;
        this.GridOptions = this.GetGridOptions(table.Grid.GridOptionArray.ToList(), screenInfo.OutputFields);
    }

    public override XpeDataTable DataTable
    {
        get;
        set;
    }

    public override IEnumerable<IModField5250> GridFieldItems
    {
        get
        {
            return this.gridFieldItems;
        }
    }

    private string FormatGridHeader(string headerText, IEnumerable<ScreenField5250> outputFields)
    {
        // Split the Link Data Expression by strings contained in brackets
        List<string> fieldValues = Regex.Split(headerText, "(?={)|(?<=})").ToList();

        // Strip brackets from all known tokens (SPACE, RANGE, field references) and
        // leave/display the rest
        for (int i = 0; i < fieldValues.Count; i++)
        {
            if (fieldValues[i].StartsWith("{SPACE:", true, System.Globalization.CultureInfo.InvariantCulture) ||
                fieldValues[i].StartsWith("{RANGE", true, System.Globalization.CultureInfo.InvariantCulture) ||
                Regex.IsMatch(fieldValues[i], "{[0-9]{5}}"))
            {
                fieldValues[i] = fieldValues[i].Replace("{", string.Empty);
                fieldValues[i] = fieldValues[i].Replace("}", string.Empty);
            }

            int n;
            bool isNumeric = int.TryParse(fieldValues[i], out n);

            if (isNumeric && fieldValues[i].Length == 5)
            {
                ScreenField5250 screen5250 = ScreenField5250Extensions.GetFieldByRRCCC(fieldValues[i], outputFields);

                if (screen5250 != null)
                {
                    fieldValues[i] = screen5250.Data.Trim();
                }
                else
                {
                    // If we don't find the RRCCC, then set the item to blank.
                    fieldValues[i] = string.Empty;
                }
            }
        }

        return string.Join(string.Empty, fieldValues);
    }

    private XpeField GetColumnFieldItem(ScreenField screenfield, ScreenField5250 screenfield5250, IEnumerable<ScreenField> screenFields, ScreenInfoResponse screenInfo, ICurrentUserInfo userInfo)
    {
        ////If the the field is a linkable account and data is null, just return an empty AccountNumberScreenFieldItem.  Otherwise, it causes binding issues in our grids.
        if ((screenfield.IsLinkTypeAccount() || screenfield.IsLinkTypeGLAccount() || screenfield.IsLinkTypeCustomer()) && string.IsNullOrWhiteSpace(screenfield5250.Data))
        {
            if (screenfield.IsLinkTypeAccount())
            {
                return new AccountNumberScreenFieldItem();
            }
            else if (screenfield.IsLinkTypeGLAccount())
            {
                return new GLAccountNumberScreenFieldItem();
            }
            else if (screenfield.IsLinkTypeCustomer())
            {
                return new CustomerNumberScreenFieldItem();
            }
        }

        return this.fieldItemProvider.GetFieldItem(screenfield, screenfield5250, screenFields, screenInfo, userInfo);
    }

    private ScreenInfoRequest GetScreenInfoRequest(CursorLocation cursorLocation, string key)
    {
        KeyConverter keyConverter = new KeyConverter();

        string[] keyWithModifier = key.Split('+');

        if (keyWithModifier.Length > 1)
        {
            Key modifier = (Key)keyConverter.ConvertFromString(keyWithModifier[0]);
            Key keyPress = (Key)keyConverter.ConvertFromString(keyWithModifier[1]);

            return new ScreenInfoRequest(new KeyPress(keyPress, modifier), cursorLocation);
        }
        else
        {
            return new ScreenInfoRequest(new KeyPress((Key)keyConverter.ConvertFromString(key.Replace(" ", string.Empty)), Key.None), cursorLocation);
        }
    }
}
