﻿namespace Xpe.Abstraction.Model;

public abstract class XpeDataCellProvider
{
    public virtual string CellValuePresenterStyleKey
    {
        get
        {
            return null;
        }
    }

    public abstract bool IsCustomDataGridCellRequired
    {
        get;
    }
}
