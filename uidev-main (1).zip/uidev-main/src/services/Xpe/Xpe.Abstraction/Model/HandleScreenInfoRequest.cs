﻿// -----------------------------------------------------------------------
// <copyright file="HandleScreenInfoRequest.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2018 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
using System.Collections.Generic;

namespace Xpe.Abstraction.Model;

public class HandleScreenInfoRequest : ScreenInfoRequest
{
    public HandleScreenInfoRequest(KeyPress key, CursorLocation cursorLocation, bool ignoreMaxConsecutiveScreensHandled = false, List<ScreenField5250> changedFields = null)
        : base(key, cursorLocation, changedFields)
    {
        this.IgnoreMaxConsecutiveScreensHandled = ignoreMaxConsecutiveScreensHandled;
    }

    public HandleScreenInfoRequest(ScreenInfoRequest request, bool ignoreMaxConsecutiveScreensHandled = false)
        : this(request.Key, request.CursorLocation, ignoreMaxConsecutiveScreensHandled)
    {
    }

    public bool IgnoreMaxConsecutiveScreensHandled
    {
        get;
        set;
    }
}
