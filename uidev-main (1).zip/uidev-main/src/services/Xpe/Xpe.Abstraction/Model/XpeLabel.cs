﻿using System;
using System.Linq;

namespace Xpe.Abstraction.Model;

public class XpeLabel : IEditorControlProvider
{
    private string labelValue;
    private bool isBrightText;

    public XpeLabel(string labelValue, bool isBrightText)
    {
        this.labelValue = labelValue;
        this.isBrightText = isBrightText;

        if (this.labelValue != null && this.labelValue.Trim().All(x => x == '_'))
        {
            this.labelValue = this.labelValue.Replace("_", string.Empty);
        }
    }

    public bool IsPromptable
    {
        get
        {
            return false;
        }
    }

    public string LabelValue { get; set; }

    public Type EditAsType
    {
        get
        {
            return typeof(string);
        }
    }

    public string BindingPath
    {
        get
        {
            return "LabelValue";
        }
    }

    public string EditorMask
    {
        get
        {
            return string.Empty;
        }
    }

    public int MaxLength
    {
        get
        {
            return 0;
        }
    }

    private bool IsDelimeter()
    {
        if (this.labelValue != null && this.labelValue.Length == 1)
        {
            char labelChar = Convert.ToChar(this.labelValue);

            if (char.IsSymbol(labelChar) || char.IsPunctuation(labelChar))
            {
                return true;
            }
        }

        return false;
    }
}