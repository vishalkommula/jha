﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using Xpe.Abstraction.Enums;

namespace Xpe.Abstraction.Model;

[Serializable]
public class ScreenField5250
{
    public ScreenField5250(string fieldName, string fieldType, int row, int col, FieldAttribute attribute,
        int fieldSize, string data, int screenWidth, FieldFormatWord fieldFormatWord = null,
        FieldControlWord fieldControlWord = null)
    {
        FieldName = fieldName;
        FieldType = fieldType;
        Att = attribute;
        Data = data;
        ScreenWidth = screenWidth;
        FieldFormatWord = fieldFormatWord;
        FieldControlWord = fieldControlWord;

        RRCCCs = new List<string>();

        if (ScreenWidth != 0 && fieldSize > 0)
        {
            for (var i = 0; i < fieldSize; i++)
            {
                var column = (col + i) % ScreenWidth;

                // If there is no remainder, then the column should be 1 instead of 0.
                if (column == 0)
                {
                    column = ScreenWidth;
                }

                var rowIncrememnter = (col + i - 1) / ScreenWidth;

                RRCCCs.Add(string.Format("{0:00}{1:000}", row + rowIncrememnter, column));
            }
        }
    }

    public ScreenField5250()
    {
    }

    public List<ScreenField5250> AssociatedMaskedFields { get; set; }

    public bool IsFocused { get; set; }

    [XmlIgnore]
    public string RRCCC =>
        // This only happens when a 5250 field is created in NVPGridData for the convenience of using a XpeScreenFieldItem
        RRCCCs.Count == 0 ? "00000" : RRCCCs.FirstOrDefault();

    public string FieldName { get; set; }

    public string FieldType { get; set; }

    [XmlIgnore] public int Row => Convert.ToInt32(RRCCC.Substring(0, 2));

    [XmlIgnore] public int Col => Convert.ToInt32(RRCCC.Substring(2, 3));

    public FieldAttribute Att { get; set; }

    public FieldFormatWord FieldFormatWord { get; set; }

    public FieldControlWord FieldControlWord { get; set; }

    [XmlIgnore] public int FieldSize => RRCCCs.Count();

    public string Data { get; set; }

    public List<string> RRCCCs { get; set; }

    public int ScreenWidth { get; set; }

    public static List<ScreenField5250> Reorder(IEnumerable<ScreenField5250> unorderedOutputFields)
    {
        return unorderedOutputFields.OrderBy(f => f.RRCCC).ToList();
    }

    public void AppendData(string data)
    {
        Data += data;

        var lastRRCCC = RRCCCs.LastOrDefault();

        var row = Convert.ToInt32(lastRRCCC.Substring(0, 2));
        var col = Convert.ToInt32(lastRRCCC.Substring(2, 3));

        if (ScreenWidth == 0 || data.Length <= 0)
        {
            return;
        }

        for (var i = 1; i < data.Length + 1; i++)
        {
            var column = (col + i) % ScreenWidth;

            // If there is no remainder, then the column should be 1 instead of 0.
            if (column == 0)
            {
                column = ScreenWidth;
            }

            var rowIncrementor = (col + i - 1) / ScreenWidth;

            RRCCCs.Add($"{row + rowIncrementor:00}{column:000}");
        }
    }

    public ScreenField5250 Clone()
    {
        var clonedField = new ScreenField5250(FieldName, FieldType, Row, Col, Att, FieldSize, Data, ScreenWidth,
            FieldFormatWord, FieldControlWord)
        {
            AssociatedMaskedFields = AssociatedMaskedFields
        };
        return clonedField;
    }

    public override string ToString()
    {
        var fieldString = new StringBuilder();

        if (FieldType == ScreenField5250Type.InputField)
        {
            fieldString.Append("Input Field   ");
        }
        else if (FieldType == ScreenField5250Type.OutputField || FieldType == ScreenField5250Type.Attribute)
        {
            fieldString.Append("Output Field ");
        }
        else if (FieldType == ScreenField5250Type.ErrorField)
        {
            fieldString.Append("Error Field  ");
        }
        else
        {
            fieldString.Append(FieldType + "  ");
        }

        if (!string.IsNullOrEmpty(RRCCC))
        {
            fieldString.Append("  RRCCC:" + RRCCC);
        }

        fieldString.Append(" Size:" + FieldSize);

        if (!string.IsNullOrEmpty(FieldName))
        {
            fieldString.Append("  Name:" + FieldName);
        }

        if (!string.IsNullOrEmpty(Data))
        {
            fieldString.Append("  Data:" + Data);
        }

        if (IsFocused)
        {
            fieldString.Append("  Field Has Focus");
        }

        return fieldString.ToString();
    }
}