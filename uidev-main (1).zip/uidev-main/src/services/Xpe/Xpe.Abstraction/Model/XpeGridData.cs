﻿namespace Xpe.Abstraction.Model;

using Xpe.Abstraction.Extensions;

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;

public abstract class XpeGridData
{
    public abstract XpeDataTable DataTable { get; set; }

    public abstract IEnumerable<IModField5250> GridFieldItems { get; }

    public virtual List<ScreenMapGridArrayGridGridOption> GridOptions { get; set; }

    public string HeaderText { get; set; }

    public int Index { get; set; }

    public ScreenInfoRequest NextDataCommand { get; set; }

    public ScreenInfoRequest PreviousDataCommand { get; set; }

    public ScreenInfoRequest ExportGridDataCommand { get; set; }

    public string ExcelExportDocumentPath { get; set; }

    public ScreenField5250 GetFieldByRowCol(int row, int column, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields)
    {
        ScreenField5250 screenField = this.GetFieldByRowCol(row, column, outputFields);

        if (screenField == null)
        {
            screenField = this.GetFieldByRowCol(row, column, inputFields);
        }

        return screenField;
    }

    public ScreenField5250 GetFieldByRowCol(int row, int column, IEnumerable<ScreenField5250> fields)
    {
        return fields.FirstOrDefault(f => f.Row == row && f.Col == column);
    }

    public ScreenField5250 GetFieldByRRCCC(string rrccc, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields)
    {
        return this.GetFieldByRowCol(Convert.ToInt32(rrccc.Substring(0, 2)), Convert.ToInt32(rrccc.Substring(2, 3)), inputFields, outputFields);
    }

    public List<ScreenMapGridArrayGridGridOption> GetGridOptions(List<ScreenMapGridArrayGridGridOption> list, IEnumerable<ScreenField5250> outputFields)
    {
        List<ScreenMapGridArrayGridGridOption> gridOptions = new List<ScreenMapGridArrayGridGridOption>();

        foreach (ScreenMapGridArrayGridGridOption option in list)
        {
            ////If a tokenized field is referenced in the mapped OptionAction, grab the correct value from 5250 and reassign the OptionAction value.
            ////This value is used for the toolbar button text
            if (!string.IsNullOrEmpty(option.OptionAction) && option.OptionAction.Contains("{") && option.OptionAction.Contains("}"))
            {
                option.OptionAction = ScreenFieldExtensions.FormatLinkDataExpression(option.OptionAction, outputFields, false, false);
            }

            if (option.Row != 0 && option.Col != 0)
            {
                string dataLocation = string.Format("{0:00}{1:000}", option.Row, option.Col);
                ScreenField5250 screenField = ScreenField5250Extensions.GetFieldByRRCCC(dataLocation, outputFields);

                if (screenField != null && !string.IsNullOrEmpty(screenField.Data) && screenField.Data.Contains(option.OptionValue.ToString()))
                {
                    gridOptions.Add(option);
                }
            }
            else
            {
                gridOptions.Add(option);
            }
        }

        return gridOptions;
    }

    public string GetItemArrayString(DataRow row, bool firstColumnIsOption)
    {
        List<object> values = new List<object>();

        foreach (object o in row.ItemArray)
        {
            string value = o != null ? o.ToString() : string.Empty;

            if (!string.IsNullOrEmpty(value))
            {
                //// doing this so commas will be ignored in comma delimited file
                //// can not have commas due to creating a comma delimited file
                value = "\"" + value + "\"";
            }

            values.Add(value);
        }

        if (firstColumnIsOption)
        {
            ////remve the first column
            values.Remove(values[0]);
        }

        return string.Join(",", values);
    }
}