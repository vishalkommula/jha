﻿namespace Xpe.Abstraction.Model;

using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;

using System;
using System.Threading.Tasks;

public interface IScreenHandlerService
{
    HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId, Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService);

    Task<bool> HandleInputAsync(ScreenData screenData, ScreenInfoRequest screenInfoRq, ICurrentUserInfo userInfo);

    bool MenuOptionSelected(XpeNavigationEventArgs args);

    //void SetRelatedFunctionsClickEventArgs(string sessionId, ToolbarFunctionClickedEventArgs args);
}
