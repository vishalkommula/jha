﻿using System;
using System.Reflection;
using System.Text;

namespace Xpe.Abstraction.Model;

internal class ExceptionUtil
{
    internal static string ExceptionToString(Exception ex, bool includeSysInfo, IXtraJesLogInfo info)
    {
        var builder = new StringBuilder();

        builder.Append(ExceptionMessage(ex));

        if (info != null)
        {
            builder.Append(InfoMessage(info));
        }

        builder.AppendLine();

        builder.Append(SysInfoToString());
        builder.AppendLine();

        builder.Append(ex);

        return builder.ToString();
    }

    private static string ExceptionMessage(Exception ex)
    {
        if (string.IsNullOrEmpty(ex.Message))
        {
            return string.Empty;
        }

        var builder = new StringBuilder();
        builder.Append("Exception message:  ");

        try
        {
            builder.Append(ex.Message);
        }
        catch (Exception e)
        {
            builder.Append($"* Exception message error: {e}");
        }

        builder.Append(Environment.NewLine);
        return builder.ToString();
    }

    private static string InfoMessage(IXtraJesLogInfo info)
    {
        if (info != null)
        {
            return string.Format("{0}{0}Jes Information: Message Id {1}; Process ID: {2}; Thread ID: {3} {0}",
                Environment.NewLine, info.MessageId, info.ProcessId, info.ThreadId);
        }

        return string.Empty;
    }

    private static string SysInfoToString()
    {
        var builder = new StringBuilder();

        var parentAssembly = Assembly.GetEntryAssembly() == null
            ? Assembly.GetCallingAssembly()
            : Assembly.GetEntryAssembly();

        builder.Append("Date and Time:\t\t");
        builder.Append(DateTime.Now);
        builder.Append(Environment.NewLine);
        builder.Append("Machine Name:\t\t");

        try
        {
            builder.Append(Environment.MachineName);
        }
        catch (Exception e)
        {
            builder.Append(e.Message);
        }

        builder.Append(Environment.NewLine);
        builder.Append("Application Domain:\t\t");
        try
        {
            builder.Append(AppDomain.CurrentDomain.FriendlyName);
        }
        catch (Exception e)
        {
            builder.Append(e.Message);
        }

        builder.Append(Environment.NewLine);
        builder.Append("Assembly Location:\t\t");
        try
        {
            builder.Append(parentAssembly.Location);
        }
        catch (Exception e)
        {
            builder.Append(e.Message);
        }

        builder.Append(Environment.NewLine);
        builder.Append("Assembly Full Name:\t\t");
        try
        {
            builder.Append(parentAssembly.FullName);
        }
        catch (Exception e)
        {
            builder.Append(e.Message);
        }

        builder.Append(Environment.NewLine);
        builder.Append("Assembly Version:\t\t");
        try
        {
            builder.Append(parentAssembly.GetName().Version);
        }
        catch (Exception e)
        {
            builder.Append(e.Message);
        }

        builder.Append(Environment.NewLine);

        return builder.ToString();
    }
}