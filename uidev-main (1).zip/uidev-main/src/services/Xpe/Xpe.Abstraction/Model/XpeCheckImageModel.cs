namespace Xpe.Abstraction.Model;

using JackHenry.JHAContractTypes;

public class XPECheckImageModel : IImageItem
{
    public XPECheckImageModel(string imgNum)
    {
        ImgNum = imgNum;
    }

    public string ImgNum { get; }

    public string UniqueImageItemId
    {
        get
        {
            return ImgNum;
        }
    }
}
