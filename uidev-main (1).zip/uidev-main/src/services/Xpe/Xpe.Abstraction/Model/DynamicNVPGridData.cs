﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

using Xpe.Abstraction.Extensions;

namespace Xpe.Abstraction.Model
{
    public class DynamicNVPGridData : NVPGridData
    {
        public DynamicNVPGridData(ScreenMapGridArray table, List<ScreenField> namePairs, ScreenInfoResponse screenInfo, IFieldItemProvider fieldItemProvider, ICurrentUserInfo userInfo, ScreenMapGridArrayGrid screenmapGrid, int gridIndex)
            : base(DynamicNVPGridData.GetFields(table, screenInfo.OutputFields), screenInfo, new DynamicGridFieldItemProvider(), userInfo, gridIndex, screenmapGrid)
        {
        }

        public static List<ScreenField> GetFields(ScreenMapGridArray table, List<ScreenField5250> outputFields)
        {
            int columnLabelLineCount = 1;

            // Find out the maximum number of lines in the Column label before building Dynamic NVP Grid.
            foreach (ScreenField gridField in table.Grid.GridFields)
            {
                string columnFieldLabel = FormatDynamicColumnHeader(gridField, outputFields);

                int lineCount = 1 + Regex.Matches(columnFieldLabel, @"\\r\\n").Count;

                if (lineCount > columnLabelLineCount)
                {
                    columnLabelLineCount = lineCount;
                }
            }

            List<ScreenField> gridfields = new List<ScreenField>();

            // Process this grid like a NVP Grid. Build out all of the nvpGridFields using the grid
            // properties and then call GetNVPGrid()
            gridfields.Add(new ScreenField() { FieldCategory = ScreenMapFieldCategory.GridBegin, FieldLabel = table.Grid.GridHeader });

            foreach (ScreenField gridField in table.Grid.GridFields)
            {
                // Create a column field for the column.
                ScreenField column = gridField.Clone();
                column.FieldCategory = ScreenMapFieldCategory.Column;

                //// For converted grids we need to support the horizontal alignment, which is accomplished by the display format
                //// only if the display format is not set.
                if (string.IsNullOrWhiteSpace(column.DispFormat))
                {
                    if (!string.IsNullOrWhiteSpace(column.HorizontalAlignment))
                    {
                        if (column.HorizontalAlignment.Equals("Right", StringComparison.InvariantCultureIgnoreCase))
                        {
                            column.DispFormat = "Right Justify";
                        }
                        else if (column.HorizontalAlignment.Equals("Left", StringComparison.InvariantCultureIgnoreCase))
                        {
                            column.DispFormat = "Left Justify";
                        }
                    }
                    else if (column.IsDecimal())
                    {
                        column.DispFormat = "Right Justify";
                    }
                }

                string columnFieldLabel = FormatDynamicColumnHeader(gridField, outputFields);

                if (!string.IsNullOrEmpty(columnFieldLabel))
                {
                    column.FieldLabel = columnFieldLabel;
                }

                if (column.FieldLabel == null)
                {
                    column.FieldLabel = string.Empty;
                }

                int lineCount = 1 + Regex.Matches(column.FieldLabel, @"\\r\\n").Count;

                // Add the appropriate number of new lines.
                while (lineCount < columnLabelLineCount)
                {
                    column.FieldLabel = Environment.NewLine + column.FieldLabel;

                    lineCount++;
                }

                // If there is more than one line, then fix the new line characters.
                if (columnLabelLineCount > 1)
                {
                    column.FieldLabel = column.FieldLabel.Replace("\\r\\n", Environment.NewLine);
                }

                gridfields.Add(column);

                // Add a field to the column for every available row.
                for (int i = 0; i < table.Grid.GridPageSize * table.Grid.GridRowsPerRec; i += table.Grid.GridRowsPerRec)
                {
                    ScreenField field = gridField.Clone();
                    int row = field.Row + i;

                    // Fix the rows in linkdata expression to the current row we are on
                    if (!string.IsNullOrWhiteSpace(field.LinkDataExpression))
                    {
                        string[] expressionValues = Regex.Split(field.LinkDataExpression, "{SPACE:[1-9]?[0-9]}");

                        for (int j = 0; j < expressionValues.Length; j++)
                        {
                            if (!expressionValues[j].StartsWith("{SPACE:"))
                            {
                                expressionValues[j] = expressionValues[j].Replace(string.Format("{0}{1}", "{", field.Row.ToString("00")), string.Format("{0}{1}", "{", row.ToString("00")));
                                expressionValues[j] = expressionValues[j].Replace(string.Format(":{0}", field.Row.ToString("00")), ":" + row.ToString("00"));
                            }
                        }

                        field.LinkDataExpression = string.Join(string.Empty, expressionValues);
                    }

                    field.Row = row;

                    gridfields.Add(field);
                }
            }

            return gridfields;
        }
        public static string FormatDynamicColumnHeader(ScreenField namePair, IEnumerable<ScreenField5250> outputFields)
        {
            string expression = namePair.FieldLabel != null ? namePair.FieldLabel : string.Empty;

            if (namePair.IsLinkTypeLabel() && !string.IsNullOrEmpty(namePair.LinkDataExpression))
            {
                expression = namePair.LinkDataExpression;
            }

            List<string> fieldValues = ScreenFieldExtensions.TokenizeLinkDataExpression(expression, outputFields, false);

            if (fieldValues.Any())
            {
                // Iterate through the combined RRCCC's and get their output field values
                for (int i = 0; i < fieldValues.Count; i++)
                {
                    if (ScreenFieldExtensions.IsValidRRCCC(fieldValues[i]))
                    {
                        ScreenField5250 screen5250 = ScreenField5250Extensions.GetFieldByRRCCC(fieldValues[i], outputFields);

                        if (screen5250 != null && !string.IsNullOrEmpty(screen5250.Data))
                        {
                            int startingIndex = namePair.Col - screen5250.Col;

                            if (startingIndex >= 0)
                            {
                                int remainingLength = screen5250.Data.Length - startingIndex;

                                if (namePair.Length != null && namePair.Length < remainingLength)
                                {
                                    fieldValues[i] = screen5250.Data.Substring(startingIndex, namePair.Length);
                                }
                                else
                                {
                                    fieldValues[i] = screen5250.Data.Substring(startingIndex, remainingLength);
                                }
                            }
                            else
                            {
                                fieldValues[i] = screen5250.Data;
                            }
                        }
                        else
                        {
                            fieldValues[i] = string.Empty;
                        }
                    }
                }

                // Combine the values into one string
                StringBuilder sb = new StringBuilder();

                foreach (string value in fieldValues)
                {
                    sb.Append(value);
                }

                return sb.ToString();
            }

            return null;
        }
    }
}
