﻿namespace Xpe.Abstraction.Model;

public interface IToolbarMultiItem
{
}