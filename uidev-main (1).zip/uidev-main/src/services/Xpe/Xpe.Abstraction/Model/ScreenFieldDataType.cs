﻿namespace Xpe.Abstraction.Model;

public class ScreenFieldDataType
{
    public const string String = "String";
    public const string Decimal = "Decimal";
    public const string Date = "Date";
    public const string Time = "Time";
    public const string Int = "Int";
}