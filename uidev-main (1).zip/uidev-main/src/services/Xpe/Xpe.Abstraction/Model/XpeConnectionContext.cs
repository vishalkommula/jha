﻿using Xpe.Abstraction.Enums;

namespace Xpe.Abstraction.Model;

public class XpeConnectionContext
{
    public string UserId { get; set; }
    
    public string SessionId { get; set; }
    
    public string InstitutionNumber { get; set; }
    
    public string BankName { get; set; }
    
    public string ConnectionId { get; set; }
    
    public string KerberosToken { get; set; }
    
    public string SamlAssertion { get; set; }
}