﻿namespace Xpe.Abstraction.Model;
using System.Collections.Generic;
using System.Linq;
using Xpe.Abstraction.Extensions;
using Xpe.Abstraction.Services;

public class GridSearchToolbarItem : ToolbarItem, IToolbarItem, IToolbarMultiItem
{
    private IFieldItemProvider fieldItemProvider;
    private List<ScreenMapGridArray> gridArray;
    private IEnumerable<ScreenField5250> inputFields;
    private IEnumerable<ScreenField> namePairs;
    private IEnumerable<ScreenField5250> outputFields;
    private List<string> rrcccList;
    private List<IEditorControlProvider> searchFields = new List<IEditorControlProvider>();
    private List<IModField5250> searchInputFields = new List<IModField5250>();
    private List<IToolbarItem> toolbarItems;

    public GridSearchToolbarItem(
        List<string> rrcccList,
        IEnumerable<ScreenField> namePairs,
        IEnumerable<ScreenField5250> inputFields,
        IEnumerable<ScreenField5250> outputFields,
        List<ScreenMapGridArray> gridArray,
        IFieldItemProvider fieldItemProvider)
    {
        this.rrcccList = rrcccList;
        this.namePairs = namePairs;
        this.inputFields = inputFields;
        this.outputFields = outputFields;
        this.gridArray = gridArray;
        this.fieldItemProvider = fieldItemProvider;

        this.InitializeSearchFields();
    }

    public List<IModField5250> SearchInputFields
    {
        get
        {
            return this.searchInputFields;
        }
    }

    private void InitializeSearchFields()
    {
        foreach (string rrccc in this.rrcccList)
        {
            int row = int.Parse(rrccc.Substring(0, 2));
            int col = int.Parse(rrccc.Substring(2, 3));
            ScreenField searchField = this.namePairs.FirstOrDefault(nvp => nvp.Col == col && nvp.Row == row);
            List<ScreenField> searchFields = this.namePairs.Where(nvp => nvp.Col == col && nvp.Row == row).ToList();

            if (searchFields.Count > 1)
            {
                foreach (ScreenField field in searchFields)
                {
                    if (this.fieldItemProvider.IsFieldBestMatch(field, this.namePairs, this.inputFields, this.outputFields))
                    {
                        searchField = field;
                    }
                }
            }

            if (searchField != null)
            {
                ScreenField5250 searchField5250 = ScreenField5250Extensions.Get5250Field(searchField, this.inputFields);

                if (searchField5250 != null)
                {
                    string fieldLabel = string.Empty;

                    if (searchField.IsLinkTypeLabel())
                    {
                        fieldLabel = ScreenFieldExtensions.FormatLinkDataExpression(searchField, this.inputFields.Union(this.outputFields), false);
                    }
                    else if (this.rrcccList.Count > 1)
                    {
                        // Only set the field label using the searchField.FieldLabel if there are
                        // more than two search fields. We have to do this because the initial
                        // mapping convention didn't include setting the searchField.FieldLabel
                        // if there was only one search field. Therefore, the label of
                        // CONTROL,PSTTO and other garbage would be displayed on the screen.
                        fieldLabel = ScreenFieldExtensions.FormatDynamicLabelText(searchField, this.inputFields.Union(this.outputFields));
                    }

                    if (!string.IsNullOrWhiteSpace(fieldLabel))
                    {
                        XpeLabel label = new XpeLabel(fieldLabel.Trim(), false);
                        this.searchFields.Add(label);
                    }

                    //TODO: Implement
                    //GridSearchField gridSearchField = new GridSearchField(searchField5250, searchField, this.gridArray, this.outputFields, this.fieldItemProvider.GetCultureInfo(this.userInfo));
                    //this.searchInputFields.Add(gridSearchField);
                    //this.searchFields.Add(gridSearchField);
                }
            }
        }
    }
}
