﻿namespace Xpe.Abstraction.Model;

using System.Data;

public class XpeDataRow : DataRow
{
    internal XpeDataRow(DataRowBuilder builder, XpeGridData parent = null)
        : base(builder)
    {
        this.Parent = parent;
    }

    public ModField5250 OptionField { get; set; }

    public XpeGridData Parent { get; set; }

    public int LocationRow5250 { get; set; }
}