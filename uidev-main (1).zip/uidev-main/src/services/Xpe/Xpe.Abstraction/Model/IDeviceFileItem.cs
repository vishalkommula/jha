﻿namespace Xpe.Abstraction.Model;

public interface IDeviceFileItem
{
    string MachineName { get; }
    string ConnectionParameters { get; }
    string JWalkParameters { get; }
    string Device { get; }
    string Printer { get; }
    string DeviceName { get; set; }
    string DeviceSequence { get; set; }
    string ISeriesPrinter { get; set; }
    PrinterFileItem PrinterConfiguration { get; set; }
    string NetworkPrinter { get; set; }
    string PCPrinter { get; }
    bool IsInvalidDeviceItem { get; }
    void SetProperties();

    void SetProperties(bool jWalkUseBaseDeviceSequencing, bool reserveBaseDeviceForVertex, bool isVertexJump,
        bool skipSequencing = false);

    bool IncrementDeviceSequence(string startupResponse);
}