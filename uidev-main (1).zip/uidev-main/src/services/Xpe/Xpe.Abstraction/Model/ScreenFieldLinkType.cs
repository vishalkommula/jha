﻿namespace Xpe.Abstraction.Model;

public class ScreenFieldLinkType
{
    public const string Combined = "Combined";
    public const string Label = "Label";
    public const string AccountNumber = "Account Number";
    public const string CustomerNumber = "Customer Number";
    public const string Decimal = "Decimal";
    public const string URL = "URL";
    public const string PhoneNumber = "Phone Number";
    public const string EmailAddress = "Email Address";
    public const string GLAccountNumber = "GL Account Number";
    public const string Zip = "Zip";
    public const string Date = "Date";
    public const string PlanCode = "IRA Plan Code";
    public const string ColumnTotal = "Column Total";
    public const string Value = "Value";
    public const string Navigation = "Navigation";
    public const string KeyPressNav = "Key Press Nav";
    public const string ContinuedField = "Continued Field";
    public const string Image = "Image";
}