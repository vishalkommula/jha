﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Globalization;
using System.Linq;

using Xpe.Abstraction.Extensions;
using Xpe.Abstraction.Model.XpeFields;

namespace Xpe.Abstraction.Model;

public class NVPGridData : XpeGridData/*, IFrameworkElementProvider*/
{
    private Dictionary<int, NVPColumnInfo> columnIndexInformationDictionary = new Dictionary<int, NVPColumnInfo>();
    private Dictionary<string, NVPColumnInfo> columnNameInformationDictionary = new Dictionary<string, NVPColumnInfo>();
    private List<IModField5250> gridFieldItems;
    private int gridIndex;
    private bool isFieldsHighlighted;
    private bool isGridRowSelectEnabled;
    private System.Windows.Input.ICommand printCommand;

    public NVPGridData(List<ScreenField> gridfields, ScreenInfoResponse screenInfo, IFieldItemProvider fieldItemProvider, ICurrentUserInfo userInfo, int gridIndex, ScreenMapGridArrayGrid screenmapGrid = null)
    {
        this.ColumnNameInformationDictionary = new Dictionary<string, NVPColumnInfo>();
        this.gridFieldItems = new List<IModField5250>();
        this.ToolbarItems = new ObservableCollection<IToolbarItem>();
        this.gridIndex = gridIndex;

        var gridHeaderField = gridfields.FirstOrDefault(f => f.IsCategoryGridBegin());

        if (gridHeaderField != null && !string.IsNullOrEmpty(gridHeaderField.FieldLabel))
        {
            this.HeaderText = gridHeaderField.FormatDynamicLabelText(screenInfo.InputFields.Union(screenInfo.OutputFields));
        }

        if (screenmapGrid != null)
        {
            this.isGridRowSelectEnabled = true;
            if (screenmapGrid.GridOptionArray != null && screenmapGrid.GridOptionArray.Any())
            {
                this.GridOptions = this.GetGridOptions(screenmapGrid.GridOptionArray.ToList(), screenInfo.OutputFields);
            }
        }

        var table = new XpeDataTable(this);
        var columnFields = gridfields.Where(f => f.IsCategoryColumn());
        int columnNum = 0;

        // Add the columns to the grid.
        foreach (ScreenField columnfield in columnFields)
        {
            // Don't add the option field to the grid.
            if (columnfield.OptionField)
            {
                continue;
            }

            NVPColumnInfo columnInfo = new NVPColumnInfo();
            columnInfo.ColumnName = string.Format("Field{0}", columnNum.ToString());
            columnInfo.IsLabelField = false;
            columnInfo.Alignment = columnfield.DispFormat;

            if (columnfield.FieldLabel != null)
            {
                columnInfo.ColumnLabel = columnfield.FormatDynamicLabelText(screenInfo.InputFields.Union(screenInfo.OutputFields));
            }
            else if (columnfield.Row != 0 && columnfield.Col != 0)
            {
                var field5250 = this.GetFieldByRowCol(columnfield.Row, columnfield.Col, screenInfo.OutputFields);

                if (field5250 != null && field5250.Data != null)
                {
                    columnInfo.ColumnLabel = field5250.Data.Trim();
                }
            }

            this.columnIndexInformationDictionary[columnNum] = columnInfo;
            this.ColumnNameInformationDictionary[columnInfo.ColumnName] = columnInfo;

            DataColumn dataColumn = new DataColumn(columnInfo.ColumnName, typeof(XpeDataCellProvider));
            dataColumn.Caption = columnInfo.ColumnLabel;

            table.Columns.Add(dataColumn);
            columnNum++;
        }

        int numberOfRows = 0;
        int rowIndex = 0;
        columnNum = -1;

        // This grid is built vertically in column/row sequential order. e.g. The first column is
        // built starting at the first row until the column is complete. The next column is built
        // starting at the first row until the column is complete.
        foreach (ScreenField gridField in gridfields)
        {
            // If we come across a column, start the row counter over again.
            if (gridField.IsCategoryColumn())
            {
                rowIndex = 0;

                // Don't increment column for the Option field since it isn't displayed in the grid.
                if (!gridField.OptionField)
                {
                    columnNum++;
                }
            }
            else if (gridField.IsCategoryField() && !gridField.IsDisplayFormatIgnored())
            {
                // Create a row if it doesn't exist.
                if (table.Rows.Count < rowIndex + 1)
                {
                    table.Rows.Add(table.NewRow());
                }

                // Get the row
                var row = table.Rows[rowIndex] as XpeDataRow;

                // When the field doesn't have a row or column, use the label that is defined on it.
                if (gridField.Row == 0 && gridField.Col == 0 && (string.IsNullOrEmpty(gridField.LinkType) || gridField.IsLinkTypeLabel()))
                {
                    if (gridField.IsLinkTypeLabel())
                    {
                        gridField.FieldLabel = ScreenFieldExtensions.FormatLinkDataExpression(gridField, screenInfo.AllFields, false);
                    }
                    else
                    {
                        gridField.FieldLabel = gridField.FormatDynamicLabelText(screenInfo.AllFields);
                    }

                    string label = gridField.FieldLabel != null ? gridField.FieldLabel : string.Empty;

                    if (columnNum >= 0 && columnNum < table.Columns.Count)
                    {
                        row[columnNum] = new XpeScreenFieldItem(new ScreenField5250(null, ScreenField5250Type.OutputField, 0, 0, 0, label.Length, label, 0), gridField, CultureInfo.InvariantCulture, screenInfo.OutputFields);
                    }
                    else
                    {
                        throw new Exception("Column definitions are missing or out of order for NVP Grid.");
                    }

                    if (label.Length > 0)
                    {
                        this.columnIndexInformationDictionary[columnNum].IsLabelField = true;
                    }

                    if (rowIndex >= numberOfRows)
                    {
                        numberOfRows = rowIndex + 1;
                    }
                }
                else
                {
                    var field5250 = this.GetFieldByRowCol(gridField.Row, gridField.Col, screenInfo.InputFields, screenInfo.OutputFields);

                    if (field5250 != null || (!string.IsNullOrEmpty(gridField.LinkType) && (gridField.IsLinkTypeValue() || gridField.IsLinkTypeNavigation())))
                    {
                        // If we find a screenField5250, set the numberofRows to the rowIndex +
                        // 1. We are keeping track of this so that we can remove empty rows after
                        // we are done building the table.
                        if (rowIndex >= numberOfRows)
                        {
                            numberOfRows = rowIndex + 1;
                        }

                        if (gridField.OptionField)
                        {
                            var modField = new ModField5250(field5250);
                            row.OptionField = modField;
                            this.gridFieldItems.Add(modField);
                            rowIndex++;
                            continue;
                        }

                        // Make the screens with dynamic label column values that end in
                        // "......." look better
                        if (field5250 != null && columnNum == 0 && field5250.IsOutputField() && field5250.Data != null && field5250.Data.EndsWith(".."))
                        {
                            field5250.Data = field5250.Data.TrimEnd('.');
                        }

                        XpeDataCellProvider fieldItem = fieldItemProvider.GetFieldItem(gridField, field5250, gridfields, screenInfo, userInfo, screenmapGrid);

                        // Only need to set highlighting if there is a 5250 field.
                        if (fieldItem != null && field5250 != null)
                        {
                            XpeField xpeField = fieldItem as XpeField;

                            if (xpeField != null)
                            {
                                if (xpeField.IsHighlightedStandard)
                                {
                                    this.isFieldsHighlighted = true;
                                }
                            }
                        }

                        row[columnNum] = fieldItem;

                        if (fieldItem is IModField5250)
                        {
                            this.gridFieldItems.Add(fieldItem as IModField5250);
                        }
                    }
                }

                rowIndex++;
            }
        }

        // Remove rows that don't have any data.
        while (table.Rows.Count > numberOfRows)
        {
            table.Rows.RemoveAt(table.Rows.Count - 1);
        }

        if (string.IsNullOrEmpty(this.HeaderText))
        {
            this.HeaderText = "Additional Information";
        }

        this.DataTable = table;
    }

    public override XpeDataTable DataTable
    {
        get;
        set;
    }

    public override IEnumerable<IModField5250> GridFieldItems
    {
        get
        {
            return this.gridFieldItems;
        }
    }

    public bool IsToolbarVisible
    {
        get
        {
            return (this.GridOptions != null && this.GridOptions.Any()) || this.NextDataCommand != null || this.PreviousDataCommand != null;
        }
    }

    public bool SupportsExcelExport
    {
        get
        {
            return false;
        }
    }

    public bool SupportsPDFExport
    {
        get
        {
            return false;
        }
    }

    public bool SupportsSaveAsExcel
    {
        get
        {
            return false;
        }
    }

    public ObservableCollection<IToolbarItem> ToolbarItems
    {
        get;
        set;
    }

    protected Dictionary<string, NVPColumnInfo> ColumnNameInformationDictionary
    {
        get;
        set;
    }
}