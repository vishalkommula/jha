﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using JackHenry.JHAContractTypes;

namespace Xpe.Abstraction.Model;

public class PrvdInstInfoModel : IComparable<PrvdInstInfoModel>
{
    private IIAdapter iadapter;
    private string releaseLevelParsed;
    private int releaseLevelSaved = -1;
    private int releaseMajor = -1;

    public PrvdInstInfoModel()
    {
        ShowInsitutionNumberInDisplayName = true;
    }

    public PrvdInstInfoModel(PrvdInstInfo_CType prvdInstInfo, BankingAlias alias, bool? isXperienceEnabled = null)
    {
        PrvdInstInfo = prvdInstInfo;
        Alias = alias;
        ShowInsitutionNumberInDisplayName = true;
    }

    public bool ShowInsitutionNumberInDisplayName { get; set; }

    public BankingAlias Alias { get; set; }

    public SLInt_Type Branch
    {
        get => PrvdInstInfo.Branch;
        set => PrvdInstInfo.Branch = value;
    }

    public string DetailsTooltip =>
        new StringBuilder()
            .AppendLine("Name:\t\t" + InstitutionNumber)
            .AppendLine("Description:\t" + PrvdInstInfo.PrvdInstName)
            .AppendLine("Environment:\t" + Environment)
            .AppendLine("Number:\t\t" + InstitutionNumber)
            .AppendLine("Is Default:\t" + IsDefault)
            .ToString();

    public string DisplayName => ShowInsitutionNumberInDisplayName
        ? $"{PrvdInstInfo.PrvdInstId.Value} - {PrvdInstInfo.PrvdInstName.GetValueOrDefault()}"
        : PrvdInstInfo.PrvdInstName.GetValueOrDefault();

    public string Environment => PrvdInstInfo?.PrvdInstEnv;

    public int InstitutionNumber
    {
        get
        {
            try
            {
                return Convert.ToInt32(PrvdInstInfo.PrvdInstId);
            }
            catch
            {
                return Convert.ToInt32(
                    Regex.Replace(PrvdInstInfo.PrvdInstId, "[^0-9.]", string.Empty));
            }
        }
    }

    public bool IsDefault { get; set; } = false;

    public bool IsSelected { get; set; } = false;

    public bool? IsXperienceEnabled => true;

    public bool ActivatePasswordReset { get; set; }

    public SLString_Type PrvdInstEnv
    {
        get => PrvdInstInfo.PrvdInstEnv;

        set => PrvdInstInfo.PrvdInstEnv = value;
    }

    public SLString_Type PrvdInstId
    {
        get => PrvdInstInfo.PrvdInstId;

        set => PrvdInstInfo.PrvdInstId = value;
    }

    public PrvdInstInfo_CType PrvdInstInfo { get; set; } = new();

    public SLString_Type PrvdInstName
    {
        get => PrvdInstInfo.PrvdInstName;

        set => PrvdInstInfo.PrvdInstName = value;
    }

    public SLString_Type PrvdInstProd
    {
        get => PrvdInstInfo.PrvdInstProd;

        set => PrvdInstInfo.PrvdInstProd = value;
    }

    public SLString_Type PrvdInstRtId
    {
        get => PrvdInstInfo.PrvdInstRtId;

        set => PrvdInstInfo.PrvdInstRtId = value;
    }

    public ParmRec_CType[] PrvdInstSecGroupArray
    {
        get => PrvdInstInfo.PrvdInstSecGroupArray;

        set => PrvdInstInfo.PrvdInstSecGroupArray = value;
    }

    public SLString_Type ReleaseLvl
    {
        get => PrvdInstInfo.ReleaseLvl;

        set => PrvdInstInfo.ReleaseLvl = value;
    }

    public int ReleaseLevelMajor => GetReleaseLevelMajor();

    public string SerializableKey => InstitutionNumber.ToString();

    public IIAdapter IAdapter
    {
        get
        {
            if (iadapter == null && PrvdInstInfo.AdptPort > 0)
            {
                iadapter = new IAdapterModel(PrvdInstInfo.AdptInstId,
                    PrvdInstInfo.AdptSslCert?.Value.ToLower() == "true", PrvdInstInfo.AdptPortKey,
                    PrvdInstInfo.AdptPort, PrvdInstInfo.AdptSvr,
                    PrvdInstInfo.ReqSAMLAuth?.Value.ToLower() == "true");
            }

            return iadapter;
        }
    }

    public int CompareTo(PrvdInstInfoModel other)
    {
        if (other == null)
        {
            return -1;
        }

        if (string.Compare(other.Environment, Environment, StringComparison.OrdinalIgnoreCase) != 0)
        {
            return -2;
        }

        if (other.InstitutionNumber != InstitutionNumber)
        {
            return -3;
        }

        if (string.Compare(other.PrvdInstInfo.AdptInstId.GetValueOrDefault(),
                PrvdInstInfo.AdptInstId.GetValueOrDefault(), StringComparison.OrdinalIgnoreCase) != 0)
        {
            return -4;
        }

        return 0;
    }

    public override string ToString()
    {
        return DisplayName;
    }

    public string GetReleaseLevel()
    {
        if (string.IsNullOrWhiteSpace(ReleaseLvl))
        {
            return null;
        }

        return releaseLevelParsed ??= Regex.Replace(ReleaseLvl.Value, "[^0-9]", string.Empty);
    }

    public int GetReleaseLevelMajor()
    {
        if (releaseMajor != -1)
        {
            return releaseMajor;
        }

        releaseMajor = 0;
        var fullReleaseLevel = GetReleaseLevelAsInt().ToString();

        if (fullReleaseLevel.Length > 4)
        {
            fullReleaseLevel = fullReleaseLevel[..4];
        }

        return int.TryParse(fullReleaseLevel, out releaseMajor) ? releaseMajor : 0;
    }

    public int GetReleaseLevelAsInt()
    {
        return GetReleaseLevelAsInt(ReleaseLvl);
    }

    public void AddInstitutionIAdapterInfo(AdptConnInfo_CType adptConnInfo, string server)
    {
        PrvdInstInfo.AdptInstId = adptConnInfo.AdptInstId;
        PrvdInstInfo.AdptPort = adptConnInfo.AdptPort;
        PrvdInstInfo.AdptPortKey = adptConnInfo.AdptPortKey;
        PrvdInstInfo.AdptSslCert = adptConnInfo.AdptSslCert;
        PrvdInstInfo.AdptSvr = server;
        PrvdInstInfo.ReqSAMLAuth = adptConnInfo.ReqSAMLAuth;
    }

    private int GetReleaseLevelAsInt(SLString_Type releaseLvl)
    {
        try
        {
            if (releaseLvl == null || releaseLevelSaved != -1)
            {
                return releaseLevelSaved;
            }

            var input = releaseLvl.Value;

            var rel = GetReleaseLevel();

            if (rel.Length < 6)
            {
                rel = rel.PadRight(6, '0');
            }
            else if (rel.Length > 6)
            {
                rel = rel[..6];
            }

            if (!int.TryParse(rel, out var num))
            {
                return releaseLevelSaved;
            }

            releaseLevelSaved = num;

            return releaseLevelSaved;
        }
        catch
        {
            return 0;
        }
    }
}