﻿using System;

namespace Xpe.Abstraction.Model;

public class PropertyChange : ICloneable
{
    public PropertyChange()
    {
    }

    public PropertyChange(string propertyName, object oldValue, object newValue, object originalSource,
        string description = null)
    {
        PropertyName = propertyName;
        OldValue = oldValue;
        NewValue = newValue;
        OldValueFormatted = oldValue;
        NewValueFormatted = newValue;
        OriginalSource = originalSource;
        SourceType = originalSource != null ? originalSource.GetType().Name : null;
        Description = description;
    }

    public string Description { get; set; }

    public object NewValue { get; set; }

    public object NewValueFormatted { get; set; }

    public object OldValue { get; set; }

    public object OldValueFormatted { get; set; }

    public object OriginalSource { get; set; }

    public string PropertyName { get; set; }

    public string SourceType { get; set; }

    public object Clone()
    {
        var value = new PropertyChange();

        value.PropertyName = PropertyName;
        value.OldValue = OldValue;
        value.NewValue = NewValue;
        value.OriginalSource = OriginalSource;
        value.SourceType = SourceType;

        return value;
    }
}