﻿using Xpe.Abstraction.Enums;

namespace Xpe.Abstraction.Model;

public record KeyPress(Key Key, Key Modifier);