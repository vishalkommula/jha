﻿using System;
using System.Collections.Generic;
using JackHenry.JHAContractTypes;

namespace Xpe.Abstraction.Model;

public interface IInquiryResponse<TPayload> : IResponse<TPayload>
{
    IEnumerable<IResultInfoMessage> Errors { get; }

    IEnumerable<IResultInfoMessage> Faults { get; }

    IEnumerable<IResultInfoMessage> Warnings { get; }

    IEnumerable<IResultInfoMessage> Overrides { get; }

    IEnumerable<IResultInfoMessage> UndefinedErrors { get; }

    bool HasFaults { get; }

    bool HasWarnings { get; }

    bool HasOverrides { get; }

    bool HasMalady { get; }

    bool HasUndefinedErrors { get; }

    bool HasMaladyExcludeWarnings { get; }

    List<IResultInfoMessage> AllMessages { get; }

    bool HasResultErrors { get; }

    bool MoreRecords { get; }

    string Cursor { get; }

    int TotalRecords { get; }

    bool ResponseStatSuccess { get; }

    string FaultsToString();

    string WarningsToString();

    string OverridesToString();

    string UndefinedErrorsToString();

    string ErrorsToString();

    string AllMessagesToString();

    void AddMessages(IEnumerable<IResultInfoMessage> messages);
}