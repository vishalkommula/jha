﻿namespace Xpe.Abstraction.Model;

public interface IXtraJesLogInfo
{
    string MessageId { get; }

    string ProcessId { get; }

    string ThreadId { get; }
}