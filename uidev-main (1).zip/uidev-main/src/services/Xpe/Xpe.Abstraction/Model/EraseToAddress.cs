﻿using System.Collections.Generic;

namespace Xpe.Abstraction.Model;

public class EraseToAddress
{
    public EraseToAddress(Queue<byte> snaRecord)
    {
        Row = snaRecord.Dequeue();
        Column = snaRecord.Dequeue();
        Length = snaRecord.Dequeue();
        ExtendedAttributes = new List<ExtendedAttribute>();

        // Get all of the Extended Attributes.
        for (var i = 0; i < Length - 1; i++) ExtendedAttributes.Add((ExtendedAttribute) snaRecord.Dequeue());
    }

    public List<ExtendedAttribute> ExtendedAttributes { get; }

    public int Length { get; }

    public int Row { get; }

    public int Column { get; }
}