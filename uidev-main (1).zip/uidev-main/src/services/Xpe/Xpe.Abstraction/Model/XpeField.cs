﻿namespace Xpe.Abstraction.Model;

public abstract class XpeField : XpeDataCellProvider, IFieldItem
{
    public abstract bool IsReadOnly
    {
        get;
    }

    public abstract bool IsItemDisplayed
    {
        get;
        protected set;
    }

    public bool IsFocused
    {
        get;
        protected set;
    }

    public bool IsHighlightedStandard
    {
        get;
        set;
    }

    public bool IsHighlightedRed
    {
        get;
        set;
    }

    public bool IsHighlightedBlue
    {
        get;
        set;
    }

    public CursorLocation CursorLocation
    {
        get;
        protected set;
    }

    public string FieldID
    {
        get;
        protected set;
    }

    public string ScreenFieldHelpId
    {
        get;
        set;
    }
}