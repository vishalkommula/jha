﻿using System;

namespace Xpe.Abstraction.Model;

public class ColumnInfo
{
    public ColumnInfo(string name)
    {
        this.Name = name;
    }

    public string Name
    {
        get;
        set;
    }

    public string Label
    {
        get;
        set;
    }

    public bool AllowEdit
    {
        get;
        set;
    }

    public string BindingPath
    {
        get;
        set;
    }

    public string EditorMask
    {
        get;
        set;
    }

    public int MaxLength
    {
        get;
        set;
    }

    public string CellValuePresenterStyleKey
    {
        get;
        set;
    }

    public string SummaryText
    {
        get;
        set;
    }

    public string CurrencyFormat
    {
        get;
        set;
    }

    public bool IsPromptable
    {
        get;
        set;
    }
}