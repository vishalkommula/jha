﻿namespace Xpe.Abstraction.Model;

public class ScreenFieldDisplayFormat
{
    public const string Ignore = "Ignore";
    public const string Currency = "$";
    public const string Rate = "%";
    public const string DateMMDDYY = "MMDDYY";
    public const string DateDDMMYY = "DDMMYY";
    public const string DateYYMMDD = "YYMMDD";
    public const string DateYYDDD = "YYDDD";
    public const string DateYYYYMMDD = "YYYYMMDD";
    public const string DateMMDDYYYY = "MMDDYYYY";
    public const string NegativePrefixCurrency = "Negative Prefix $ (-$12.34)";
    public const string NegativePrefixDecimal = "Negative Prefix Decimal (-12.34)";
    public const string NegativePrefixRate = "Negative Prefix % (-12.34%)";
    public const string Notification = "Notification";
    public const string Warning = "Warning";
    public const string Error = "Error";
    public const string Blank = "Blank";
    public const string Zip = "Zip";
    public const string Phone = "Phone";
    public const string NoWrap = "No Wrap";
    public const string List = "ListOptions";
    public const string TimeMilitaryHHMMSS = "HH:MM:SS";
    public const string TimeMilitaryHHMM = "HH:MM";

    public static bool IsBlank(string displayFormat)
    {
        return displayFormat == Blank;
    }

    public static bool IsMonthDayYearDate(string displayFormat)
    {
        return displayFormat == DateMMDDYY ||
               displayFormat == DateDDMMYY ||
               displayFormat == DateYYMMDD ||
               displayFormat == DateYYYYMMDD ||
               displayFormat == DateMMDDYYYY;
    }

    public static bool IsTwoDigitYear(string displayFormat)
    {
        return displayFormat == DateMMDDYY ||
               displayFormat == DateDDMMYY ||
               displayFormat == DateYYMMDD;
    }

    public static bool IsJulianDate(string displayFormat)
    {
        return displayFormat == DateYYDDD;
    }

    public static bool IsIgnored(string displayFormat)
    {
        return displayFormat == Ignore;
    }

    public static bool IsCurrency(string displayFormat)
    {
        return displayFormat == Currency;
    }

    public static bool IsRate(string displayFormat)
    {
        return displayFormat == Rate;
    }

    public static bool IsTime(string displayFormat)
    {
        return displayFormat == TimeMilitaryHHMM || displayFormat == TimeMilitaryHHMMSS;
    }

    public static bool IsNegativePrefix(string displayFormat)
    {
        return displayFormat == NegativePrefixCurrency || displayFormat == NegativePrefixDecimal ||
               displayFormat == NegativePrefixRate;
    }
}