﻿// -----------------------------------------------------------------------
// <copyright file="ModField5250.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2015 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

using System.Collections.Generic;
using Xpe.Abstraction.Extensions;

namespace Xpe.Abstraction.Model;

public class ModField5250 : IModField5250
{
    private readonly ScreenField5250 screenField5250;
    private string fieldValue;

    public ModField5250(ScreenField5250 screenField5250)
    {
        this.screenField5250 = screenField5250;
        fieldValue = screenField5250.Data;
        CursorLocation = new CursorLocation(screenField5250.Row, screenField5250.Col);
        IsFocused = screenField5250.IsFocused;
    }

    public CursorLocation CursorLocation { get; }

    public bool IsReadOnly => !screenField5250.IsInputField();

    public bool IsFocused { get; }

    public string FieldValue
    {
        get => fieldValue;

        set
        {
            if (fieldValue != value)
            {
                fieldValue = value;
            }
        }
    }

    public void AddToChangedList(List<ScreenField5250> changedList, bool includeModifiedDataTagField)
    {
        if (screenField5250.Data != FieldValue)
        {
            screenField5250.Data = FieldValue;
            changedList.Add(screenField5250);
        }
        else if (includeModifiedDataTagField)
        {
            if (screenField5250.FieldFormatWord != null && screenField5250.FieldFormatWord.ModifiedDataTag)
            {
                changedList.Add(screenField5250);
            }
        }
    }
}