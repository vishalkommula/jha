﻿namespace Xpe.Abstraction.Model;

public class ScreenMapFieldCategory
{
    public const string Header = "Header";
    public const string Field = "Field";
    public const string AddressType = "Address Type";
    public const string Message = "Message";
    public const string Banner = "Banner";
    public const string CurrentPage = "Current Page";
    public const string TotalPages = "Total Pages";
    public const string BankName = "Bank Name";
    public const string PageTitle = "Page Title";
    public const string PageMode = "Page Mode";
    public const string GridBegin = "Grid Begin";
    public const string GridEnd = "Grid End";
    public const string Column = "Column";
    public const string Sentence = "Sentence";
    public const string SentenceHeader = "Sentence Header";
    public const string Search = "Search";
}