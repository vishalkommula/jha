﻿namespace Xpe.Abstraction.Model;

using System;
using System.Data;

public class XpeDataTable : DataTable
{
    public XpeDataTable(XpeGridData parent)
        : base()
    {
        this.Parent = parent;
    }

    public XpeGridData Parent
    {
        get;
        protected set;
    }

    protected override Type GetRowType()
    {
        return typeof(XpeDataRow);
    }

    protected override DataRow NewRowFromBuilder(DataRowBuilder builder)
    {
        return new XpeDataRow(builder, this.Parent);
    }
}