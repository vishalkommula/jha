﻿namespace Xpe.Abstraction.Enums;

public enum MessagesFilterTypes
{
    All,
    Customer,
    Account,
    Collateral,
    Collections,
    CustomerAlerts,
    AccountAlerts,
    Alerts,
    ODComments,
    PassPortAlerts,
    Plan
}