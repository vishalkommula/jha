﻿namespace Xpe.Abstraction.Enums;

public enum CoreParmDisplayType
{
    Description,
    Value,
    DescriptionAndValue,
    None
}