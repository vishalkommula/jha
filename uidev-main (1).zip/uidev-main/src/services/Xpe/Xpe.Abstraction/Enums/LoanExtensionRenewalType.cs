﻿namespace Xpe.Abstraction.Enums;

public enum LoanExtensionRenewalType
{
    Renewal,
    Extension
}