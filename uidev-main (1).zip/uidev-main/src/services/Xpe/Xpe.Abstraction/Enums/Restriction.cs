﻿namespace Xpe.Abstraction.Enums;

public enum Restriction
{
    Undefined,
    NoAccess,
    NoAccessPart,
    ReadWrite,
    ReadWritePart,
    ReadOnly,
    ReadOnlyPart,
    Hid
}