﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum ActivityIntention
{
    [Description("Read Only")] ReadOnly,

    [Description("Update")] Upd,

    [Description("Delete")] Dlt
}