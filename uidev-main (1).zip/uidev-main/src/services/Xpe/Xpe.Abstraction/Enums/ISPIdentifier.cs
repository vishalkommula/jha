﻿using System;
using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

[Serializable]
public enum ISPIdentifier
{
    [Description("NetTeller")] Netteller,

    [Description("Pay from Account")] Account,

    [Description("Pay from Account and Email Address ")]
    AccountAndEmail,

    [Description("Pay from Account and Tax ID")]
    AccountAndTaxId
}