﻿namespace Xpe.Abstraction.Enums;

public enum EditFormType
{
    RecordDetail,
    NonRecordDetail
}