﻿namespace Xpe.Abstraction.Enums;

public enum ErrorCategory
{
    Warning,
    Error,
    Fault,
    Override
}