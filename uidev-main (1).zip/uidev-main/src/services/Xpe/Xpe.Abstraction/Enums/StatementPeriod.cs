﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum StatementPeriod
{
    [Description("")] None,

    [Description("Current Cycle")] SinceLastStmtDate,

    [Description("Date Range")] DateRange,

    [Description("Last 7 days")] LastSevenDays,

    [Description("Last 14 days")] LastFourteenDays,

    [Description("Last 30 days")] LastThirtyDays,

    [Description("Last 60 days")] LastSixtyDays,

    [Description("Expired History")] PriorLastStmtDate,

    [Description("All History")] All
}