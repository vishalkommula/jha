﻿namespace Xpe.Abstraction.Enums;

public enum LookupType
{
    Both,
    Account,
    Customer
}