﻿namespace Xpe.Abstraction.Enums;

public enum SvcDictSvcPrvdFldType
{
    Integer,
    String,
    Date,
    DateTime,
    Time,
    Decimal,
    URI,
    Boolean
}