﻿namespace Xpe.Abstraction.Enums;

public enum LoanExtRenUpdateSoldLoanType
{
    Update,
    Commit,
    Cancel
}