﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum SvcDictVisualStyleType
{
    [Description("Hide Field When")] Hide,

    [Description("Show Field When")] Show,

    [Description("All Fields Hide Field When")]
    HideAllFields,

    [Description("All Fields Show Field When")]
    ShowAllFields,

    [Description("Highlight Only When")] Highlight,

    [Description("Go To Related Function")]
    Function,

    [Description("Go To Related Function When")]
    Related
}