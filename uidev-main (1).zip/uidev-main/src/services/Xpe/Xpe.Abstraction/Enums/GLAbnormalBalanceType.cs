﻿namespace Xpe.Abstraction.Enums;

public enum GLAbnormalBalanceType
{
    Credit,
    Debit,
    Negative,
    None
}