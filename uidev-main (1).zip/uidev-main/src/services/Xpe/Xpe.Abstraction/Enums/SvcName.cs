﻿namespace Xpe.Abstraction.Enums;

public enum SvcName
{
    CustAdd,
    CustRelAdd,
    XferAdd,
    TaxPlnAdd,
    TaxPlnBenfAdd,
    AcctAdd,
    StopChkAdd,
    TrnAdd,
    IdVerifyAdd,
    CollatTrackItemAdd,
    CollatTrackDocAdd,
    RealEstatePropAdd,
    LOCAdd,
    EscrwAdd,
    FASB91Add,
    LnAcctAdd,
    ACHXferAdd,
    LnPmtSchedAdd,
    CrBurInfoAdd,
    CustMsgAdd,
    LnAppRgtrAdd,
    TeleXferAdd,
    FutXferAdd,
    GLBatchTrnAdd,
    GLReconParmSrch,
    GLReconParmMod,
    GLReconParmInq,
    GLRecon
}