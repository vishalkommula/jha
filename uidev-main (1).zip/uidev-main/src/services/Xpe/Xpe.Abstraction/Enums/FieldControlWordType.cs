﻿namespace Xpe.Abstraction.Enums;

public enum FieldControlWordType : byte
{
    // Need to look at both bytes here and extend this according to table 49 in the documentation.
    EntryFieldResequencing = 0x80,
    MagneticStripeOrLightPen = 0x81,
    Ideographic = 0x82,
    Transparency = 0x84,
    ForwardEdgeTrigger = 0x85,
    ContinuedEntry = 0x86,
    CursorProgression = 0x88,
    Highlighted = 0x89,
    PointerDevice = 0x8a,
    SelfCheck = 0xb1
}