﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum DateKeyWords
{
    [Description("Today's Date")] TODAY,

    [Description("Next processing Date")] NPDATE,

    [Description("Last Processing Date")] LPDATE,

    BLANK
}