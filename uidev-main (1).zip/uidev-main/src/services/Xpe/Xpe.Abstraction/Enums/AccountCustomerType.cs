﻿namespace Xpe.Abstraction.Enums;

public enum AccountCustomerType
{
    Customer,
    Account
}