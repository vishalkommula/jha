﻿namespace Xpe.Abstraction.Enums;

public enum PadType
{
    Left,
    Rigth
}