﻿using System;

namespace Xpe.Abstraction.Enums;

[Serializable]
public enum FavoriteCenterState
{
    ShowAll,
    ShowCustomers,
    ShowAccounts,
    ShowRecent
}