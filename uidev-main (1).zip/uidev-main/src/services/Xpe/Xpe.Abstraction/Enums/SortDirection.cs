﻿namespace Xpe.Abstraction.Enums;

public enum SortDirection
{
    Ascending = 1,

    /// <summary>Sort Descending</summary>
    Descending = 2
}