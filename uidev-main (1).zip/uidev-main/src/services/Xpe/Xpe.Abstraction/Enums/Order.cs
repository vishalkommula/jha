﻿namespace Xpe.Abstraction.Enums;

public enum Order : byte
{
    SetBufferAddress = 0x11, // 17
    InsertCursor = 0x13, // 19
    MoveCursor = 0x14, // 20
    RepeatToAddress = 0x02, // 2
    EraseToAddress = 0x03, // 3
    StartOfHeader = 0x01, // 1
    TransparentData = 0x10, // 16
    WriteExtendedAttribute = 0x12, // 18
    StartOfField = 0x1D, // 29
    WriteToDisplayStructuredField = 0x15 // 21
}