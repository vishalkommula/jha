﻿namespace Xpe.Abstraction.Enums;

public enum CollatTrackAccountType
{
    Account,
    Customer,
    CustomerAndAccount
}