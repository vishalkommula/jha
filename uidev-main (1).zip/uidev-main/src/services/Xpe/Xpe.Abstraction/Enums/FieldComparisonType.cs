﻿namespace Xpe.Abstraction.Enums;

public enum FieldComparisonType
{
    Moved,
    MovedDown,
    MovedUp,
    Removed,
    Added,
    NotSet
}