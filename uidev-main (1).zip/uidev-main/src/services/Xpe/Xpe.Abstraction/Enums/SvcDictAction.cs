﻿namespace Xpe.Abstraction.Enums;

public enum SvcDictAction
{
    Import,
    Export,
    ImportHelp,
    Create
}