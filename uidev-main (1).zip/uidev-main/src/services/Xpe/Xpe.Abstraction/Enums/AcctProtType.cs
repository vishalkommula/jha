﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum AcctProtType
{
    All,

    [Description("Sweeps")] Sweep,

    [Description("Bounce")] Bounce,

    [Description("Smart EIP")] SmartEIP,

    [Description("OD Limit")] ODLimit,

    [Description("Line of Credit")] LOC
}