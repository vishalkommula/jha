﻿namespace Xpe.Abstraction.Enums;

public enum XpeViewType
{
    Standalone,
    RelatedFunction,
    Dialog
}
