﻿namespace Xpe.Abstraction.Enums;

public enum PrintFontTypes
{
    None,
    Bold,
    Italic,
    Underline
}