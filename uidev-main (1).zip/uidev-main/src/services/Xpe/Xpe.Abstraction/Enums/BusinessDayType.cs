﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum BusinessDayType
{
    [Description("Today")] Today,

    [Description("Next Day")] NextDay
}