﻿namespace Xpe.Abstraction.Enums;

public enum Jha5250FieldType
{
    Unknown,
    FieldFormatWord,
    FieldControlWord,
    Attribute
}