﻿namespace Xpe.Abstraction.Enums;

public enum EnrollmentApplicationType
{
    VR
}