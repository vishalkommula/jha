﻿namespace Xpe.Abstraction.Enums;

public enum ProdActionType
{
    AllProducts,
    Default,
    Select
}