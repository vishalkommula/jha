﻿namespace Xpe.Abstraction.Enums;

/// Service default filter
/// </summary>
public enum SvcDftFilter
{
    Actype,
    Acctno,
    StopType,
    Application,
    FromAcType,
    FromAcctNo,
    LoanType,
    UserStatusCode,
    Plan,
    WireAcctId,
    WireAcctType,
    WireFuncType,
    WireType,
    WireSubType,
    LnFeeType,
    AcctId,
    AcctType,
    LnFeeCode,
    EscrwAddType,
    LOCAcctId,
    LOCCustId
}