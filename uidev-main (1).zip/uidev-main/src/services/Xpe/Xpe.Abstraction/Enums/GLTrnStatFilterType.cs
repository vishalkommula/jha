﻿namespace Xpe.Abstraction.Enums;

public enum GLTrnStatFilterType
{
    All,
    Active,
    Resolved,
    NotSet
}