﻿namespace Xpe.Abstraction.Enums;

public enum DisplayErrorAs
{
    Error,
    Exception,
    Validation,
    Warning,
    Information,
    ExceptionOnly,
    NotificationError,
    NoDisplay
}