﻿using System;

namespace Xpe.Abstraction.Enums;

[Serializable]
public enum PrintCategory
{
    None,
    AccountInfo,
    AccountNumber,
    AccountNumberName,
    AccountNumberProduct,
    BankName,
    BankNumber,
    BankInfo,
    PageNumber,
    CustomerInfo,
    CustomerNumber,
    CustomerNumberName,
    CustomerNumberType,
    DateAndTimeLong,
    DateAndTimeShort,
    DateLong,
    DateShort,
    Title
}