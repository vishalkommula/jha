﻿namespace Xpe.Abstraction.Enums;

/// <summary>
///     Service dictionary file type
/// </summary>
public enum SvcDictFileType
{
    Xml,
    Csv
}