﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum SvcDictFieldUsage
{
    [Description("Email Address")] EMAIL,
    [Description("Web URL Address")] URL,
    [Description("Account")] ACCT,
    [Description("String Concatenation")] CONCAT,

    [Description("Calculated Concatenation")]
    CALC,
    [Description("System")] SYSTEM,
    [Description("Banner")] BANNER,
    [Description("Date Calculation")] DATECALC
}