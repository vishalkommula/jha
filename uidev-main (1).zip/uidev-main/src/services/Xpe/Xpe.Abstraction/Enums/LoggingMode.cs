namespace Xpe.Abstraction.Enums;

public enum LoggingMode
{
    None,
    Network,
    NetworkAndLocal,
    LocalOnly_ShouldNotBeUsedUnlessNetworkIssues
}