﻿using System.ComponentModel;

namespace Xpe.Abstraction.Enums;

public enum TranType
{
    [Description("Debit")] D,

    [Description("Credit")] C,

    [Description("All")] A
}