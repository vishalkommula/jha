﻿namespace Xpe.Abstraction.Enums;

public enum MessageTypes
{
    Undefined,
    Message,
    Collections,
    Collateral,
    Alert,
    ExcessODComment,
    PassPort,
    Plan,
    Main
}