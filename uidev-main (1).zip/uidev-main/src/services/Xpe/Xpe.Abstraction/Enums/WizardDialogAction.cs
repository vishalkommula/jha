﻿namespace Xpe.Abstraction.Enums;

public enum WizardDialogAction
{
    Commit,
    Cancel,
    Complete
}