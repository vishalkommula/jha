﻿namespace Xpe.Abstraction.Enums;

public enum EnterpriseAuditEventCodes
{
    AuditedCommand = 20,
    AuditedObjectAccess = 30,
    AuditedObjectChanges = 40,
    AuthorityChanges = 50,
    AuthorityFailure = 60,
    ChangesToSecurityAccount = 110,
    FailedAuthenticationLoginAttempt = 130,
    JobApplicationExecution = 160,
    AuditedObjectCreated = 190,
    AuditedObjectDeleted = 200,
    AuditedObjectMovedOrRenamed = 210,
    AuditedSensitiveFieldAccessChange = 340,
    ChangesToAuditingSystem = 370,
    FileDeletion = 480,
    LoginOnWeekendsAndAfterHours = 490,
    LoginStandard = 530,
    AuditedTransaction = 580,
    AccountModification = 650,
    CustomerMemberModification = 660
}