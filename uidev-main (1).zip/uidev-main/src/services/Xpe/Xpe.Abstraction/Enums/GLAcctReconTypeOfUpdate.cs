﻿namespace Xpe.Abstraction.Enums;

public enum GLAcctReconTypeOfUpdate
{
    AutoMatch,
    Review,
    ReviewAll,
    None
}