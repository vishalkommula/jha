﻿using JackHenry.JHAContractTypes;

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;
using Xpe.Abstraction.Model;
using Xpe.Abstraction.Model.XpeFields;
using Xpe.Abstraction.Services;

namespace Xpe.Services
{
    public class XpeFieldItemProvider : IFieldItemProvider
    {
        private readonly IInquiryTypeProvider inquiryTypeProvider;
        private readonly IUserService userService;

        private Dictionary<string, CultureInfo> cultureInfoDictionary;

        public XpeFieldItemProvider(
            IInquiryTypeProvider inquiryTypeProvider,
            IUserService userService)
        {
            this.inquiryTypeProvider = inquiryTypeProvider;
            this.userService = userService;

            this.cultureInfoDictionary = new Dictionary<string, CultureInfo>();
        }

        public virtual CultureInfo GetCultureInfo(ICurrentUserInfo userInfo)
        {
            CultureInfo cultureInfo;

            if (!this.cultureInfoDictionary.TryGetValue(userInfo.InstitutionNumber, out cultureInfo))
            {
                cultureInfo = new CultureInfo(CultureInfo.CurrentCulture.LCID);

                //TODO: Implement
                //ParmRec_CType parm = this.bankParameterService.GetParameterValue(userInfo.InstitutionNumber, BankParmKeys.JHAYY, BankParmLevel.Bank, 0);

                //if (parm != null)
                //{
                //    // If we receive the parm back, then use it and subtract 1 to adjust for the variance between the parm and the TwoDigitYearMax property.
                //    cultureInfo.Calendar.TwoDigitYearMax = CultureInfo.CurrentCulture.Calendar.ToFourDigitYear(Convert.ToInt16(parm.ParmVal)) - 1;
                //}
                //else
                //{
                //    // Else we use the default of 60.
                //    cultureInfo.Calendar.TwoDigitYearMax = 2059;
                //}

                this.cultureInfoDictionary.Add(userInfo.InstitutionNumber, cultureInfo);
            }

            return cultureInfo;
        }

        public virtual XpeField GetFieldItem(ScreenField screenField, ScreenField5250 screenField5250, IEnumerable<ScreenField> screenFields, ScreenInfoResponse screenInfo, ICurrentUserInfo userInfo, ScreenMapGridArrayGrid screenMapGrid)
        {
            if (screenField.IsEditMasked())
            {
                return this.GetEditMaskField(screenField, screenField5250, screenInfo.InputFields, screenInfo.OutputFields, userInfo);
            }
            else if (screenField5250.IsPasswordField())
            {
                return new PasswordScreenFieldItem(screenField5250, screenField, screenInfo.OutputFields);
            }
            else if (screenField.IsLinkTypeCombined() && screenField.LinkDataExpression != null)
            {
                return this.GetCombinedField(screenField, screenField5250, screenInfo.InputFields, screenInfo.OutputFields, userInfo);
            }
            else if (screenField.IsLinkTypeCustomer())
            {
                return this.GetCustomerNumberTypeField(screenField, screenField5250, screenInfo.InputFields, screenInfo.OutputFields, userInfo);
            }
            else if (screenField.IsLinkTypeAccount())
            {
                return this.GetAccountNumberTypeField(screenField, screenField5250, screenInfo.InputFields, screenInfo.OutputFields, userInfo);
            }
            else if (screenField.IsLinkTypeDecimal())
            {
                return this.GetDecimalTypeField(screenField, screenField5250, screenFields, screenInfo.InputFields, screenInfo.OutputFields, screenInfo, userInfo);
            }
            else if (screenField.IsLinkTypeURL())
            {
                return this.GetURLTypeField(screenField, screenField5250, userInfo, screenInfo.OutputFields);
            }
            else if (screenField.IsLinkTypeNavigation())
            {
                return this.GetNavigationField(screenField, screenField5250, screenInfo.InputFields, userInfo, screenInfo.OutputFields);
            }
            else if (screenField.IsLinkTypeEmailAddress())
            {
                return this.GetEmailTypeField(screenField, screenField5250, userInfo, screenInfo.OutputFields);
            }
            else if (screenField.IsLinkTypeGLAccount())
            {
                return this.GetGLAccountTypeField(screenField, screenField5250, screenInfo.InputFields, screenInfo.OutputFields, userInfo);
            }
            else if (screenField.IsLinkTypePhoneNumber())
            {
                return this.GetPhoneNumberTypeField(screenField, screenField5250, screenFields, screenInfo.InputFields, screenInfo.OutputFields, userInfo);
            }
            else if (screenField.IsLinkTypeZip())
            {
                return this.GetZipField(screenField, screenField5250, screenFields, screenInfo.InputFields, screenInfo.OutputFields, userInfo);
            }
            else if (screenField.IsLinkTypeDate())
            {
                return this.GetDateField(screenField, screenField5250, screenFields, screenInfo.InputFields, screenInfo.OutputFields, userInfo);
            }
            else if (screenField.IsLinkTypeValue())
            {
                return this.GetValueExpressionField(screenField, screenField5250, screenInfo.OutputFields, screenInfo.InputFields, userInfo);
            }
            else if (screenField.IsCheckBox())
            {
                return this.GetCheckboxField(screenField, screenField5250, screenInfo.OutputFields);
            }
            else if (screenField.IsFieldValueList())
            {
                return this.GetFieldItemListOptionValues(screenField, screenField5250, screenInfo.OutputFields);
            }
            else if (screenField.IsLinkTypeKeyPressNav())
            {
                return this.GetKeyPressNavField(screenField, screenField5250, userInfo, screenInfo.OutputFields);
            }
            else if (screenField.IsLinkTypeContinedField())
            {
                return this.GetContinuedField(screenField, screenField5250, screenInfo.InputFields, userInfo, screenInfo.OutputFields);
            }
            else
            {
                return new XpeScreenFieldItem(screenField5250, screenField, this.GetCultureInfo(userInfo), screenInfo.OutputFields);
            }
        }

        public virtual bool IsFieldBestMatch(ScreenField screenField, IEnumerable<ScreenField> screenFields, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields)
        {
            bool isBestMatch = true;

            if (!screenField.IsDisplayFormatIgnored() && !(screenField.Row == 0 && screenField.Col == 0))
            {
                ScreenField5250 screenField5250 = ScreenField5250Extensions.Get5250Field(screenField, inputFields.Union(outputFields));
                List<ScreenField> matchedFields = screenFields.Where(nvp => nvp.Row == screenField.Row && nvp.Col == screenField.Col && !nvp.IsDisplayFormatIgnored()).ToList();

                if (screenField5250 != null)
                {
                    // Use the # of matched fields to determine if we have the best matched field
                    if (matchedFields.Count > 1)
                    {
                        matchedFields = matchedFields.Where(nvp => nvp.ReadOnly == screenField5250.IsOutputField()).ToList();

                        if (matchedFields.Count > 1)
                        {
                            int length = screenField5250.FieldSize;

                            ////5250 length will include "-" for SignedNumeric and NumericOnly
                            ////these screenfields might have been changed to not include "-" in length (so length - 1)
                            if (screenField5250.FieldFormatWord != null &&
                                (screenField5250.FieldFormatWord.FieldShiftEditSpecification == FieldShiftEditSpecification.SignedNumeric ||
                                 screenField5250.FieldFormatWord.FieldShiftEditSpecification == FieldShiftEditSpecification.NumericOnly))
                            {
                                ////Try (length - 1 first), use it if there are matches, else it will use the 5250 length, means the map has not been adjusted for "-"
                                var lengthMinusOneFields = matchedFields.Where(nvp => nvp.Length == length - 1).ToList();

                                if (lengthMinusOneFields.Count > 0)
                                {
                                    length = screenField5250.FieldSize - 1;
                                }
                            }

                            matchedFields = matchedFields.Where(nvp => nvp.Length == length).ToList();

                            ////If we still have multiple matches, we're limited to finding the first String type...we don't have anything else at this point
                            ////that we can use to narrow it down.
                            if (matchedFields.Count > 1)
                            {
                                matchedFields = matchedFields.Where(nvp => nvp.DataType == ScreenFieldDataType.String).ToList();

                                if (matchedFields.Count >= 1)
                                {
                                    if (screenField.DataType != ScreenFieldDataType.String)
                                    {
                                        return false;
                                    }
                                }
                            }
                            else if (screenField.Length != length)
                            {
                                isBestMatch = false;
                            }
                        }
                        else if (screenField.ReadOnly != screenField5250.IsOutputField())
                        {
                            isBestMatch = false;
                        }
                    }
                }
                ////else
                ////{
                ////    isBestMatch = false;
                ////}
            }

            return isBestMatch;
        }

        protected virtual XpeField GetValueExpressionField(ScreenField namePair, ScreenField5250 screenField, IEnumerable<ScreenField5250> outputFields, IEnumerable<ScreenField5250> inputFields, ICurrentUserInfo userInfo)
        {
            if (namePair.ReadOnly &&
                !string.IsNullOrEmpty(namePair.LinkDataExpression))
            {
                return new ValueExpressionScreenFieldItem(namePair, outputFields.Union(inputFields));
            }

            return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
        }

        protected virtual XpeField GetCombinedField(ScreenField namePair, ScreenField5250 screenField, IEnumerable<ScreenField5250> outputFields, IEnumerable<ScreenField5250> inputFields, ICurrentUserInfo userInfo)
        {
            if (screenField.IsOutputField() &&
                !string.IsNullOrWhiteSpace(screenField.Data) &&
                !string.IsNullOrEmpty(namePair.LinkDataExpression))
            {
                return new CombinedOutputScreenFieldItem(screenField, namePair, inputFields.Union(outputFields));
            }

            return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
        }

        protected virtual XpeField GetCheckboxField(ScreenField namePair, ScreenField5250 screenField, IEnumerable<ScreenField5250> outputFields)
        {
            return new CheckboxScreenFieldItem(screenField, namePair, outputFields);
        }

        protected virtual XpeField GetContinuedField(ScreenField namePair, ScreenField5250 screenField, IEnumerable<ScreenField5250> inputFields, ICurrentUserInfo userInfo, IEnumerable<ScreenField5250> outputFields)
        {
            if (!string.IsNullOrEmpty(namePair.LinkDataExpression))
            {
                List<string> rrcccList = namePair.TokenizeLinkDataExpression(inputFields);
                rrcccList = rrcccList.Where(x => !string.IsNullOrEmpty(x)).ToList();
                List<ScreenField5250> continuedInputFields = new List<ScreenField5250>();
                continuedInputFields.Add(screenField);

                foreach (string rrccc in rrcccList)
                {
                    if (ScreenFieldExtensions.IsValidRRCCC(rrccc))
                    {
                        continuedInputFields.Add(inputFields.FirstOrDefault(nvp => nvp.RRCCC == rrccc));
                    }
                }

                if (continuedInputFields.Count > 1)
                {
                    return new ContinuedFieldScreenFieldItem(screenField, namePair, continuedInputFields, outputFields);
                }
            }

            return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
        }

        protected virtual XpeField GetURLTypeField(ScreenField namePair, ScreenField5250 screenField, ICurrentUserInfo userInfo, IEnumerable<ScreenField5250> outputFields)
        {
            if (screenField.IsOutputField() &&
                !string.IsNullOrWhiteSpace(screenField.Data))
            {
                return new URLScreenFieldItem(screenField, namePair, outputFields);
            }

            return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
        }

        protected virtual XpeField GetNavigationField(ScreenField namePair, ScreenField5250 screenField, IEnumerable<ScreenField5250> inputFields, ICurrentUserInfo userInfo, IEnumerable<ScreenField5250> outputFields)
        {
            if (!string.IsNullOrEmpty(namePair.LinkDataExpression))
            {
                var list = namePair.TokenizeLinkDataExpression(inputFields).Where(s => !string.IsNullOrWhiteSpace(s)).ToList();

                string rrccc = list.FirstOrDefault(nvp => ScreenFieldExtensions.IsValidRRCCC(nvp));
                string value = string.Empty;

                if (rrccc != null)
                {
                    int index = list.IndexOf(rrccc);

                    if (index + 1 < list.Count)
                    {
                        value = list[index + 1];
                    }

                    int row = int.Parse(rrccc.Substring(0, 2));
                    int col = int.Parse(rrccc.Substring(2, 3));
                    ScreenField5250 input = ScreenField5250Extensions.GetFieldByRRCCC(rrccc, inputFields);
                    string fieldValue = screenField == null || (namePair.Row == 0 && namePair.Col == 0) ? namePair.FormatDynamicLabelText(outputFields) : fieldValue = screenField.Data;

                    if (input != null)
                    {
                        if (!string.IsNullOrWhiteSpace(fieldValue))
                        {
                            return new NavigationScreenFieldItem(namePair, screenField, input, value, fieldValue, outputFields);
                        }
                        else
                        {
                            return null;
                        }
                    }
                }
            }

            return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
        }

        protected virtual XpeField GetEmailTypeField(ScreenField namePair, ScreenField5250 screenField, ICurrentUserInfo userInfo, IEnumerable<ScreenField5250> outputFields)
        {
            if (screenField.IsOutputField() &&
                !string.IsNullOrWhiteSpace(screenField.Data))
            {
                return new EmailScreenFieldItem(screenField, namePair, outputFields);
            }

            return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
        }

        protected virtual XpeField GetPhoneNumberTypeField(ScreenField namePair, ScreenField5250 screenField, IEnumerable<ScreenField> nameValuePairFields, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields, ICurrentUserInfo userInfo)
        {
            if (!string.IsNullOrEmpty(namePair.LinkDataExpression))
            {
                List<string> linkDataExpFields = namePair.TokenizeLinkDataExpression(inputFields.Union(outputFields));
                List<string> rrcccList = new List<string>();

                foreach (string exp in linkDataExpFields)
                {
                    if (ScreenFieldExtensions.IsValidRRCCC(exp))
                    {
                        rrcccList.Add(exp);
                    }
                }

                // Verify we have at least 2 fields in the Link Data Exp (making a total of 3 fields to combine)
                if (rrcccList.Count >= 2)
                {
                    ScreenField5250 prefixField5250 = ScreenField5250Extensions.GetFieldByRRCCC(rrcccList[0].ToString(), inputFields.Union(outputFields));
                    ScreenField5250 lineNumberField5250 = ScreenField5250Extensions.GetFieldByRRCCC(rrcccList[1].ToString(), inputFields.Union(outputFields));

                    if (prefixField5250 != null && lineNumberField5250 != null)
                    {
                        ScreenField prefixField = nameValuePairFields.Where(n => n.IsDisplayFormatIgnored() && n.Row == prefixField5250.Row && n.Col == prefixField5250.Col).FirstOrDefault();
                        ScreenField lineNumberField = nameValuePairFields.Where(n => n.IsDisplayFormatIgnored() && n.Row == lineNumberField5250.Row && n.Col == lineNumberField5250.Col).FirstOrDefault();

                        if (screenField.IsOutputField())
                        {
                            return new PhoneNumberScreenFieldItem(screenField, namePair, outputFields, prefixField5250, lineNumberField5250);
                        }
                        else
                        {
                            return new CombinedPhoneScreenFieldItem(screenField, namePair, prefixField5250, prefixField, lineNumberField5250, lineNumberField, outputFields);
                        }
                    }
                }
            }
            else if (screenField.IsOutputField() && !string.IsNullOrWhiteSpace(screenField.Data))
            {
                return new PhoneNumberScreenFieldItem(screenField, namePair, outputFields, null, null);
            }

            return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
        }

        protected virtual XpeField GetDecimalTypeField(ScreenField namePair, ScreenField5250 screenField, IEnumerable<ScreenField> nameValuePairFields, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields, ScreenInfoResponse screenInfo, ICurrentUserInfo userInfo)
        {
            if (!string.IsNullOrEmpty(namePair.LinkDataExpression))
            {
                string rrccc = namePair.TokenizeLinkDataExpression(inputFields.Union(outputFields)).FirstOrDefault(nvp => ScreenFieldExtensions.IsValidRRCCC(nvp));

                if (rrccc != null)
                {
                    int row = int.Parse(rrccc.Substring(0, 2));
                    int col = int.Parse(rrccc.Substring(2, 3));
                    ScreenField5250 screen5250Decimal = ScreenField5250Extensions.GetFieldByRRCCC(rrccc, inputFields.Union(outputFields));

                    if (screen5250Decimal != null)
                    {
                        ScreenField decimalField = nameValuePairFields.Where(n => n.IsDisplayFormatIgnored() && n.Row == row && n.Col == col).FirstOrDefault();

                        if (screenInfo.ScreenId == "LN900IFM-SCREEN14" && (decimalField.FieldRefId == "HER#2" || decimalField.FieldRefId == "TDR#2"))
                        {
                            screen5250Decimal.Data = screen5250Decimal.Data.Trim().PadLeft(screen5250Decimal.FieldSize, '0');
                        }

                        return new DecimalScreenFieldItem(screenField, namePair, screen5250Decimal, decimalField, outputFields);
                    }
                }
            }

            return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
        }

        protected virtual XpeField GetZipField(ScreenField namePair, ScreenField5250 screenField, IEnumerable<ScreenField> nameValuePairFields, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields, ICurrentUserInfo userInfo)
        {
            if (!string.IsNullOrEmpty(namePair.LinkDataExpression))
            {
                string rrccc = namePair.TokenizeLinkDataExpression(inputFields.Union(outputFields)).FirstOrDefault(nvp => ScreenFieldExtensions.IsValidRRCCC(nvp));
                int row = int.Parse(rrccc.Substring(0, 2));
                int col = int.Parse(rrccc.Substring(2, 3));
                ScreenField5250 zipScreenField5250 = ScreenField5250Extensions.GetFieldByRRCCC(rrccc, inputFields.Union(outputFields));

                if (zipScreenField5250 != null)
                {
                    ScreenField zipScreenField = nameValuePairFields.Where(n => n.IsDisplayFormatIgnored() && n.Row == row && n.Col == col).FirstOrDefault();

                    return new ZipCodeScreenFieldItem(screenField, namePair, zipScreenField5250, zipScreenField, outputFields);
                }
            }

            return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
        }

        protected virtual XpeField GetFieldItemListOptionValues(ScreenField namePair, ScreenField5250 screenField, IEnumerable<ScreenField5250> outputFields)
        {
            return new ListOptionsValuesScreenFieldItem(screenField, namePair, outputFields);
        }

        protected virtual XpeField GetDateField(ScreenField namePair, ScreenField5250 screenField, IEnumerable<ScreenField> nameValuePairFields, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields, ICurrentUserInfo userInfo)
        {
            if (!string.IsNullOrEmpty(namePair.LinkDataExpression) && screenField.IsInputField())
            {
                IEnumerable<string> rrcccs = namePair.TokenizeLinkDataExpression(inputFields.Union(outputFields)).Where(nvp => ScreenFieldExtensions.IsValidRRCCC(nvp));

                if (rrcccs.Count() == 1)
                {
                    string secondFieldRRCCC = rrcccs.First();
                    int row = int.Parse(secondFieldRRCCC.Substring(0, 2));
                    int col = int.Parse(secondFieldRRCCC.Substring(2, 3));

                    ScreenField5250 dateScreenField5250 = ScreenField5250Extensions.GetFieldByRRCCC(secondFieldRRCCC, inputFields.Union(outputFields));

                    if (dateScreenField5250 != null)
                    {
                        return new DateScreenFieldItem(namePair, screenField, dateScreenField5250, null, outputFields);
                    }
                }
                else if (rrcccs.Count() > 1)
                {
                    string secondFieldRRCCC = rrcccs.First();

                    ScreenField5250 secondDateScreenField5250 = ScreenField5250Extensions.GetFieldByRRCCC(secondFieldRRCCC, inputFields.Union(outputFields));

                    string thirdFieldRRCCC = rrcccs.ElementAt(1);

                    ScreenField5250 thirdDateScreenField5250 = ScreenField5250Extensions.GetFieldByRRCCC(thirdFieldRRCCC, inputFields.Union(outputFields));

                    if (secondDateScreenField5250 != null && thirdDateScreenField5250 != null)
                    {
                        return new DateScreenFieldItem(namePair, screenField, secondDateScreenField5250, thirdDateScreenField5250, outputFields);
                    }
                }
            }

            return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
        }

        protected virtual XpeField GetEditMaskField(ScreenField namePair, ScreenField5250 screenField, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields, ICurrentUserInfo userInfo)
        {
            return new EditMaskScreenFieldItem(namePair, screenField, inputFields, outputFields, this.GetCultureInfo(userInfo));
        }

        protected virtual XpeField GetGLAccountTypeField(ScreenField namePair, ScreenField5250 screenField, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields, ICurrentUserInfo userInfo)
        {
            if (!string.IsNullOrEmpty(namePair.LinkDataExpression) && screenField.IsOutputField() &&
               screenField.Data != null && !string.IsNullOrEmpty(screenField.Data.Trim()))
            {
                List<string> glpairvalues = namePair.TokenizeLinkDataExpression(inputFields.Union(outputFields));

                string branchRCCC = string.Empty;
                string costCenterRCCC = string.Empty;
                string prodCodeRCCC = string.Empty;

                string branch = string.Empty;
                string costCenter = string.Empty;
                string prodCode = string.Empty;
                ScreenField5250 linkScreenField = null;

                if (glpairvalues.Count >= 2)
                {
                    foreach (string expression in glpairvalues)
                    {
                        int fieldIndex = glpairvalues.IndexOf(expression) + 1;

                        switch (expression)
                        {
                            case "B":
                                if (fieldIndex <= glpairvalues.Count)
                                {
                                    branchRCCC = glpairvalues[fieldIndex];
                                    linkScreenField = ScreenField5250Extensions.GetFieldByRRCCC(branchRCCC, inputFields.Union(outputFields));

                                    if (linkScreenField != null)
                                    {
                                        branch = linkScreenField.Data != null ? linkScreenField.Data.Trim() : null;
                                    }
                                }

                                break;
                            case "C":
                                if (fieldIndex <= glpairvalues.Count)
                                {
                                    costCenterRCCC = glpairvalues[fieldIndex];
                                    linkScreenField = ScreenField5250Extensions.GetFieldByRRCCC(costCenterRCCC, inputFields.Union(outputFields));

                                    if (linkScreenField != null)
                                    {
                                        costCenter = linkScreenField.Data != null ? linkScreenField.Data.Trim() : null;
                                    }
                                }

                                break;
                            case "P":
                                if (fieldIndex <= glpairvalues.Count)
                                {
                                    prodCodeRCCC = glpairvalues[fieldIndex];
                                    linkScreenField = ScreenField5250Extensions.GetFieldByRRCCC(prodCodeRCCC, inputFields.Union(outputFields));

                                    if (linkScreenField != null)
                                    {
                                        prodCode = linkScreenField.Data != null ? linkScreenField.Data.Trim() : null;
                                    }
                                }

                                break;
                        }
                    }

                    return new GLAccountNumberScreenFieldItem(screenField, namePair, branch, costCenter, prodCode, this.inquiryTypeProvider.GLCode, this.inquiryTypeProvider, this.userService, userInfo, outputFields);
                }
            }

            return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
        }

        protected virtual XpeField GetCustomerNumberTypeField(ScreenField namePair, ScreenField5250 screenField, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields, ICurrentUserInfo userInfo)
        {
            if (screenField.IsOutputField() && !string.IsNullOrWhiteSpace(screenField.Data))
            {
                return new CustomerNumberScreenFieldItem(screenField, namePair, inputFields.Union(outputFields));
            }

            return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
        }

        protected virtual XpeField GetAccountNumberTypeField(ScreenField namePair, ScreenField5250 screenField, IEnumerable<ScreenField5250> inputFields, IEnumerable<ScreenField5250> outputFields, ICurrentUserInfo userInfo)
        {
            if (screenField.IsOutputField() &&
                                 !string.IsNullOrWhiteSpace(screenField.Data) &&
                                 !string.IsNullOrEmpty(namePair.LinkDataExpression))
            {
                var accountType = namePair.FormatLinkDataExpression(inputFields.Union(outputFields), false);
                return new AccountNumberScreenFieldItem(screenField, namePair, accountType, this.inquiryTypeProvider, this.userService, userInfo, outputFields);
            }

            return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
        }

        protected virtual XpeField GetKeyPressNavField(ScreenField namePair, ScreenField5250 screenField, ICurrentUserInfo userInfo, IEnumerable<ScreenField5250> outputFields)
        {
            if (!string.IsNullOrEmpty(namePair.LinkDataExpression) &&
                (screenField.IsOutputField() || (screenField.Att == FieldAttribute.Green || screenField.Att == FieldAttribute.GreenReverse)) &&
                !string.IsNullOrWhiteSpace(screenField.Data))
            {
                string keyString = namePair.LinkDataExpression.Replace("{", string.Empty);
                keyString = keyString.Replace("}", string.Empty);

                try
                {
                    KeyConverter keyConverter = new KeyConverter();
                    Key inputKey = (Key)keyConverter.ConvertFromString(keyString);

                    return new KeyPressNavScreenFieldItem(screenField, namePair, new KeyPress(inputKey, Key.None), outputFields);
                }
                catch
                {
                    return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
                }
            }

            return new XpeScreenFieldItem(screenField, namePair, this.GetCultureInfo(userInfo), outputFields);
        }
    }
}