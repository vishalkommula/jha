﻿using JackHenry.JHAContractTypes;
using Xpe.Abstraction.Infrastructure;
using Xpe.Abstraction.Model;

namespace Xpe.Services;

public class InstitutionService : IInstitutionService
{
    public PrvdInstInfoModel GetCurrentInstitution()
    {
        return new PrvdInstInfoModel(
            new PrvdInstInfo_CType
            {
                PrvdInstId = "510",
                PrvdInstProd = "SILVERLAKE",
                PrvdInstName = "SLXP QA  TEST BANK 510   R2022",
                PrvdInstRtId = "113102552",
                AdptInstId = "2022510",
                ReleaseLvl = "3000.00.0000.00",
                AdptPort = 42510,
                AdptPortKey = "66ce7003ffae1a4293d60004ac1c6f9b",
                AdptSslCert = false.ToString(),
                AdptSvr = "ICOREDEV.JHACORP.COM",
                ReqSAMLAuth = false.ToString()
            },
            new BankingAlias());
    }

    public IIAdapter GetIAdapter()
    {
        var info = GetCurrentInstitution();
        return info.IAdapter;
    }
}