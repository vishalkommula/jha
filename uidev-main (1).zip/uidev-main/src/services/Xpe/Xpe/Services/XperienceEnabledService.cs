﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

using JackHenry.JHAContractTypes;

using Xpe.Abstraction.Commands;
using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;
using Xpe.Abstraction.Model;
using Xpe.Abstraction.Services;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Xpe.Abstraction.Model.XpeFields;

namespace Xpe.Services;

public class XperienceEnabledService : IXperienceEnabledService
{
    private const string KerberosTokenRejected = "CPF9898 851968 EUVF02016E Security mechanism detects error.";

    public XperienceEnabledService(
        ILogger<XperienceEnabledService> logger,
        IJha5250 jha5250,
        IMediator mediator,
        IFieldItemProvider fieldItemProvider,
        IUserService userService)
    {
        Logger = logger;
        Jha5250 = jha5250;
        Mediator = mediator;
        UserService = userService;
        FieldItemProvider = fieldItemProvider;

        FunctionKeyRegex = new Regex(@"\bF-?([0-9]{1,2})\b");
        ValidFunctionKey = new Regex("^(F[1-9]|F1[0-9]|F2[0-4])$");
        ScreenFunctionKeysStorage = new List<ScreenMapActionKey>();
    }

    private bool Initialized { get; set; }

    private IJha5250 Jha5250 { get; set; }

    private IMediator Mediator { get; }

    private IUserService UserService { get; set; }

    private IFieldItemProvider FieldItemProvider { get; set; }

    private ILogger<XperienceEnabledService> Logger { get; }

    private IServiceProvider ServiceProvider { get; }

    private List<ScreenMapActionKey> ScreenFunctionKeysStorage { get; set; }

    private string ScreenId { get; set; }

    private Regex FunctionKeyRegex { get; }

    private Regex ValidFunctionKey { get; }

    private string LastCommandAutoUnFoldScreenId { get; set; }

    private IServiceScope ServiceScope { get; set; }

    public void Dispose()
    {
        Dispose(true);

        GC.SuppressFinalize(this);
    }

    public IInquiryResponse<object> SignOn(string userIdentifier, CurrentUserInfo currentUserInfo)
    {
        try
        {
            Initialize(userIdentifier);

            return new InquiryResponse<object>();
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "Error during XPE sign on.");

            return new InquiryResponse<object>
            {
                Exception = ex
            };
        }
    }

    public void EndSession(string userIdentifier, CurrentUserInfo currentUserInfo)
    {
        Jha5250.DisconnectFromServer();

        Initialized = false;
    }

    public virtual IInquiryResponse<ScreenInfoRequest> SendCommand(ScreenInfoRequest screenInfoRequest)
    {
        try
        {
            ScreenFunctionKeysStorage.Clear();

            SendDataCommand(screenInfoRequest);

            return new InquiryResponse<ScreenInfoRequest>
            {
                Payload_Rs = screenInfoRequest
            };
        }
        catch (Exception ex)
        {
            // this.LoggingService.LogException("Error sending command", ex.Message, ex);

            return new InquiryResponse<ScreenInfoRequest>
            {
                Payload_Rs = screenInfoRequest,
                Exception = new GenericException($"Error sending command; {ex.Message}", ex)
            };
        }
    }

    public void OnScreenChanged(ScreenChangedCmd args, bool isStaticView)
    {
        // if (args.Exception != null)
        // {
        //     Logger.LogError(args.Exception, "{Method} => {Message}",
        //         nameof(OnScreenChanged), args.Exception.Message);
        //     return;
        // }

        if (!string.IsNullOrWhiteSpace(ScreenId) && ScreenId.Contains('-') &&
            !string.IsNullOrEmpty(args.ScreenInfo.ScreenId) && args.ScreenInfo.ScreenId.Contains('-') &&
            ScreenId[..ScreenId.LastIndexOf("-", StringComparison.Ordinal)] !=
            args.ScreenInfo.ScreenId[..args.ScreenInfo.ScreenId.LastIndexOf("-", StringComparison.Ordinal)])
        {
            ScreenFunctionKeysStorage.Clear();
        }

        Logger.LogDebug("{Method} => Screen {ScreenId}",
            nameof(OnScreenChanged), args.ScreenInfo?.ScreenId);

        var greenScreenFieldLog = new StringBuilder();

        if (args.ScreenInfo?.AllFields != null)
        {
            foreach (var greenScreenField in args.ScreenInfo.AllFields.OrderBy(f => f.Row).ThenBy(f => f.Col))
            {
                greenScreenFieldLog.Append(greenScreenField);
                greenScreenFieldLog.AppendLine();
            }
        }

        ScreenData screenData = null;

        if (isStaticView)
        {
            screenData = new ScreenData(args.ScreenInfo, false, isStaticView);

            foreach (var outputField in args.ScreenInfo.OutputFields)
            {
                var fieldData = outputField.Data.Trim();

                // Get dynamic Error messages that have been flagged in the data stream
                if (outputField.IsErrorField())
                {
                    screenData.ErrorMessages.Add(fieldData);
                }
            }

            LogToMonitor("Processed screen using static layout ", MonitorType.CommandData);

            var staticLayoutMonitorMsg = "Screen is utilizing a static layout ";
            LogToMonitor(string.Format("N/A - {0}", staticLayoutMonitorMsg), MonitorType.MappedFields);
            LogToMonitor(string.Format("N/A - {0}", staticLayoutMonitorMsg), MonitorType.ScreenMap);
        }
        else
        {
            var screenMap = args.ScreenInfo.ScreenMapData;

            // If the screen has a screen map and we're not on an IBM screen, call a method to use it.
            if (!string.IsNullOrEmpty(screenMap) && !args.ScreenInfo.IsIBMScreen)
            {
                LogToMonitor("Processing mapped screen using mapping file from data stream ", MonitorType.CommandData);
                screenData = ProcessMappedScreen(screenMap, args.ScreenInfo);
            }
            else
            {
                // Don't log missing screen maps for IBM screens since they are not supposed to be mapped.
                if (args.ScreenInfo.IsIBMScreen)
                {
                    LogToMonitor("Processing IBM screen as unmapped ", MonitorType.CommandData);
                }
                else
                {
                    LogToMonitor("No map was returned from data stream ", MonitorType.CommandData);
                }

                screenData = ProcessUndefinedScreen(args.ScreenInfo);
            }
        }

        if (screenData != null)
        {
            screenData.ScreenInfo = args.ScreenInfo;

            Mediator.Send(new ScreenDataUpdatedCmd(args.UserIdentifier, screenData));
        }
    }

    public bool IsCustomScreen(ICurrentUserInfo userInfo, string screenId = null, string program = null, string screenAccountType = null, bool refresh = false)
    {
        List<ScrInfo_CType> customScreens = this.GetCustomScreens(userInfo, refresh);

        return this.IsCustom(customScreens, screenId, program, screenAccountType);
    }

    public List<ScrInfo_CType> GetCustomScreens(ICurrentUserInfo userInfo, bool refresh = false)
    {
        List<ScrInfo_CType> customScreens = new List<ScrInfo_CType>();

        //TODO: Implement
        //try
        //{
        //    IInquiryResponse<ScrIdListInqRs_MType> response = null;

        //    string key = "CustomMappedScreens";

        //    if (!refresh && (response = this.cacheService.ItemFromCache<IInquiryResponse<ScrIdListInqRs_MType>>(key, userInfo.InstitutionNumber)) != null)
        //    {
        //        if (response.Payload_Rs != null && response.Payload_Rs.ScrIdArray != null)
        //        {
        //            customScreens.AddRange(response.Payload_Rs.ScrIdArray);
        //        }

        //        return customScreens;
        //    }

        //    ScrIdListInqRq_MType request = new ScrIdListInqRq_MType();
        //    request.MsgRqHdr = this.contractMessageHeaderHelper.GetSlcMessageHeader(userInfo.AliasName, userInfo.InstitutionNumber, userInfo.SecurityGroup, userInfo.UserToken?.Name, userInfo.Alias?.Context?.SecretKey, userInfo.UserTokenXml, userInfo.IsSAMLAuthRequired, userInfo.Alias?.UniqueId?.Value);
        //    request.MsgRqHdr.jXchangeHdr.ConsumerName.Value = "CUSTOM";

        //    response = this.GetScreenIdList(userInfo, request);

        //    if (!response.HasMaladyExcludeWarnings && !response.HasException)
        //    {
        //        this.cacheService.AddItemToCache(key, response, CacheItemType.Search);

        //        if (response.Payload_Rs != null && response.Payload_Rs.ScrIdArray != null)
        //        {
        //            customScreens.AddRange(response.Payload_Rs.ScrIdArray);
        //        }

        //        return customScreens;
        //    }
        //    else
        //    {
        //        if (response.HasException)
        //        {
        //            Logger.LogError(string.Empty, response.Exception);
        //        }
        //        else if (response.HasMaladyExcludeWarnings)
        //        {
        //            Logger.LogError(string.Empty, new GenericException("Soap HdrFault returned", response.ErrorsToString(), null));
        //        }
        //    }

        //    return customScreens;
        //}
        //catch (Exception ex)
        //{
        //    Logger.LogError(string.Empty, "Error getting custom screens", ex);
        //}

        return customScreens;
    }

    public bool IsCustom(List<ScrInfo_CType> customScreens, string screenId, string program, string screenAccountType)
    {
        bool isCustom = !string.IsNullOrEmpty(screenId) && customScreens.Any(s => s.ScreenId == screenId);

        //TODO: Implement
        //if (!isCustom && !string.IsNullOrEmpty(program) && this.AccountLookupMenuScreenIds.ContainsKey(program))
        //{
        //    //// this is an account inquiry screen prompt program we need to determine if the inquiry screen is custom
        //    //// so if it is then we need to keeep the prompt screen open in xpe so they can get to the inquiry screen

        //    string[] screenIds = this.AccountLookupMenuScreenIds[program];

        //    foreach (string screenId1 in screenIds)
        //    {
        //        isCustom = customScreens.Any(s => s.ScreenId == screenId1);

        //        if (isCustom)
        //        {
        //            return isCustom;
        //        }
        //    }
        //}
        //else if (!isCustom && !string.IsNullOrEmpty(screenId) && !string.IsNullOrEmpty(screenAccountType) && this.AccountLookupMenuScreenIds.ContainsKey(string.Format("{0}_{1}", screenId, screenAccountType)))
        //{
        //    //// this is a prompt screen so we need to find the inquiry screen by screen id and account type
        //    //// to determine if the inquiry screen is custom to leave the prompt in xpe so they can still
        //    //// get to custom inquiry screens

        //    string[] screenIds = this.AccountLookupMenuScreenIds[string.Format("{0}_{1}", screenId, screenAccountType)];

        //    foreach (string screenId1 in screenIds)
        //    {
        //        isCustom = customScreens.Any(s => s.ScreenId == screenId1);

        //        if (isCustom)
        //        {
        //            return isCustom;
        //        }
        //    }
        //}

        return isCustom;
    }

    public IInquiryResponse<ScrIdListInqRs_MType> GetScreenIdList(ICurrentUserInfo userInfo, ScrIdListInqRq_MType scrIdListRequest)
    {
        try
        {
            //TODO: Implement
            //return this.inquiryService.Inquire<ScrIdListInqRq_MType, ScrIdListInqRs_MType>(scrIdListRequest, userInfo.InstitutionNumber);
            return new InquiryResponse<ScrIdListInqRs_MType>();
        }
        catch (Exception ex)
        {
            Logger.LogError(string.Empty, "Error getting screen Id list", ex);
            return null;
        }
    }

    private void Initialize(string userIdentifier)
    {
        if (Initialized)
        {
            return;
        }

        Initialized = Jha5250.Initialize(userIdentifier);
    }

    private void SendDataCommand(ScreenInfoRequest screenInfoRequest, string logText = null)
    {
        var command = GetFormattedCommandLogEntry(screenInfoRequest);

        logText = string.IsNullOrEmpty(logText) ? command : $"{logText} {Environment.NewLine} {command}";

        LogToMonitor($"Sending command: {logText}", MonitorType.CommandData);

        Jha5250.SendCommandToServer(screenInfoRequest);
    }

    private void LogToMonitor(string format, object commandData)
    {
        Console.WriteLine($"{commandData} | {format}");
    }

    private List<ScreenMapActionKey> GetScreenFunctionKeys(IEnumerable<ScreenField5250> outputFields,
        string functionKeyParsingRange)
    {
        var screenFunctionKeys = new List<ScreenMapActionKey>();

        string functionKey;

        var ranges = new List<Tuple<int, int>>();
        try
        {
            if (!string.IsNullOrWhiteSpace(functionKeyParsingRange))
            {
                var trimmedRawRanges = functionKeyParsingRange.Trim('{', '}');
                var strRanges = trimmedRawRanges.Split(',');

                foreach (var rawRange in strRanges)
                {
                    var trimmedRawRange = rawRange.Trim('[', ']');
                    var strRange = trimmedRawRange.Split(':');

                    if (int.TryParse(strRange[0], out var strRange0) && int.TryParse(strRange[1], out var strRange1))
                    {
                        ranges.Add(new Tuple<int, int>(strRange0, strRange1));
                    }
                }
            }
        }
        catch (Exception ex)
        {
        }

        foreach (var outputField in outputFields.Where(of => !ranges.Any() || ranges.Any(range =>
                     range.Item1 <= Convert.ToInt32(of.RRCCC) && Convert.ToInt32(of.RRCCC) <= range.Item2)))
        {
            // Add the function key(s) if not hidden.
            if (outputField.IsVisible())
            {
                // If there is a match in the output field data
                foreach (Match match in FunctionKeyRegex.Matches(outputField.Data))
                {
                    var screenFunction = new ScreenMapActionKey();
                    var nextMatch = FunctionKeyRegex.Match(outputField.Data, match.Index + 1);

                    if (nextMatch.Value != string.Empty)
                    {
                        functionKey = outputField.Data.Substring(match.Index, nextMatch.Index - match.Index);
                    }
                    else
                    {
                        functionKey = outputField.Data.Substring(match.Index);
                    }

                    var index = functionKey.IndexOf('=');

                    // If we don't find an '=', try to find a ' '.
                    if (index == -1)
                    {
                        index = functionKey.IndexOf(' ');
                    }

                    // If we find a '=' or a ' ', use it to parse out the function key.
                    if (index != -1)
                    {
                        screenFunction.Key = functionKey.Substring(0, index).Trim();

                        // some screens have F07=Something or F-7=Something, just need it to be F7
                        screenFunction.Key = screenFunction.Key.Replace("F0", "F");
                        screenFunction.Key = screenFunction.Key.Replace("F-", "F");

                        if (functionKey.Length > index + 1)
                        {
                            screenFunction.Action = functionKey.Substring(index + 1).Trim();
                        }
                        else
                        {
                            // This shouldn't happen, but if it does just display the Action as the Key.
                            screenFunction.Action = screenFunction.Key;
                        }
                    }
                    else
                    {
                        // I don't think this will happen, but if it does, add the function key so we know it exists
                        // on the screen so we can hopefully add the function from the map. In this case we must use
                        // a more specific RegEx to get the function key to avoid adding a garbage value.
                        var funcRegex = new Regex("F([0-9][0-9]|[0-9])");
                        screenFunction.Key = funcRegex.Match(functionKey).Value;
                    }

                    // If we found a key
                    if (!string.IsNullOrEmpty(screenFunction.Key))
                    {
                        // If it doesn't exist, add it....
                        if (!screenFunctionKeys.Any(f => f.Key == screenFunction.Key))
                        {
                            if (ValidFunctionKey.IsMatch(screenFunction.Key))
                            {
                                screenFunctionKeys.Add(screenFunction);
                            }
                            // ....Unless we incorrectly created a key from the outputField.Data because the string
                            // contained F[0-9], example: screen LNSERV option 1, Name = A, Inquiry Type = P
                        }
                        else if (!string.IsNullOrEmpty(screenFunction.Action))
                        {
                            // Else if it also has an action, then look for the associated function key
                            var associatedScreenFunction =
                                screenFunctionKeys.FirstOrDefault(f => f.Key == screenFunction.Key);

                            // If the associated function key doesn't have an action, set the Action to the screenFunction's Action
                            if (associatedScreenFunction != null &&
                                string.IsNullOrEmpty(associatedScreenFunction.Action))
                            {
                                associatedScreenFunction.Action = screenFunction.Action;
                            }
                        }
                    }
                }
            }
        }

        return screenFunctionKeys;
    }

    protected ScreenData ProcessMappedScreen(string screenMappingFile, ScreenInfoResponse screenInfo)
    {
        ScreenMap screenMap;

        try
        {
            screenMap = ScreenMap.Deserialize(screenMappingFile);

            SetScreenMapSequenceNumbers(screenMap);
            LogToMonitor(screenMappingFile, MonitorType.ScreenMap);
        }
        catch (Exception ex)
        {
            var errorMessage = string.Format("Unable to use mapping file - Error: {0}", ex.Message);

            LogToMonitor(errorMessage, MonitorType.CommandData);

            return ProcessUndefinedScreen(screenInfo);
        }

        var screenData = ProcessData(screenMap, screenInfo);

        return screenData;
    }

    private ScreenData ProcessData(ScreenMap screenMap, ScreenInfoResponse screenInfo)
    {
        try
        {
            // If we are on a Window screen, remove all fields that aren't within the specified window and set the cursor location.
            // Unfortunately, this code has to be here because we aren't receiving the WriteStructuredField window definitions from
            // the 5250 data stream. Therefore, we use the window definitions on the Screen Maps.
            if (screenMap.WinLeftSpecified && screenMap.WinTopSpecified && screenMap.WinWidthSpecified &&
                screenMap.WinHeightSpecified)
            {
                // Create a list of all of the RRCCCs within the window.
                var windowRRCCCs = new List<string>();

                // Add the RRCCCs for every row. Add two to the height to include the bottom and top window borders.
                for (var h = 0; h < screenMap.WinHeight; h++)
                    // Add the RRCCCs for every column on the row. Add four to the width to include the left and right side window borders.
                for (var w = 0; w < screenMap.WinWidth + 2; w++)
                    windowRRCCCs.Add(
                        string.Format("{0:00}{1:000}", screenMap.WinTop + 1 + h, screenMap.WinLeft + 1 + w));

                // If the error row is outside the bounds of the window, then don't remove any fields that are marked as an error field.
                if (screenInfo.ErrorRow < screenMap.WinTop + 1 ||
                    screenInfo.ErrorRow > screenMap.WinTop + screenMap.WinHeight)
                {
                    screenInfo.OutputFields.RemoveAll(f =>
                        !f.IsErrorField() && f.RRCCCs.Where(rrccc => !windowRRCCCs.Contains(rrccc)).Any());
                    screenInfo.InputFields.RemoveAll(f =>
                        !f.IsErrorField() && f.RRCCCs.Where(rrccc => !windowRRCCCs.Contains(rrccc)).Any());
                }
                else
                {
                    // Remove all fields that don't exist within the defined window.
                    screenInfo.OutputFields.RemoveAll(f =>
                        f.RRCCCs.Where(rrccc => !windowRRCCCs.Contains(rrccc)).Any());
                    screenInfo.InputFields.RemoveAll(f => f.RRCCCs.Where(rrccc => !windowRRCCCs.Contains(rrccc)).Any());
                }

                // Set the Cursor Location to the first non bypass input field within the window.
                if (screenInfo.InputFields.Any(f => f.FieldFormatWord != null && !f.FieldFormatWord.Bypass))
                {
                    var inputField =
                        screenInfo.InputFields.FirstOrDefault(f =>
                            f.FieldFormatWord != null && !f.FieldFormatWord.Bypass);
                    screenInfo.CursorLocation.Row = inputField.Row;
                    screenInfo.CursorLocation.Column = inputField.Col;
                }
                else
                {
                    // Else set it to the first index inside the window.
                    screenInfo.CursorLocation.Row = screenMap.WinTop + 1;
                    screenInfo.CursorLocation.Column = screenMap.WinLeft + 2;
                }
            }

            //// Ordinarily we wouldn't change the 5250 field attributes that come through the stream.  However, we do not want to set focus on an input
            //// field that the user indicated they want to hide....so, try to set focus to the next visible field.
            if (screenInfo.InputFields.Any(f => f.IsFocused))
            {
                var screenfield5250 = screenInfo.InputFields.FirstOrDefault(f => f.IsFocused);
                var originalFieldIndex = screenInfo.InputFields.IndexOf(screenfield5250);
                var screenField = screenMap.GetMatchingField(screenfield5250);

                //// If OptionField is true or DisplayFormat is Ignore, the field is not displayed/should not have focus.
                if (screenField != null && (screenField.IsDisplayFormatIgnored() || screenField.OptionField))
                {
                    ////Find the next available field in screenInfo.InputFields
                    ////If there is a next available field, set focus to it and remove focus from previous field
                    ////Else, do nothing
                    var fieldIndex = originalFieldIndex + 1;

                    for (var i = fieldIndex; i < screenInfo.InputFields.Count; i++)
                    {
                        screenField = screenMap.GetMatchingField(screenInfo.InputFields[i]);

                        if (screenField != null &&
                            (!screenField.IsDisplayFormatIgnored() || screenField.OptionField == false))
                        {
                            screenInfo.InputFields[originalFieldIndex].IsFocused = false;
                            screenInfo.InputFields[i].IsFocused = true;
                            break;
                        }
                    }
                }
            }

            var screenData = new ScreenData(screenInfo, true);
            var mappedFieldLog = new StringBuilder();

            var isGridUnfolded = false;
            var includeUnfoldKey = true;

            GetUnmappedScreenMessages(screenMap, screenData, screenInfo.OutputFields);

            // If there is a Grid Unfold Key, send it first and return null to stop processing the screen.
            foreach (var table in screenMap.GridArray)
            {
                var unfoldData = table.Grid.GetUnFoldKeyData();

                if (!string.IsNullOrWhiteSpace(unfoldData.Key))
                {
                    ////Check to see that there are records in the grid before sending Fold command
                    if (table.Grid.GridFields.Any() && screenInfo.InputFields != null &&
                        screenInfo.OutputFields != null)
                    {
                        isGridUnfolded = IsGridUnfolded(table.Grid, screenInfo.AllFields, unfoldData);

                        if (!isGridUnfolded)
                        {
                            ScreenField5250 field5250 = null;

                            // find the first column that exists in the first row, just to make sure there is data in the grid
                            foreach (var column in table.Grid.GridFields.Where(s =>
                                         s.Row == table.Grid.GridFields[0].Row))
                            {
                                field5250 = ScreenField5250Extensions.Get5250Field(column,
                                    screenInfo.InputFields.Union(screenInfo.OutputFields));

                                if (field5250 != null)
                                {
                                    break;
                                }
                            }

                            if (field5250 != null)
                            {
                                // If we didn't unfold the grid, add the unfold button, continue processing. Else we stop processing and wait for the 5250 to render the
                                // unfolded screen and tell us to Update the view.
                                if (!table.Grid.AutoUnfoldGrid || screenInfo.OutputFields.Any(of => of.IsErrorField()))
                                {
                                    //// Fix the screen map to make it the unfolded view
                                    IEnumerable<IGrouping<int, ScreenField>> query = table.Grid.GridFields
                                        .GroupBy(field => field.Row, field => field).OrderBy(g => g.Key);
                                    var firstRowFields = query.First();
                                    table.Grid.GridFields = new ObservableCollection<ScreenField>(firstRowFields);
                                    table.Grid.GridPageSize = table.Grid.GridPageSize * table.Grid.GridRowsPerRec;
                                    table.Grid.GridRowCount = table.Grid.GridPageSize;
                                    table.Grid.GridRowsPerRec = 1;
                                }
                                else if (LastCommandAutoUnFoldScreenId == screenInfo.ScreenId)
                                {
                                    // Last command was same thing
                                    LogToMonitor(
                                        string.Format("Unable to determine folded/unfolded state for screen '{0}'",
                                            screenInfo.ScreenId), MonitorType.CommandData);
                                    screenData = ProcessUndefinedScreen(screenInfo);
                                }
                                else
                                {
                                    LastCommandAutoUnFoldScreenId = screenInfo.ScreenId;

                                    try
                                    {
                                        var keyConverter = new KeyConverter();

                                        SendDataCommand(
                                            new ScreenInfoRequest(
                                                new KeyPress(
                                                    (Key) keyConverter.ConvertFromString(
                                                        unfoldData.Key.Replace(" ", string.Empty)), Key.None),
                                                screenInfo.CursorLocation),
                                            string.Format("Unfolding grid using the '{0}' unfold key.",
                                                unfoldData.Key));
                                    }
                                    catch (Exception ex)
                                    {
                                    }

                                    return null;
                                }
                            }
                        }
                        else if (table.Grid.AutoUnfoldGrid)
                        {
                            //// Auto unfold happened for this screen, don't inlcude the unfold key
                            includeUnfoldKey = false;
                        }
                    }
                }
            }

            // We need to go get function keys first to know if we need to get MORE function keys. Otherwise, we will be performing a lot
            // of unnecessary processing to build the screen. However, after the screen is built, we need to Set the OK button. We have to
            // do this after the screen is built because we need the ScreenData.FieldItems to determine if the OK button should be set or not.
            screenData.ScreenActionItems =
                GetMappedFunctionKeys(screenData, screenMap, includeUnfoldKey, out var getMoreFunctionKeys);

            // If there are more function keys to get, send F24 to get them first and return null to stop processing the screen.
            if (getMoreFunctionKeys)
            {
                if (!screenInfo.AllFields.Any(of => of.IsErrorField()))
                {
                    SendDataCommand(
                        new ScreenInfoRequest(new KeyPress(Key.F24, Key.None), screenInfo.CursorLocation),
                        "Getting more function keys using the F24 key.");
                    return null;
                }

                ////add the F24 more functions key
                screenData.ScreenActionItems.Add(new ScreenMapActionKey { Action = "More Functions", Key = "F24" });
            }

            if (screenMap.NamePairArray != null && screenMap.NamePairArray.Any())
            {
                IEnumerable<ScreenField> nameValuePairGridFields;
                IEnumerable<ScreenField> recordDetailItems;
                IEnumerable<ScreenField> otherCategoryTypes;

                this.SortScreenFields(screenMap.NamePairArray.ToList(), mappedFieldLog, out nameValuePairGridFields, out recordDetailItems, out otherCategoryTypes);

                //    TODO: Implement below code
                screenData.FieldItems = this.GetFieldItems(recordDetailItems, screenInfo);

                if (!string.IsNullOrEmpty(screenMap.NamePairDetails.HeaderText))
                {
                    screenData.RecordDetailHeader = this.FormatPageHeader(screenMap.NamePairDetails.HeaderText, screenInfo.OutputFields);
                }

                if (recordDetailItems.Any(nvp => nvp.IsLinkTypeAccount()))
                {
                    //TODO
                    //this.SetCurrentAccount(screenInfo.ScreenId, screenData, recordDetailItems, screenInfo.InputFields, screenInfo.OutputFields);
                }
                else if (recordDetailItems.Any(nvp => nvp.IsLinkTypeCustomer()))
                {
                    ScreenField accountField = recordDetailItems.First(nvp => nvp.IsLinkTypeCustomer());
                    ScreenField5250 customerNumber5250 = ScreenField5250Extensions.Get5250Field(accountField, screenInfo.AllFields);

                    if (customerNumber5250 != null)
                    {
                        //TODO
                        //screenData.CurrentAccount = new MiniAccount(customerNumber5250.Data.Trim(), this.inquiryTypeProvider.CustomerType);
                        //screenData.CurrentAccount.CustId = customerNumber5250.Data.Trim();
                    }
                }
                else if (recordDetailItems.Any(nvp => nvp.IsLinkTypeGLAccount()))
                {
                    GLAccountNumberScreenFieldItem glScreenFieldItem = screenData.FieldItems.Where(f => f is GLAccountNumberScreenFieldItem).FirstOrDefault() as GLAccountNumberScreenFieldItem;

                    if (glScreenFieldItem != null)
                    {
                        //TODO
                        //screenData.CurrentAccount = glScreenFieldItem.GLAccount;
                    }
                }

                if (recordDetailItems.Any(nvp => nvp.IsLinkTypePlan()) && recordDetailItems.Any(nvp => nvp.IsLinkTypeCustomer()))
                {
                    ScreenField customerField = recordDetailItems.First(nvp => nvp.IsLinkTypeCustomer());
                    ScreenField5250 customerNumber5250 = ScreenField5250Extensions.Get5250Field(customerField, screenInfo.AllFields);
                    ScreenField planField = recordDetailItems.First(nvp => nvp.IsLinkTypePlan());
                    ScreenField5250 planCode5250 = ScreenField5250Extensions.Get5250Field(planField, screenInfo.AllFields);

                    if (customerNumber5250 != null && planCode5250 != null)
                    {
                        //TODO
                        ////screenData.CurrentAccount = new MiniAccount(planCode5250.Data.Trim(), this.inquiryTypeProvider.IRACode);
                        ////screenData.CurrentAccount.CustId = customerNumber5250.Data.Trim();
                    }
                }

                if (nameValuePairGridFields.Any())
                {
                    screenData.NVPGrids = this.GetNVPGrids(nameValuePairGridFields, screenInfo, screenMap);
                }

                if (otherCategoryTypes.Any(nvp => nvp.IsCategoryBanner()))
                {
                    screenData.BannerMessageType = this.GetBannerMessageType(screenMap.ScreenId);
                    screenData.BannerFields = this.GetBannerFields(otherCategoryTypes, screenInfo.InputFields.Union(screenInfo.OutputFields));
                }

                var pageModeField = otherCategoryTypes.FirstOrDefault(nvp => nvp.IsCategoryPageMode());

                if (pageModeField != null)
                {
                    if (!string.IsNullOrEmpty(pageModeField.LinkDataExpression))
                    {
                        screenData.PageMode = pageModeField.FormatLinkDataExpression(screenInfo.AllFields, true);
                    }
                    else if (pageModeField.Row == 0 && pageModeField.Col == 0 && !string.IsNullOrWhiteSpace(pageModeField.FieldLabel))
                    {
                        screenData.PageMode = pageModeField.FieldLabel.Trim();
                    }
                    else
                    {
                        ScreenField5250 pageMode5250Field = ScreenField5250Extensions.Get5250Field(pageModeField, screenInfo.AllFields);

                        if (pageMode5250Field != null && !string.IsNullOrWhiteSpace(pageMode5250Field.Data))
                        {
                            screenData.PageMode = pageMode5250Field.Data.Trim();
                        }
                    }
                }

                var pageTitleField = otherCategoryTypes.FirstOrDefault(nvp => nvp.IsCategoryPageTitle());

                if (pageTitleField != null)
                {
                    if (!string.IsNullOrEmpty(pageTitleField.LinkDataExpression))
                    {
                        screenData.ScreenName = pageTitleField.FormatLinkDataExpression(screenInfo.AllFields, true);
                    }
                    else if (pageTitleField.Row == 0 && pageTitleField.Col == 0 && !string.IsNullOrWhiteSpace(pageTitleField.FieldLabel))
                    {
                        screenData.ScreenName = pageTitleField.FieldLabel.Trim();
                    }
                    else
                    {
                        ScreenField5250 pageTitleScreenField = ScreenField5250Extensions.Get5250Field(pageTitleField, screenInfo.AllFields);

                        if (pageTitleScreenField != null)
                        {
                            screenData.ScreenName = pageTitleScreenField.Data.Trim();
                        }
                    }
                }

                if (otherCategoryTypes.Any(nvp => nvp.IsCategoryMessage()) || screenInfo.OutputFields.Any(of => of.IsErrorField() || of.Row == 24))
                {
                    this.GetMappedScreenMessages(otherCategoryTypes, screenData, screenInfo.InputFields, screenInfo.OutputFields);
                }

                //TODO: Implement
                //if (otherCategoryTypes.Any(nvp => nvp.IsCategorySentence()))
                //{
                //    screenData.SentencePanel = new XpeSentencePanel(screenMap.NamePairArray, screenInfo, this.FieldItemProvider, this.UserInfo);
                //}

                if (otherCategoryTypes.Any(nvp => nvp.IsCategorySearch()))
                {
                    IToolbarItem searchToolbarItem = this.GetGridSearchToolbarItem(otherCategoryTypes, screenInfo.InputFields, screenInfo.OutputFields, screenMap.GridArray.ToList());

                    if (searchToolbarItem != null)
                    {
                        screenData.GridToolbarItems.Add(searchToolbarItem);
                    }
                }

                var currentPageField = otherCategoryTypes.FirstOrDefault(nvp => nvp.IsCategoryCurrentPage());

                if (currentPageField != null)
                {
                    ScreenField5250 currentPageScreenField = ScreenField5250Extensions.Get5250Field(currentPageField, screenInfo.AllFields);

                    if (currentPageScreenField != null)
                    {
                        screenData.CurrentPage = currentPageScreenField;
                    }
                }

                var totalPageField = otherCategoryTypes.FirstOrDefault(nvp => nvp.IsCategoryTotalPages());

                if (totalPageField != null)
                {
                    ScreenField5250 totalPageScreenField = ScreenField5250Extensions.Get5250Field(totalPageField, screenInfo.AllFields);

                    if (totalPageScreenField != null)
                    {
                        screenData.TotalPages = totalPageScreenField;
                    }
                }

                ////If a link type of image is specified, assign the override key and image Id RRCCC so the view model can utilize the image service to
                ////display the check image
                var imageIdScreenField = screenMap.NamePairArray.FirstOrDefault(f => f.IsLinkTypeImage() && !string.IsNullOrEmpty(f.LinkDataExpression));

                if (imageIdScreenField != null)
                {
                    screenData.NVPImageViewerIdRRCCC = imageIdScreenField.GetRRCCC();
                    screenData.NVPImageViewerOverrideKey = imageIdScreenField.LinkDataExpression.Replace("{", string.Empty).Replace("}", string.Empty);
                }
            }

            if (string.IsNullOrEmpty(screenData.ScreenName))
            {
                // First try to use the Title on the Screen Map.
                if (!string.IsNullOrEmpty(screenMap.Title))
                {
                    screenData.ScreenName = FormatPageHeader(screenMap.Title, screenInfo.OutputFields);
                }
                else
                {
                    screenData.ScreenName = string.Empty;
                }
            }

            if (screenMap.GridArray != null && screenMap.GridArray.Any())
            {
                // Convert any UIGrids (that contain input fields) to NVPGrids since NVPGrids use RecordDetailFieldItems for the input fields.
                // This ensures that the expected styles are applied for input and allows for better data entry.
                if (screenMap.GridArray.Any(g => g.Grid.IsGridConvertToNVPGrid(screenInfo.InputFields)))
                {
                    ConvertUIGridToNVPGrid(screenMap.GridArray, screenData, screenInfo);
                }

                foreach (var table in screenMap.GridArray)
                {
                    if (table.Grid != null && table.Grid.GridFields != null)
                    {
                        foreach (var column in table.Grid.GridFields)
                        {
                            mappedFieldLog.Append(column);
                            mappedFieldLog.AppendLine();

                            ////If a link type of image is specified, assign the override option and image Id column so the view model can utilize the image service to
                            ////display the check image
                            if (column.IsLinkTypeImage() &&
                                !string.IsNullOrEmpty(column.LinkDataExpression) &&
                                screenData.GridImageIdColumn == 0 &&
                                string.IsNullOrEmpty(screenData.GridImageViewerOverrideOption))
                            {
                                screenData.GridImageViewerOverrideOption = column.LinkDataExpression
                                    .Replace("{", string.Empty).Replace("}", string.Empty);
                                screenData.GridImageIdColumn = column.Col;
                            }
                        }
                    }
                }

                var xpeGridData = GetGridData(screenMap, screenInfo, screenData);

                if (xpeGridData.Any())
                {
                    screenData.Grids = xpeGridData;
                }
            }

            // We must set the OK button after we have all of the function keys and ScreenData.FieldItems.
            if (screenData.ScreenActionItems != null && screenData.ScreenActionItems.Any())
            {
                screenData.ScreenActionItems = SetOKButtonAndButtonFocus(screenData);
            }

            LogToMonitor(mappedFieldLog.ToString(), MonitorType.MappedFields);

            return screenData;
        }
        catch (Exception ex)
        {
            var errorMessage = string.Format("Error processing screen mapping file: {0}", ex.Message);

            LogToMonitor(errorMessage, MonitorType.CommandData);
            var unmapped = ProcessUndefinedScreen(screenInfo);
            unmapped.MappingFileProcessingException = ex;

            return unmapped;
        }
    }

    protected virtual List<IFieldItem> GetFieldItems(IEnumerable<ScreenField> nameValuePairFields, ScreenInfoResponse screenInfo)
    {
        List<IFieldItem> fieldItems = new List<IFieldItem>();
        bool wasLastItemHeader = false;
        IFieldItem lastHeader = null;

        // Add NameValuePairs
        foreach (ScreenField namePair in nameValuePairFields)
        {
            try
            {
                // Determine if the current namePair is the best match for the 5250 field.  If not, continue to the next iteration.
                if (!this.FieldItemProvider.IsFieldBestMatch(namePair, nameValuePairFields, screenInfo.InputFields, screenInfo.OutputFields))
                {
                    continue;
                }

                if (namePair.FieldLabel == string.Empty)
                {
                    namePair.FieldLabel = null;
                }

                ScreenField5250 screenField = ScreenField5250Extensions.Get5250Field(namePair, screenInfo.AllFields);

                if (namePair.FieldCategory == ScreenMapFieldCategory.Header)
                {
                    if (wasLastItemHeader && lastHeader != null)
                    {
                        fieldItems.Remove(lastHeader);
                    }

                    //TODO
                    ////if (fieldItems.Any())
                    ////{
                    ////    fieldItems.Add(new BlankFieldItem(null));
                    ////}

                    ////lastHeader = this.GetHeaderField(namePair, screenField);

                    fieldItems.Add(lastHeader);
                    wasLastItemHeader = true;
                }
                else if ((namePair.Col == 0 && namePair.Row == 0) && !string.IsNullOrEmpty(namePair.FieldLabel))
                {
                    // Add label-only fields
                    fieldItems.Add(new LabelOnlyScreenFieldItem(namePair, screenInfo.AllFields));
                    if (namePair != null &&
                        !namePair.IsDisplayFormatIgnored())
                    {
                        wasLastItemHeader = false;
                    }
                }
                else if (namePair.FieldCategory == ScreenMapFieldCategory.AddressType)
                {
                    if (screenField?.Data != null && !string.IsNullOrEmpty(screenField?.Data?.Trim()))
                    {
                        fieldItems.Add(this.FieldItemProvider.GetFieldItem(namePair, screenField, nameValuePairFields, screenInfo, this.UserService.CurrentUserInfo));
                        if (namePair != null &&
                            !namePair.IsDisplayFormatIgnored())
                        {
                            wasLastItemHeader = false;
                        }
                    }
                }
                else if (namePair.IsCategoryField())
                {
                    if (namePair.IsLinkTypeLabel())
                    {
                        string expression = namePair.FormatLinkDataExpression(screenInfo.AllFields, false);

                        if (expression != null)
                        {
                            namePair.FieldLabel = expression;
                        }
                    }

                    // Don't add fields with Att of 39(Hidden Field) or output fields with empty label & value
                    if (screenField != null && screenField.IsVisible())
                    {
                        if (!namePair.IsDisplayFormatIgnored())
                        {
                            if (screenField.IsOutputField() && string.IsNullOrWhiteSpace(screenField.Data) && string.IsNullOrWhiteSpace(namePair.FieldLabel))
                            {
                                continue;
                            }

                            fieldItems.Add(this.FieldItemProvider.GetFieldItem(namePair, screenField, nameValuePairFields, screenInfo, this.UserService.CurrentUserInfo));

                            if (namePair != null)
                            {
                                wasLastItemHeader = false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //// adding this here so that if there is an error with one field due to mapping it will at least try to load something on the screen
                //// and not just completely error out the whole view
                string errorMessage = string.Format("Error displaying field item for {0} Location:{1} {2}", namePair.FieldLabel, namePair.Row, namePair.Col);

                this.LogToMonitor(errorMessage, MonitorType.CommandData);
                this.Logger.LogError(errorMessage, ex.Message, ex);
            }
        }

        if (wasLastItemHeader && lastHeader != null)
        {
            fieldItems.Remove(lastHeader);
        }

        return fieldItems;
    }

    private IToolbarItem GetGridSearchToolbarItem(IEnumerable<ScreenField> otherCategoryTypes, List<ScreenField5250> inputFields, List<ScreenField5250> outputFields, List<ScreenMapGridArray> gridArray)
    {
        List<string> rrcccList = new List<string>();

        foreach (ScreenField screenField in otherCategoryTypes)
        {
             if (screenField.IsCategorySearch())
            {
                rrcccList.Add(screenField.GetRRCCC());
              }
        }

        rrcccList = rrcccList.Distinct().ToList();

        List<ScreenField> searchFields = otherCategoryTypes.Where(nvp => nvp.IsCategorySearch()).ToList();

        IToolbarItem gridSearchToolbarItem = rrcccList.Count > 0 ? 
            new GridSearchToolbarItem(rrcccList, searchFields, inputFields, outputFields, gridArray, this.FieldItemProvider) : null;

        return gridSearchToolbarItem;
    }

    private void GetMappedScreenMessages(IEnumerable<ScreenField> namePairs, ScreenData screenData, List<ScreenField5250> inputFields, List<ScreenField5250> outputFields)
    {
        // Get mapped Error/Warning/Info messages
        foreach (ScreenField namePair in namePairs)
        {
            bool isMessageVisible = true;

            if (!namePair.IsDisplayFormatIgnored() && namePair.IsCategoryMessage())
            {
                if (namePair.IsDisplayFormatError())
                {
                    string errorMessage = this.GetFormattedScreenMessage(namePair, inputFields, outputFields, screenData);

                    if (!string.IsNullOrEmpty(errorMessage))
                    {
                        isMessageVisible = screenData.InfoMessages.Any(x => x == errorMessage) ? false : true;

                        if (isMessageVisible)
                        {
                            screenData.ErrorMessages.Add(errorMessage);
                        }
                    }
                }

                if (namePair.IsDisplayFormatWarning())
                {
                    string warningMessage = this.GetFormattedScreenMessage(namePair, inputFields, outputFields, screenData);

                    if (!string.IsNullOrEmpty(warningMessage))
                    {
                        isMessageVisible = screenData.ErrorMessages.Any(x => x == warningMessage) || screenData.InfoMessages.Any(x => x == warningMessage) ? false : true;

                        if (isMessageVisible)
                        {
                            screenData.WarningMessages.Add(warningMessage);
                        }
                    }
                }

                if (namePair.IsDisplayFormatNotification() || namePair.DispFormat == null)
                {
                    string infoMessage = this.GetFormattedScreenMessage(namePair, inputFields, outputFields, screenData);

                    if (!string.IsNullOrEmpty(infoMessage))
                    {
                        isMessageVisible = screenData.ErrorMessages.Any(x => x == infoMessage) ? false : true;

                        if (isMessageVisible)
                        {
                            // If the message already exists, retain the mapped version.  This ensures that notification messages display in the correct order.
                            if (screenData.InfoMessages.Any(x => x == infoMessage))
                            {
                                screenData.InfoMessages.Remove(infoMessage);
                            }

                            screenData.InfoMessages.Add(infoMessage);
                        }
                    }
                }
            }
        }

        // Remove duplicate messages
        screenData.WarningMessages = screenData.WarningMessages.Distinct().ToList();
        screenData.ErrorMessages = screenData.ErrorMessages.Distinct().ToList();
        screenData.InfoMessages = screenData.InfoMessages.Distinct().ToList();
    }

    private string GetFormattedScreenMessage(ScreenField namePair, List<ScreenField5250> inputFields, List<ScreenField5250> outputFields, ScreenData screenData)
    {
        string message = namePair.FieldLabel;

        if (string.IsNullOrEmpty(namePair.FieldLabel))
        {
            List<ScreenField5250> allFields = inputFields.Union(outputFields).ToList();
            ScreenField5250 screenField = ScreenField5250Extensions.Get5250Field(namePair, allFields);

            if (namePair.LinkDataExpression == null)
            {
                if (screenField != null)
                {
                    message = screenField.Data.Trim();
                }
            }
            else
            {
                message = namePair.FormatLinkDataExpression(allFields, false);

                if (namePair.LinkDataExpression.Contains("{") && namePair.LinkDataExpression.Contains("}") && namePair.LinkDataExpression.Contains("|"))
                {
                    // Split the Link Data Expression by strings contained in brackets and get the 5250 value
                    List<string> fieldValues = Regex.Split(namePair.LinkDataExpression, "(?={)|(?<=})").ToList();

                    message = null;

                    foreach (string fieldValue in fieldValues)
                    {
                        if (!string.IsNullOrEmpty(fieldValue))
                        {
                            string expression = fieldValue.Replace("{", string.Empty).Replace("}", string.Empty);

                            if (expression.Contains("|"))
                            {
                                string originalString = expression.Substring(0, expression.IndexOf('|')).Trim();

                                // Sometimes the cursor location on the messages can be a char off.  If we didn't find it by cursor location, try matching to the mapped
                                // original string.
                                if (screenField == null && !string.IsNullOrEmpty(originalString))
                                {
                                    screenField = allFields.FirstOrDefault(f => f.Data.Trim().Equals(originalString, StringComparison.OrdinalIgnoreCase));
                                }

                                // If the value preceding the '|' in the Link Data Expression matches the 5250 value, remove the 5250 value and return the value after the '|' in
                                // the Link Data Expression
                                if (screenField != null && !string.IsNullOrWhiteSpace(screenField.Data))
                                {
                                    if (expression.Trim().ToLower().StartsWith(screenField.Data.Trim().ToLower()))
                                    {
                                        message = expression.Substring(expression.IndexOf("|") + 1);

                                        if (screenData.ErrorMessages != null)
                                        {
                                            screenData.ErrorMessages.RemoveAll(m => m.Trim().ToLower().StartsWith(originalString.ToLower()));
                                        }

                                        if (screenData.WarningMessages != null)
                                        {
                                            screenData.WarningMessages.RemoveAll(m => m.Trim().ToLower().StartsWith(originalString.ToLower()));
                                        }

                                        if (screenData.InfoMessages != null)
                                        {
                                            screenData.InfoMessages.RemoveAll(m => m.Trim().ToLower().StartsWith(originalString.ToLower()));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return message;
    }

    private List<NVPGridData> GetNVPGrids(IEnumerable<ScreenField> nameValuePairGridFields, ScreenInfoResponse screenInfo, ScreenMap screenMap)
    {
        var list = new List<NVPGridData>();
        List<ScreenField> gridfields = new List<ScreenField>();
        List<ScreenField> mappedNVPFields = nameValuePairGridFields.ToList();
        bool showGrid = true;
        int gridIndex = 1;

        foreach (ScreenField field in mappedNVPFields)
        {
            if (field.IsCategoryGridBegin())
            {
                showGrid = true;

                // If the Row/Column on the GridBegin field is defined and there is NOT a field on the screen at the defined location,
                // then we want to hide this grid.
                if (field.Row != 0 && field.Col != 0 && !screenInfo.AllFields.Any(f => f.Row == field.Row && f.Col == field.Col))
                {
                    showGrid = false;
                }

                gridfields.Clear();
                gridfields.Add(field);
            }
            else if (field.IsCategoryGridEnd() && showGrid)
            {
                list.Add(new NVPGridData(gridfields, screenInfo, this.FieldItemProvider, this.UserService.CurrentUserInfo, gridIndex));
                gridIndex++;
            }
            else
            {
                gridfields.Add(field);
            }
        }

        return list;
    }

    private void SortScreenFields(List<ScreenField> list, StringBuilder mappedFieldLog, out IEnumerable<ScreenField> nameValuePairGridFields, out IEnumerable<ScreenField> recordDetailItems, out IEnumerable<ScreenField> otherCategories)
    {
        var recordDetailItemsList = new List<ScreenField>();
        var nameValuePairGridFieldsList = new List<ScreenField>();
        var otherCategoriesList = new List<ScreenField>();
        bool inGridBlock = false;

        foreach (ScreenField f in list)
        {
            mappedFieldLog.Append(f.ToString());
            mappedFieldLog.AppendLine();

            if (inGridBlock)
            {
                if (f.IsCategoryGridEnd())
                {
                    nameValuePairGridFieldsList.Add(f);
                    inGridBlock = false;
                }
                else if (f.IsCategoryRecordDetialItem() || f.IsCategoryColumn())
                {
                    nameValuePairGridFieldsList.Add(f);
                }
                else
                {
                    ////not sure , shouldn't be here, probably add it to other
                    otherCategoriesList.Add(f);
                }
            }
            else
            {
                if (f.IsCategoryGridBegin())
                {
                    nameValuePairGridFieldsList.Add(f);
                    inGridBlock = true;
                }
                else if (f.IsCategoryRecordDetialItem())
                {
                    recordDetailItemsList.Add(f);
                }
                else
                {
                    otherCategoriesList.Add(f);
                }
            }
        }

        recordDetailItems = recordDetailItemsList;
        nameValuePairGridFields = nameValuePairGridFieldsList;
        otherCategories = otherCategoriesList;
    }

    private string GetBannerMessageType(string screenId)
    {
        var screenIdStartsWith = screenId;

        if (!string.IsNullOrEmpty(screenId) && screenId.Contains('-'))
        {
            screenIdStartsWith = screenId.Substring(0, screenId.IndexOf("-"));
        }

        switch (screenIdStartsWith)
        {
            ////case "EP0210FM":
            ////case "EP0270FM":
            ////case "EP0300FM":
            ////case "EP0310FM":
            ////case "EP0600FM":
            ////case "EP0810FM":
            ////    return MessageFilterType.Exception;
            case "LN5050FM":
            case "LN5055FM":
                return MessageFilterType.Payoff;
            /* Filter type of 'None' causes us to display the messages that appear on green
             * screen (instead of utilizing CBS to retrieve the messages).  This is needed
             * in some programs due to some messages not coming back in the standard account-level
             * banner message response (CustInfoMsgSrch)*/
            case "CX0900FM":
            case "CD9000FM":
            case "DD9000FM":
            case "SH5000FM":
            case "LN5350FM":
            case "LN5360FM":
            case "LNS500FM":
            case "LN9000FM":
            case "LX5055FM":
            case "LX0900FM":
            case "EP0210FM":
            case "EP0270FM":
            case "EP0300FM":
            case "EP0310FM":
            case "EP0600FM":
            case "EP0810FM":
                return MessageFilterType.None;
            default:
                return MessageFilterType.AllAccounts;
        }
    }

    private BannerMessageFields GetBannerFields(IEnumerable<ScreenField> otherCategoryTypes, IEnumerable<ScreenField5250> allFields)
    {
        BannerMessageFields fields = null;
        ScreenField5250 messageLine = null;
        ScreenField5250 currentLine;
        ScreenField5250 lines;

        try
        {
            ScreenField messageLineDef = otherCategoryTypes.FirstOrDefault(f => f.IsCategoryBanner() && f.FieldRefId == "MSGLIN");
            ScreenField currentLineDef = otherCategoryTypes.FirstOrDefault(f => f.IsCategoryBanner() && f.FieldRefId == "LINE#");
            ScreenField linesDef = otherCategoryTypes.FirstOrDefault(f => f.IsCategoryBanner() && f.FieldRefId == "LINES");

            messageLine = messageLineDef.HasRangeLinkDataExpression() ? messageLine = ScreenField5250Extensions.GetFirstMatchingFieldInRange(messageLineDef.LinkDataExpression, allFields) : ScreenField5250Extensions.Get5250Field(messageLineDef, allFields);

            if (messageLine != null)
            {
                lines = linesDef.HasRangeLinkDataExpression() ? ScreenField5250Extensions.GetFirstMatchingFieldInRange(linesDef.LinkDataExpression, allFields) : ScreenField5250Extensions.Get5250Field(linesDef, allFields);
                currentLine = currentLineDef.HasRangeLinkDataExpression() ? ScreenField5250Extensions.GetFirstMatchingFieldInRange(currentLineDef.LinkDataExpression, allFields) : ScreenField5250Extensions.Get5250Field(currentLineDef, allFields);

                fields = new BannerMessageFields(messageLine, currentLine, lines);
            }
        }
        catch (Exception ex)
        {
            this.Logger.LogError("Error retrieving banner message fields from 5250", ex.Message, ex);
        }

        return fields;
    }

    private List<ScreenMapActionKey> SetOKButtonAndButtonFocus(ScreenData screenData)
    {
        ScreenMapActionKey functionOK = null;
        var isFocusSet = false;

        // Need a list here so that we can change the index of the OK button.
        List<ScreenMapActionKey> screenActionItemsList = screenData.ScreenActionItems;

        // If there is a function that starts with {submit}, set it as the OK Function.
        foreach (var mappedFunctionKey in screenActionItemsList)
        {
            var submitToken = "{submit}";

            if (mappedFunctionKey.Action != null && mappedFunctionKey.Action.ToLower().StartsWith(submitToken))
            {
                // If the mapped Action text is specified, strip the {submit} token.  Else, set to 'OK'.
                var useDefaultActionText = mappedFunctionKey.Action.Trim().ToLower() == submitToken;
                mappedFunctionKey.Action = useDefaultActionText
                    ? "OK"
                    : mappedFunctionKey.Action.Replace(submitToken, string.Empty).Trim();
                functionOK = mappedFunctionKey;
                mappedFunctionKey.IsMappedSubmitKey = true;

                // If we add a mapped function as the OK button, remove the Enter key.
                screenActionItemsList.RemoveAll(f => f.IsEnter());
                break;
            }
        }

        if (screenData.FieldItems != null && screenData.FieldItems.Any())
        {
            this.SetIsFocusAndOKfunction(screenData.FieldItems, screenData, ref isFocusSet, ref functionOK);
        }

        if (screenData.NVPGrids != null && screenData.NVPGrids.Any())
        {
            foreach (NVPGridData nvpGridData in screenData.NVPGrids)
            {
                this.SetIsFocusAndOKFunction(nvpGridData.GridFieldItems, screenData, ref isFocusSet, ref functionOK);
            }
        }

        if (screenData.Grids != null && screenData.Grids.Any())
        {
            foreach (XpeGridData xpeGridData in screenData.Grids)
            {
                this.SetIsFocusAndOKFunction(xpeGridData.GridFieldItems, screenData, ref isFocusSet, ref functionOK);
            }
        }

        //TODO: implement below code
        //if (screenData.SentencePanel?.SentenceInputFields?.Any() != null)
        //{
        //    this.SetIsFocusAndOKFunction(screenData.SentencePanel.SentenceInputFields, screenData, ref isFocusSet, ref functionOK);
        //}

        // If we set the OK button, move it to the appropriate location.
        if (functionOK != null)
        {
            screenActionItemsList.Remove(functionOK);

            // Try to get the F12 key first.
            var functionBeforeOk = screenActionItemsList.FirstOrDefault(f => f.Key == Key.F12.ToString());

            // If there isn't a F12 key, look for an F3 key.
            if (functionBeforeOk == null)
            {
                functionBeforeOk = screenActionItemsList.FirstOrDefault(f => f.Key == Key.F3.ToString());
            }

            // If we found the F12 or F3 key, put the OK function after.
            if (functionBeforeOk != null)
            {
                screenActionItemsList.Insert(screenActionItemsList.IndexOf(functionBeforeOk) + 1, functionOK);
            }
            else
            {
                // Else put the OK function at the beginning.
                screenActionItemsList.Insert(0, functionOK);
            }
        }

        if (!isFocusSet && ((screenData.TotalPages != null && screenData.TotalPages.IsFocused) ||
                            (screenData.CurrentPage != null && screenData.CurrentPage.IsFocused)))
        {
            isFocusSet = true;
        }

        // If focus was not set on any field, then set focus on the Enter or OK button.
        if (!isFocusSet)
        {
            screenActionItemsList.ForEach(f =>
            {
                if (f.IsEnter() || f.IsOK())
                {
                    f.IsFocused = true;
                }
                else
                {
                    f.IsFocused = false;
                }
            });
        }
        else
        {
            //// make sure no buttons have focus
            screenActionItemsList.ForEach(b => b.IsFocused = false);
        }

        return screenActionItemsList;
    }

    private void SetIsFocusAndOKFunction(IEnumerable<IModField5250> fieldItems, ScreenData screenData, ref bool isFocusSet, ref ScreenMapActionKey functionOK)
    {
        foreach (IModField5250 fieldItem in fieldItems)
        {
            XpeField xpeField = fieldItem as XpeField;

            if (xpeField != null)
            {
                if (!xpeField.IsReadOnly)
                {
                    if (xpeField.IsFocused)
                    {
                        isFocusSet = true;
                    }

                    // If there is an input field in a NVP Grid and we haven't set the OK Function, set it now.
                    if (functionOK == null)
                    {
                        ScreenMapActionKey enterKey = screenData.ScreenActionItems.FirstOrDefault(f => f.IsEnter());

                        if (enterKey != null && enterKey.HasEnterActionText())
                        {
                            enterKey.Action = "OK";
                        }

                        functionOK = enterKey;
                    }
                }

                continue;
            }

            ModField5250 modField = fieldItem as ModField5250;

            if (modField != null)
            {
                if (!modField.IsReadOnly)
                {
                    if (modField.IsFocused)
                    {
                        isFocusSet = true;
                    }

                    // If there is an input field in a NVP Grid and we haven't set the OK Function, set it now.
                    if (functionOK == null)
                    {
                        ScreenMapActionKey enterKey = screenData.ScreenActionItems.FirstOrDefault(f => f.IsEnter());

                        if (enterKey != null && enterKey.HasEnterActionText())
                        {
                            enterKey.Action = "OK";
                        }

                        functionOK = enterKey;
                    }
                }
            }
        }
    }

    private void SetIsFocusAndOKfunction(List<IFieldItem> fieldItems, ScreenData screenData, ref bool isFocusSet, ref ScreenMapActionKey functionOK)
    {
        foreach (IFieldItem fieldItem in fieldItems)
        {
            XpeField xpeField = fieldItem as XpeField;

            if (xpeField != null && !xpeField.IsReadOnly)
            {
                if (xpeField.IsFocused)
                {
                    isFocusSet = true;
                }

                // If there is an input field in the Field Items and we haven't set the OK Function, set it now.
                if (functionOK == null)
                {
                    ScreenMapActionKey enterKey = screenData.ScreenActionItems.FirstOrDefault(f => f.IsEnter());

                    if (enterKey != null && enterKey.HasEnterActionText())
                    {
                        enterKey.Action = "OK";
                    }

                    functionOK = enterKey;
                }
            }
        }
    }

    private List<XpeGridData> GetGridData(ScreenMap screenMap, ScreenInfoResponse screenInfo, ScreenData screenData)
    {
        var gridlist = new List<XpeGridData>();

        int uiGridIndex = 1;
        int dynamicGridIndex = 1;
        int allGridIndex = 1;

        // Add tables.
        foreach (ScreenMapGridArray table in screenMap.GridArray)
        {
            bool removeScreenActionItems = false;
            XpeGridData gridData;

            if (!table.Grid.IsGridConvertToNVPGrid(screenInfo.InputFields))
            {
                if (!table.Grid.IsDynamicGrid)
                {
                    gridData = new XpeUIGridData(table, screenInfo, this.FieldItemProvider, this.UserService.CurrentUserInfo, screenMap);
                    gridlist.Add(gridData);

                    if (uiGridIndex == screenMap.GridArray.Count)
                    {
                        removeScreenActionItems = true;
                    }

                    uiGridIndex++;
                }
                else
                {
                    gridData = new DynamicNVPGridData(table, screenMap.NamePairArray.ToList(), screenInfo, this.FieldItemProvider, this.UserService.CurrentUserInfo, table.Grid, dynamicGridIndex);
                    gridlist.Add(gridData);

                    if (dynamicGridIndex == screenMap.GridArray.Count)
                    {
                        removeScreenActionItems = true;
                    }

                    dynamicGridIndex++;
                }

                // give the grid an index of which grid it is in the list of grids on this screen
                gridData.Index = allGridIndex;

                allGridIndex++;

                this.SetGridNextPreviousCommands(table, gridData, screenInfo, screenData, removeScreenActionItems);
            }
        }

        return gridlist;
    }

    private void SetGridNextPreviousCommands(ScreenMapGridArray table, XpeGridData gridData, ScreenInfoResponse screenInfo, ScreenData screenData, bool removeScreenActionItems)
    {
        ScreenField screenFieldFirst = table.Grid.GridFields.FirstOrDefault(f => f.Col > 0 && f.Row > 0);
        CursorLocation cursorLocation = screenFieldFirst != null ? new CursorLocation(screenFieldFirst.Row, screenFieldFirst.Col) : screenInfo.CursorLocation;

        // If Page Up exists in the action item, setup the Previous Data Command and remove the Page Up action item.
        ScreenMapActionKey pageUp = screenData.ScreenActionItems.FirstOrDefault(a => a.Key == "Page Up");

        if (pageUp != null)
        {
            gridData.PreviousDataCommand = screenData.ScreenActionItems.Any(a => a.Key == "Page Up") ?
                new ScreenInfoRequest(new KeyPress(Key.PageUp, Key.None), cursorLocation) : null;

            if (removeScreenActionItems)
            {
                screenData.ScreenActionItems.Remove(pageUp);
            }
        }

        // If Page Down exists in the action item, setup the Next Data Command and remove the Page Down action item.
        ScreenMapActionKey pageDown = screenData.ScreenActionItems.FirstOrDefault(a => a.Key == "Page Down");

        if (pageDown != null)
        {
            gridData.NextDataCommand = screenData.ScreenActionItems.Any(a => a.Key == "Page Down") ?
                new ScreenInfoRequest(new KeyPress(Key.PageDown, Key.None), cursorLocation) : null;

            if (removeScreenActionItems)
            {
                screenData.ScreenActionItems.Remove(pageDown);
            }
        }
    }

    private void ConvertUIGridToNVPGrid(ObservableCollection<ScreenMapGridArray> gridArrays, ScreenData screenData,
        ScreenInfoResponse screenInfo)
    {
        List<ScreenMapGridArray> nvpConvertList = gridArrays.Where(g => g.Grid.IsGridConvertToNVPGrid(screenInfo.InputFields)).ToList();

        if (nvpConvertList != null && nvpConvertList.Any())
        {
            int gridIndex = screenData.NVPGrids != null && screenData.NVPGrids.Any() ? screenData.NVPGrids.Count : 1;

            foreach (ScreenMapGridArray gridArray in nvpConvertList)
            {
                bool removeScreenActionItems = false;

                if (gridArray.Grid.IsGridConvertToNVPGrid(screenInfo.InputFields))
                {
                    List<ScreenField> nvpFields = DynamicNVPGridData.GetFields(gridArray, screenInfo.OutputFields);

                    var gridHeaderField = nvpFields.FirstOrDefault(f => f.IsCategoryGridBegin());
                    gridHeaderField.FieldLabel = gridArray.Grid.HeaderText;

                    if (screenData.NVPGrids == null)
                    {
                        screenData.NVPGrids = new List<NVPGridData>();
                    }

                    if (gridIndex == nvpConvertList.Count)
                    {
                        removeScreenActionItems = true;
                    }

                    gridIndex++;

                    NVPGridData convertedNVPGrid = new NVPGridData(nvpFields, screenInfo, this.FieldItemProvider, this.UserService.CurrentUserInfo, gridIndex, gridArray.Grid);
                    this.SetGridNextPreviousCommands(gridArray, convertedNVPGrid, screenInfo, screenData, removeScreenActionItems);
                    screenData.NVPGrids.Add(convertedNVPGrid);
                }
            }
        }
    }

    private string FormatPageHeader(string headerText, List<ScreenField5250> outputFields)
    {
        // Split the Link Data Expression by strings contained in brackets
        var fieldValues = Regex.Split(headerText, "(?={)|(?<=})").ToList();

        // Strip brackets from all known tokens (SPACE, RANGE, field references) and leave/display the rest
        for (var i = 0; i < fieldValues.Count; i++)
        {
            if (fieldValues[i].StartsWith("{SPACE:", true, CultureInfo.InvariantCulture) ||
                fieldValues[i].StartsWith("{RANGE", true, CultureInfo.InvariantCulture) ||
                Regex.IsMatch(fieldValues[i], "{[0-9]{5}}"))
            {
                fieldValues[i] = fieldValues[i].Replace("{", string.Empty);
                fieldValues[i] = fieldValues[i].Replace("}", string.Empty);
            }

            int n;
            var isNumeric = int.TryParse(fieldValues[i], out n);

            if (isNumeric && fieldValues[i].Length == 5)
            {
                var screen5250 = ScreenField5250Extensions.GetFieldByRRCCC(fieldValues[i], outputFields);

                if (screen5250 != null)
                {
                    fieldValues[i] = screen5250.Data.Trim();
                }
                else
                {
                    // If we don't find the RRCCC, then set the item to blank.
                    fieldValues[i] = string.Empty;
                }
            }
        }

        return string.Join(string.Empty, fieldValues);
    }

    private bool IsGridUnfolded(ScreenMapGridArrayGrid grid, IEnumerable<ScreenField5250> allFields,
        UnfoldKeyData unfoldData)
    {
        var isUnfolded = false;

        ////look at screen and determine if screen is folded or unfolded
        if (grid.GridRowsPerRec > 1 && grid.GridFields != null && grid.GridFields.Any())
        {
            if (!string.IsNullOrEmpty(unfoldData.StateExpression))
            {
                try
                {
                    return IsGridUnfolded(unfoldData.StateExpression, allFields);
                }
                catch (Exception ex)
                {
                    LogToMonitor(
                        string.Format("Error using expression to determine Fold/Unfold state: {0}", ex.Message),
                        MonitorType.CommandData);
                }
            }

            LogToMonitor("Using default code to determine fold/unfold state.", MonitorType.CommandData);

            var foldedMatches = 0;
            var unfoldedMatches = 0;
            var trailingBlankRow = false;
            var additionalFields = false;

            // group grid fields by row, tally matches for "folded" and "unfolded"
            IEnumerable<IGrouping<int, ScreenField>> query = grid.GridFields.GroupBy(field => field.Row, field => field)
                .OrderBy(g => g.Key);

            var firstRow = query.First().Key;
            var lastrow = query.Last().Key;

            var lastRowFields = allFields.Where(f => f.Row == lastrow);

            var lastLineData = string.Empty;

            foreach (var data in lastRowFields)
            {
                lastLineData = string.Format("{0}{1}", lastLineData, data.Data);
            }

            if (string.IsNullOrEmpty(lastLineData.Trim()))
            {
                trailingBlankRow = true;
            }

            var firstRowFields = query.First();
            var fieldCount = 0;

            foreach (var field in firstRowFields)
            {
                // check what should be unfolded rows for matches against first row fields, matches mean grid is probably folded
                for (var row = firstRow; row <= lastrow; row++)
                {
                    fieldCount++;
                    var rrccc = string.Format("{0}{1}", row.ToString("00"), field.Col.ToString("000"));
                    var field5250 = GetFieldByRRCCC(rrccc, allFields);

                    if (field5250 != null)
                    {
                        foldedMatches++;
                    }
                }
            }

            var foldedAccuracy = (double) foldedMatches / fieldCount;

            if (foldedAccuracy == 1.0)
            {
                ////check for additional fields on these rows that could mean its unfolded, even though all the right ones matched
                for (var row = firstRow + 1; row <= lastrow; row++)
                    if (allFields.Any(f => f.Row == row && !firstRowFields.Any(sf => sf.Col == f.Col)))
                    {
                        additionalFields = true;
                        break;
                    }
            }

            if (!trailingBlankRow || additionalFields)
            {
                ////check the accuracy using the unfolded mapping
                var unfoldedFieldCount = 0;

                foreach (var field in grid.GridFields)
                {
                    unfoldedFieldCount++;
                    var rrccc = string.Format("{0}{1}", field.Row.ToString("00"), field.Col.ToString("000"));
                    var field5250 = GetFieldByRRCCC(rrccc, allFields);

                    if (field5250 != null)
                    {
                        unfoldedMatches++;
                    }
                }

                var unfoldedAccuracy = (double) unfoldedMatches / unfoldedFieldCount;

                isUnfolded = unfoldedAccuracy > foldedAccuracy;
            }
        }

        LogToMonitor("Grid is " + (isUnfolded ? "Unfolded" : "Folded"), MonitorType.CommandData);
        return isUnfolded;
    }

    private bool IsGridUnfolded(string functionKeyExpression, IEnumerable<ScreenField5250> allFields)
    {
        LogToMonitor(string.Format("Using expression to determine Fold/Unfold state: '{0}'", functionKeyExpression),
            MonitorType.CommandData);
        //// use the expression to figure out folded or unfolded, right now the only supported function is {UNFOLDED:position:optional-value}
        var unfoldedfunctionPattern = @"{unfolded:";
        var function = Regex.Match(functionKeyExpression, unfoldedfunctionPattern, RegexOptions.IgnoreCase).Value;

        if (!string.IsNullOrEmpty(function))
        {
            function = function.Replace("{", string.Empty).Replace(":", string.Empty).ToLower();

            var values = Regex.Split(functionKeyExpression, unfoldedfunctionPattern, RegexOptions.IgnoreCase);
            var expression = string.Empty;

            foreach (var s in values)
            {
                expression = string.Format("{0}{1}", expression, s);
            }

            expression = expression.TrimEnd('}');

            var comparison = Regex.Split(expression, ":");
            var rightValue = string.Empty;
            var leftValue = string.Empty;
            var left = true;
            var curlyCount = 0;
            var index = 0;

            foreach (var s in comparison)
            {
                if (s.StartsWith("{"))
                {
                    curlyCount++;
                }

                if (s.EndsWith("}"))
                {
                    curlyCount--;
                }

                if (!left)
                {
                    if (index > 0)
                    {
                        rightValue = string.Format("{0}:", rightValue);
                    }

                    rightValue = string.Format("{0}{1}", rightValue, s);
                }
                else
                {
                    if (index > 0)
                    {
                        leftValue = string.Format("{0}:", leftValue);
                    }

                    leftValue = string.Format("{0}{1}", leftValue, s);
                }

                if (left && curlyCount == 0)
                {
                    left = false;
                    index = 0;
                }
                else
                {
                    index++;
                }
            }

            var rrccc = leftValue.TrimStart('{').TrimEnd('}').Trim();
            int n;
            var isNumeric = int.TryParse(rrccc, out n);

            //// Right side is empty, check for existence of field at rrccc
            if (rrccc.Length == 5 && isNumeric && string.IsNullOrEmpty(rightValue))
            {
                LogToMonitor(
                    string.Format("Checking the existence of a field at {0} to determine Fold/Unfold state", rrccc),
                    MonitorType.CommandData);
                var screen5250 = ScreenField5250Extensions.GetFieldByRRCCC(rrccc, allFields);

                if (screen5250 != null)
                {
                    LogToMonitor(string.Format("Found field at {0}, screen is unfolded.", rrccc),
                        MonitorType.CommandData);
                    return true;
                }

                LogToMonitor(string.Format("No field found at {0}, screen is folded.", rrccc), MonitorType.CommandData);
                return false;
            }

            leftValue = ScreenFieldExtensions.FormatLinkDataExpression(leftValue, allFields, false, false);

            if (leftValue != null)
            {
                LogToMonitor(
                    string.Format("Comparing '{0}' with '{1}' to determine folded/unfolded state.", leftValue,
                        rightValue), MonitorType.CommandData);

                //// Right side is empty, check for non whitespace
                if (string.IsNullOrEmpty(rightValue))
                {
                    LogToMonitor("Checking the existence of non whitespace to determine Fold/Unfold state",
                        MonitorType.CommandData);

                    if (!string.IsNullOrWhiteSpace(leftValue))
                    {
                        LogToMonitor(string.Format("Non whitespace in '{0}', screen is unfolded", leftValue),
                            MonitorType.CommandData);
                        return true;
                    }
                }
                else if (leftValue.ToLower().Contains(rightValue.ToLower()))
                {
                    LogToMonitor(string.Format("'{0}' is in '{1}', screen is unfolded", rightValue, leftValue),
                        MonitorType.CommandData);
                    return true;
                }
            }

            LogToMonitor("Screen is folded", MonitorType.CommandData);
            return false;
        }

        throw new Exception("Fold/Unfold expression is not valid");
    }

    private ScreenField5250 GetFieldByRRCCC(string rrccc, IEnumerable<ScreenField5250> fields)
    {
        foreach (var entry in fields)
        {
            if (entry.RRCCC == rrccc)
            {
                return entry;
            }
        }

        return null;
    }

    private List<ScreenMapActionKey> GetMappedFunctionKeys(ScreenData screenData, ScreenMap screenMap,
        bool includeUnFoldKey, out bool getMoreFunctionKeys)
    {
        getMoreFunctionKeys = false;

        // Get the function keys from the screen.
        var screenFunctionKeys =
            GetScreenFunctionKeys(screenData.ScreenInfo.OutputFields, screenMap.FunctionKeyParsingRange);

        // Check for existence of all the function keys on the current screen to know if we have gathered this list yet.
        foreach (var screenFunctionKey in screenFunctionKeys)
        {
            // If it doesn't exist, add it.
            if (!ScreenFunctionKeysStorage.Any(f => f.Key == screenFunctionKey.Key))
            {
                ScreenFunctionKeysStorage.Add(screenFunctionKey);

                // If we add a function key and there is a F24 function key on the screen, we need to go get more functions.
                if (!getMoreFunctionKeys && screenFunctionKeys.Any(f => f.IsMoreFunction()) &&
                    !screenMap.ScreenActionKeyArray.Any(f => f.IsMoreForceDisplay()) &&
                    !screenMap.ScreenActionKeyArray.Any(f => f.IsMoreIgnored()))
                {
                    getMoreFunctionKeys = true;
                }
            }
            else if (!string.IsNullOrEmpty(screenFunctionKey.Action))
            {
                // Else if it also has an action, then look for the associated function key
                var associatedScreenFunction =
                    ScreenFunctionKeysStorage.FirstOrDefault(f => f.Key == screenFunctionKey.Key);

                // If the associated function key doesn't have an action, set the Action to the screenFunctionKeys's Action
                if (associatedScreenFunction != null && string.IsNullOrEmpty(associatedScreenFunction.Action))
                {
                    associatedScreenFunction.Action = screenFunctionKey.Action;
                }
            }
        }

        // Stop processing this screen and go get more function keys.s
        ////if (getMoreFunctionKeys)
        ////{
        ////    return null;
        ////}

        var mappedScreenFunctionKeys = new List<ScreenMapActionKey>();

        ScreenFunctionKeysStorage.AddRange(GetForcedFunctionKeys(screenMap, ScreenFunctionKeysStorage));
        ScreenFunctionKeysStorage = ScreenFunctionKeysStorage.OrderBy(k => k.Key.Length).ThenBy(k => k.Key).ToList();

        ScreenFunctionKeysStorage.InsertRange(0,
            GetMappedPagingFunctionKeys(screenData.ScreenInfo.OutputFields, screenMap));
        ScreenFunctionKeysStorage.InsertRange(0, GetDefaultFunctionKeys());

        foreach (var screenFunctionKey in ScreenFunctionKeysStorage)
        {
            // If the function key doesn't already exist and it isn't F4=Field Values or F24. We don't want to display F4 because we should have
            // elipses for all functions that are promptable and the user can click that instead.
            if (
                !mappedScreenFunctionKeys.Exists(f => f.Key == screenFunctionKey.Key) &&
                (!screenFunctionKey.IsMoreFunction() ||
                 screenMap.ScreenActionKeyArray.Any(f => f.IsMoreForceDisplay())) &&
                (!screenFunctionKey.IsPromptFunction() ||
                 (!screenFunctionKey.IsFieldValues() && !screenFunctionKey.IsTypeHelp())))
            {
                // Look for the associated function in the Screen Map.
                var mappedfunctionKey =
                    screenMap.ScreenActionKeyArray.FirstOrDefault(a => a.Key == screenFunctionKey.Key);

                // If the Screen Map function key has an action(*description) defined, use the Screen Map function keys action(*description).
                // Note: There is currently a null check on function.Action, but in the future Action should never be null since the mapper only saves
                // out Function Keys when there is an action present.
                if (mappedfunctionKey != null)
                {
                    if (mappedfunctionKey.IsForceDisplay())
                    {
                        // If the mapped function key is ForceDisplayed, then we need to scrub off the {forcedisplay} tag.
                        mappedfunctionKey.Action = mappedfunctionKey.Action
                            .Substring(mappedfunctionKey.Action.LastIndexOf('}') + 1).Trim();
                    }

                    if (!string.IsNullOrEmpty(mappedfunctionKey.Action))
                    {
                        screenFunctionKey.Action = mappedfunctionKey.Action;
                    }
                    else if (!string.IsNullOrEmpty(screenFunctionKey.Action))
                    {
                        screenFunctionKey.Action =
                            Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(screenFunctionKey.Action);
                    }
                }
                else
                {
                    // If we don't find the Screen Map function, camel case the text that is on the Green Screen. Must pass the Action in lower case
                    // or the ToTitleCase method doesn't work correctly.
                    if (!string.IsNullOrEmpty(screenFunctionKey.Action))
                    {
                        // If the first char is a numeric and 2nd char is upper-alpha we want to make the 2nd char lower instead
                        // Example: "1St Address" and "2Nd Address" look silly
                        if (char.IsDigit(screenFunctionKey.Action[0]) && char.IsLetter(screenFunctionKey.Action[1]))
                        {
                            // If the FunctionKey is multiple words: we want to skip titlecase on the first word,
                            // but ensure the others are properly formatted.
                            var splitIndex = screenFunctionKey.Action.IndexOf(' ');
                            if (splitIndex > 0)
                            {
                                screenFunctionKey.Action = string.Format(
                                    "{0}{1}",
                                    screenFunctionKey.Action.Substring(0, splitIndex),
                                    Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(
                                        screenFunctionKey.Action.Substring(splitIndex)));
                            }
                        }
                        else
                        {
                            screenFunctionKey.Action =
                                Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(screenFunctionKey.Action);
                        }
                    }
                }

                if (screenFunctionKey != null && screenFunctionKey.Action != null)
                {
                    if (!screenFunctionKey.IsIgnore())
                    {
                        mappedScreenFunctionKeys.Add(screenFunctionKey);
                    }
                }
            }
        }

        // Remove the Grid Unfold Key from the functions list.
        if (screenMap.GridArray.Any() && !includeUnFoldKey)
        {
            foreach (var grid in screenMap.GridArray)
            {
                if (grid.Grid != null && !string.IsNullOrEmpty(grid.Grid.GetUnFoldKeyData().Key))
                {
                    mappedScreenFunctionKeys.RemoveAll(f =>
                        f.Key.ToLower() == grid.Grid.GetUnFoldKeyData().Key.ToLower());
                }
            }
        }

        return mappedScreenFunctionKeys;
    }

    private List<ScreenMapActionKey> GetForcedFunctionKeys(ScreenMap screenMap,
        List<ScreenMapActionKey> screenFunctionKeys)
    {
        var forcedFunctionKeys = new List<ScreenMapActionKey>();

        // Add any function keys that we always want to force on screen if indicated in the mapper
        foreach (var functionKey in screenMap.ScreenActionKeyArray)
        {
            // If the mapper indicates the function should be forced, add it if we doesn't already exist
            if (functionKey.IsForceDisplay())
            {
                if (!screenFunctionKeys.Any(a => a.Key == functionKey.Key))
                {
                    forcedFunctionKeys.Add(functionKey);
                }
            }
        }

        return forcedFunctionKeys;
    }

    private void GetUnmappedScreenMessages(ScreenMap screenMap, ScreenData screenData,
        List<ScreenField5250> outputFields)
    {
        screenData.ErrorMessages.Clear();
        screenData.WarningMessages.Clear();
        screenData.InfoMessages.Clear();

        var sb = new StringBuilder();

        foreach (var outputField in outputFields)
        {
            var fieldData = outputField.Data.Trim();

            // Get dynamic Error messages that have been flagged in the data stream
            if (outputField.IsErrorField())
            {
                screenData.ErrorMessages.Add(fieldData);
            }

            // Get row 24 messages (fields that do not contain a function key string and are not suppressed in the mapper)
            if (!screenMap.IsLine24MessageIgnored)
            {
                if (outputField.Row == 24 && fieldData.Length > 1)
                {
                    var message = outputField.Data.Trim();

                    if (!screenData.ErrorMessages.Any(x => x == message) &&
                        !FunctionKeyRegex.IsMatch(outputField.Data) &&
                        !outputField.Data.StartsWith("ENTER="))
                    {
                        sb.Append(message);
                    }
                }
            }
        }

        ////If we've added line 24 messages, check the screen map for any fields that have been mapped without a Label OR a LinkDataExpression but have a display format
        ////specified.  This indicates to us what message type to use.  Else, we default to notification type.
        var combinedMessage = sb.ToString();

        if (!string.IsNullOrEmpty(combinedMessage))
        {
            var defaultMessageTypeField = screenMap.NamePairArray?.FirstOrDefault(nvp =>
                nvp.IsCategoryMessage() &&
                !string.IsNullOrEmpty(nvp.DispFormat) &&
                string.IsNullOrEmpty(nvp.FieldLabel) &&
                string.IsNullOrEmpty(nvp.LinkDataExpression));

            if (defaultMessageTypeField == null || defaultMessageTypeField.IsDisplayFormatNotification())
            {
                screenData.InfoMessages.Add(sb.ToString());
            }

            if (defaultMessageTypeField != null)
            {
                if (defaultMessageTypeField.IsDisplayFormatWarning())
                {
                    screenData.WarningMessages.Add(sb.ToString());
                }
                else if (defaultMessageTypeField.IsDisplayFormatError())
                {
                    screenData.ErrorMessages.Add(sb.ToString());
                }
            }
        }
    }

    private ScreenData ProcessUndefinedScreen(ScreenInfoResponse screenInfo)
    {
        var screenData = new ScreenData(screenInfo);
        var screenMap = new ScreenMap();

        if (!string.IsNullOrEmpty(screenInfo.ScreenMapData))
        {
            screenMap = ScreenMap.Deserialize(screenInfo.ScreenMapData);
        }

        screenData.ScreenActionItems = GetUnmappedFunctionKeys(screenData.ScreenInfo.OutputFields, screenInfo.ScreenId,
            screenMap.FunctionKeyParsingRange);

        ////If this is an unmapped IBM screen, set the appropriate screen name with prefix
        if (screenInfo.OutputFields != null && screenInfo.OutputFields.Any() && screenInfo.IsIBMScreen)
        {
            screenData.ScreenName = "IBM Screen";
            IEnumerable<ScreenField5250> outputFields = ScreenField5250.Reorder(screenInfo.OutputFields);
            var titleField = outputFields.FirstOrDefault(f =>
                !string.IsNullOrWhiteSpace(f.Data) && !f.Data.ToLower().Contains("copyright ibm"));

            if (titleField != null)
            {
                screenData.ScreenName = string.Format("{0} - {1}", screenData.ScreenName, titleField.Data.Trim());
            }
        }

        return screenData;
    }

    private List<ScreenMapActionKey> GetUnmappedFunctionKeys(IEnumerable<ScreenField5250> outputFields, string screenId,
        string functionKeyParsingRange)
    {
        var unmappedFunctionKeys = new List<ScreenMapActionKey>();

        unmappedFunctionKeys.AddRange(GetDefaultFunctionKeys());
        unmappedFunctionKeys.AddRange(GetUnmappedPagingFunctionKeys(outputFields, screenId));

        // Add function keys from the screen.
        foreach (var screenFunctionKey in GetScreenFunctionKeys(outputFields, functionKeyParsingRange))
        {
            // Add the function key if it doesn't already exist.
            if (unmappedFunctionKeys.FirstOrDefault(f => f.Key == screenFunctionKey.Key) == null)
            {
                unmappedFunctionKeys.Add(screenFunctionKey);
            }
        }

        return unmappedFunctionKeys;
    }

    private void SetScreenMapSequenceNumbers(ScreenMap screenMap)
    {
        ////Sometimes the screen map generator fails to assign valid sequence values.  We use those sequence numbers to assign a FieldId when
        ////building JHARecordDetailFieldItems so it's important that they are unique.  Changes have also been made to Screen Mapper to ensure that the sequence numbers
        ////exist when saving maps.  However, maps can still exist in the field that contain unassigned numbers (causing the JHARecordDetail container to throw an error)
        if (screenMap.NamePairArray != null && screenMap.NamePairArray.Any(f => f.Sequence == 0))
        {
            AssignFieldSequences(screenMap.NamePairArray);
        }

        if (screenMap.GridArray != null)
        {
            if (screenMap.GridArray.Count >= 1 && screenMap.GridArray[0]?.Grid?.GridFields != null &&
                screenMap.GridArray[0].Grid.GridFields.Any(f => f.Sequence == 0))
            {
                AssignFieldSequences(screenMap.GridArray[0].Grid.GridFields);
            }

            if (screenMap.GridArray.Count > 1 && screenMap.GridArray[1]?.Grid?.GridFields != null &&
                screenMap.GridArray[1].Grid.GridFields.Any(f => f.Sequence == 0))
            {
                AssignFieldSequences(screenMap.GridArray[1].Grid.GridFields);
            }
        }
    }

    private void AssignFieldSequences(ObservableCollection<ScreenField> fields)
    {
        var fieldCounter = 10;

        foreach (var screenField in fields)
        {
            if (screenField.Sequence != fieldCounter)
            {
                screenField.Sequence = fieldCounter;
            }

            fieldCounter += 10;
        }
    }

    private static string GetFormattedCommandLogEntry(ScreenInfoRequest screenInfoRequest)
    {
        var cmd = string.Format("[{0:00}][{1:000}][{2}][{3}]",
            screenInfoRequest.CursorLocation.Row,
            screenInfoRequest.CursorLocation.Column,
            screenInfoRequest.Key?.Modifier != null
                ? $"{{{screenInfoRequest.Key.Modifier}}}"
                : string.Empty,
            screenInfoRequest.Key?.Key != null
                ? $"{{{screenInfoRequest.Key.Key}}}"
                : string.Empty);

        if (screenInfoRequest.ChangedFields == null || !screenInfoRequest.ChangedFields.Any())
        {
            return cmd;
        }

        var inputCommand = screenInfoRequest.ChangedFields
            .Aggregate(string.Empty, (current, screenField) =>
                string.Format("{0}^[{1:00}][{2:000}][{3}]", current, screenField.Row, screenField.Col,
                    screenField.IsPasswordField() ? "**MASKED**" : screenField.Data ?? string.Empty));

        if (!string.IsNullOrEmpty(inputCommand))
        {
            cmd += inputCommand;
        }

        return cmd;
    }

    private IEnumerable<ScreenMapActionKey> GetDefaultFunctionKeys()
    {
        var defaultFunctionKeys = new List<ScreenMapActionKey>();

        // Add the exit key.
        var exitFunctionKey = new ScreenMapActionKey
        {
            Key = "F3",
            Action = "Exit"
        };
        defaultFunctionKeys.Add(exitFunctionKey);

        // Add the previous key.
        var previousFunctionKey = new ScreenMapActionKey
        {
            Key = "F12",
            Action = "Previous"
        };
        defaultFunctionKeys.Add(previousFunctionKey);

        // Add the enter key.
        var enterFunctionKey = new ScreenMapActionKey
        {
            Key = "Enter",
            Action = "Enter"
        };
        defaultFunctionKeys.Add(enterFunctionKey);

        return defaultFunctionKeys;
    }

    private IEnumerable<ScreenMapActionKey> GetUnmappedPagingFunctionKeys(IEnumerable<ScreenField5250> outputFields,
        string screenId)
    {
        var pagingFunctionKeys = new List<ScreenMapActionKey>();

        ////Add function keys for Page Up and Page Down.  If we're on the Programmer's Menu, it is always an unmapped view and paging functions should always display.  Else,
        ////we add paging keys if More/Bottom fields exist
        if (screenId == ScreenIdentification.ProgrammersMenu)
        {
            pagingFunctionKeys.Add(GetPageUpActionKey());
            pagingFunctionKeys.Add(GetPageDownActionKey());
        }
        else
        {
            foreach (var outputField in outputFields)
            {
                //// found that some unmapped 3rd party screens have a space after More
                if (outputField.Data.Contains("More..") || outputField.Data.Contains("Bottom") ||
                    outputField.Data.Contains("More .."))
                {
                    pagingFunctionKeys.Add(GetPageUpActionKey());
                    pagingFunctionKeys.Add(GetPageDownActionKey());
                    break;
                }
            }
        }

        return pagingFunctionKeys;
    }

    private IEnumerable<ScreenMapActionKey> GetMappedPagingFunctionKeys(IEnumerable<ScreenField5250> outputFields,
        ScreenMap screenMap)
    {
        var pagingFunctionKeys = new List<ScreenMapActionKey>();

        if (outputFields.Any(o => o.Data.Contains("More..")))
        {
            pagingFunctionKeys.Add(GetPageUpActionKey());
            pagingFunctionKeys.Add(GetPageDownActionKey());
        }
        else if (outputFields.Any(o => o.Data.Contains("Bottom")))
        {
            pagingFunctionKeys.Add(GetPageUpActionKey());
        }
        else if (screenMap?.GridArray?.Any() == true)
        {
            // Assume that since there are mapped grids, we want paging function keys
            pagingFunctionKeys.Add(GetPageUpActionKey());

            // The screen isn't using "More.." to indicate more records, so how about a "+"?
            if (HasPlusPagingIndicator(outputFields, screenMap))
            {
                pagingFunctionKeys.Add(GetPageDownActionKey());
            }
        }

        return pagingFunctionKeys;
    }

    private bool HasPlusPagingIndicator(IEnumerable<ScreenField5250> outputFields, ScreenMap screenMap)
    {
        foreach (var gridMap in screenMap.GridArray)
        {
            if (gridMap?.Grid?.GridFields?.Any() == true)
            {
                var firstGridRow = gridMap.Grid.GridFields.Min(f => f.Row);
                var lastGridRow = firstGridRow - 1 + gridMap.Grid.GridRowCount * gridMap.Grid.GridRowsPerRec;

                var plusPagingIndicatorField = outputFields.FirstOrDefault(
                    f => f.Row == lastGridRow && f.Col == screenMap.ScreenWidth - 1);

                if (plusPagingIndicatorField?.Data == "+")
                {
                    return true;
                }
            }
        }

        return false;
    }

    private ScreenMapActionKey GetPageDownActionKey()
    {
        return new ScreenMapActionKey
        {
            Key = "Page Down",
            Action = "Page Down"
        };
    }

    private ScreenMapActionKey GetPageUpActionKey()
    {
        return new ScreenMapActionKey
        {
            Key = "Page Up",
            Action = "Page Up"
        };
    }

    private void ReleaseUnmanagedResources()
    {
        // TODO release unmanaged resources here
    }

    private void Dispose(bool disposing)
    {
        ReleaseUnmanagedResources();

        if (disposing)
        {
            ServiceScope?.Dispose();
        }
    }

    ~XperienceEnabledService()
    {
        Dispose(false);
    }
}