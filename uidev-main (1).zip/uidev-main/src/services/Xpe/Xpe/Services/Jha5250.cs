﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Ardalis.GuardClauses;
using JackHenry.Banking.IAdapter.Infrastructure.Models;
using Xpe.Abstraction.Commands;
using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Extensions;
using Xpe.Abstraction.Infrastructure;
using Xpe.Abstraction.Model;
using Xpe.Abstraction.Services;
using Xpe.Infrastructure;
using MediatR;
using Microsoft.Extensions.Logging;
using Xpe.Cache;
using Xpe.Cache.Infrastructure;

namespace Xpe.Services;

public class Jha5250 : IJha5250
{
    private const byte NULL = 0x00; // Read Mandatory Fields
    private const byte EORM = 0xFF; // End of Record Marker
    private const byte EOR = 0xEF; // End of Record
    private const byte ESC = 0x04;

    public Jha5250(
        ILogger<Jha5250> logger,
        IISeriesConnectionInfoService connectionInfoService,
        IISeriesServer server,
        IEbcdicConverter ebcdicConversion,
        IUserCache cacheManager,
        IMediator mediator)
    {
        Logger = Guard.Against.Null(logger,
            nameof(logger));

        ConnectionInfoService = Guard.Against.Null(connectionInfoService,
            nameof(connectionInfoService));

        Server = Guard.Against.Null(server,
            nameof(server));

        EbcdicConversion = Guard.Against.Null(ebcdicConversion,
            nameof(ebcdicConversion));

        CacheManager = Guard.Against.Null(cacheManager,
            nameof(cacheManager));

        Mediator = Guard.Against.Null(mediator,
            nameof(mediator));

        ResponseCollection = new BlockingCollection<List<byte>>();
        PrinterResponseCollection = new BlockingCollection<List<byte>>();
    }

    private IMediator Mediator { get; }
    private IUserCache CacheManager { get; }
    private IISeriesConnectionInfoService ConnectionInfoService { get; }
    private IEbcdicConverter EbcdicConversion { get; }
    private ILogger<Jha5250> Logger { get; }
    private IISeriesServer Server { get; }
    private string UserIdentifier { get; set; }
    private Task MonitorServerStreamTask { get; set; }
    private Task MonitorResponseCollectionTask { get; set; }
    private CancellationTokenSource CancellationTokenSource { get; set; }
    private CursorLocation CursorLocation { get; set; } = new(0, 0);
    private BlockingCollection<List<byte>> PrinterResponseCollection { get; set; }
    private BlockingCollection<List<byte>> ResponseCollection { get; set; }
    private DeviceFileItem DeviceFileItem { get; set; }
    private List<ScreenField5250> InputFieldList { get; } = new();
    private List<ScreenField5250> OutputFieldList { get; } = new();
    private Dictionary<string, ScreenInfoResponse> saveScreenDictionary { get; } = new();
    private int ErrorRow { get; set; }
    private int ScreenHeight { get; set; } = 24;
    private string ScreenId { get; set; } = string.Empty;
    private string ScreenLibrary { get; set; } = string.Empty;
    private string ScreenMap { get; set; } = string.Empty;
    private int ScreenWidth { get; set; } = 80;
    private string SessionId { get; set; }

    public bool Initialize(string userIdentifier)
    {
        UserIdentifier = userIdentifier;

        DeviceFileItem = new DeviceFileItem(ConnectionInfoService.ConnectionInfo.Device);

        if (false && IsDeviceSequencingProgramInstalled())
        {
            NegotiateVirtualTerminalConnection();
        }
        else
        {
            NegotiateSocketConnection();
        }

        StartMonitoringResponseCollection();

        return true;
    }

    public void SendCommandToServer(ScreenInfoRequest screenInfoRequest)
    {
        // These fields have to be in order, or the 5250 won't recognize changes to a field location prior to a field thats already been added
        screenInfoRequest.ChangedFields =
            screenInfoRequest.ChangedFields.OrderBy(f => f.Row).ThenBy(f => f.Col).ToList();


        UpdateChangedInputFields(screenInfoRequest);

        var byteCommand = FormatDataCommand(screenInfoRequest);

        // Remove error fields that exist on line 25 when we send a command. The emulator handles
        // removing error fields on line 25, so we don't want to have them hanging around.
        OutputFieldList.RemoveAll(f => f.Row == ErrorRow && f.FieldType == ScreenField5250Type.ErrorField);

        Server.SendRequestToServer(byteCommand.ToArray());
    }

    public void DisconnectFromServer()
    {
        // Cancel the token to cancel the monitor tasks.
        if (this.CancellationTokenSource != null)
        {
            Logger.LogTrace("Canceling the task token");
            this.CancellationTokenSource.Cancel();
        }

        // Send a LOGOFF to the Virtual Terminal.
        if (Server.ServerStream != null)
        {
            Logger.LogTrace("Sending logoff to virtual terminal");

            SocketHeader sh = new SocketHeader(
                ConnectionInfoService.ConnectionInfo.Product, 
                ConnectionInfoService.ConnectionInfo.User, 
                SocketCommand.LOGOFF, 
                OperationCode.PutOrGet);

            Server.SendRequestToServer(sh.GetRequest().ToArray());
        }

        //Server.DisconnectFromServer();

        if (this.MonitorServerStreamTask != null)
        {
            Logger.LogTrace("Waiting for server stream task to finish");

            // This wait will finish when either of the following two conditions occur:
            // 1) When the Token is cancelled(Called above):
            //    This happens when checking if the Device Program is installed and the Device Program is NOT 
            //    installed on the iSeries. The reason cancelling the Token works in this case is the server 
            //    sends 0 data back on Reads so the MonitorServerStream loop continues to Read and the cancel
            //    check stops the iteration, which causes the method to complete.
            // 2) When the Server Stream is disconnected(Called above):
            //    This happens when a device can't be allocated. The server doesn't send any data back on reads 
            //    so the MonitorServerStream sits on the Read method. Disconnecting the Server Stream results in 
            //    an exception, which causes the method to complete.
            this.MonitorServerStreamTask.Wait();
            this.MonitorServerStreamTask.Dispose();
            this.MonitorServerStreamTask = null;
            Logger.LogTrace("Server stream task finished");
        }

        if (this.MonitorResponseCollectionTask != null)
        {
            Logger.LogTrace("Waiting for response collection task to finish");

            // This wait will finish when the ResponseCollection.CompleteAdding() method is called. We call 
            // CompleteAdding() when the monitorServerStreamTask is finished.
            this.MonitorResponseCollectionTask.Wait();
            this.MonitorResponseCollectionTask.Dispose();
            this.MonitorResponseCollectionTask = null;
            Logger.LogTrace("Response collection task finished");
        }

        if (this.CancellationTokenSource != null)
        {
            this.CancellationTokenSource.Dispose();
            this.CancellationTokenSource = null;
        }
    }

    private void StartMonitoringResponseCollection()
    {
        // Start a new task to monitor the Response Collection
        MonitorResponseCollectionTask = Task.Run(MonitorResponseCollection, CancellationTokenSource.Token);
    }

    private void NegotiateSocketConnection()
    {
        try
        {
            var isNegotiated = false;

            var token = GetKerberosToken();

            while (!isNegotiated)
            {
                Server.ConnectToServer(ConnectionInfoService.ConnectionInfo);

                StartMonitoringServerStream();

                var product = ConnectionInfoService.ConnectionInfo.Product[..1];
                var requestHeader = new SocketHeader(
                    product,
                    string.Empty,
                    SocketCommand.LOGON,
                    OperationCode.PutOrGet);

                var startupData = new List<byte>();

                // Add the Device data.
                startupData.AddRange(EbcdicConversion.StringToEbcdic(DeviceFileItem.Device));

                if (token != null)
                {
                    // Add the token data.
                    startupData.AddRange(token);
                }

                Server.SendRequestToServer(requestHeader.GetRequest(startupData).ToArray());

                var snaRecord = ResponseCollection.Take();
                var socketHeader = new SocketHeader(snaRecord);

                // If we are on a startup record, then process the record here.
                // Else add it to the response collection to process the record after the connection is negotiated.
                if (socketHeader.Command.Trim() == SocketCommand.STARTUP)
                {
                    var startupResponse = EbcdicConversion.EbcdicToString(
                        snaRecord.GetRange(0, snaRecord.Count - 2).ToArray());

                    if (startupResponse != StartupResponse.Success)
                    {
                        if (StartupResponse.StartupResponseDescription.ContainsKey(startupResponse))
                        {
                            if (startupResponse == StartupResponse.I0004)
                            {
                                throw new Exception(
                                    "Failed to negotiate connection. Verify EIM association is correct. ");
                            }
                        }

                        // If the device is available
                        if (!DeviceFileItem.IncrementDeviceSequence(startupResponse))
                        {
                            throw new Exception(
                                new StringBuilder()
                                    .Append("Failed to negotiate connection. ")
                                    .Append("Could not allocate device. ")
                                    .Append("Contact a System Administrator to verify ")
                                    .Append($"the {DeviceFileItem.Device} device configuration.")
                                    .ToString());
                        }

                        // Disconnect and reconnect for now in order to work around issue with device allocation on the iSeries.
                        Server.DisconnectFromServer();
                    }
                    else
                    {
                        isNegotiated = true;
                    }
                }
                else if (socketHeader.Command.Trim() == SocketCommand.ERROR)
                {
                    var response = EbcdicConversion.EbcdicToString(
                        snaRecord.GetRange(0, snaRecord.Count - 2).ToArray());

                    throw new JHA5250Exception("Failed to negotiate connection.", response);
                }
                else
                {
                    ResponseCollection.Add(snaRecord);
                }
            }
        }
        catch (Exception ex)
        {
            // Log Exception
            Server.DisconnectFromServer();
            throw;
        }
    }

    private byte[] GetKerberosToken()
    {
        var cacheResponse = CacheManager
            .GetInMemoryCache<XpeConnectionContext>(UserIdentifier, CacheConstants.XpeContextKey);

        if (!cacheResponse.IsFound || cacheResponse.Value?.KerberosToken == null)
        {
            throw new ApplicationException("Xpe Context not found.");
        }

        return TokenConverter.ConvertToBytes(cacheResponse.Value.KerberosToken);
    }

    private void NegotiateVirtualTerminalConnection()
    {
        try
        {
            var token = GetKerberosToken();

            var product = ConnectionInfoService.ConnectionInfo.Product[..1];
            var requestHeader = new SocketHeader(
                product,
                string.Empty,
                SocketCommand.LOGON,
                OperationCode.PutOrGet);

            var startupData = new List<byte>();

            startupData.AddRange(EbcdicConversion.StringToEbcdic(DeviceFileItem.Device));

            // this.LoggingService.AddProcessedDataEntry(string.Format("Attempting to connect with device '{0}'",
            //     DeviceFileItem.Device));

            if (token != null)
            {
                // Add the token data.
                startupData.AddRange(token);
            }

            Server.SendRequestToServer(requestHeader.GetRequest(startupData).ToArray());

            var snaRecord = ResponseCollection.Take();
            var socketHeader = new SocketHeader(snaRecord);
            string response;

            if (socketHeader.Command.Trim() == SocketCommand.STARTUP)
            {
                response = EbcdicConversion.EbcdicToString(snaRecord.GetRange(0, snaRecord.Count - 2).ToArray());

                if (response == StartupResponse.Success)
                {
                    // this.LoggingService.AddProcessedDataEntry("Successfully created session");

                    // If we connected successfully, send a device command. This will sit in the ResponseCollection to be picked
                    // up by the ProcessSNARecordFromServer method.
                    requestHeader = new SocketHeader(product, string.Empty, SocketCommand.DEVICE,
                        OperationCode.PutOrGet);
                    Server.SendRequestToServer(requestHeader.GetRequest().ToArray());
                }
                else
                {
                    // Convert the response to something meaningful if possible.
                    if (response == StartupResponse.I0004)
                    {
                        response = "Failed to negotiate connection. Verify EIM association is correct. ";
                    }
                    else if (StartupResponse.StartupResponseDescription.ContainsKey(response))
                    {
                        response = StartupResponse.StartupResponseDescription[response];
                    }

                    // this.LoggingService.AddProcessedDataEntry(response);

                    throw new Exception(response);
                }
            }
            else if (socketHeader.Command.Trim() == SocketCommand.ERROR)
            {
                response = EbcdicConversion.EbcdicToString(
                    snaRecord.GetRange(0, snaRecord.Count - 2).ToArray());

                throw new Exception($"Failed to negotiate connection. Error details: '{response}' ");
            }
        }
        catch (Exception ex)
        {
            // If an exception occurs, we want to close the socket connection and then notify the UI.
            // this.LoggingService.AddProcessedDataEntry(ex.Message);
            Server.DisconnectFromServer();
            throw;
        }
    }

    private void StartMonitoringServerStream()
    {
        // Create a new CancellationTokenSource. This will be used later when disconnecting from the server to
        // stop monitoring the server stream and the response collection.
        CancellationTokenSource = new CancellationTokenSource();

        // Clear out the ResponseCollection
        ResponseCollection = new BlockingCollection<List<byte>>();

        PrinterResponseCollection = new BlockingCollection<List<byte>>();

        // Start a new task to monitor the server stream.
        MonitorServerStreamTask = Task.Run(MonitorServerStream, CancellationTokenSource.Token);
    }

    private void MonitorServerStream()
    {
        try
        {
            var receivedData = new List<byte>();

            while (!CancellationTokenSource.IsCancellationRequested)
            {
                Array.Clear(Server.DataStreamBuffer, 0x000, Server.DataStreamBuffer.Length);

                var inCount =
                    Server.ServerStream.Read(Server.DataStreamBuffer, 0, Server.ServerSocket.ReceiveBufferSize);
                receivedData.AddRange(Server.DataStreamBuffer.Take(inCount));

                // Parse through the data returned and separate it out into snaRecords in a serverQueue.
                for (var index = 0; index < receivedData.Count; index++)
                    // If the current element is 255 and the next element is 239, we are at the end of a record.
                    // Add it to the collection
                    if (receivedData[index] == 0x0FF && receivedData.Count > index + 1 &&
                        receivedData[index + 1] == 0X0EF)
                    {
                        // Ran into a case where the Screen Map returned on the data stream had a FFEF. To prevent cutting
                        // the Screen Map in half, we have to create a socket header and check the length that the record
                        // is supposed to be.
                        var socketHeader = new SocketHeader(receivedData.GetRange(0, index + 2).CloneObject());

                        if (socketHeader.Length != index + 2)
                        {
                            continue;
                        }

                        var snaRecord = new List<byte>();
                        snaRecord.AddRange(receivedData.GetRange(0, index + 2));
                        receivedData.RemoveRange(0, index + 2);

                        if (socketHeader.Command.Trim() == SocketCommand.PRINTER)
                        {
                            PrinterResponseCollection.Add(snaRecord);
                        }
                        else
                        {
                            ResponseCollection.Add(snaRecord);
                        }

                        index = -1;
                    }
            }
        }
        catch (Exception ex)
        {
            // Only write an error if we didn't disconnect the server.
            if (!CancellationTokenSource.IsCancellationRequested)
            {
                // Mediator.Send(new ScreenChangedCmd(UserIdentifier, null, ex));
                Logger.LogError(ex, "Error accessing screen.");
            }
        }
        finally
        {
            // Call CompleteAdding on the Response Collection to stop the MonitorResponseCollection thread.
            ResponseCollection.CompleteAdding();
            PrinterResponseCollection.CompleteAdding();
        }
    }

    private void MonitorResponseCollection()
    {
        while (!ResponseCollection.IsCompleted)
        {
            List<byte>? snaRecord = null;

            // Blocks if number.Count == 0
            // IOE means that Take() was called on a completed collection.
            // Some other thread can call CompleteAdding after we pass the
            // IsCompleted check but before we call Take.
            // In this example, we can simply catch the exception since the
            // loop will break on the next iteration.
            try
            {
                snaRecord = ResponseCollection.Take();
            }
            catch (InvalidOperationException)
            {
            }

            if (snaRecord == null)
            {
                continue;
            }

            try
            {
                var requestedActionFromServer = ProcessSnaRecordFromServer(snaRecord);

                List<byte>? commandToSendToServer = null;

                if (requestedActionFromServer != null)
                {
                    commandToSendToServer = InterpretRequestedActionFromServer(requestedActionFromServer);
                }

                if (commandToSendToServer != null)
                {
                    Server.SendRequestToServer(commandToSendToServer.ToArray());
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, "Error accessing Screen.");

                // Mediator.Send(new ScreenChangedCmd(UserIdentifier, null, ex));

                throw;
            }
        }
    }

    private List<byte>? InterpretRequestedActionFromServer(List<byte> requestedAction)
    {
        List<byte>? commandToSendToServer = null;

        if (!requestedAction.Any())
        {
            return commandToSendToServer;
        }

        var operationCode = (OperationCode) requestedAction[0];

        switch (operationCode)
        {
            case OperationCode.SaveScreen:
            {
                if (requestedAction.Count > 2)
                {
                    var command = (Command) requestedAction[2];
                    switch (command)
                    {
                        case Command.SaveScreen:
                        {
                            var saveScreenReply = new List<byte>();

                            // Add the operation code.
                            saveScreenReply.Add(0x04);
                            saveScreenReply.Add(0x12);

                            // Only keep the 100 most recent screens. This is subject to change.
                            if (saveScreenDictionary.Count > 100)
                            {
                                saveScreenDictionary.Remove(saveScreenDictionary.Keys.First());
                            }

                            var currentScreenKey = Guid.NewGuid().ToString();

                            var inputFields = new List<ScreenField5250>();
                            var outputFields = new List<ScreenField5250>();

                            OutputFieldList.ForEach(f => outputFields.Add(f.Clone()));
                            InputFieldList.ForEach(f => inputFields.Add(f.Clone()));

                            var currentScreen = new ScreenInfoResponse(ScreenLibrary, ScreenId, ScreenMap,
                                ScreenHeight, ScreenWidth, CursorLocation, ErrorRow, inputFields, outputFields);

                            saveScreenDictionary.Add(currentScreenKey, currentScreen);

                            var screenKeyByteArray = Encoding.UTF8.GetBytes(currentScreenKey.ToCharArray());

                            saveScreenReply.AddRange(screenKeyByteArray);

                            // Adding this extra byte because sometimes the datastream doesn't return the last byte of the data that we save 
                            // off as part of the SaveScreen Operation - RestoreScreen Command that we send. Then when we get the data back
                            // we just get the length of a GUID.
                            saveScreenReply.Add(0x00);

                            var sh = new SocketHeader(
                                ConnectionInfoService.ConnectionInfo.Product,
                                ConnectionInfoService.ConnectionInfo.User,
                                string.Empty, operationCode);
                            commandToSendToServer = sh.GetRequest(saveScreenReply);
                            break;
                        }
                    }
                }

                break;
            }

            case OperationCode.PutOrGet:
            {
                if (requestedAction.Count > 2)
                {
                    var command = (Command) requestedAction[2];
                    switch (command)
                    {
                        case Command.WriteStructuredField:
                        {
                            var wsf = new WriteStructuredField();


                            var sh = new SocketHeader(
                                ConnectionInfoService.ConnectionInfo.Product,
                                ConnectionInfoService.ConnectionInfo.User,
                                string.Empty, operationCode);
                            commandToSendToServer = sh.GetRequest(wsf.GetReply());
                            break;
                        }

                        case Command.SavePartialScreen:
                        {
                            // Need to reply with a PutOrGet -> Restore Partial : Contents of the display
                            break;
                        }
                    }
                }

                break;
            }

            case OperationCode.ReadScreen:
            {
                // This should be sending back the contents of the display, but I haven't determined why we need to do that.
                // Sending a dummy response to the server for now.
                var readScreenReply = new List<byte>();

                var lastRow = 1;
                var lastColumn = 0;
                foreach (var sf in OutputFieldList.OrderBy(f => f.Row).ThenBy(f => f.Col))
                {
                    var spaceBetweenFields = (sf.Row - lastRow) * ScreenWidth + sf.Col - lastColumn - 1;

                    for (var i = 0; i < spaceBetweenFields; i++) readScreenReply.Add(0x40);

                    lastRow = Convert.ToInt16(sf.RRCCCs.Last().Substring(0, 2));
                    lastColumn = Convert.ToInt16(sf.RRCCCs.Last().Substring(2, 3));

                    if (sf.FieldType == ScreenField5250Type.Attribute)
                    {
                        readScreenReply.Add((byte) sf.Att);
                    }
                    else
                    {
                        readScreenReply.AddRange(EbcdicConversion.StringToEbcdic(sf.Data));
                    }
                }

                // Bug 166780. For some reason the server tells us to clear our(Clear Unit) screen and then asks us
                // to return the contents of our(Read Screen) screen. Since we just cleared our screen we don't 
                // have anything to send back. When we don't send anything back the Virtual Terminal blows up.
                // Sending in a single null byte as a workaround. 
                if (readScreenReply.Count == 0)
                {
                    readScreenReply.Add(0x00);
                }

                var sh = new SocketHeader(
                    ConnectionInfoService.ConnectionInfo.Product,
                    ConnectionInfoService.ConnectionInfo.User,
                    string.Empty, operationCode);
                commandToSendToServer = sh.GetRequest(readScreenReply);
                break;
            }

            case OperationCode.CancelInvite:
            {
                var sh = new SocketHeader(
                    ConnectionInfoService.ConnectionInfo.Product,
                    ConnectionInfoService.ConnectionInfo.User,
                    string.Empty, operationCode);
                commandToSendToServer = sh.GetRequest();
                break;
            }
        }

        return commandToSendToServer;
    }

    private List<byte>? ProcessSnaRecordFromServer(List<byte> snaRecord)
    {
        var requestedActionFromServer = new List<byte>();

        var socketHeader = new SocketHeader(snaRecord);

        if (socketHeader.Command.Trim() == SocketCommand.SCREENID)
        {
            ScreenLibrary = string.Empty;
            ScreenId = string.Empty;

            var screenInfo = EbcdicConversion.EbcdicToString(snaRecord.GetRange(0, snaRecord.Count - 2).ToArray());

            var firstHyphen = screenInfo.IndexOf('-');

            if (firstHyphen != -1)
            {
                ScreenLibrary = screenInfo[..firstHyphen];
                ScreenId = screenInfo[(firstHyphen + 1)..];
            }
            else
            {
                ScreenLibrary = screenInfo;
                ScreenId = screenInfo;
            }

            return null;
        }

        if (socketHeader.Command.Trim() == SocketCommand.SCREENMAP)
        {
            // Decompress the the byte array version of the map into a string.
            ScreenMap = CompressionHelper.ZlibDecompress(snaRecord.GetRange(0, snaRecord.Count - 2).ToArray());
            return null;
        }

        if (socketHeader.Command.Trim() == SocketCommand.DEVICE)
        {
            // Set the device to what is returned from the iSeries.
            var response = EbcdicConversion.EbcdicToString(snaRecord.GetRange(0, snaRecord.Count - 2).ToArray());
            DeviceFileItem.DeviceName = response;
            DeviceFileItem.DeviceSequence = string.Empty;
            return null;
        }

        if (socketHeader.Command.Trim() == SocketCommand.ERROR)
        {
            var response = EbcdicConversion.EbcdicToString(snaRecord.GetRange(0, snaRecord.Count - 2).ToArray());
            throw new Exception(response);
        }

        var q = new Queue<byte>(snaRecord);

        int[] bufferAddress = { 0, 0 }; // row, column

        FieldAttribute att = 0;

        while (q.Count > 0)
        {
            var currentByte = q.Dequeue();
            switch (currentByte)
            {
                case EORM: // End of Record (FF)
                    q.Dequeue(); // 0xEF
                    break;

                case ESC: // Data Steam Commands
                    requestedActionFromServer.Clear();
                    requestedActionFromServer.Add(0x04);

                    switch ((Command) q.Peek())
                    {
                        case Command.ClearUnit:
                            requestedActionFromServer.Add(q.Dequeue());

                            ScreenHeight = 24;
                            ScreenWidth = 80;
                            OutputFieldList.Clear();
                            InputFieldList.Clear();
                            bufferAddress[0] = 0;
                            bufferAddress[1] = 0;
                            CursorLocation = new CursorLocation(0, 0); // row, column
                            break;

                        case Command.ClearUnitAlternate:
                            requestedActionFromServer.Add(q.Dequeue());

                            if (q.Peek() == 0x00)
                            {
                                // Set screen to 27x132
                                // Clear the screen
                                ScreenHeight = 27;
                                ScreenWidth = 132;
                                OutputFieldList.Clear();
                                InputFieldList.Clear();
                                bufferAddress[0] = 0;
                                bufferAddress[1] = 0;
                                CursorLocation = new CursorLocation(0, 0); // row, column
                            }

                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.ClearFormatTable:
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.WriteErrorCode:
                            // Allows the host system to force the keyboard into the pre-help error state.
                            // +------------------------------------------------------------------------+
                            // ¦ ESC   ¦ WRITE ERROR CODE ¦ IC@@ ¦ Data ¦
                            // ¦       ¦                  ¦      ¦      ¦
                            // ¦ X'04' ¦ X'21'            ¦      ¦      ¦
                            // +------------------------------------------------------------------------+
                            requestedActionFromServer.Add(q.Dequeue());

                            var wecWorkingCharacter = q.Peek();

                            var errorText = string.Empty;
                            var runningText = string.Empty;
                            var currentAttribute = FieldAttribute.Green;

                            // While we are not at the end of the record.
                            while (wecWorkingCharacter != EORM && wecWorkingCharacter != ESC && q.Count > 1)
                            {
                                wecWorkingCharacter = q.Dequeue();

                                // If the command contains an Insert Cursor, set the cursor location and continue;
                                if (wecWorkingCharacter == (byte) Order.InsertCursor)
                                {
                                    bufferAddress[0] = q.Dequeue();
                                    bufferAddress[1] = q.Dequeue();
                                    CursorLocation.Row = bufferAddress[0];
                                    CursorLocation.Column = bufferAddress[1];
                                    wecWorkingCharacter = q.Peek();
                                    continue;
                                }

                                if (GetFieldType(wecWorkingCharacter) == Jha5250FieldType.Attribute)
                                {
                                    if ((FieldAttribute) wecWorkingCharacter != currentAttribute &&
                                        errorText.Length > 0)
                                    {
                                        var errorField = new ScreenField5250(string.Empty,
                                            ScreenField5250Type.ErrorField, ErrorRow, 1 + runningText.Length,
                                            currentAttribute, errorText.Length, errorText, ScreenWidth);
                                        UpdateFields(errorField);
                                        runningText += errorText;
                                        errorText = string.Empty;
                                    }

                                    currentAttribute = (FieldAttribute) wecWorkingCharacter;
                                    errorText += " ";
                                }
                                else if (wecWorkingCharacter == NULL)
                                {
                                    errorText += " ";
                                }
                                else
                                {
                                    // Add it to the text string we are working on.
                                    errorText = $@"{errorText}{EbcdicConversion.EbcdicToString(wecWorkingCharacter)}";
                                }

                                wecWorkingCharacter = q.Peek();
                            }

                            if (errorText.Length > 0)
                            {
                                var errorField = new ScreenField5250(string.Empty, ScreenField5250Type.ErrorField,
                                    ErrorRow, 1 + runningText.Length, currentAttribute, errorText.Length,
                                    errorText, ScreenWidth);
                                UpdateFields(errorField);
                            }

                            break;

                        case Command.WriteErrorCodeToWindow:
                            requestedActionFromServer.Add(q.Dequeue());
                            var writeErrorCodeToWindow = new WriteErrorCodeToWindow(q, EbcdicConversion);
                            var windowErrorField = new ScreenField5250($"Error Row: {ErrorRow.ToString()}",
                                ScreenField5250Type.ErrorField, ErrorRow, writeErrorCodeToWindow.StartColumn,
                                writeErrorCodeToWindow.Attribute,
                                writeErrorCodeToWindow.Length, writeErrorCodeToWindow.ErrorData, ScreenWidth);
                            UpdateFields(windowErrorField);
                            break;

                        case Command.ReadInputFields:
                            // Allows the host system to have the terminal send the contents of all input fields defined in the format table.
                            // Throw Not Implemented?
                            q.Dequeue();
                            q.Dequeue();
                            q.Dequeue();
                            break;

                        case Command.ReadMDTFields:
                            // Allows the host system to ask the terminal to send data from only those fields that have been modified.
                            // A field is recognized as having been modified if the MDT bit for the field is on.
                            requestedActionFromServer.Add(q.Dequeue());
                            // Byte 1 of Control Character
                            requestedActionFromServer.Add(q.Dequeue());
                            // Byte 2 of Control Character
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.ReadMDTAlternate:
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.ReadScreen:
                            // Causes the contents of the display to go to the host system in the sequence that it appears on the display (for example, row 1 goes first).
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.ReadScreenWithExtendedAttributes:
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.ReadScreenToPrint:
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.ReadScreenToPrintWithExtendedAttributes:
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.ReadScreenToPrintWithExtendedAttributesAndGridlines:
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.ReadImmediate:
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.ReadModifiedImmediateAlternate:
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.SaveScreen:
                            requestedActionFromServer.Add(q.Dequeue());
                            q.Clear();
                            break;

                        case Command.SavePartialScreen:
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.RestoreScreen:
                            requestedActionFromServer.Add(q.Dequeue());

                            var screenKeyByteArray = new byte[36];

                            for (var i = 0; i < 36; i++) screenKeyByteArray[i] = q.Dequeue();

                            var saveScreenKey = Encoding.UTF8.GetString(screenKeyByteArray);

                            if (saveScreenDictionary.TryGetValue(saveScreenKey, out var savedScreen))
                            {
                                OutputFieldList.Clear();
                                InputFieldList.Clear();

                                foreach (var field in savedScreen.OutputFields.Union(savedScreen.InputFields))
                                {
                                    if (field.FieldType is ScreenField5250Type.OutputField
                                        or ScreenField5250Type.ErrorField)
                                    {
                                        OutputFieldList.Add(field.Clone());
                                    }
                                    else if (field.FieldType == ScreenField5250Type.InputField)
                                    {
                                        if (field.FieldFormatWord != null && field.FieldFormatWord.Bypass)
                                        {
                                            OutputFieldList.Add(field.Clone());
                                        }
                                        else
                                        {
                                            InputFieldList.Add(field.Clone());
                                        }
                                    }
                                }

                                ScreenLibrary = savedScreen.ScreenLibrary;
                                ScreenId = savedScreen.ScreenId;
                                ScreenMap = savedScreen.ScreenMapData;
                                ScreenHeight = savedScreen.ScreenHeight;
                                ScreenWidth = savedScreen.ScreenWidth;
                                CursorLocation = savedScreen.CursorLocation;
                                ErrorRow = savedScreen.ErrorRow;
                            }

                            break;

                        case Command.RestorePartialScreen:
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.Roll:
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.WriteStructuredField:
                            requestedActionFromServer.Add(q.Dequeue());
                            // Byte 1 of Field Size
                            requestedActionFromServer.Add(q.Dequeue());
                            // Byte 2 of Field Size
                            requestedActionFromServer.Add(q.Dequeue());
                            // Class of structured field
                            requestedActionFromServer.Add(q.Dequeue());
                            // 5250 Query
                            requestedActionFromServer.Add(q.Dequeue());
                            // Flags : Reserved
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.WriteSingleStructuredField:
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.CopyToPrinter:
                            requestedActionFromServer.Add(q.Dequeue());
                            break;

                        case Command.WriteToDisplay:
                            // Writes characters and attributes into the display regeneration buffer and creates, adds to and modifies the format table that
                            // is associates with the display.
                            // +------------------------------------------------------------------------+
                            // ¦ ESC   ¦ WRITE TO DISPLAY ¦ Control   ¦ Parameter        ¦
                            // ¦       ¦                  ¦           ¦                  ¦
                            // ¦ X'04' ¦ X'11'            ¦ Character ¦ (see Figure 19)  ¦
                            // ¦       ¦                  ¦           ¦                  ¦
                            // ¦       ¦                  ¦ 2 bytes   ¦                  ¦
                            // +------------------------------------------------------------------------+
                            requestedActionFromServer.Add(q.Dequeue());
                            // Byte 0 of Control Character
                            requestedActionFromServer.Add(q.Dequeue());
                            // Byte 1 of Control Character
                            requestedActionFromServer.Add(q.Dequeue());

                            ScreenField5250 writeToDisplayField = null;

                            var wtdInputFields = new List<ScreenField5250>();

                            CursorLocation = new CursorLocation(0, 0);

                            while (q.Count > 2 && q.Peek() != ESC)
                            {
                                var writeToDisplayByte = q.Dequeue();
                                switch ((Order) writeToDisplayByte)
                                {
                                    case Order.SetBufferAddress:
                                        // Set Buffer Address Order
                                        // The set buffer address (SBA) order specifies the address at which data transfer and input field definition will begin. Any location within
                                        // the boundaries of the workstation presentation screen is valid. The order code is X'11'.
                                        //
                                        // SBA | Row Address | Column Address
                                        // x11 | 1 byte      | 1 byte
                                        //
                                        // Byte 0  Set Buffer Address order
                                        // Byte 1  Row address in hexadecimal
                                        // Byte 2  Column address in hexadecimal
                                        //
                                        // The row is equal to 1 and the column address is equal to 0, followed by an SF field starting in row 1, column 1. Any other use of 0 in row
                                        // or column address results in a parameter error.
                                        bufferAddress[0] = q.Dequeue();
                                        bufferAddress[1] = q.Dequeue();
                                        break;

                                    case Order.InsertCursor:
                                        // Insert Cursor Order
                                        // The insert cursor (IC) order specifies the position of the cursor when the AS/400 system unlocks the keyboard or when the
                                        // workstation operator presses the Home key. The order code is X'13'.
                                        //
                                        // IC  | Row Address | Column Address
                                        // x13 | 1 byte      | 1 byte
                                        //
                                        // Byte 0  Insert Cursor order
                                        // Byte 1  Row address in hexadecimal for cursor to be placed
                                        // Byte 2  Column address in hexadecimal for cursor to be placed
                                        //
                                        // If multiple IC orders exist within a single WTD command, only the last one in the command is retained. The last IC or MC
                                        // order in the command determines cursor position.
                                        bufferAddress[0] = q.Dequeue();
                                        bufferAddress[1] = q.Dequeue();
                                        CursorLocation.Row = bufferAddress[0];
                                        CursorLocation.Column = bufferAddress[1];
                                        break;

                                    case Order.MoveCursor:
                                        // Allows the AS/400 system to move the cursor to a specified position without modifying the home address and without regard to the state of the keyboard,
                                        bufferAddress[0] = q.Dequeue();
                                        bufferAddress[1] = q.Dequeue();
                                        CursorLocation.Row = bufferAddress[0];
                                        CursorLocation.Column = bufferAddress[1];
                                        break;

                                    case Order.RepeatToAddress:
                                        // Repeat to Address Order
                                        // The repeat to address (RA) order results in the repetition of a selected character from the current workstation screen address up to and
                                        // including the screen row and column addresses given in the order. The order code is X'02'.
                                        //
                                        // RA  | Row Address | Column Address | Repeated Character
                                        // x02 | 1 byte      | 1 byte         | 1 byte
                                        //
                                        // Byte 0  Repeat To Address order
                                        // Byte 1  Row address in hexadecimal to repeat to
                                        // Byte 2  Column address in hexadecimal to repeat to
                                        // Byte 3  Repeated Character, is the character that will fill the space from the current buffer position to the specified row and column address.
                                        int row = q.Dequeue();
                                        int col = q.Dequeue();

                                        byte repeatedCharacter;

                                        if (q.Peek() == NULL)
                                        {
                                            repeatedCharacter = 0x40;
                                            q.Dequeue();
                                        }
                                        else
                                        {
                                            repeatedCharacter = q.Dequeue();
                                        }

                                        var numberOfCharacters = (row - bufferAddress[0]) * ScreenWidth + col + 1 -
                                                                 bufferAddress[1];

                                        var ebcdicBytes = new byte[numberOfCharacters];

                                        for (var i = 0; i < ebcdicBytes.Length; i++) ebcdicBytes[i] = repeatedCharacter;

                                        // 01 010 - 01 070 = 60
                                        // 01 010 - 02 010 = 80
                                        // 01 010 - 02 005 = 75
                                        // 01 010 - 02 015 = 85

                                        var repeatingText = EbcdicConversion.EbcdicToString(ebcdicBytes);

                                        if (writeToDisplayField == null)
                                        {
                                            writeToDisplayField = new ScreenField5250(string.Empty,
                                                ScreenField5250Type.OutputField, bufferAddress[0], bufferAddress[1],
                                                att, repeatingText.Length, repeatingText, ScreenWidth);
                                        }
                                        else
                                        {
                                            writeToDisplayField.AppendData(repeatingText);
                                        }

                                        // Set the buffer address to the end location of the RA order.
                                        bufferAddress[0] = row;
                                        bufferAddress[1] = col;

                                        // Increment the buffer address by one according to the documentation.
                                        IncrementBufferAddress(ref bufferAddress);
                                        break;

                                    case Order.EraseToAddress:
                                        // Clears selected extended attribute types and optionally clears the display screen.
                                        // Transparent Data 10, ll, data allows the transmission of data with any value to the workstation screen.
                                        if (writeToDisplayField != null && writeToDisplayField.FieldSize > 0)
                                        {
                                            UpdateFields(writeToDisplayField);
                                            writeToDisplayField = null;
                                        }

                                        var eta = new EraseToAddress(q);

                                        var etaCount = (eta.Row - bufferAddress[0]) * ScreenWidth + eta.Column +
                                            1 - bufferAddress[1];

                                        var etaText = new string(' ', etaCount);

                                        EraseFields(new ScreenField5250(string.Empty,
                                            ScreenField5250Type.OutputField, bufferAddress[0], bufferAddress[1], att,
                                            etaText.Length, etaText, ScreenWidth));

                                        bufferAddress[0] = eta.Row;
                                        bufferAddress[1] = eta.Column;

                                        // Increment the buffer address by one according to the documentation.
                                        IncrementBufferAddress(ref bufferAddress);
                                        break;

                                    case Order.TransparentData:
                                        break;

                                    case Order.WriteExtendedAttribute:
                                        // allows an extended attribute to be written to the workstation extended character buffer (ECB) at the current workstation address.
                                        break;

                                    case Order.WriteToDisplayStructuredField:
                                        break;

                                    case Order.StartOfHeader:
                                        // Start of Header Order
                                        // The start of header (SOH) order specifies header information for the format table. Because the parameters in this order
                                        // vary in length, the first byte after the control code contains the number of bytes included. The command code is X'01'.
                                        //
                                        // SOH | Length | Flag   | RSVD | RESQ Field | ERR Row | Command Key Switches
                                        // x01 | 1 byte | 1 byte | x0   | 1 byte     | 1 byte  | 3 bytes
                                        //
                                        // Byte 0  Length of data following SOH order not including the length byte.
                                        // Note: A value of 0 or a value > 7 is not valid and triggers a parameter error.
                                        //
                                        // Byte 1  Flag byte:
                                        //      Bit 0-Right-to-left screen level cursor direction
                                        //      Bit 1-Reserved
                                        //      Bit 2-Automatic local screen reverse
                                        //      Bit 3-The cursor is allowed to move only to input-capable positions; this cursor movement mode applies to this display screen.
                                        //      Bits 4-7 Reserved.
                                        //
                                        // Byte 2  Reserved.
                                        // Byte 3  The number of the first field that the control unit sends to the AS/400 system in response to a READ INPUT FIELD,
                                        //      READ MDT FIELD, READ MDT ALTERNATE, READ IMMEDIATE, or READ IMMEDIATE ALTERNATE command. Specify 0 if resequencing is not desired.
                                        // Byte 4  ERR Row.
                                        //
                                        // For displays without a separate message line, line 24 is set as the message line. For displays with a separate message line, the message
                                        // line is set as the default.
                                        //
                                        // SOH bytes 5, 6, and 7 contain the data included switches for the 24 PF keys. If the SOH byte 0 contains a value of 6 or less, all screen
                                        // input fields are returned with every entry of a PF key. When bytes 5 through 7 are included with an SOH order, a set bit prevents input
                                        // data and AID codes from being returned with a request from the corresponding PF key. Bits 0 through 7 of byte 5 represent PF keys 24
                                        // through 17,respectively. Bits 0 through 7 of byte 6 represent PF keys 16 through 9, respectively. Bits 0 through 7 of byte 7 represent
                                        // PF keys 8 through 1, respectively.

                                        // If there are any fields in the input field list, move them to the output field list.
                                        for (var i = InputFieldList.Count; i > 0; i--)
                                        {
                                            var protectedInputField = InputFieldList[i - 1];
                                            if (protectedInputField.FieldFormatWord != null)
                                            {
                                                protectedInputField.FieldFormatWord.Bypass = true;
                                            }


                                            InputFieldList.Remove(protectedInputField);
                                            OutputFieldList.Add(protectedInputField);
                                        }

                                        int headerLength = q.Dequeue();
                                        q.Dequeue();
                                        q.Dequeue();
                                        q.Dequeue();
                                        ErrorRow = q.Dequeue();
                                        q.Dequeue();
                                        q.Dequeue();
                                        q.Dequeue();
                                        break;

                                    case Order.StartOfField:
                                        // Start of Field Order
                                        // The start of field (SF) order controls the characteristics of every INPUT field that appears on workstation screens. The SF order CAN
                                        // also define OUTPUT fields that appear on the workstation screen. However, using an SBA order followed by data characters is preferred
                                        // for better performance. The order code is X'1D'. SF orders include control words that determine the operating characteristics, display
                                        // attributes, and length of individual fields.
                                        //
                                        // SF  | FFW     | FCW     | @      | LL
                                        // x1D | 2 bytes | 2 bytes | 1 byte | 2 bytes
                                        //
                                        // Byte 0  Start Field order
                                        // Byte 1  FFW- Field Format Word (optional), if specified, causes an input field to be defined.
                                        // Byte 2  FCW - Field Control Word (optional), may not be specified unless FFW is coded.
                                        // Byte 3  @ - Leading field attribute.
                                        // Byte 4  LL - Field length.
                                        FieldFormatWord fieldFormatWord = null;
                                        if (GetFieldType(q.Peek()) == Jha5250FieldType.FieldFormatWord)
                                        {
                                            var ffw = new byte[2];
                                            ffw[1] = q.Dequeue();
                                            ffw[0] = q.Dequeue();

                                            var rawFFW = BitConverter.ToUInt16(ffw, 0);

                                            fieldFormatWord = new FieldFormatWord
                                            {
                                                RawBits = rawFFW,
                                                // 0x2000 = 0010 0000 0000 0000
                                                // Bit 2
                                                Bypass = Convert.ToBoolean(rawFFW & 0x2000),
                                                // 0x1000 = 0001 0000 0000 0000
                                                // Bit 3
                                                DupOrFieldMarkEnable = Convert.ToBoolean(rawFFW & 0x1000),
                                                // 0x800  = 0000 1000 0000 0000
                                                // Bit 4
                                                ModifiedDataTag = Convert.ToBoolean(rawFFW & 0x800),
                                                // 0x700  = 0000 0111 0000 0000
                                                // Bits 5-7
                                                FieldShiftEditSpecification =
                                                    (FieldShiftEditSpecification) ((rawFFW & 0x700) >> 8),
                                                // 0x80   = 0000 0000 1000 0000
                                                // Bit 8
                                                AutoEnter = Convert.ToBoolean(rawFFW & 0x80),
                                                // 0x40   = 0000 0000 0100 0000
                                                // Bit 9
                                                FieldExitRequired = Convert.ToBoolean(rawFFW & 0x40),
                                                // 0x20   = 0000 0000 0010 0000
                                                // Bit 10
                                                Monocase = Convert.ToBoolean(rawFFW & 0x20),
                                                // 0x8    = 0000 0000 0000 1000
                                                // Bit 12
                                                // Bit 11 - Reserved
                                                MandatoryEnter = Convert.ToBoolean(rawFFW & 0x8),
                                                // 0x7    = 0000 0000 0000 0111
                                                // Bits 13-15
                                                RightAdjustMandatoryFill = (MandatoryFill) (rawFFW & 0x7)
                                            };
                                        }

                                        FieldControlWord fieldControlWord = null;

                                        // There has been one case where there were two FCWs on an input field that I know of. Bug 137340
                                        while (GetFieldType(q.Peek()) == Jha5250FieldType.FieldControlWord)
                                        {
                                            var fcw = new byte[2];
                                            fcw[1] = q.Dequeue();
                                            fcw[0] = q.Dequeue();

                                            fieldControlWord = new FieldControlWord
                                            {
                                                RawData = BitConverter.ToUInt16(fcw, 0)
                                            };
                                            fieldControlWord.Type = (FieldControlWordType)
                                                (fieldControlWord.RawData >> 8);
                                        }

                                        if (GetFieldType(q.Peek()) == Jha5250FieldType.Attribute)
                                        {
                                            if (writeToDisplayField != null && writeToDisplayField.FieldSize > 0)
                                            {
                                                UpdateFields(writeToDisplayField);

                                                writeToDisplayField = null;
                                            }

                                            // Get the attribute from the third byte.
                                            att = (FieldAttribute) q.Dequeue();
                                            IncrementBufferAddress(ref bufferAddress);
                                        }

                                        // Get the field size from the high and low order bits.
                                        var fieldSize = q.Dequeue() * 256 + q.Dequeue();

                                        var inputField = new ScreenField5250(string.Empty,
                                            ScreenField5250Type.InputField, bufferAddress[0], bufferAddress[1], att,
                                            fieldSize, new string(' ', fieldSize), ScreenWidth, fieldFormatWord,
                                            fieldControlWord);
                                        wtdInputFields.Add(inputField);
                                        UpdateFieldsWithInputField(inputField);
                                        break;

                                    default:
                                    {
                                        var text = string.Empty;

                                        if (GetFieldType(writeToDisplayByte) == Jha5250FieldType.Attribute)
                                        {
                                            if (writeToDisplayField != null && writeToDisplayField.FieldSize > 0)
                                            {
                                                UpdateFields(writeToDisplayField);
                                            }

                                            att = (FieldAttribute) writeToDisplayByte;

                                            writeToDisplayField = new ScreenField5250(
                                                $"ATT - {att.ToString()}",
                                                ScreenField5250Type.Attribute, bufferAddress[0], bufferAddress[1], att,
                                                1, " ", ScreenWidth);
                                            UpdateFieldAttributes(writeToDisplayField);

                                            IncrementBufferAddress(ref bufferAddress);

                                            writeToDisplayField = null;
                                        }
                                        else if (writeToDisplayByte == NULL || writeToDisplayByte > 0x3F)
                                        {
                                            if (writeToDisplayByte == NULL)
                                            {
                                                text = $"{text} ";
                                            }
                                            else
                                            {
                                                text = string.Format("{0}{1}", text,
                                                    EbcdicConversion.EbcdicToString(writeToDisplayByte));
                                            }
                                        }

                                        byte workingByte;

                                        // Get data to display on the screen.
                                        while ((q.Peek() == NULL || q.Peek() > 0x3F) && q.Count > 1 && q.Peek() != EORM)
                                        {
                                            workingByte = q.Dequeue();

                                            // if it is null then replace it.
                                            if (workingByte == NULL)
                                            {
                                                workingByte = 0x40;
                                            }

                                            // Add it to the text string we are working on.
                                            text = string.Format("{0}{1}", text,
                                                EbcdicConversion.EbcdicToString(workingByte));
                                        }

                                        // Done getting all of the data in respect to this field. Add it to the list of fields.
                                        if (text.Length > 0)
                                        {
                                            if (writeToDisplayField == null)
                                            {
                                                writeToDisplayField = new ScreenField5250(string.Empty,
                                                    ScreenField5250Type.OutputField, bufferAddress[0], bufferAddress[1],
                                                    att, text.Length, text, ScreenWidth);
                                            }
                                            else
                                            {
                                                writeToDisplayField.AppendData(text);
                                            }

                                            IncrementBufferAddress(ref bufferAddress, text.Length);
                                        }
                                    }
                                        break;
                                }
                            }

                            if (writeToDisplayField != null && writeToDisplayField.FieldSize > 0)
                            {
                                UpdateFields(writeToDisplayField);
                            }

                            // If the cursor doesn't get set, set the cursor location to the first input field that is defined in the WTD Command.
                            if (CursorLocation.Row == 0 && CursorLocation.Column == 0)
                            {
                                if (wtdInputFields.Any(f => f.FieldFormatWord != null && !f.FieldFormatWord.Bypass))
                                {
                                    var inputField = wtdInputFields
                                        .Where(f => f.FieldFormatWord != null && !f.FieldFormatWord.Bypass)
                                        .OrderBy(f => f.Row).ThenBy(f => f.Col).FirstOrDefault();
                                    CursorLocation.Row = inputField.Row;
                                    CursorLocation.Column = inputField.Col;
                                }
                            }

                            break;
                    }

                    break;
            }
        }

        // Update the service when there aren't any more responses coming from the server.
        if (!ResponseCollection.Any() &&
            (socketHeader.OperationCode == OperationCode.PutOrGet ||
             socketHeader.OperationCode == OperationCode.Invite) &&
            (InputFieldList.Any() || OutputFieldList.Any()))
        {
            // If the cursor location doesn't get set by one of the WTD commands and it didn't persist from a previous record.
            if (CursorLocation.Row == 0 && CursorLocation.Column == 0)
            {
                if (InputFieldList.Any(f => f.FieldFormatWord != null && !f.FieldFormatWord.Bypass))
                {
                    var inputField = InputFieldList
                        .Where(f => f.FieldFormatWord != null && !f.FieldFormatWord.Bypass).OrderBy(f => f.Row)
                        .ThenBy(f => f.Col).FirstOrDefault();
                    CursorLocation.Row = inputField.Row;
                    CursorLocation.Column = inputField.Col;
                }
                else if (bufferAddress[0] != 0 && bufferAddress[1] != 0)
                {
                    CursorLocation.Row = bufferAddress[0];
                    CursorLocation.Column = bufferAddress[1];
                }
                else
                {
                    CursorLocation.Row = 1;
                    CursorLocation.Column = 1;
                }
            }

            // Clone the input and output fields and set the ScreenCursorLocation. We have to do this after all of the fields
            // are built in the SNA Record because we don't know what the cursor location for sure until after all of the fields
            // have been processed.
            var inputFields = new List<ScreenField5250>();
            var outputFields = new List<ScreenField5250>();

            foreach (var clonedField in InputFieldList.Select(field => field.Clone()))
            {
                if (CursorLocation.Row == clonedField.Row && CursorLocation.Column == clonedField.Col)
                {
                    clonedField.IsFocused = true;
                }

                if (clonedField.Data == null || clonedField.Data.Trim() == string.Empty)
                {
                    clonedField.Data = string.Empty;
                }


                if (clonedField.FieldFormatWord != null && clonedField.FieldFormatWord.Bypass)
                {
                    clonedField.FieldType = ScreenField5250Type.OutputField;
                    outputFields.Add(clonedField);
                }
                else
                {
                    inputFields.Add(clonedField);
                }
            }

            foreach (var clonedField in OutputFieldList.Select(field => field.Clone()))
            {
                if (CursorLocation.Row == clonedField.Row && CursorLocation.Column == clonedField.Col)
                {
                    clonedField.IsFocused = true;
                }

                if (clonedField.FieldType != ScreenField5250Type.Attribute)
                {
                    outputFields.Add(clonedField);
                }
            }

            var screenInfo = new ScreenInfoResponse(ScreenLibrary, ScreenId, ScreenMap,
                ScreenHeight, ScreenWidth, CursorLocation, ErrorRow, inputFields, outputFields);

            Mediator.Send(new ScreenChangedCmd(UserIdentifier, screenInfo));
        }

        // Add the Operation Code at the beginning.
        requestedActionFromServer.Insert(0, (byte) socketHeader.OperationCode);

        return requestedActionFromServer;
    }

    private void UpdateFieldAttributes(ScreenField5250 screenAttribute)
    {
        int[] bufferAddress = { screenAttribute.Row, screenAttribute.Col };
        IncrementBufferAddress(ref bufferAddress);

        var rrccc = $"{bufferAddress[0]:00}{bufferAddress[1]:000}";

        var outputFields = OutputFieldList.Where(f => f.RRCCC == rrccc).ToList();

        foreach (var field in outputFields)
        {
            field.Att = screenAttribute.Att;
        }

        if (screenAttribute.Att.ToString().Contains("Underscore"))
        {
            var inputFields = InputFieldList.Where(f => f.RRCCC == rrccc).ToList();

            foreach (var field in inputFields)
            {
                field.Att = screenAttribute.Att;
            }
        }

        UpdateFields(screenAttribute);
    }

    private void UpdateFieldsWithInputField(ScreenField5250 newInputField)
    {
        var indexes = OutputFieldList
            .Select((f, index) => f.RRCCCs
                .Any(rrccc => newInputField.RRCCCs.Contains(rrccc))
                ? index
                : -1)
            .Where(i => i >= 0).ToArray();

        // Must remove starting at the end. Otherwise indexes change.
        foreach (var i in indexes.Reverse())
        {
            var preExistingField = OutputFieldList[i];

            // Offset is the variance in the starting index between the two fields.
            var offset = newInputField.Col - preExistingField.Col +
                         (newInputField.Row - preExistingField.Row) * ScreenWidth;

            // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
            //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
            //                  _
            //				    _________________________________
            //                  ____________________________________
            //                             _
            //                             ______________________
            //							   _________________________
            //               ______________
            //               ____________________________________
            //               _______________________________________

            // The new field starts at the same location as the preExistingField.
            if (offset == 0)
            {
                if (newInputField.FieldSize < preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // the new field does not entirely consume the preExistingField
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                                                _
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // 0000000000
                    //                                                _
                    // Preexisting field wraps lines. New field wraps lines.
                    //                                                000000000000000000000000000000000
                    // 0000000000
                    //                                                _________________________________
                    // _____
                    newInputField.Data = preExistingField.Data?[..newInputField.FieldSize];

                    preExistingField.Data = preExistingField.Data?[newInputField.FieldSize..];
                    preExistingField.RRCCCs.RemoveRange(0, newInputField.FieldSize);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //				                                  _________________________________
                    newInputField.Data = preExistingField.Data;

                    OutputFieldList.Remove(preExistingField);
                }
            }
            else if (offset > 0) // The new field starts in the middle of the preExistingField.
            {
                if (newInputField.FieldSize < preExistingField.FieldSize - offset)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                                                       _
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOOOOOOO
                    //                                                       _
                    // Preexisting field wraps lines. New field wraps lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOOOOOOO
                    //                                                       __________________________
                    // _____
                    newInputField.Data = preExistingField.Data?.Substring(offset, newInputField.FieldSize);

                    // Build the second half of the previously existing field.
                    var secondField = preExistingField.Clone();
                    secondField.Data = secondField.Data?[(newInputField.FieldSize + offset)..];
                    secondField.RRCCCs.RemoveRange(0, newInputField.FieldSize + offset);
                    OutputFieldList.Add(secondField);

                    // Build the first half of the previously existing field.
                    preExistingField.Data = preExistingField.Data?[..offset];
                    preExistingField.RRCCCs.RemoveRange(offset, preExistingField.RRCCCs.Count - offset);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                             ______________________
                    //							   _________________________
                    newInputField.Data = preExistingField.Data?.Substring(offset, preExistingField.FieldSize - offset);

                    preExistingField.Data = preExistingField.Data?[..offset];
                    preExistingField.RRCCCs.RemoveRange(offset, preExistingField.RRCCCs.Count - offset);
                }
            }
            else // The new field starts before the preExistingField.
            {
                offset += newInputField.FieldSize;
                if (offset < preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               ______________
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOO
                    //               ______________
                    // Preexisting field wraps lines. New field wraps lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOO
                    //               __________________________________________________________________
                    // __
                    newInputField.Data = string.Format("{0}{1}",
                        newInputField.Data?[..(newInputField.FieldSize - offset)],
                        preExistingField.Data?[..offset]);

                    preExistingField.Data = preExistingField.Data?[offset..];
                    preExistingField.RRCCCs.RemoveRange(0, offset);
                }
                else if (offset == preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               ____________________________________
                    newInputField.Data = string.Format("{0}{1}",
                        newInputField.Data?[..(newInputField.FieldSize - offset)], preExistingField.Data);

                    OutputFieldList.Remove(preExistingField);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               _______________________________________

                    var s = newInputField.Data;
                    newInputField.Data = string.Format("{0}{1}",
                        newInputField.Data?[..(newInputField.FieldSize - offset)], preExistingField.Data);


                    if (s.Length > offset)
                    {
                        newInputField.Data = $"{newInputField.Data}{s[offset..]}";
                    }

                    // This needs work
                    OutputFieldList.Remove(preExistingField);
                }
            }
        }

        // Get all output fields that have a RRCCC in the same location as the field that we are working with.
        indexes = InputFieldList
            .Select((f, index) => f.RRCCCs
                .Any(rrccc => newInputField.RRCCCs.Contains(rrccc))
                ? index
                : -1)
            .Where(i => i >= 0).ToArray();

        // Must remove starting at the end. Otherwise indexes change.
        foreach (var i in indexes.Reverse())
        {
            var preExistingField = InputFieldList[i];

            // Offset is the variance in the starting index between the two fields.
            var offset = newInputField.Col - preExistingField.Col +
                         (newInputField.Row - preExistingField.Row) * ScreenWidth;

            // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
            //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
            //                  _
            //				    _________________________________
            //                  ____________________________________
            //                             _
            //                             ______________________
            //							   _________________________
            //               ______________
            //               ____________________________________
            //               _______________________________________

            // The new field starts at the same location as the preExistingField.
            if (offset == 0)
            {
                if (newInputField.FieldSize < preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // the new field does not entirely consume the preExistingField
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                                                _
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // 0000000000
                    //                                                _
                    // Preexisting field wraps lines. New field wraps lines.
                    //                                                000000000000000000000000000000000
                    // 0000000000
                    //                                                _________________________________
                    // _____
                    newInputField.Data = preExistingField.Data?[..newInputField.FieldSize];

                    preExistingField.Data = preExistingField.Data?[newInputField.FieldSize..];
                    preExistingField.RRCCCs.RemoveRange(0, newInputField.FieldSize);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //				                                  _________________________________
                    newInputField.Data = preExistingField.Data;

                    InputFieldList.Remove(preExistingField);
                }
            }
            else if (offset > 0) // The new field starts in the middle of the preExistingField.
            {
                if (newInputField.FieldSize < preExistingField.FieldSize - offset)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                                                       _
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOOOOOOO
                    //                                                       _
                    // Preexisting field wraps lines. New field wraps lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOOOOOOO
                    //                                                       __________________________
                    // _____
                    newInputField.Data = preExistingField.Data?.Substring(offset, newInputField.FieldSize);

                    // Build the second half of the previously existing field.
                    var secondField = preExistingField.Clone();
                    secondField.Data = secondField.Data?[(newInputField.FieldSize + offset)..];
                    secondField.RRCCCs.RemoveRange(0, newInputField.FieldSize + offset);
                    InputFieldList.Add(secondField);

                    // Build the first half of the previously existing field.
                    preExistingField.Data = preExistingField.Data?[..offset];
                    preExistingField.RRCCCs.RemoveRange(offset, preExistingField.RRCCCs.Count - offset);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                             ______________________
                    //							   _________________________
                    newInputField.Data = preExistingField.Data?.Substring(offset, preExistingField.FieldSize - offset);

                    preExistingField.Data = preExistingField.Data?[..offset];
                    preExistingField.RRCCCs.RemoveRange(offset, preExistingField.RRCCCs.Count - offset);
                }
            }
            else // The new field starts before the preExistingField.
            {
                offset += newInputField.FieldSize;
                if (offset < preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               ______________
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOO
                    //               ______________
                    // Preexisting field wraps lines. New field wraps lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOO
                    //               __________________________________________________________________
                    // __
                    newInputField.Data = string.Format("{0}{1}",
                        newInputField.Data?[..(newInputField.FieldSize - offset)],
                        preExistingField.Data?[..offset]);

                    preExistingField.Data = preExistingField.Data?[offset..];
                    preExistingField.RRCCCs.RemoveRange(0, offset);
                }
                else if (offset == preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               ____________________________________
                    newInputField.Data = string.Format("{0}{1}",
                        newInputField.Data?[..(newInputField.FieldSize - offset)], preExistingField.Data);

                    InputFieldList.Remove(preExistingField);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               _______________________________________
                    newInputField.Data = string.Format("{0}{1}{2}",
                        newInputField.Data?[..(newInputField.FieldSize - offset)], preExistingField.Data,
                        newInputField.Data?[offset..]);

                    // This needs work
                    InputFieldList.Remove(preExistingField);
                }
            }
        }

        if (newInputField.RRCCCs.Any())
        {
            if (newInputField.FieldType == ScreenField5250Type.InputField)
            {
                InputFieldList.Add(newInputField);
            }
            else
            {
                OutputFieldList.Add(newInputField);
            }
        }
    }

    private void EraseFields(ScreenField5250 eraseField)
    {
        var indexes = OutputFieldList
            .Select((f, index) => f.RRCCCs
                .Any(rrccc => eraseField.RRCCCs.Contains(rrccc))
                ? index
                : -1)
            .Where(i => i >= 0).ToArray();

        // Must remove starting at the end. Otherwise indexes change.
        foreach (var i in indexes.Reverse())
        {
            var preExistingField = OutputFieldList[i];

            // Offset is the variance in the starting index between the two fields.
            var offset = eraseField.Col - preExistingField.Col + (eraseField.Row - preExistingField.Row) * ScreenWidth;

            // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
            //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
            //                  _
            //				    _________________________________
            //                  ____________________________________
            //                             _
            //                             ______________________
            //							   _________________________
            //               ______________
            //               ____________________________________
            //               _______________________________________

            // The new field starts at the same location as the preExistingField.
            if (offset == 0)
            {
                if (eraseField.FieldSize < preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // the new field does not entirely consume the preExistingField
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                                                _
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // 0000000000
                    //                                                _
                    // Preexisting field wraps lines. New field wraps lines.
                    //                                                000000000000000000000000000000000
                    // 0000000000
                    //                                                _________________________________
                    // _____
                    preExistingField.Data = preExistingField.Data?[eraseField.FieldSize..];
                    preExistingField.RRCCCs.RemoveRange(0, eraseField.FieldSize);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //				                                  _________________________________
                    OutputFieldList.Remove(preExistingField);
                }
            }
            else if (offset > 0) // The new field starts in the middle of the preExistingField.
            {
                if (eraseField.FieldSize < preExistingField.FieldSize - offset)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                                                       _
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOOOOOOO
                    //                                                       _
                    // Preexisting field wraps lines. New field wraps lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOOOOOOO
                    //                                                       __________________________
                    // _____

                    // Build the second half of the previously existing field.
                    var secondField = preExistingField.Clone();
                    secondField.Data = secondField.Data?[(eraseField.FieldSize + offset)..];
                    secondField.RRCCCs.RemoveRange(0, eraseField.FieldSize + offset);
                    OutputFieldList.Add(secondField);

                    // Build the first half of the previously existing field.
                    preExistingField.Data = preExistingField.Data?[..offset];
                    preExistingField.RRCCCs.RemoveRange(offset, preExistingField.RRCCCs.Count - offset);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                             ______________________
                    //							   _________________________
                    preExistingField.Data = preExistingField.Data?[..offset];
                    preExistingField.RRCCCs.RemoveRange(offset, preExistingField.RRCCCs.Count - offset);
                }
            }
            else // The new field starts before the preExistingField.
            {
                offset += eraseField.FieldSize;
                if (offset < preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               ______________
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOO
                    //               ______________
                    // Preexisting field wraps lines. New field wraps lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOO
                    //               __________________________________________________________________
                    // __
                    preExistingField.Data = preExistingField.Data?[offset..];
                    preExistingField.RRCCCs.RemoveRange(0, offset);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               ____________________________________
                    //               _______________________________________
                    OutputFieldList.Remove(preExistingField);
                }
            }
        }

        indexes = InputFieldList
            .Select((f, index) => f.RRCCCs
                .Any(rrccc => eraseField.RRCCCs.Contains(rrccc))
                ? index
                : -1)
            .Where(i => i >= 0).ToArray();

        // Must remove starting at the end. Otherwise indexes change.
        foreach (var i in indexes.Reverse())
        {
            var preExistingField = InputFieldList[i];

            // Offset is the variance in the starting index between the two fields.
            var offset = eraseField.Col - preExistingField.Col + (eraseField.Row - preExistingField.Row) * ScreenWidth;

            // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
            //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
            //                  _
            //				    _________________________________
            //                  ____________________________________
            //                             _
            //                             ______________________
            //							   _________________________
            //               ______________
            //               ____________________________________
            //               _______________________________________

            // The new field starts at the same location as the preExistingField.
            if (offset == 0)
            {
                if (eraseField.FieldSize < preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // the new field does not entirely consume the preExistingField
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                                                _
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // 0000000000
                    //                                                _
                    // Preexisting field wraps lines. New field wraps lines.
                    //                                                000000000000000000000000000000000
                    // 0000000000
                    //                                                _________________________________
                    // _____
                    preExistingField.Data = preExistingField.Data?[eraseField.FieldSize..];
                    preExistingField.RRCCCs.RemoveRange(0, eraseField.FieldSize);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //				                                  _________________________________
                    InputFieldList.Remove(preExistingField);
                }
            }
            else if (offset > 0) // The new field starts in the middle of the preExistingField.
            {
                if (eraseField.FieldSize < preExistingField.FieldSize - offset)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                                                       _
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOOOOOOO
                    //                                                       _
                    // Preexisting field wraps lines. New field wraps lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOOOOOOO
                    //                                                       __________________________
                    // _____

                    // Build the second half of the previously existing field.
                    var secondField = preExistingField.Clone();
                    secondField.Data = secondField.Data?[(eraseField.FieldSize + offset)..];
                    secondField.RRCCCs.RemoveRange(0, eraseField.FieldSize + offset);
                    InputFieldList.Add(secondField);

                    // Build the first half of the previously existing field.
                    preExistingField.Data = preExistingField.Data?[..offset];
                    preExistingField.RRCCCs.RemoveRange(offset, preExistingField.RRCCCs.Count - offset);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                             ______________________
                    //							   _________________________
                    preExistingField.Data = preExistingField.Data?[..offset];
                    preExistingField.RRCCCs.RemoveRange(offset, preExistingField.RRCCCs.Count - offset);
                }
            }
            else // The new field starts before the preExistingField.
            {
                offset += eraseField.FieldSize;
                if (offset < preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               ______________
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOO
                    //               ______________
                    // Preexisting field wraps lines. New field wraps lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOO
                    //               __________________________________________________________________
                    // __
                    preExistingField.Data = preExistingField.Data?[offset..];
                    preExistingField.RRCCCs.RemoveRange(0, offset);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               ____________________________________
                    //               _______________________________________
                    InputFieldList.Remove(preExistingField);
                }
            }
        }
    }

    private void IncrementBufferAddress(ref int[] bufferAddress, int length = 1)
    {
        if (length > 1)
        {
            // The amount of text in the field that has been processed.
            var cursor = 0;

            while (cursor < length)
                // If the field doesn't overflow the current row.
                if (length - cursor <= ScreenWidth - bufferAddress[1] + 1)
                {
                    bufferAddress[1] += length - cursor;
                    cursor += length - cursor;
                }
                else
                {
                    cursor += ScreenWidth - bufferAddress[1] + 1;
                    bufferAddress[0]++;
                    bufferAddress[1] = 1;
                }
        }
        else
        {
            bufferAddress[1] += 1;
        }

        if (bufferAddress[1] > ScreenWidth)
        {
            bufferAddress[0] += 1;
            bufferAddress[1] = 1;
        }

        if (bufferAddress[0] > ScreenHeight)
        {
            bufferAddress[0] = 1;
        }
    }

    private void UpdateFields(ScreenField5250 newField)
    {
        // This method is... the cause of much pain and consternation. Fixing one bug, more often than not, results in another
        // bug being created. If you think there is a bug in this method, come talk to me first. -Philip, Developer of this madness
        var indexes = OutputFieldList
            .Select((f, index) => f.RRCCCs
                .Any(rrccc => newField.RRCCCs.Contains(rrccc))
                ? index
                : -1)
            .Where(i => i >= 0).ToArray();

        // Must remove starting at the end. Otherwise indexes change.
        foreach (var i in indexes.Reverse())
        {
            var preExistingField = OutputFieldList[i];

            // Offset is the variance in the starting index between the two fields.
            var offset = newField.Col - preExistingField.Col + (newField.Row - preExistingField.Row) * ScreenWidth;

            // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
            //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
            //                  _
            //				    _________________________________
            //                  ____________________________________
            //                             _
            //                             ______________________
            //							   _________________________
            //               ______________
            //               ____________________________________
            //               _______________________________________

            // The new field starts at the same location as the preExistingField.
            if (offset == 0)
            {
                if (newField.FieldSize < preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // the new field does not entirely consume the preExistingField
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                                                _
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // 0000000000
                    //                                                _
                    // Preexisting field wraps lines. New field wraps lines.
                    //                                                000000000000000000000000000000000
                    // 0000000000
                    //                                                _________________________________
                    // _____
                    preExistingField.Data = preExistingField.Data?[newField.FieldSize..];
                    preExistingField.RRCCCs.RemoveRange(0, newField.FieldSize);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //				                                  _________________________________
                    OutputFieldList.Remove(preExistingField);
                }
            }
            else if (offset > 0) // The new field starts in the middle of the preExistingField.
            {
                if (newField.FieldSize < preExistingField.FieldSize - offset)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                                                       _
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOOOOOOO
                    //                                                       _
                    // Preexisting field wraps lines. New field wraps lines.
                    //                                                OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOOOOOOO
                    //                                                       __________________________
                    // _____

                    // Build the second half of the previously existing field.
                    var secondField = preExistingField.Clone();
                    secondField.Data = secondField.Data?[(newField.FieldSize + offset)..];
                    secondField.RRCCCs.RemoveRange(0, newField.FieldSize + offset);
                    OutputFieldList.Add(secondField);

                    // Build the first half of the previously existing field.
                    preExistingField.Data = preExistingField.Data?[..offset];
                    preExistingField.RRCCCs.RemoveRange(offset, preExistingField.RRCCCs.Count - offset);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                             ______________________
                    //							   _________________________
                    preExistingField.Data = preExistingField.Data?[..offset];
                    preExistingField.RRCCCs.RemoveRange(offset, preExistingField.RRCCCs.Count - offset);
                }
            }
            else // The new field starts before the preExistingField.
            {
                offset += newField.FieldSize;
                if (offset < preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // Preexisting field doesn't wrap lines. New field doesn't wrap lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               ______________
                    // Preexisting field wraps lines. New field doesn't wrap lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOO
                    //               ______________
                    // Preexisting field wraps lines. New field wraps lines.
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    // OOOOO
                    //               __________________________________________________________________
                    // __
                    preExistingField.Data = preExistingField.Data?[offset..];
                    preExistingField.RRCCCs.RemoveRange(0, offset);
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               ____________________________________
                    //               _______________________________________
                    OutputFieldList.Remove(preExistingField);
                }
            }
        }

        // Get all output fields that have a RRCCC in the same location as the field that we are working with.
        indexes = InputFieldList
            .Select((f, index) => f.RRCCCs
                .Any(rrccc => newField.RRCCCs.Contains(rrccc))
                ? index
                : -1)
            .Where(i => i >= 0).ToArray();

        // Must remove starting at the end. Otherwise indexes change.
        foreach (var i in indexes.Reverse())
        {
            if (newField.Att == FieldAttribute.GreenUnderscore && string.IsNullOrEmpty(newField.Data?.Trim('_')))
            {
                newField.RRCCCs.Clear();
                continue;
            }

            var preExistingField = InputFieldList[i];

            var offset = newField.Col - preExistingField.Col + (newField.Row - preExistingField.Row) * ScreenWidth;

            // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
            //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
            //                  _
            //				    _________________________________
            //                  ____________________________________
            //                             _
            //                             ______________________
            //							   _________________________
            //               ______________
            //               ____________________________________
            //               _______________________________________

            // The new field starts at the same location as the preExistingField.
            if (offset == 0)
            {
                if (newField.FieldSize < preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    // the new field does not entirely consume the preExistingField
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                  _
                    if (newField.Att != preExistingField.Att)
                    {
                        preExistingField.Data = preExistingField.Data?[newField.FieldSize..];
                        preExistingField.RRCCCs.RemoveRange(0, newField.FieldSize);
                    }
                    else
                    {
                        preExistingField.Data = string.Format("{0}{1}", newField.Data,
                            preExistingField.Data?[newField.FieldSize..]);
                        newField.RRCCCs.Clear();
                    }
                }
                else if (newField.FieldSize == preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //				    _________________________________
                    if (newField.Att != preExistingField.Att)
                    {
                        InputFieldList.Remove(preExistingField);
                    }
                    else
                    {
                        preExistingField.Data = newField.Data;
                        newField.RRCCCs.Clear();
                    }
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                  ____________________________________
                    if (newField.Att != preExistingField.Att)
                    {
                        InputFieldList.Remove(preExistingField);
                    }
                    else
                    {
                        preExistingField.Data = newField.Data?[..preExistingField.FieldSize];
                        newField.Data = newField.Data?.Substring(preExistingField.FieldSize,
                            newField.FieldSize - preExistingField.FieldSize);
                        newField.RRCCCs.RemoveRange(0, preExistingField.FieldSize);
                    }
                }
            }
            else if (offset > 0) // The new field starts in the middle of the preExistingField.
            {
                if (newField.FieldSize < preExistingField.FieldSize - offset)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                             _
                    if (newField.Att != preExistingField.Att)
                    {
                        // Build the second half of the previously existing field.
                        var secondField = preExistingField.Clone();
                        secondField.Data = secondField.Data?[(newField.FieldSize + offset)..];
                        secondField.RRCCCs.RemoveRange(0, newField.FieldSize + offset);
                        OutputFieldList.Add(secondField);

                        // Build the first half of the previously existing field.
                        preExistingField.Data = preExistingField.Data?[..offset];
                        preExistingField.RRCCCs.RemoveRange(offset, preExistingField.RRCCCs.Count - offset);
                    }
                    else
                    {
                        preExistingField.Data = string.Format("{0}{1}{2}", preExistingField.Data?[..offset],
                            newField.Data, preExistingField.Data?[(offset + newField.FieldSize)..]);
                        newField.RRCCCs.Clear();
                    }
                }
                else if (newField.FieldSize == preExistingField.FieldSize - offset)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //                             ______________________
                    if (newField.Att != preExistingField.Att)
                    {
                        preExistingField.Data = preExistingField.Data?[..offset];
                        preExistingField.RRCCCs.RemoveRange(offset, preExistingField.RRCCCs.Count - offset);
                    }
                    else
                    {
                        preExistingField.Data = string.Format("{0}{1}", preExistingField.Data?[..offset],
                            newField.Data);
                        newField.RRCCCs.Clear();
                    }
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //							   _________________________
                    if (newField.Att != preExistingField.Att)
                    {
                        preExistingField.Data = preExistingField.Data?[..offset];
                        preExistingField.RRCCCs.RemoveRange(offset, preExistingField.RRCCCs.Count - offset);
                    }
                    else
                    {
                        preExistingField.Data = preExistingField.Data?[..offset] +
                                                newField.Data?[..(preExistingField.FieldSize - offset)];
                        newField.Data = newField.Data?[(preExistingField.FieldSize - offset)..];
                        newField.RRCCCs.RemoveRange(0, preExistingField.FieldSize - offset);
                    }
                }
            }
            else // The new field starts before the preExistingField.
            {
                offset += newField.FieldSize;
                if (offset < preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               ______________
                    if (newField.Att != preExistingField.Att)
                    {
                        preExistingField.Data = preExistingField.Data?[offset..];
                        preExistingField.RRCCCs.RemoveRange(0, offset);
                    }
                    else
                    {
                        preExistingField.Data = string.Format("{0}{1}",
                            newField.Data?[(newField.FieldSize - offset)..],
                            preExistingField.Data?[offset..]);
                        newField.Data = newField.Data?[..(newField.FieldSize - offset)];
                        newField.RRCCCs.RemoveRange(newField.FieldSize - offset, offset);
                    }
                }
                else if (offset == preExistingField.FieldSize)
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               ____________________________________
                    if (newField.Att != preExistingField.Att)
                    {
                        InputFieldList.Remove(preExistingField);
                    }
                    else
                    {
                        preExistingField.Data =
                            newField.Data?.Substring(newField.FieldSize - offset, preExistingField.FieldSize);
                        newField.Data = newField.Data?[..(newField.FieldSize - offset)];
                        newField.RRCCCs.RemoveRange(newField.FieldSize - offset, preExistingField.FieldSize);
                    }
                }
                else
                {
                    // 00000000001111111111222222222233333333334444444444555555555566666666667777777777
                    //                  OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
                    //               _______________________________________
                    if (newField.Att != preExistingField.Att)
                    {
                        InputFieldList.Remove(preExistingField);
                    }
                    else
                    {
                        preExistingField.Data =
                            newField.Data?.Substring(newField.FieldSize - offset, preExistingField.FieldSize);

                        // Create a field to hold the data that exists after the pre existing input field.
                        var secondField = newField.Clone();
                        secondField.RRCCCs.RemoveRange(0, newField.FieldSize - offset + preExistingField.FieldSize);
                        secondField.Data =
                            secondField.Data?[(newField.FieldSize - offset + preExistingField.FieldSize)..];

                        OutputFieldList.Add(secondField);

                        newField.Data = newField.Data?[..(newField.FieldSize - offset)];
                        newField.RRCCCs.RemoveRange(newField.FieldSize - offset, offset);
                    }
                }
            }
        }

        if (newField.RRCCCs.Any())
        {
            if (newField.FieldType == ScreenField5250Type.InputField)
            {
                InputFieldList.Add(newField);
            }
            else
            {
                OutputFieldList.Add(newField);
            }
        }
    }

    private Jha5250FieldType GetFieldType(byte b)
    {
        // Bitwise AND comparison
        if ((b & 0x80) == 0x80)
        {
            // FCW  = 10
            // 0x80 = 1000 0000
            // true = 1000 0000
            // false= 0000 0000
            return Jha5250FieldType.FieldControlWord;
        }

        if ((b & 0xc0) == 0x40)
        {
            // FFW  = 01
            // 0xC0 = 1100 0000
            // 0x40 = 0100 0000
            // true = 0100 0000
            // false= 0000 0000
            return Jha5250FieldType.FieldFormatWord;
        }

        if ((b & 0xe0) == 0x20)
        {
            // Att  = 001
            // 0xE0 = 1110 0000
            // 0x20 = 0010 0000
            // true = 0010 0000
            // false= 0000 0000
            return Jha5250FieldType.Attribute;
        }

        return Jha5250FieldType.Unknown;
    }

    private void UpdateChangedInputFields(ScreenInfoRequest screenInfoRequest)
    {
        if (!screenInfoRequest.ChangedFields.Any() || !InputFieldList.Any())
        {
            return;
        }

        foreach (var changedField in screenInfoRequest.ChangedFields)
        {
            var inputField = InputFieldList.FirstOrDefault(f =>
                f.Row == changedField.Row && f.Col == changedField.Col && f.FieldSize == changedField.FieldSize);

            if (inputField != null)
            {
                inputField.Data = changedField.Data;
            }
        }
    }

    private List<byte> FormatDataCommand(ScreenInfoRequest screenInfoRequest)
    {
        var data = new List<byte>();

        // this.LoggingService.AddProcessedDataEntry(" ");
        // this.LoggingService.AddProcessedDataEntry(" ");
        // this.LoggingService.AddProcessedDataEntry(" ");
        // this.LoggingService.AddProcessedDataEntry("Sending command: ");

        // First command:  build out the Row/Column of the Cursor and set the Attention Identification
        // to the key that was pressed. 
        data.Add(BitConverter.GetBytes(screenInfoRequest.CursorLocation.Row)[0]); // 10 Row Address of CURSOR
        data.Add(BitConverter.GetBytes(screenInfoRequest.CursorLocation.Column)[0]); // 11 Column Address of CURSOR 
        // this.LoggingService.AddProcessedDataEntry(string.Format("  Row Address: {0}", screenInfoRequest.CursorLocation.Row));
        // this.LoggingService.AddProcessedDataEntry(string.Format("  Column Address: {0}", screenInfoRequest.CursorLocation.Column));

        data.Add(GetFunctionKeyByte(screenInfoRequest.Key)); // AID Key
        // this.LoggingService.AddProcessedDataEntry(string.Format("  AID Key: Modifier - {0}, Key - {1} ", screenInfoRequest.Key.Modifier.ToString(), screenInfoRequest.Key.Key.ToString()));

        foreach (var screenField5250 in screenInfoRequest.ChangedFields)
        {
            if (!string.IsNullOrEmpty(screenField5250.Data) && screenField5250.FieldFormatWord != null &&
                screenField5250.FieldFormatWord.Monocase)
            {
                screenField5250.Data = screenField5250.Data.ToUpper();
            }

            // Order Code: Set Buffer Address (SBA) (0x11)
            data.Add(0x11);
            // this.LoggingService.AddProcessedDataEntry("  Set Buffer Address");

            // Update the field in the comm layer so the data will be retained if an error occurs and the screen is redisplayed. Bug 144111.
            var commLayerField = InputFieldList.Union(OutputFieldList)
                .FirstOrDefault(f => f.Row == screenField5250.Row && f.Col == screenField5250.Col);
            if (commLayerField != null)
            {
                if (screenField5250.Data != null)
                {
                    commLayerField.Data = screenField5250.Data.PadRight(commLayerField.FieldSize);
                }

                // Set the AssociatedMaskedFields on the comm layer field.
                commLayerField.AssociatedMaskedFields = screenField5250.AssociatedMaskedFields;
            }

            ScreenField5250 dataField;

            // If the ScreenField5250 has AssociatedMaskedFields, then the data for the entire field is contained
            // within the first AssociatedMaskedField. The 5250 data also needs to be sent at the first 
            // AssociatedMaskedField's location. Therfore, use the first AssociatedMaskedField for sending data.
            if (screenField5250.AssociatedMaskedFields != null && screenField5250.AssociatedMaskedFields.Count > 1)
            {
                dataField = screenField5250.AssociatedMaskedFields.FirstOrDefault();
            }
            else
            {
                // Else just use the screenField5250.
                dataField = screenField5250;
            }

            // Row
            data.Add(BitConverter.GetBytes(dataField.Row)[0]);
            // this.LoggingService.AddProcessedDataEntry(string.Format("    Row: {0}", dataField.Row));

            // Column
            data.Add(BitConverter.GetBytes(dataField.Col)[0]);
            // this.LoggingService.AddProcessedDataEntry(string.Format("    Column: {0}", dataField.Col));

            //----For Each Character in the Command
            if (dataField.Data != null)
            {
                data.AddRange(EbcdicConversion.StringToEbcdic(dataField.Data));
            }

            // this.LoggingService.AddProcessedDataEntry(string.Format("    Data: {0}", dataField.Data));
        }

        var socketCommand = string.Empty;

        if (screenInfoRequest.Key.Key == Key.Escape)
        {
            if (screenInfoRequest.Key.Modifier == Key.LeftShift)
            {
                socketCommand = SocketCommand.SYSRQ;
            }
            else if (screenInfoRequest.Key.Modifier == Key.None)
            {
                socketCommand = SocketCommand.ATTN;
            }
        }

        if (!string.IsNullOrEmpty(screenInfoRequest.SocketCommand))
        {
            socketCommand = screenInfoRequest.SocketCommand;
        }

        // this.LoggingService.AddProcessedDataEntry(string.Format("Sending socket command: {0}", socketCommand));

        var sh = new SocketHeader(
            ConnectionInfoService.ConnectionInfo.Product,
            ConnectionInfoService.ConnectionInfo.User,
            socketCommand,
            OperationCode.PutOrGet);

        data = sh.GetRequest(data);
        // this.LoggingService.AddProcessedDataEntry(string.Format("Command Length: {0}", sh.Length));
        // this.LoggingService.WriteLogs();

        return data;
    }

    private byte GetFunctionKeyByte(KeyPress key)
    {
        byte retVal = 0x00;
        switch (key.Key)
        {
            case Key.F1:
            {
                retVal = key.Modifier == Key.LeftAlt ? (byte) 0xf3 : (byte) 0x31;
                break;
            }

            case Key.F2:
            {
                retVal = 0x32;
                break;
            }

            case Key.F3:
            {
                retVal = 0x33;
                break;
            }

            case Key.F4:
            {
                retVal = 0x34;
                break;
            }

            case Key.F5:
            {
                retVal = 0x35;
                break;
            }

            case Key.F6:
            {
                retVal = 0x36;
                break;
            }

            case Key.F7:
            {
                retVal = 0x37;
                break;
            }

            case Key.F8:
            {
                retVal = 0x38;
                break;
            }

            case Key.F9:
            {
                retVal = 0x39;
                break;
            }

            case Key.F10:
            {
                retVal = 0x3A;
                break;
            }

            case Key.F11:
            {
                retVal = 0x3b;
                break;
            }

            case Key.F12:
            {
                retVal = 0x3c;
                break;
            }

            case Key.F13:
            {
                retVal = 0xb1;
                break;
            }

            case Key.F14:
            {
                retVal = 0xb2;
                break;
            }

            case Key.F15:
            {
                retVal = 0xb3;
                break;
            }

            case Key.F16:
            {
                retVal = 0xb4;
                break;
            }

            case Key.F17:
            {
                retVal = 0xb5;
                break;
            }

            case Key.F18:
            {
                retVal = 0xb6;
                break;
            }

            case Key.F19:
            {
                retVal = 0xb7;
                break;
            }

            case Key.F20:
            {
                retVal = 0xb8;
                break;
            }

            case Key.F21:
            {
                retVal = 0xb9;
                break;
            }

            case Key.F22:
            {
                retVal = 0xba;
                break;
            }

            case Key.F23:
            {
                retVal = 0xbb;
                break;
            }

            case Key.F24:
            {
                retVal = 0xbc;
                break;
            }

            case Key.PageUp:
            {
                // Page up and Page down seem to be reversed according to 5250 documentation at http://www.ingenuityworking.com/knowledge/w/knowledgebase/ibm-5250-data-stream.aspx
                retVal = 0xf4;
                break;
            }

            case Key.PageDown:
            {
                retVal = 0xf5;
                break;
            }

            case Key.Enter:
            {
                retVal = 0xF1;
                break;
            }

            case Key.Escape:
            {
                // Return 0x00 for Escape and Shift Escape.
                retVal = 0x00;
                break;
            }
        }

        return retVal;
    }

    private bool IsDeviceSequencingProgramInstalled()
    {
        Server.ConnectToServer(ConnectionInfoService.ConnectionInfo);
        StartMonitoringServerStream();

        var isDeviceSequencingProgramInstalled = false;

        try
        {
            // this.LoggingService.AddProcessedDataEntry("Checking if the device sequencing program is installed");

            var requestHeader = new SocketHeader(
                ConnectionInfoService.ConnectionInfo.Product[..1],
                string.Empty,
                SocketCommand.DEVICE,
                OperationCode.PutOrGet);

            // Send a DEVICE command to the server. The server will return SUCCESS if the device program is installed 
            // or an ERROR if the device program is not installed.
            Server.SendRequestToServer(requestHeader.GetRequest().ToArray());

            // Get the response from the server.
            var snaRecord = ResponseCollection.Take();

            var socketHeader = new SocketHeader(snaRecord);
            var response = EbcdicConversion.EbcdicToString(snaRecord.GetRange(0, snaRecord.Count - 2).ToArray());

            // If we get a device command back, then the Device Sequencing program is installed and we don't need to disconnect.                     
            if (socketHeader.Command.Trim() == SocketCommand.DEVICE && response == StartupResponse.Success)
            {
                // this.LoggingService.AddProcessedDataEntry("The Device Sequencing program is installed.");
                isDeviceSequencingProgramInstalled = true;
            }
            else
            {
                // Else we get an error back and the Device Sequencing program is not installed and we need to disconnect.
                // this.LoggingService.AddProcessedDataEntry(
                //     string.Format("The Device Sequencing program is not installed: '{0}'", response));
                Server.DisconnectFromServer();
            }
        }
        catch (Exception ex)
        {
            // If an exception occurs in this method, we don't want to blow up because it is quite possible that the iAdapter
            // doesn't have the code installed to respond to the device command. 
            // this.LoggingService.AddProcessedDataEntry(ex.Message);
        }

        return isDeviceSequencingProgramInstalled;
    }
}