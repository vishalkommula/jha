﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xpe.Abstraction.Model;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;
using Microsoft.Extensions.Logging;

namespace Xpe.Services;

public class ScreenHandlerService : IScreenHandlerService
{
    public ScreenHandlerService(ILogger<ScreenHandlerService> logger, IEnumerable<IScreenHandler> screenHandler)
    {
        Logger = logger;
        ScreenHandler = screenHandler;
    }

    private ILogger<ScreenHandlerService> Logger { get; }
    private IEnumerable<IScreenHandler> ScreenHandler { get; }
    private int MaxConsecutiveScreensHandled { get; } = 10;
    private int ConsecutiveScreensHandled { get; set; }

    public HandleScreenInfoRequest HandleScreen(ScreenData screenData, ICurrentUserInfo userInfo, string sessionId,
        Action<ScreenInfoRequest> deferredCommand, IXperienceEnabledService xperienceEnabledService)
    {
        if (!string.IsNullOrWhiteSpace(screenData?.ScreenInfo?.ScreenId))
        {
            var handlers = GetCombinedStandardAndCustomScreenHandlers(screenData.ScreenInfo.ScreenId);

            foreach (var handler in handlers)
            {
                if (handler.IsScreenHandler(screenData.ScreenInfo.ScreenId))
                {
                    var rq = handler.HandleScreen(screenData, userInfo, sessionId, deferredCommand,
                        xperienceEnabledService);

                    if (rq != null)
                    {
                        if (rq.IgnoreMaxConsecutiveScreensHandled ||
                            ++ConsecutiveScreensHandled < MaxConsecutiveScreensHandled)
                        {
                            return rq;
                        }

                        //// Too many consecutive screens have been handled - stop and let the user take over
                        break;
                    }
                }
            }
        }

        ConsecutiveScreensHandled = 0;
        return null;
    }

    public async Task<bool> HandleInputAsync(ScreenData screenData, ScreenInfoRequest screenInfoRq,
        ICurrentUserInfo userInfo)
    {
        if (!string.IsNullOrWhiteSpace(screenData?.ScreenInfo?.ScreenId))
        {
            var handlers = GetCombinedStandardAndCustomScreenHandlers(screenData.ScreenInfo.ScreenId);

            foreach (var handler in handlers)
            {
                if (handler.IsInputObserver(screenData.ScreenInfo.ScreenId))
                {
                    var observeInputTask = handler.ObserveInputAsync(screenData, screenInfoRq, userInfo);
                    if (observeInputTask != null && await observeInputTask)
                    {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public bool MenuOptionSelected(XpeNavigationEventArgs args)
    {
        ConsecutiveScreensHandled = 0;

        if (ScreenHandler != null)
        {
            foreach (var handler in ScreenHandler)
            {
                if (handler.IsMenuOptionObserver())
                {
                    if (handler.MenuOptionSelected(args))
                    {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private bool TryGetCustomScreenHandler(string screenId, out IScreenHandler customScreenHandler)
    {
        customScreenHandler = null;

        //// Get the custom screen mappings for this window/institution.
        //ICustomScreenHandlerMapping screenHandlerMapping = this.unityContainer.ResolveWithWindowIdentifier<ICustomScreenHandlerMapping>(windowIdentifier);

        //// Determine if this institution has a custom screen handler mapped for this specific screen id. If so, the screen handler should be registered
        //// with the name set as the GUID stored in the screenHandlerMapping. We can use this to resolve this institution's custom screen handler.
        //string resolveGuid;
        //ICustomScreenHandler screenHandler;
        //if (screenHandlerMapping.TryGetCustomScreenHandlerFromScreenId(screenId, out resolveGuid) &&
        //    this.unityContainer.TryResolve<ICustomScreenHandler>(resolveGuid, out screenHandler))
        //{
        //    // ICustomScreenHandler is used to resolve out custom handlers, but we want to return it out as a generic IScreenHandler.
        //    customScreenHandler = screenHandler as IScreenHandler;
        //    return true;
        //}

        return false;
    }

    private List<IScreenHandler> GetCombinedStandardAndCustomScreenHandlers(string screenId)
    {
        var handlers = new List<IScreenHandler>();

        // See if this institution has any custom screen handlers registered for this screenid.
        if (TryGetCustomScreenHandler(screenId, out var customScreenHandler))
        {
            handlers.Add(customScreenHandler);
        }

        // Add the standard screenhandlers to this list to be considered.
        if (ScreenHandler.Any())
        {
            handlers.AddRange(ScreenHandler);
        }

        return handlers;
    }
}