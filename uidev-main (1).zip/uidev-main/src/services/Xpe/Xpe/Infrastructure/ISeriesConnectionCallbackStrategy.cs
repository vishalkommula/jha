﻿using System;
using System.Threading;
using Ardalis.GuardClauses;
using Xpe.Abstraction.Infrastructure;
using Microsoft.Extensions.Logging;

namespace Xpe.Infrastructure;

// ReSharper disable once InconsistentNaming
public class ISeriesConnectionCallbackStrategy : IISeriesConnectionCallbackStrategy
{
    public ISeriesConnectionCallbackStrategy(
        ILogger<ISeriesConnectionCallbackStrategy> logger)
    {
        Logger = Guard.Against.Null(logger,
            nameof(logger));
    }

    private ILogger<IISeriesConnectionCallbackStrategy> Logger { get; }

    public void ConnectToServerCallback(IAsyncResult asyncResult)
    {
        IISeriesServer state = null;
        ManualResetEvent connStatus = null;

        try
        {
            state = (IISeriesServer) asyncResult.AsyncState;

            connStatus = state.ConnectionStatus;

            if (state.ServerSocket.IsConnected)
            {
                state.ServerSocket.EndConnect(asyncResult);
                state.IsConnected = true;
            }
            else
            {
                state.IsConnected = false;
                Logger.LogError("ISeries Connection failed with \"{Reason}\"",
                    "JHA3812 callback");
            }
        }
        catch (Exception ex)
        {
            if (state != null)
            {
                state.IsConnected = false;
            }

            Logger.LogError(ex,
                "ISeries Connection failed with \"{ErrorMessage}\"",
                ex.Message);
        }
        finally
        {
            connStatus?.Set();
        }
    }
}