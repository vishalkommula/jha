﻿using System;
using System.Xml;

namespace Xpe.Infrastructure;

public static class TokenConverter
{
    public static byte[] ConvertToBytes(string? tokenValue)
    {
        if (string.IsNullOrWhiteSpace(tokenValue))
        {
            return Array.Empty<byte>();
        }

        var doc = new XmlDocument();
        doc.LoadXml(tokenValue);
        return Convert.FromBase64String(doc.InnerText);
    }
}