﻿using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using Ardalis.GuardClauses;
using Xpe.Abstraction.Infrastructure;
using Microsoft.Extensions.Logging;

namespace Xpe.Infrastructure;

public class CertificateValidationStrategy : ICertificateValidationStrategy
{
    public CertificateValidationStrategy(
        ILogger<CertificateValidationStrategy> logger)
    {
        Logger = Guard.Against.Null(logger,
            nameof(logger));
    }

    private ILogger<CertificateValidationStrategy> Logger { get; }

    public bool CertificateValidationCallback(object sender,
        X509Certificate certificate,
        X509Chain chain,
        SslPolicyErrors sslPolicyErrors)
    {
        // TODO: Implement

        return true;
    }
}