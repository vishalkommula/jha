﻿using System.Text;
using JackHenry.UID.Cache;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Xpe.Cache.Infrastructure;
using Xpe.Cache.Model;

namespace Xpe.Cache;

public class UserCache : IUserCache
{
    public UserCache(
        ILogger<UserCache> logger,
        ICacheManager cacheManager)
    {
        Logger = logger;
        CacheManager = cacheManager;
    }

    private ILogger<UserCache> Logger { get; }
    private ICacheManager CacheManager { get; }

    public void AddInMemoryCache<T>(string userIdentifier, string key, T value, UserCacheOptions options)
    {
        if (options.SlidingExpiration == null && options.AbsoluteExpiration == null)
        {
            throw new ArgumentException(new StringBuilder()
                    .Append("Either ")
                    .Append(nameof(UserCacheOptions.AbsoluteExpiration))
                    .Append(" or ")
                    .Append(nameof(UserCacheOptions.SlidingExpiration))
                    .ToString(),
                nameof(options));
        }

        var cacheKey = GenerateCacheKey(userIdentifier, key);

        CacheManager.AddInMemoryCache(cacheKey, value, new MemoryCacheEntryOptions
        {
            SlidingExpiration = options.SlidingExpiration,
            AbsoluteExpiration = options.AbsoluteExpiration
        }, true);
    }

    public UserCacheResponse<T> GetInMemoryCache<T>(string userIdentifier, string key)
    {
        var cacheKey = GenerateCacheKey(userIdentifier, key);

        var result = CacheManager.GetInMemoryCache<T>(cacheKey);

        return new UserCacheResponse<T>(result.IsFound, result.Value);
    }

    private string GenerateCacheKey(string userIdentifier, string key)
    {
        return $"{userIdentifier}-{key}";
    }
}