﻿namespace Xpe.Cache.Model;

public record UserCacheResponse<T>(bool IsFound, T? Value);
