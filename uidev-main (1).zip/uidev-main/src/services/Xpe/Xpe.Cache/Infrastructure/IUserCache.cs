﻿using Xpe.Cache.Model;

namespace Xpe.Cache.Infrastructure;

public interface IUserCache
{
    void AddInMemoryCache<T>(string userIdentifier, string key, T value, UserCacheOptions options);
    UserCacheResponse<T> GetInMemoryCache<T>(string userIdentifier, string key);
}