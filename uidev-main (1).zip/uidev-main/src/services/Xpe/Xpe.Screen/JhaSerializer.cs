﻿using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Extensions.Logging;

namespace Jha.X3.Xpe.Screen;

/// <summary>
/// Provides Serialization Services
/// </summary>
public static class JhaSerializer
{
    private static readonly byte[] SALT = new byte[]
        { 0x26, 0xdc, 0xff, 0x00, 0xad, 0xed, 0x7a, 0xee, 0xc5, 0xfe, 0x07, 0xaf, 0x4d, 0x08, 0x22, 0x3c };

    private static readonly object lockObject = new();
    private static readonly Dictionary<string, XmlSerializer> serializers = new();

    /// <summary>
    /// Gets the serializer.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="rootName">Name of the root.</param>
    /// <param name="xs">The xs.</param>
    /// <returns>serializer for type</returns>
    public static XmlSerializer GetSerializer(Type type)
    {
        lock (lockObject)
        {
            var key = string.Concat(type.Name, type.GetHashCode().ToString());

            XmlSerializer serializer;

            if (!serializers.TryGetValue(key, out serializer))
            {
                serializer = new XmlSerializer(type);

                serializers.Add(key, serializer);
            }

            return serializer;
        }
    }

    /// <summary>
    /// Deserializes the type of the unknown.
    /// </summary>
    /// <param name="filePath">The file path.</param>
    /// <returns>The deserialized unknown type.</returns>
    public static object DeserializeUnknownType(string filePath)
    {
        var f = new FileInfo(filePath);
        using (Stream s = f.Open(FileMode.Open))
        {
            var b = new BinaryFormatter();
            return b.Deserialize(s);
        }
    }

    /// <summary>
    /// Serializes the specified o.
    /// </summary>
    /// <typeparam name="T">Some Type.</typeparam>
    /// <param name="o">The o.</param>
    /// <returns>The serialized object value.</returns>
    public static string Serialize<T>(T o)
    {
        return InternalSerialize(o);
    }

    /// <summary>
    /// Returns the string representation of the object passed in.  returns string.Empty if object is null;
    /// </summary>
    /// <param name="o">The o.</param>
    /// <returns>
    /// returns the serialized object.
    /// </returns>
    public static string Serialize(object o)
    {
        return InternalSerialize(o);
    }

    /// <summary>
    /// Serializes the passed in object using either DataContractSerialize or XmlSerialize - depending on whether or not the object is IExtensible or not
    /// if null is passed in for the object the function returns.
    /// </summary>
    /// <param name="o">The o.</param>
    /// <param name="filePath">The file path.</param>
    public static void Serialize(object o, string filePath)
    {
        if (o == null)
        {
            return;
        }

        XmlSerialize(o, filePath);
    }

    /// <summary>
    /// Toes the raw XML string.
    /// </summary>
    /// <typeparam name="T">some type.</typeparam>
    /// <param name="obj">The obj.</param>
    /// <param name="namespaces">The namespaces.</param>
    /// <returns>
    /// The serialized xml of an object.
    /// </returns>
    public static string ToRawXmlString<T>(T obj, XmlQualifiedName[] namespaces = null)
    {
        return SerializeToStrippedXML(GetSerializer(typeof(T)), obj, namespaces);
    }

    /// <summary>
    /// Deserialize an object from its xml representation
    /// </summary>
    /// <typeparam name="T">Type of the object</typeparam>
    /// <param name="xml">xml od the object</param>
    /// <returns>An object of type T</returns>
    public static T XmlDeserialize<T>(string xml)
    {
        if (string.IsNullOrEmpty(xml))
        {
            return default(T);
        }

        return (T)XmlDeserialize(xml, typeof(T));
    }

    /// <summary>
    /// XMLs the deserialize.
    /// </summary>
    /// <param name="xml">The XML.</param>
    /// <param name="type">The type.</param>
    /// <returns>The deserialized object.</returns>
    public static object XmlDeserialize(string xml, Type type)
    {
        try
        {
            using (var sr = new StringReader(xml))
            {
                var xs = GetSerializer(type);
                return xs.Deserialize(sr);
            }
        }
        catch (Exception ex)
        {
            throw new XmlException("Error deserializing object: " + type.Name, ex);
        }
    }

    /// <summary>
    /// XMLs the deserialize from file.
    /// </summary>
    /// <param name="filePath">The file path.</param>
    /// <param name="type">The type.</param>
    /// <returns>The deserialized object.</returns>
    public static object XmlDeserializeFromFile(string filePath, Type type)
    {
        using (var r = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Read, FileShare.ReadWrite))
        {
            var xmls = GetSerializer(type);
            return xmls.Deserialize(r);
        }
    }

    /// <summary>
    /// Serialize an object into xml
    /// </summary>
    /// <param name="obj">Serializable object</param>
    /// <returns>Serialized XML</returns>
    public static string XmlSerialize(object obj)
    {
        if (obj == null)
        {
            return string.Empty;
        }

        using (var ms = new MemoryStream())
        {
            var xs = GetSerializer(obj.GetType());
            xs.Serialize(ms, obj);
            ms.Seek(0, SeekOrigin.Begin);

            using (var sr = new StreamReader(ms))
            {
                var xd = new XmlDocument();

                xd.LoadXml(sr.ReadToEnd());
                //// todo: look at changing this; need to research which is better performance
                //// xd.Load(sr);

                foreach (XmlNode node in xd)
                {
                    if (node.NodeType == XmlNodeType.XmlDeclaration)
                    {
                        xd.RemoveChild(node);
                    }
                }

                return xd.OuterXml;
            }
        }
    }

    /// <summary>
    /// XMLs the serialize.
    /// </summary>
    /// <param name="obj">The obj.</param>
    /// <param name="filePath">The file path.</param>
    public static void XmlSerialize(object obj, string filePath)
    {
        if (obj == null)
        {
            return;
        }

        using (var fs = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.ReadWrite))
        {
            var xmls = new System.Xml.Serialization.XmlSerializer(obj.GetType());

            var osn =
                new System.Xml.Serialization.XmlSerializerNamespaces();
            osn.Add(string.Empty, string.Empty);

            xmls.Serialize(fs, obj, osn);
        }
    }

    /// <summary>
    /// Encrypts the and serialize.
    /// </summary>
    /// <param name="obj">The object.</param>
    /// <param name="fileName">Name of the file.</param>
    /// <param name="loggingService">The logging service.</param>
    /// <returns>if was success</returns>
    public static bool EncryptAndSerialize(object obj, string fileName, ILogger loggingService)
    {
        try
        {
            using (var fs = File.Open(fileName, FileMode.Create))
            {
                EncryptAndSerialize(obj, fs);
            }

            return true;
        }
        catch (Exception ex)
        {
            loggingService.LogError("Error exporting xml encrypted data", ex.Message, ex);
            return false;
        }
    }

    /// <summary>
    /// Encrypts the and serialize.
    /// </summary>
    /// <param name="obj">The object.</param>
    /// <param name="outputStream">The output stream.</param>
    public static void EncryptAndSerialize(object obj, Stream outputStream)
    {
        var magicStringThatCannotBeChanged = "3e28aa8b-3362-48c5-b923-fcd354ab25dd";
        var aue = new UnicodeEncoding();
        using (var rmcrypto = new RijndaelManaged())
        {
            using (var pdb = new Rfc2898DeriveBytes(magicStringThatCannotBeChanged, SALT))
            {
                rmcrypto.Key = pdb.GetBytes(32);
                rmcrypto.IV = pdb.GetBytes(16);

                using (var cs = new CryptoStream(outputStream, rmcrypto.CreateEncryptor(),
                           CryptoStreamMode.Write))
                {
                    var xmlser = new XmlSerializer(obj.GetType());
                    xmlser.Serialize(cs, obj);
                }
            }
        }
    }

    /// <summary>
    /// Decrypts the and deserialize.
    /// </summary>
    /// <typeparam name="T">object type parameter</typeparam>
    /// <param name="filename">The filename.</param>
    /// <param name="loggingService">The logging service.</param>
    /// <returns>
    /// serialized object from file
    /// </returns>
    public static T DecryptAndDeserialize<T>(string filename, ILogger loggingService, bool throwError = false)
    {
        try
        {
            var magicStringThatCannotBeChanged = "3e28aa8b-3362-48c5-b923-fcd354ab25dd";

            var doc = new XmlDocument();
            doc.PreserveWhitespace = true;

            var afileStream = new FileStream(filename, FileMode.Open);
            var astreamReader = new StreamReader(afileStream);
            var aue = new UnicodeEncoding();
            var rmcrypto = new RijndaelManaged();

            var pdb = new Rfc2898DeriveBytes(magicStringThatCannotBeChanged, SALT);
            rmcrypto.Key = pdb.GetBytes(32);
            rmcrypto.IV = pdb.GetBytes(16);

            using (var acryptoStream =
                   new CryptoStream(afileStream, rmcrypto.CreateDecryptor(), CryptoStreamMode.Read))
            {
                using (XmlReader reader = new XmlTextReader(acryptoStream))
                {
                    doc.Load(reader);
                }

                afileStream.Close();
            }

            return (T)XmlDeserialize<T>(doc.OuterXml);
        }
        catch (Exception ex)
        {
            loggingService.LogError("Error importing xml encrypted data", ex.Message, ex);

            if (throwError)
            {
                throw ex;
            }
        }

        return default(T);
    }

    /// <summary>
    /// Decrypts the and deserialize.
    /// </summary>
    /// <typeparam name="T">object type parameter</typeparam>
    /// <param name="stream">The stream.</param>
    /// <param name="loggingService">The logging service.</param>
    /// <returns>
    /// serialized object from file
    /// </returns>
    public static T DecryptAndDeserialize<T>(Stream stream, ILogger loggingService, bool throwError = false)
    {
        try
        {
            var magicStringThatCannotBeChanged = "3e28aa8b-3362-48c5-b923-fcd354ab25dd";

            var doc = new XmlDocument();
            doc.PreserveWhitespace = true;

            var astreamReader = new StreamReader(stream);
            var aue = new UnicodeEncoding();
            var rmcrypto = new RijndaelManaged();

            var pdb = new Rfc2898DeriveBytes(magicStringThatCannotBeChanged, SALT);
            rmcrypto.Key = pdb.GetBytes(32);
            rmcrypto.IV = pdb.GetBytes(16);

            using (var acryptoStream =
                   new CryptoStream(stream, rmcrypto.CreateDecryptor(), CryptoStreamMode.Read))
            {
                using (XmlReader reader = new XmlTextReader(acryptoStream))
                {
                    doc.Load(reader);
                }

                stream.Close();
            }

            return (T)XmlDeserialize<T>(doc.OuterXml);
        }
        catch (Exception ex)
        {
            loggingService.LogError("Error importing xml encrypted data", ex.Message, ex);

            if (throwError)
            {
                throw ex;
            }
        }

        return default(T);
    }

    /// <summary>
    /// Internals the serialize.
    /// </summary>
    /// <param name="o">The o.</param>
    /// <returns>Internal class serializes.</returns>
    private static string InternalSerialize(object o)
    {
        if (o == null)
        {
            return string.Empty;
        }

        return XmlSerialize(o);
    }

    /// <summary>
    /// Serializes to stripped XML.
    /// </summary>
    /// <param name="serializer">The serializer.</param>
    /// <param name="o">The o.</param>
    /// <param name="namespaces">The namespaces.</param>
    /// <returns>
    /// The serialized object without starting xml tags.
    /// </returns>
    private static string SerializeToStrippedXML(XmlSerializer serializer, object o, XmlQualifiedName[] namespaces)
    {
        var sb = new StringBuilder();
        using (var xmlWriter = System.Xml.XmlWriter.Create(
                   sb,
                   new System.Xml.XmlWriterSettings()
                   {
                       OmitXmlDeclaration = true,
                       NewLineChars = string.Empty,
                       NewLineHandling = System.Xml.NewLineHandling.Replace
                   }))
        {
            var ns = new XmlSerializerNamespaces();
            ns.Add(string.Empty, string.Empty);

            if (namespaces != null)
            {
                foreach (var name in namespaces)
                {
                    ns.Add(name.Name, name.Namespace);
                }
            }

            serializer.Serialize(xmlWriter, o, ns);
        }

        return sb.ToString();
    }
}