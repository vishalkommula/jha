﻿using System.Text;
using System.Xml.Serialization;

namespace Jha.X3.Xpe.Screen
{
    /// <summary>
    /// The Screen Field 5250
    /// </summary>
    [Serializable]
    public class ScreenField5250
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ScreenField5250" /> class.
        /// </summary>
        /// <param name="fieldName">Name of the field.</param>
        /// <param name="fieldType">Type of the field.</param>
        /// <param name="row">The row.</param>
        /// <param name="col">The col.</param>
        /// <param name="attribute">The attribute.</param>
        /// <param name="fieldSize">Size of the field.</param>
        /// <param name="data">The data.</param>
        /// <param name="screenWidth">Width of the screen.</param>
        /// <param name="fieldFormatWord">The field format word.</param>
        /// <param name="fieldControlWord">The field control word.</param>
        public ScreenField5250(string fieldName, string fieldType, int row, int col, FieldAttribute attribute, int fieldSize, string data, int screenWidth, FieldFormatWord fieldFormatWord = null, FieldControlWord fieldControlWord = null)
        {
            this.FieldName = fieldName;
            this.FieldType = fieldType;
            this.Att = attribute;
            this.Data = data;
            this.ScreenWidth = screenWidth;
            this.FieldFormatWord = fieldFormatWord;
            this.FieldControlWord = fieldControlWord;

            this.RRCCCs = new List<string>();

            if (this.ScreenWidth != 0 && fieldSize > 0)
            {
                for (int i = 0; i < fieldSize; i++)
                {
                    int column = (col + i) % this.ScreenWidth;

                    // If there is no remainder, then the column should be 1 instead of 0.
                    if (column == 0)
                    {
                        column = this.ScreenWidth;
                    }

                    int rowIncrememnter = (col + i - 1) / this.ScreenWidth;

                    this.RRCCCs.Add(string.Format("{0:00}{1:000}", row + rowIncrememnter, column));
                }
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ScreenField5250"/> class.
        /// </summary>
        public ScreenField5250()
        {
        }

        /// <summary>
        /// Gets or sets the associated masked fields.
        /// </summary>
        /// <value>
        /// The associated masked fields.
        /// </value>
        public List<ScreenField5250> AssociatedMaskedFields
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is focused.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is focused; otherwise, <c>false</c>.
        /// </value>
        public bool IsFocused
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the RRCCC.
        /// </summary>
        /// <value>
        /// The RRCCC.
        /// </value>
        [XmlIgnore]
        public string RRCCC
        {
            get
            {
                // This only happens when a 5250 field is created in NVPGridData for the convenience of using a SLLiteScreenFieldItem
                if (this.RRCCCs.Count == 0)
                {
                    return "00000";
                }
                else
                {
                    return this.RRCCCs.FirstOrDefault();
                }
            }
        }

        /// <summary>
        /// Gets or sets the name of the field.
        /// </summary>
        /// <value>
        /// The name of the field.
        /// </value>
        public string FieldName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the type of the field.
        /// </summary>
        /// <value>
        /// The type of the field.
        /// </value>
        public string FieldType
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the row.
        /// </summary>
        /// <value>
        /// The row.
        /// </value>
        [XmlIgnore]
        public int Row
        {
            get
            {
                return Convert.ToInt32(this.RRCCC.Substring(0, 2));
            }
        }

        /// <summary>
        /// Gets the col.
        /// </summary>
        /// <value>
        /// The col.
        /// </value>
        [XmlIgnore]
        public int Col
        {
            get
            {
                return Convert.ToInt32(this.RRCCC.Substring(2, 3));
            }
        }

        /// <summary>
        /// Gets or sets the att.
        /// </summary>
        /// <value>
        /// The att.
        /// </value>
        public FieldAttribute Att
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the field format word.
        /// </summary>
        /// <value>
        /// The field format word.
        /// </value>
        public FieldFormatWord FieldFormatWord
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the field control word.
        /// </summary>
        /// <value>
        /// The field control word.
        /// </value>
        public FieldControlWord FieldControlWord
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the size of the field.
        /// </summary>
        /// <value>
        /// The size of the field.
        /// </value>
        [XmlIgnore]
        public int FieldSize
        {
            get
            {
                return this.RRCCCs.Count();
            }
        }

        /// <summary>
        /// Gets or sets the data.
        /// </summary>
        /// <value>
        /// The data.
        /// </value>
        public string Data
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the RRCC cs.
        /// </summary>
        /// <value>
        /// The RRCC cs.
        /// </value>
        public List<string> RRCCCs
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the width of the screen.
        /// </summary>
        /// <value>
        /// The width of the screen.
        /// </value>
        public int ScreenWidth
        {
            get;
            set;
        }

        /// <summary>
        /// Reorders the output fields by the RRCCC column so that
        /// they are processed in the correct order.  The fields do not come
        /// back from the service in the correct order.
        /// </summary>
        /// <param name="unorderedOutputFields">an IEnumerable of unordered outputFields</param>
        /// <returns>a List of outputFields ordered by RRCCC</returns>
        public static List<ScreenField5250> Reorder(IEnumerable<ScreenField5250> unorderedOutputFields)
        {
            return unorderedOutputFields.OrderBy(f => f.RRCCC).ToList();
        }

        /// <summary>
        /// Appends the data.
        /// </summary>
        /// <param name="data">The data.</param>
        public void AppendData(string data)
        {
            this.Data += data;

            string lastRRCCC = this.RRCCCs.LastOrDefault();

            int row = Convert.ToInt32(lastRRCCC.Substring(0, 2));
            int col = Convert.ToInt32(lastRRCCC.Substring(2, 3));

            if (this.ScreenWidth != 0 && data.Length > 0)
            {
                for (int i = 1; i < data.Length + 1; i++)
                {
                    int column = (col + i) % this.ScreenWidth;

                    // If there is no remainder, then the column should be 1 instead of 0.
                    if (column == 0)
                    {
                        column = this.ScreenWidth;
                    }

                    int rowIncrememnter = (col + i - 1) / this.ScreenWidth;

                    this.RRCCCs.Add(string.Format("{0:00}{1:000}", row + rowIncrememnter, column));
                }
            }
        }

        /// <summary>
        /// Clones this instance.
        /// </summary>
        /// <returns>The cloned Screen Field</returns>
        public ScreenField5250 Clone()
        {
            ScreenField5250 clonedField = new ScreenField5250(this.FieldName, this.FieldType, this.Row, this.Col, this.Att, this.FieldSize, this.Data, this.ScreenWidth, this.FieldFormatWord, this.FieldControlWord);
            clonedField.AssociatedMaskedFields = this.AssociatedMaskedFields;
            return clonedField;
        }

        /// <summary>
        /// Returns a <see cref="string" /> that represents this instance.
        /// </summary>
        /// <returns>
        /// A <see cref="string" /> that represents this instance.
        /// </returns>
        public override string ToString()
        {
            StringBuilder fieldString = new StringBuilder();

            if (this.FieldType == ScreenField5250Type.InputField)
            {
                fieldString.Append("Input Field   ");
            }
            else if (this.FieldType == ScreenField5250Type.OutputField || this.FieldType == ScreenField5250Type.Attribute)
            {
                fieldString.Append("Output Field ");
            }
            else if (this.FieldType == ScreenField5250Type.ErrorField)
            {
                fieldString.Append("Error Field  ");
            }
            else
            {
                fieldString.Append(this.FieldType + "  ");
            }

            if (this.RRCCC != null && this.RRCCC != string.Empty)
            {
                fieldString.Append("  RRCCC:" + this.RRCCC);
            }

            fieldString.Append(" Size:" + this.FieldSize.ToString());

            if (this.FieldName != null && this.FieldName != string.Empty)
            {
                fieldString.Append("  Name:" + this.FieldName);
            }

            if (this.Data != null && this.Data != string.Empty)
            {
                fieldString.Append("  Data:" + this.Data);
            }

            if (this.IsFocused)
            {
                fieldString.Append("  Field Has Focus");
            }

            return fieldString.ToString();
        }
    }
}
