﻿namespace Jha.X3.Xpe.Screen;

/// <summary>
/// The Field Attribute.
/// </summary>
[Serializable]
public enum FieldAttribute : byte
{
    Green = 0x20,
    GreenReverse = 0x21,
    White = 0x22,
    WhiteReverse = 0x23,
    GreenUnderscore = 0x24,
    GreenUnderscoreReverse = 0x25,
    WhiteUnderscore = 0x26,
    NonDisplay27 = 0x27,
    Red = 0x28,
    RedReverse = 0x29,
    RedBlink = 0x2A,
    RedBlinkReverse = 0x2B,
    RedUnderscore = 0x2C,
    RedUnderscoreReverse = 0x2D,
    RedUnderscoreBlink = 0x2E,
    NonDisplay2F = 0x2F,
    TurquoiseColumn = 0x30,
    TurquoiseColumnReverse = 0x31,
    YellowColumn = 0x32,
    YellowColumnReverse = 0x33,
    TurquoiseUnderscore = 0x34,
    TurquoiseUnderscoreReverse = 0x35,
    YellowUnderscore = 0x36,
    NonDisplay37 = 0x37,
    Pink = 0x38,
    PinkReverse = 0x39,
    Blue = 0x3A,
    BlueReverse = 0x3B,
    PinkUnderscore = 0x3C,
    PinkUnderscoreReverse = 0x3D,
    BlueUnderscore = 0x3E,
    NonDisplay3f = 0x3F
}