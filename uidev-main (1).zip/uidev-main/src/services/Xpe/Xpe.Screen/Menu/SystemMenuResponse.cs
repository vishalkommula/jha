namespace Jha.X3.Xpe.Screen;

public class SystemMenuResponse
{
    public IEnumerable<SystemMenuFolder> MenuItems { get; set; }
    
    public string InitialMenuItem { get; set; }
    
    public IEnumerable<string>? Errors { get; set; }
    
    public SystemMenuResponseStatus Status { get; set; }
}