namespace Jha.X3.Xpe.Screen;

public class SystemMenuRequest
{
    public string Folder { get; set; }
}