﻿namespace Jha.X3.Xpe.Screen;

public class SystemMenuFolder
{
    public string FavoriteToolTip { get; set; }
    public bool HasMenuItems { get; set; }
    public bool IsFavoriteMenuItem { get; set; }
    public bool IsPasswordRequired { get; set; }
    public bool IsSubFolder { get; set; }
    public string MenuId { get; set; }
    public string MenuName { get; set; }
    public string Product { get; set; }
    public string Title { get; set; }
    public string ToolTipDetail { get; set; }
    public bool IsSameMenuOpt { get; set; }    
}