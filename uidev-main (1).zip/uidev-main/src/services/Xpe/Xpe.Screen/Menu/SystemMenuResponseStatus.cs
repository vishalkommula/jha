namespace Jha.X3.Xpe.Screen;

public enum SystemMenuResponseStatus
{
    Success,
    Error
}