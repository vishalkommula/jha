﻿using Xpe.WebApi.Infrastructure;
using Xpe.WebApi.Infrastructure.Services;

namespace Xpe.WebApi;

public static class XpeBackgroundServiceExtensions
{
    public static IServiceCollection AddXpeBackgroundService(this IServiceCollection services)
    {
        return services
            .AddSingleton<IXpeSessionManager, XpeSessionManager>()
            .AddSingleton<IXpeUserSessionManager, XpeUserSessionManager>()
            .AddSingleton<IXpeBackgroundTaskQueue, XpeBackgroundTaskQueue>()
            .AddHostedService<XpeBackgroundService>();
    }
}