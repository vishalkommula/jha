using Xpe.DependencyInjection;
using Xpe.WebApi;
using Xpe.WebApi.Hubs;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services
    .AddLogging()
    .AddXpeMediatr()
    .AddXpeBackend()
    .AddXpeBackgroundService();

builder.Services.AddControllers();
builder.Services.AddSignalR()
    .AddNewtonsoftJsonProtocol();

builder.Services.AddCors(options =>
{
    options.AddPolicy("CorsPolicy", builder => builder
        .WithOrigins("https://localhost:4200", "https://localhost:4203")
        .AllowAnyMethod()
        .AllowAnyHeader()
        .AllowCredentials());
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    // app.UseSwagger();
    // app.UseSwaggerUI();
}

// app.UseHttpsRedirection();
// app.UseAuthorization();

app.MapControllers();
app.MapHub<XpeHub>("/XpeHub");
app.UseCors("CorsPolicy");

app.Run();