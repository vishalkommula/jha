using Xpe.Abstraction.Navigation;

namespace Xpe.WebApi.Infrastructure.Services;

public interface IXpeSessionManager
{
    IXpeUserSessionManager GetUserSessionManager(IServiceScope scope, string userId);
    IXpeNavigationService GetUserSession(IServiceScope scope, string userId, string sessionId);
}