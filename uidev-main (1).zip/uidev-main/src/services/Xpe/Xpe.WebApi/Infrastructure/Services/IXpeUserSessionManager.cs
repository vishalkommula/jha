﻿using Xpe.Abstraction.Navigation;

namespace Xpe.WebApi.Infrastructure.Services;

public interface IXpeUserSessionManager
{
    IXpeNavigationService GetUserSession(IServiceScope scope, string sessionId);
}