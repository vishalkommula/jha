﻿namespace Xpe.WebApi.Infrastructure.Services;

public interface IXpeBackgroundTaskQueue
{
    ValueTask QueueBackgroundWorkItemAsync(BackgroundWorkItem workItem);

    ValueTask<BackgroundWorkItem> DequeueAsync(CancellationToken cancellationToken);    
}