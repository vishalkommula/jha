﻿namespace Xpe.WebApi.Infrastructure.Services;

public delegate ValueTask BackgroundWorkItem(
    CancellationToken cancellationToken,
    IServiceScope scope,
    IXpeSessionManager sessionManager);