﻿using System.Collections.Concurrent;
using Xpe.Abstraction.Navigation;

namespace Xpe.WebApi.Infrastructure.Services;

public class XpeSessionManager : IXpeSessionManager
{
    private readonly ConcurrentDictionary<string, IXpeUserSessionManager> sessions = new();

    public IXpeUserSessionManager GetUserSessionManager(IServiceScope scope, string userId)
    {
        if (sessions.ContainsKey(userId))
        {
            return sessions[userId];
        }

        var userSessionManager = scope.ServiceProvider.GetRequiredService<IXpeUserSessionManager>();
        sessions.TryAdd(userId, userSessionManager);
        return userSessionManager;
    }

    public IXpeNavigationService GetUserSession(IServiceScope scope, string userId, string sessionId)
    {
        var userSessions = GetUserSessionManager(scope, userId);
        return userSessions.GetUserSession(scope, sessionId);
    }
}