﻿using Xpe.Abstraction.Enums;
using Xpe.Abstraction.Model;
using Xpe.Abstraction.Navigation;
using Xpe.WebApi.Infrastructure.Commands;
using Xpe.WebApi.Infrastructure.Services;
using MediatR;
using Xpe.Cache;
using Xpe.Cache.Infrastructure;

namespace Xpe.WebApi.Infrastructure.Handlers;

public class LaunchMenuItemCmdHandler : AsyncRequestHandler<LaunchMenuItemCmd>
{
    private readonly IXpeBackgroundTaskQueue backgroundTaskQueue;

    private readonly IUserCache cacheManager;
    private readonly ILogger<LaunchMenuItemCmdHandler> logger;

    public LaunchMenuItemCmdHandler(
        ILogger<LaunchMenuItemCmdHandler> logger,
        IUserCache cacheManager,
        IXpeBackgroundTaskQueue backgroundTaskQueue)
    {
        this.logger = logger;
        this.cacheManager = cacheManager;
        this.backgroundTaskQueue = backgroundTaskQueue;
    }

    protected override async Task Handle(LaunchMenuItemCmd request, CancellationToken cancellationToken)
    {
        try
        {
            var xpeContext = cacheManager
                .GetInMemoryCache<XpeConnectionContext>(request.UserIdentifier, CacheConstants.XpeContextKey);

            if (!xpeContext.IsFound)
            {
                logger.LogError("Xpe Connection Context not found.");
                return;
            }

            await backgroundTaskQueue.QueueBackgroundWorkItemAsync((_, scope, xpeSessionManager) =>
            {
                var navigationService = xpeSessionManager.GetUserSession(scope, 
                    request.UserIdentifier, Guid.Empty.ToString());

                navigationService.Navigate(new XpeNavigationEventArgs
                {
                    UserIdentifier = request.UserIdentifier,
                    Menu = request.MenuItem.MenuOpt?.PrvdMenuName,
                    Command = request.MenuItem.MenuOpt?.PrvdMenuCmd,
                    Option = request.MenuItem.MenuOpt?.PrvdMenuOpt,
                    Product = request.MenuItem.Product ?? "SilverLake",
                    Program = request.MenuItem.MenuOpt?.PrvdMenuPgm,
                    InstitutionNumber = xpeContext.Value?.InstitutionNumber ?? "2022510",
                    BankName = xpeContext.Value?.BankName,
                    FunctionKey2 = Key.None,
                    ImsUserSelectedSecurityGroup = "No Group",
                    Misc1 = request.MenuItem.Misc1,
                    Misc2 = request.MenuItem.Misc2,
                    Misc3 = request.MenuItem.Misc3,
                    Misc4 = request.MenuItem.Misc4
                });

                return ValueTask.CompletedTask;
            });
        }
        catch (Exception e)
        {
            logger.LogError(e, "Error navigating xpe.");
        }
    }
}