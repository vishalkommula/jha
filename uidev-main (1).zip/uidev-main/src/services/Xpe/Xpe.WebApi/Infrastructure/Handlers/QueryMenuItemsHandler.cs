﻿using Xpe.Menu;
using Xpe.Menu.Interfaces;
using Xpe.WebApi.Infrastructure.Commands;
using Xpe.WebApi.Infrastructure.Queries;
using MediatR;

namespace Xpe.WebApi.Infrastructure.Handlers;

public class QueryMenuItemsHandler : RequestHandler<QueryMenuItems, MenuQueryResponse>
{
    private readonly ILogger<QueryMenuItemsHandler> logger;
    private readonly IMediator mediator;
    private readonly IMenuService menuService;

    public QueryMenuItemsHandler(
        ILogger<QueryMenuItemsHandler> logger,
        IMediator mediator,
        IMenuService menuService)
    {
        this.logger = logger;
        this.mediator = mediator;
        this.menuService = menuService;
    }

    protected override MenuQueryResponse Handle(QueryMenuItems request)
    {
        try
        {
            return menuService.GetMenuItems(request.UserIdentifier);
        }
        catch (Exception e)
        {
            logger.LogError(e, "Error retrieving menu items.");
            return new MenuQueryResponse(MenuQueryResponseStatus.Error,
                null, null, new[] { e.Message });
        }
    }
}