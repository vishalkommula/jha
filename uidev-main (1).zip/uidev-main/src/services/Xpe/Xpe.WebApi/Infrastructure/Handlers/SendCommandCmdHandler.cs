﻿using Xpe.WebApi.Infrastructure.Commands;
using Xpe.WebApi.Infrastructure.Services;
using MediatR;

namespace Xpe.WebApi.Infrastructure.Handlers;

public class SendCommandCmdHandler : AsyncRequestHandler<SendCommandCmd>
{
    private readonly IXpeBackgroundTaskQueue backgroundTaskQueue;
    private readonly ILogger<SendCommandCmdHandler> logger;

    public SendCommandCmdHandler(
        ILogger<SendCommandCmdHandler> logger,
        IXpeBackgroundTaskQueue xpeBackgroundTaskQueue)
    {
        this.logger = logger;
        backgroundTaskQueue = xpeBackgroundTaskQueue;
    }

    protected override async Task Handle(SendCommandCmd request, CancellationToken cancellationToken)
    {
        try
        {
            await backgroundTaskQueue.QueueBackgroundWorkItemAsync((_, scope, xpeSessionManager) =>
            {
                var navigationService = xpeSessionManager.GetUserSession(scope, 
                    request.UserIdentifier, Guid.Empty.ToString());

                if (!request.IsSendingPing)
                {
                    navigationService.SendCommand(request.Key, request.IsMappedView, request.ChangedFields);
                }
                else
                {
                    navigationService.SendPing(request.IsMappedView);
                }

                return ValueTask.CompletedTask;
            });
        }
        catch (Exception e)
        {
            logger.LogError(e, "Error sending command to iSeries");
        }
    }
}