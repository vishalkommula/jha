﻿using Xpe.Abstraction.Model;
using Xpe.WebApi.Infrastructure.Commands;
using MediatR;
using Xpe.Cache;
using Xpe.Cache.Infrastructure;
using Xpe.Cache.Model;

namespace Xpe.WebApi.Infrastructure.Handlers;

public class RegisterClientCmdHandler : RequestHandler<RegisterClientCmd>
{
    public RegisterClientCmdHandler(
        ILogger<RegisterClientCmdHandler> logger,
        IUserCache cacheManager)
    {
        Logger = logger;
        CacheManager = cacheManager;
    }

    private ILogger<RegisterClientCmdHandler> Logger { get; }
    private IUserCache CacheManager { get; }

    protected override void Handle(RegisterClientCmd request)
    {
        try
        {
            CacheManager.AddInMemoryCache(
                request.UserIdentifier, CacheConstants.XpeContextKey,
                new XpeConnectionContext
                {
                    ConnectionId = request.ConnectionId,
                    KerberosToken = request.KerberosToken,
                    SamlAssertion = request.SamlAssertion,
                    UserId = request.UserIdentifier
                },
                new UserCacheOptions
                {
                    SlidingExpiration = TimeSpan.FromMinutes(5)
                });
        }
        catch (Exception e)
        {
            Logger.LogError(e, "Error registering client socket connection information.");
        }
    }
}