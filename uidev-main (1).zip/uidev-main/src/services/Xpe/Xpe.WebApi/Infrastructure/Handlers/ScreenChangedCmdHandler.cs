﻿using Xpe.Abstraction.Commands;
using Xpe.Abstraction.Model;
using Xpe.Abstraction.Services;
using MediatR;

namespace Xpe.WebApi.Infrastructure.Handlers;

public class ScreenChangedCmdHandler : RequestHandler<ScreenChangedCmd>
{
    public ScreenChangedCmdHandler(
        ILogger<ScreenChangedCmdHandler> logger,
        IXperienceEnabledService xperienceEnabledService)
    {
        Logger = logger;
        XperienceEnabledService = xperienceEnabledService;
    }

    private ILogger<ScreenChangedCmdHandler> Logger { get; }
    private IXperienceEnabledService XperienceEnabledService { get; }

    protected override void Handle(ScreenChangedCmd request)
    {
        if (request.ScreenInfo == null)
        {
            return;
        }
        var isStaticView = ScreenIdentification.StaticLayoutScreens.Contains(request.ScreenInfo?.ScreenId);

        XperienceEnabledService.OnScreenChanged(request, isStaticView);
    }
}