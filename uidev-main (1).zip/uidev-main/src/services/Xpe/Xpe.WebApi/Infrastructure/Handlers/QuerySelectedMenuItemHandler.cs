﻿using Xpe.Menu;
using Xpe.Menu.Interfaces;
using Xpe.WebApi.Infrastructure.Queries;
using MediatR;

namespace Xpe.WebApi.Infrastructure.Handlers;

public class QuerySelectedMenuItemHandler : RequestHandler<QuerySelectedMenuItem, SelectMenuItemResponse>
{
    private readonly ILogger<QuerySelectedMenuItemHandler> logger;
    private readonly IMenuService menuService;

    public QuerySelectedMenuItemHandler(
        ILogger<QuerySelectedMenuItemHandler> logger,
        IMenuService menuService)
    {
        this.logger = logger;
        this.menuService = menuService;
    }

    protected override SelectMenuItemResponse Handle(QuerySelectedMenuItem request)
    {
        try
        {
            return menuService.SelectMenuItem(request.UserIdentifier, request.MenuId);
        }
        catch (Exception e)
        {
            logger.LogError(e, "Error selecting menu item.");
            return new SelectMenuItemResponse(MenuQueryResponseStatus.Error, null, new[] { e.Message });
        }
    }
}