﻿using Xpe.Menu;
using MediatR;

namespace Xpe.WebApi.Infrastructure.Queries;

public record QueryMenuItems(string UserIdentifier) : IXpeRequest<MenuQueryResponse>;