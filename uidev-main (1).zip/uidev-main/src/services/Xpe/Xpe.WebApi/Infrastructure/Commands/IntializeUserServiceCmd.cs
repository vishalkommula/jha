﻿using MediatR;

namespace Xpe.WebApi.Infrastructure.Commands;

public record IntializeUserServiceCmd(string UserIdentifier) : IXpeRequest;
