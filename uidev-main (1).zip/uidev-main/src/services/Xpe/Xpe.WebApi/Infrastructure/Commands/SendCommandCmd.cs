﻿using Xpe.Abstraction.Model;

namespace Xpe.WebApi.Infrastructure.Commands;

public record SendCommandCmd(
    string UserIdentifier,
    string Key,
    bool IsSendingPing,
    bool IsMappedView,
    List<ScreenField5250> ChangedFields) : IXpeRequest;