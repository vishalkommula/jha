﻿using Ardalis.GuardClauses;
using Xpe.Abstraction.Model;
using Xpe.Abstraction.Model.ScreenHandlers;

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Xpe.DependencyInjection;

public static class ScreenHandlerExtensions
{
    public static IServiceCollection Replace<TService>(this IServiceCollection services, object instance)
    {
        Guard.Against.Null(instance,
            nameof(instance));

        return services.Replace(
            new ServiceDescriptor(typeof(TService),
                instance));
    }

    public static IServiceCollection AddScreenHandlers(this IServiceCollection services)
    {
        services
            .AddScoped<IScreenHandler, AccountRelatedFunctionHandler>()
            .AddScoped<IScreenHandler, AlertsBypassHandler>()
            .AddScoped<IScreenHandler, BreakMessageScreenHandler>()
            .AddScoped<IScreenHandler, CD9020FMScreenHandler>()
            .AddScoped<IScreenHandler, CF5000FMScreenHandler>()
            .AddScoped<IScreenHandler, CFMLIDFMScreenHandler>()
            .AddScoped<IScreenHandler, CustomerRelatedFunctionHandler>()
            .AddScoped<IScreenHandler, GeneralNavHoldScreenHandler>()
            .AddScoped<IScreenHandler, GLReconGLR500CScreenHandler>()
            .AddScoped<IScreenHandler, ImageSearchParmJHXPEIMGFMScreenHandler>()
            .AddScoped<IScreenHandler, ImageViewerScreenHandler>()
            .AddScoped<IScreenHandler, JH5200FMScreenHandler>()
            .AddScoped<IScreenHandler, LNC500FMScreenHandler>()
            .AddScoped<IScreenHandler, PROCESSFMScreenHandler>()
            .AddScoped<IScreenHandler, ReverseJumpScreenHandler>()
            .AddScoped<IScreenHandler, SD5000FMScreenHandler>()
            .AddScoped<IScreenHandler, SignonScreenHandler>()
            .AddScoped<IScreenHandler, StaticLayoutScreenHandler>()
            .AddScoped<IScreenHandler, WindowsCommandJHXPECMDFMScreenHandler>()
            //// This is the empty CustomScreenHandlerMapping registration. This allows for override and mapping of custom screen handlers.
            .AddScoped<ICustomScreenHandlerMapping, CustomScreenHandlerMapping>()
            // Generate Loan Payoff Letter needs to remain in XPE else we end up reloading Loan Payoff and dont land on desired screen
            .AddScoped<IScreenHandler, LoanPayoffHandler>();

        return services;
    }

}
