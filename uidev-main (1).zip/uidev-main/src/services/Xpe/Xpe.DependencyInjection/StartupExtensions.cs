﻿using Ardalis.GuardClauses;
using JackHenry.UID.Cache.Extensions;
using Xpe.Abstraction.Infrastructure;
using Xpe.Abstraction.Model;
using Xpe.Abstraction.Navigation;
using Xpe.Abstraction.Services;
using Xpe.Infrastructure;
using Xpe.Menu;
using Xpe.Menu.Interfaces;
using Xpe.Menu.Navigation;
using Xpe.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Xpe.DependencyInjection;

public static class StartupExtensions
{
    public static IServiceCollection Replace<TService>(this IServiceCollection services, object instance)
    {
        Guard.Against.Null(instance,
            nameof(instance));

        return services.Replace(
            new ServiceDescriptor(typeof(TService),
                instance));
    }

    public static IServiceCollection AddXpeBackend(this IServiceCollection services)
    {
        services
            .AddXpeCache()
            .AddScoped<IDnsLookup, DnsLookup>()
            .AddScoped<ITcpClient, TcpClient>()
            .AddScoped<IEbcdicConverter, EbcdicConverter>()
            .AddScoped<IUserService, UserService>()
            .AddScoped<ICertificateValidationStrategy, CertificateValidationStrategy>()
            .AddScoped<IISeriesConnectionCallbackStrategy, ISeriesConnectionCallbackStrategy>()
            .AddScoped<IInquiryTypeProvider, InquiryTypeProvider>()
            .AddScoped<IISeriesConnectionInfoService, ISeriesConnectionInfoService>()
            .AddScoped<IISeriesServer, ISeriesServer>()
            .AddScoped<IJha5250, Jha5250>()
            .AddScoped<IMenuCacheService, MenuCacheService>()
            .AddScoped<IMenuService, MenuService>()
            .AddScoped<IXpeExclusionHelper, XpeExclusionHelper>()
            .AddScoped<IXperienceEnabledService, XperienceEnabledService>()
            .AddScoped<IXpeNavigationService, XpeNavigationService>()
            .AddScreenHandlers()
            .AddScoped<IScreenHandlerService, ScreenHandlerService>()
            .AddScoped<IFieldItemProvider, DynamicGridFieldItemProvider>();

        return services;
    }
}