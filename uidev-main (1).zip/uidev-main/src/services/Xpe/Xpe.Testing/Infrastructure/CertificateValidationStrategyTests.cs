﻿using Jha.X3.Xpe.Abstraction.Infrastructure;
using Jha.X3.Xpe.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Jha.X3.Xpe.Testing.Infrastructure;

public class CertificateValidationStrategyTests
{
    public CertificateValidationStrategyTests()
    {
        Logger = new Mock<ILogger<CertificateValidationStrategy>>();

        ServiceProvider = new ServiceCollection()
            .AddSingleton(_ => Logger.Object)
            .AddSingleton<ICertificateValidationStrategy, CertificateValidationStrategy>()
            .BuildServiceProvider();

        CertificateValidationStrategy =
            ServiceProvider.GetRequiredService<ICertificateValidationStrategy>();
    }

    private ServiceProvider ServiceProvider { get; }
    private ICertificateValidationStrategy CertificateValidationStrategy { get; }
    private Mock<ILogger<CertificateValidationStrategy>> Logger { get; }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.UnitTest)]
    public void Can_create()
    {
        Assert.NotNull(CertificateValidationStrategy);
    }

    // TODO: Implement
}