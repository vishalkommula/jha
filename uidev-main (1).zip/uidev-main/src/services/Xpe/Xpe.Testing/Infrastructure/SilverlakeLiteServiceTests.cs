﻿using System;
using System.Collections.Generic;
using JackHenry.Enterprise.BusinessObjects.Jes;
using JackHenry.Enterprise.Client.Communication;
using JackHenry.Enterprise.Client.Identity;
using JackHenry.Enterprise.Client.Identity.Sts;
using JackHenry.JHAContractTypes;
using Jha.X3.Xpe.Abstraction.Enums;
using Jha.X3.Xpe.Abstraction.Model;
using Jha.X3.Xpe.DependencyInjection;
using Jha.X3.Xpe.Services;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Jha.X3.Xpe.Testing.Infrastructure;

public class SilverlakeLiteServiceTests
{
    public SilverlakeLiteServiceTests()
    {
        Services = new ServiceCollection()
            .AddLogging()
            .AddXpeBackend()
            .AddScoped<SilverlakeLiteService>()
            .BuildServiceProvider();

        SilverlakeLiteService = Services.GetRequiredService<SilverlakeLiteService>();
    }

    private IServiceProvider Services { get; }

    private SilverlakeLiteService SilverlakeLiteService { get; }

    private CurrentUserInfo CurrentUserInfo { get; set; }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.IntegrationTest)]
    public void Can_create()
    {
        Assert.NotNull(SilverlakeLiteService);
    }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.IntegrationTest)]
    public void Can_sign_on()
    {
        var result = SilverlakeLiteService.SignOn(CurrentUserInfo);
        Assert.NotNull(result);
        Assert.Null(result.Exception);
    }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.IntegrationTest)]
    public void Can_send_screen_request()
    {
        CurrentUserInfo = new CurrentUserInfo
        {
            Institution = new PrvdInstInfoModel
            {
                Alias = new BankingAlias
                {
                    Name = "GLEVEY"
                },
                PrvdInstInfo = new PrvdInstInfo_CType
                {
                    PrvdInstName = new SLString_Type { Value = "SLXP QA  TEST BANK 510   R2022" },
                    PrvdInstProd = new SLString_Type { Value = "SILVERLAKE" },
                    PrvdInstRtId = new SLString_Type { Value = "113102552" },
                    PrvdInstId = new SLString_Type { Value = "2022510" }
                }
            }
        };

        SilverlakeLiteService.SignOn(CurrentUserInfo);

        var enterCommand = new ScreenInfoRequest(
            new KeyPress(Key.Return, Key.None),
            new CursorLocation(1, 1));
        
        var response1 = SilverlakeLiteService.SendCommand(enterCommand);
        Assert.NotNull(response1);

        var screenCommand = new ScreenInfoRequest(
            new KeyPress(Key.Return, Key.None),
            new CursorLocation(7, 19))
        {
            ChangedFields = new List<ScreenField5250>
            {
                new() { Data = "510", FieldType = "IF", RRCCCs = new List<string> { "07019" } },
                new() { Data = "LNIN", FieldType = "IF", RRCCCs = new List<string> { "11019" } },
                new() { Data = " 3", FieldType = "IF", RRCCCs = new List<string> { "12019" } }
            }
        };

        var response2 = SilverlakeLiteService.SendCommand(screenCommand);
        Assert.NotNull(response2);
    }
}