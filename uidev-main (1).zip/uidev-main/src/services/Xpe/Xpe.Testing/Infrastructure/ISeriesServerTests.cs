using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Cryptography.X509Certificates;
using Jha.X3.Xpe.Abstraction.Infrastructure;
using Jha.X3.Xpe.DependencyInjection;
using Jha.X3.Xpe.Infrastructure;
using Jha.X3.Xpe.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;
using TcpClient = Jha.X3.Xpe.Infrastructure.TcpClient;

namespace Jha.X3.Xpe.Testing.Infrastructure;

// ReSharper disable once InconsistentNaming
public class ISeriesServerTests
{
    public ISeriesServerTests()
    {
        Logger = new Mock<ILogger<ISeriesServer>>();
        TcpClientLogger = new Mock<ILogger<TcpClient>>();
        CertificateValidationStrategy = new Mock<ICertificateValidationStrategy>();
        ConnectionCallbackStrategy = new ISeriesConnectionCallbackStrategy(
            new Mock<ILogger<ISeriesConnectionCallbackStrategy>>().Object);

        SetupMocks();

        ServiceProvider = new ServiceCollection()
            .AddSingleton(_ => Logger.Object)
            .AddSingleton(_ => TcpClientLogger.Object)
            .AddSingleton<IISeriesConnectionInfoService, ISeriesConnectionInfoService>()
            .AddXpeBackend()
            .Replace<ICertificateValidationStrategy>(CertificateValidationStrategy.Object)
            .Replace<IISeriesConnectionCallbackStrategy>(ConnectionCallbackStrategy)
            .BuildServiceProvider();

        Server = ServiceProvider.GetRequiredService<IISeriesServer>();

        ConnectionInfoService = new ISeriesConnectionInfoService
        {
            ConnectionInfo = new ISeriesConnectionInfo
            {
                Port = 51050,
                HostName = "iCoreDev.jhacorp.com"
            }
        };
    }

    private ServiceProvider ServiceProvider { get; }
    private IISeriesServer Server { get; }
    private Mock<ICertificateValidationStrategy> CertificateValidationStrategy { get; }
    private Mock<ILogger<ISeriesServer>> Logger { get; }
    private Mock<ILogger<TcpClient>> TcpClientLogger { get; }
    private IISeriesConnectionCallbackStrategy ConnectionCallbackStrategy { get; }
    private IISeriesConnectionInfoService ConnectionInfoService { get; }


    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.IntegrationTest)]
    public void Can_connect()
    {
        // Act
        Server.ConnectToServer(ConnectionInfoService.ConnectionInfo);

        // Assert
        Assert.True(Server.IsConnected);
        Assert.NotNull(Server.ServerStream);
        Assert.NotNull(Server.ServerSocket);
    }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.IntegrationTest)]
    public void Can_Disconnect()
    {
        // Act
        Server.ConnectToServer(ConnectionInfoService.ConnectionInfo);
        Server.DisconnectFromServer();

        // Assert
        Assert.False(Server.IsConnected);
        Assert.Null(Server.ServerStream);
        Assert.Null(Server.ServerSocket);
    }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.IntegrationTest)]
    public void Returns_failure_when_ipAddress_is_null()
    {
        // Arrange
        var mockDnsLookup = new Mock<IDnsLookup>();

        mockDnsLookup
            .Setup(o => o.GetHostAddress(
                It.IsAny<string>()))
            .Returns(() => null);

        var server = new ISeriesServer(Logger.Object,
            mockDnsLookup.Object,
            ServiceProvider.GetRequiredService<ITcpClient>(),
            ConnectionInfoService,
            ConnectionCallbackStrategy,
            CertificateValidationStrategy.Object);

        // Act
        var exception = Assert.Throws<Exception>(() =>
            server.ConnectToServer(ConnectionInfoService.ConnectionInfo));

        // Assert
        Assert.Equal(
            "An error occurred attempting to connect to the server: DNS could not resolve hostname.",
            exception.Message);
    }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.IntegrationTest)]
    public void Connection_fails_for_invalid_port()
    {
        // Act
        var exception = Assert.Throws<Exception>(() =>
            Server.ConnectToServer(new ISeriesConnectionInfo
            {
                Port = 0,
                HostName = "iCoreDev.jhacorp.com"
            }));

        // Assert
        Assert.Equal(
            "An error occurred attempting to connect to the server: Connection failed.",
            exception.Message);
    }

    [Theory]
    [Trait(TestConstants.TestCategory,
        TestConstants.IntegrationTest)]
    [InlineData(false,
        false)]
    [InlineData(true,
        true)]
    [InlineData(false,
        true)]
    [InlineData(true,
        false)]
    public void Returns_success_on_disconnect_with_null_Socket_And_Or_Stream(
        bool socketIsNull,
        bool streamIsNull)
    {
        // Act
        Server.ConnectToServer(ConnectionInfoService.ConnectionInfo);
        Server.ServerSocket = socketIsNull ? null : Server.ServerSocket;
        Server.ServerStream = streamIsNull ? null : Server.ServerStream;
        Server.DisconnectFromServer();

        // Assert
        Assert.False(Server.IsConnected);
    }

    [Theory]
    [Trait(TestConstants.TestCategory,
        TestConstants.IntegrationTest)]
    [MemberData(nameof(TestDataForDnsFailure))]
    public void Fails_when_dns_not_found(
        string hostName,
        string exceptionMessage)
    {
        // Act & Assert
        var exception = Assert.Throws<Exception>(() =>
            Server.ConnectToServer(new ISeriesConnectionInfo
            {
                Port = 51050,
                HostName = hostName
            }));

        Assert.Equal(
            exceptionMessage,
            exception.Message);

        // TODO: Add logger verification
    }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.IntegrationTest)]
    public void Success_for_IPV6_address()
    {
        // Arrange
        var connectionInfo = new ISeriesConnectionInfo
        {
            Port = 51050,
            HostName = "iCoreDev.jhacorp.com"
        };

        var mockDnsLookup = new Mock<IDnsLookup>();

        var mockReturnedIpAddresses = new[]
        {
            new IPAddress(654972844),
            new IPAddress(654972844)
        };

        mockDnsLookup
            .Setup(o => o.GetHostAddress(connectionInfo.HostName))
            .Returns(() => mockReturnedIpAddresses);

        mockDnsLookup
            .Setup(o => o.OSSupportsIPv6())
            .Returns(false);

        mockDnsLookup
            .SetupSequence(o => o.GetAddressFamily(It.IsAny<IPAddress>()))
            // Pretend the first address returned from GetHostAddress is IPV6
            .Returns(AddressFamily.InterNetworkV6)
            .Returns(AddressFamily.InterNetwork);

        var server = new ISeriesServer(
            ServiceProvider.GetRequiredService<ILogger<ISeriesServer>>(),
            mockDnsLookup.Object,
            ServiceProvider.GetRequiredService<ITcpClient>(),
            ServiceProvider.GetRequiredService<IISeriesConnectionInfoService>(),
            ServiceProvider.GetRequiredService<IISeriesConnectionCallbackStrategy>(),
            ServiceProvider.GetRequiredService<ICertificateValidationStrategy>()
        );

        // Act
        server.ConnectToServer(connectionInfo);

        // Assert
        Assert.True(server.IsConnected);
    }

    private void SetupMocks()
    {
        CertificateValidationStrategy.Setup(o =>
                o.CertificateValidationCallback(
                    It.IsAny<object>(),
                    It.IsAny<X509Certificate>(),
                    It.IsAny<X509Chain>(),
                    It.IsAny<SslPolicyErrors>()))
            .Returns(true);
    }

    public static IEnumerable<object[]> TestDataForDnsFailure()
    {
        return new object[][]
        {
            // Null host name
            new TestParameters
            {
                HostName = null,
                ExceptionMessage =
                    "An error occurred attempting to connect to the server: Value cannot be null. (Parameter 'hostNameOrAddress')"
            },
            // Empty host name
            new TestParameters
            {
                HostName = "",
                ExceptionMessage = "An error occurred attempting to connect to the server: Connection failed."
            },
            // Random host name
            new TestParameters
            {
                HostName = "whatever",
                ExceptionMessage = "An error occurred attempting to connect to the server: Connection failed."
            },
            // Bogus host name
            new TestParameters
            {
                HostName = "000.000.000.000",
                ExceptionMessage =
                    "An error occurred attempting to connect to the server: IPv4 address 0.0.0.0 and IPv6 address ::0 are unspecified addresses that cannot be used as a target address."
            }
        };
    }
}

public class TestParameters
{
    public string HostName { get; set; }

    public string ExceptionMessage { get; set; }

    public static implicit operator object[](TestParameters self)
    {
        return new object[]
        {
            self.HostName,
            self.ExceptionMessage
        };
    }
}