﻿using System.Linq;
using System.Net.Sockets;
using Jha.X3.Xpe.Infrastructure;
using Xunit;

namespace Jha.X3.Xpe.Testing.Infrastructure;

public class DnsLookupTests
{
    public DnsLookupTests()
    {
        DnsLookup = new DnsLookup();
    }

    private DnsLookup DnsLookup { get; }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.UnitTest)]
    public void Returns_success_for_valid_hostName()
    {
        var ipAddress = DnsLookup
            .GetHostAddress("www.jackhenry.com");

        var expectedIps = new[]
        {
            "10.202.33.5",
            "216.116.87.215"
        };
        Assert.NotNull(ipAddress);
        Assert.True(ipAddress.Any());
        Assert.Contains(ipAddress.FirstOrDefault().ToString(),
            expectedIps);
    }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.UnitTest)]
    public void Returns_success_for_ipv6_loopback()
    {
        var ipAddress = DnsLookup.GetHostAddress("::1");

        Assert.NotNull(ipAddress);
        Assert.Equal("::1",
            ipAddress.First().ToString());
    }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.UnitTest)]
    public void Throws_exception_for_invalid_hostName()
    {
        var exception = Assert.Throws<SocketException>(() =>
            DnsLookup.GetHostAddress("abc123.google.com"));

        Assert.Equal("No such host is known.",
            exception.Message);
    }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.UnitTest)]
    public void Returns_success_for_OSSupportsIPv6()
    {
        Assert.Equal(Socket.OSSupportsIPv6,
            DnsLookup.OSSupportsIPv6());
    }
}