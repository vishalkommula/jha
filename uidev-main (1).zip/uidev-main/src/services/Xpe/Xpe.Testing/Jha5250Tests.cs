﻿using Jha.X3.Xpe.Abstraction;
using Jha.X3.Xpe.Abstraction.Infrastructure;
using Jha.X3.Xpe.Abstraction.Model;
using Jha.X3.Xpe.Abstraction.Services;
using Jha.X3.Xpe.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Jha.X3.Xpe.Testing;

public class Jha5250Tests
{
    public Jha5250Tests()
    {
        Logger = new Mock<ILogger<Jha5250>>();
        ISeriesServer = new Mock<IISeriesServer>();

        ServiceProvider = new ServiceCollection()
            .AddSingleton(_ => Logger.Object)
            .AddSingleton(_ => ISeriesServer.Object)
            .AddSingleton<IISeriesConnectionInfoService, ISeriesConnectionInfoService>()
            .AddSingleton<IEbcdicConverter, EbcdicConverter>()
            .AddSingleton<IUserService, UserService>()
            .AddSingleton<IJha5250, Jha5250>()
            .BuildServiceProvider();

        Jha5250 = ServiceProvider.GetRequiredService<IJha5250>();
    }

    private ServiceProvider ServiceProvider { get; }

    private IJha5250 Jha5250 { get; }

    private Mock<ILogger<Jha5250>> Logger { get; }

    // ReSharper disable once InconsistentNaming
    private Mock<IISeriesServer> ISeriesServer { get; }

    [Fact]
    [Trait(TestConstants.TestCategory,
        TestConstants.UnitTest)]
    public void Can_create()
    {
        Assert.NotNull(Jha5250);
    }

    // TODO: Implement
}