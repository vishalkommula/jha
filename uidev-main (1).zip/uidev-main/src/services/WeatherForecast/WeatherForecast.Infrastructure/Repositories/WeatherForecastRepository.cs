﻿// ----------------------------------------------------------------------
// <copyright file="WeatherForecastRepository.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.Infrastructure.Repositories
{
    using System;
    using System.Threading.Tasks;
    using WeatherForecast.Core.Entities;
    using WeatherForecast.Core.Interfaces;
    using WeatherForecast.Core.ValueObjects;

    internal sealed class WeatherForecastRepository : IWeatherForecastRepository
    {
        public async Task<Forecast> GetWeatherForecastForDate(DateTime forecastDate, Temperature.UnitOfMeasure unitOfMeasure)
        {
            // Simulate network latency
            await Task.Delay(TimeSpan.FromSeconds(1));

            var forecast = new Forecast();

            forecast.ForecastDate = forecastDate.Date;
            forecast.Summary = "Sunny";

            forecast.UpdateCurrentTemperature(
                new Temperature(95, unitOfMeasure),
                new Temperature(99, unitOfMeasure));

            forecast.UpdateHighAndLow(
                new Temperature(100, unitOfMeasure),
                new Temperature(89, unitOfMeasure));

            return forecast;
        }
    }
}