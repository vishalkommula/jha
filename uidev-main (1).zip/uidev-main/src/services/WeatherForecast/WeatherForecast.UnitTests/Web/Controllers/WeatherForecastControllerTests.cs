﻿// ----------------------------------------------------------------------
// <copyright file="WeatherForecastControllerTests.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.UnitTests.Web.Controllers
{
    using System.Diagnostics.CodeAnalysis;
    using System.Reflection;
    using System.Threading;
    using System.Threading.Tasks;
    using MediatR;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Moq;
    using WeatherForecast.Web.Controllers;
    using WeatherForecast.Web.Requests.GetWeatherForecast;
    using Xunit;

    [ExcludeFromCodeCoverage]
    public class WeatherForecastControllerTests
    {
        private Mock<ILogger<WeatherForecastController>> loggerMock;
        private Mock<ISender> senderMock;
        private WeatherForecastController controller;
        private GetWeatherForecastRequest request = new GetWeatherForecastRequest();

        public WeatherForecastControllerTests()
        {
            this.loggerMock = new Mock<ILogger<WeatherForecastController>>();
            this.senderMock = new Mock<ISender>();
            this.controller = new WeatherForecastController(
                this.loggerMock.Object,
                this.senderMock.Object);

            this.request = new GetWeatherForecastRequest();
        }

        // Test that we get a weather forecast response for a given date an unit
        [Fact]
        public async Task GetWeatherForecast_DoesNotReturnNull()
        {
            var response = Task.FromResult(new ForecastDTO());

            this.senderMock
                .Setup(
                    x => x.Send(
                        It.IsAny<GetWeatherForecastRequest>(),
                        CancellationToken.None))
                .Returns(response);

            ForecastDTO forecast = await this.controller.GetWeatherForecast(this.request);

            Assert.NotNull(forecast);
        }

        // Make sure we call MediatR
        [Fact]
        public async Task GetWeatherForecast_CallsMediatorSend()
        {
            ForecastDTO forecast = await this.controller.GetWeatherForecast(this.request);

            this.senderMock.Verify(
                x => x.Send(
                    It.IsAny<GetWeatherForecastRequest>(),
                    CancellationToken.None),
                Times.Once);
        }

        [Fact]
        public void GetWeatherForecast_ValidateAttributes()
        {
            var controllerType = typeof(WeatherForecastController);
            MethodInfo method = controllerType.GetMethod(nameof(WeatherForecastController.GetWeatherForecast));
            ParameterInfo parameter = method.GetParameters()[0];

            Assert.Contains(method.CustomAttributes, a => a.AttributeType == typeof(HttpGetAttribute));
            Assert.Contains(parameter.CustomAttributes, a => a.AttributeType == typeof(FromQueryAttribute));
        }

        [Fact]
        public void Logger_NotNull()
        {
            Assert.NotNull(this.controller.Logger);
        }

        [Fact]
        public void Mediator_NotNull()
        {
            Assert.NotNull(this.controller.Mediator);
        }
    }
}
