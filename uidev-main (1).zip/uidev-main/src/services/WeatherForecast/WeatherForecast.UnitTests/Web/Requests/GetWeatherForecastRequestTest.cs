﻿// ----------------------------------------------------------------------
// <copyright file="GetWeatherForecastRequestTest.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.UnitTests.Web.Requests
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.Threading;
    using System.Threading.Tasks;
    using AutoMapper;
    using FluentValidation.TestHelper;
    using Moq;
    using WeatherForecast.Core.Interfaces;
    using WeatherForecast.Core.ValueObjects;
    using WeatherForecast.Web.Mappings;
    using WeatherForecast.Web.Requests.GetWeatherForecast;
    using Xunit;

    [ExcludeFromCodeCoverage]
    public class GetWeatherForecastRequestTest
    {
        public GetWeatherForecastRequestTest()
        {
            this.Configuration = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<MappingProfile>();
            });

            this.Mapper = this.Configuration.CreateMapper();
        }

        private IConfigurationProvider Configuration { get; }

        private IMapper Mapper { get; }

        public static IEnumerable<object[]> InvalidRequests { get; } = new List<object[]>
        {
            new object[] { DateTime.MinValue, Temperature.UnitOfMeasure.Celsius.ToString() },
            new object[] { new DateTime(2021, 10, 04), Temperature.UnitOfMeasure.Celsius.ToString() },
            new object[] { new DateTime(2021, 10, 05), null },
            new object[] { new DateTime(2021, 10, 05), string.Empty },
            new object[] { new DateTime(2021, 10, 05), "C" }
        };

        public static IEnumerable<object[]> ValidRequests { get; } = new List<object[]>
        {
            new object[] { DateTime.MaxValue, Temperature.UnitOfMeasure.Celsius.ToString() },
            new object[] { new DateTime(2021, 10, 05), Temperature.UnitOfMeasure.Fahrenheit.ToString() },
            new object[] { new DateTime(2021, 10, 06), "fahrenheit" },
            new object[] { new DateTime(2021, 10, 06), "celsius" }
        };

        [Fact]
        public async Task ResponseObjectMatchesRequest()
        {
            var mock = new Mock<IWeatherForecastRepository>();

            var requestDate = new DateTime(2021, 09, 17);
            var requestUnit = Temperature.UnitOfMeasure.Celsius;

            mock.Setup(x => x.GetWeatherForecastForDate(
                It.IsAny<DateTime>(),
                It.IsAny<Temperature.UnitOfMeasure>()))
                .Returns(() =>
                {
                    var forecast = new WeatherForecast.Core.Entities.Forecast();

                    forecast.ForecastDate = requestDate.Date;
                    forecast.Summary = "Sunny";

                    forecast.UpdateCurrentTemperature(
                        new Temperature(95, requestUnit),
                        new Temperature(99, requestUnit));

                    forecast.UpdateHighAndLow(
                        new Temperature(100, requestUnit),
                        new Temperature(89, requestUnit));

                    return Task.FromResult(forecast);
                });

            var requestHandler = new GetWeatherForecastRequestHandler(
                this.Mapper,
                mock.Object);

            var response = await requestHandler.Handle(
                new GetWeatherForecastRequest()
                {
                    ForecastDate = requestDate,
                    TemperatureUnit = requestUnit.ToString()
                },
                CancellationToken.None);

            Assert.Equal(requestDate, response.ForecastDate);
            Assert.Equal(requestUnit.ToString(), response.CurrentTemperature.Unit);
            Assert.Equal(requestUnit.ToString(), response.FeelsLikeTemperature.Unit);
            Assert.Equal(requestUnit.ToString(), response.HighTemperature.Unit);
            Assert.Equal(requestUnit.ToString(), response.LowTemperature.Unit);
        }

        [Theory]
        [MemberData(nameof(InvalidRequests))]
        public void InvalidRequestThrows(DateTime forecastDate, string unit)
        {
            this.TestGetWeatherForecastValidator(forecastDate, unit).ShouldHaveAnyValidationError();
        }

        [Theory]
        [MemberData(nameof(ValidRequests))]
        public void ValidRequestDoesNotThrow(DateTime forecastDate, string unit)
        {
            this.TestGetWeatherForecastValidator(forecastDate, unit).ShouldNotHaveAnyValidationErrors();
        }

        private TestValidationResult<GetWeatherForecastRequest> TestGetWeatherForecastValidator(DateTime forecastDate, string unit)
        {
            var dateTimeMock = new Mock<IDateTime>();
            dateTimeMock.SetupGet(x => x.Now).Returns(new DateTime(2021, 10, 05));

            var validator = new GetWeatherForecastValidator(dateTimeMock.Object);

            var request = new GetWeatherForecastRequest()
            {
                ForecastDate = forecastDate,
                TemperatureUnit = unit
            };

            return validator.TestValidate(request);
        }
    }
}
