﻿// ----------------------------------------------------------------------
// <copyright file="WeatherForecastController.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.Web.Controllers
{
    using System.Threading.Tasks;
    using MediatR;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using WeatherForecast.Web.Requests.GetWeatherForecast;

    [ApiController]
    [Route("api/[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        public WeatherForecastController(
            ILogger<WeatherForecastController> logger,
            ISender mediator)
        {
            this.Logger = logger;
            this.Mediator = mediator;
        }

        internal ILogger<WeatherForecastController> Logger { get; }

        internal ISender Mediator { get; }

        [HttpGet]
        public async Task<ForecastDTO> GetWeatherForecast(
            [FromQuery] GetWeatherForecastRequest request)
        {
            return await this.Mediator.Send(request);
        }
    }
}
