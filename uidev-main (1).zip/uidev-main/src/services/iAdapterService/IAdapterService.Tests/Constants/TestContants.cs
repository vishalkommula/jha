﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JackHenry.Banking.IAdapter.Tests.Constants
{
    public static class TestContants
    {
        public const string UnitTest = "UnitTest";
        public const string IntegrationTest = "IntegrationTest";
        public const string TestCategory = "TestCategory";
    }
}
