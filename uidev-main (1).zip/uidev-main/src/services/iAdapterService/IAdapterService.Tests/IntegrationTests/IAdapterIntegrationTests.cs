using JackHenry.Banking.IAdapter.Infrastructure.Interfaces;
using JackHenry.Banking.IAdapter.Infrastructure.Models;
using JackHenry.Banking.IAdapter.Infrastructure.Services;
using JackHenry.Banking.IAdapter.Tests.Constants;
using JackHenry.Banking.IAdapter.Tests.TestCases;
using JackHenry.Banking.IAdapter.Tests.Utilities;
using JackHenry.JHAContractTypes;

using Moq;

using System.Threading.Tasks;

using Xunit;

namespace JackHenry.Banking.IAdapter.Tests.IntegrationTests;

[Trait(TestContants.TestCategory, TestContants.IntegrationTest)]
public class IAdapterIntegrationTests
{
    public IAdapterIntegrationTests()
    {
        Adapter = new Mock<IMasterAdapterSetting>();
        TransportService = new Mock<ITransportService>();
    }

    public Mock<IMasterAdapterSetting> Adapter { get; }

    public Mock<ITransportService> TransportService { get; }

    public IIAdapterService IAdapterService { get; set; }

    [Fact]    
    public async Task Can_Call_Ping_Async()
    {
        SetupIAdapter();

        IAdapterService = new IAdapterService(Adapter.Object, new TransportService());

        var ping = new PingRq_MType()
        {
            PingRq = SampleiAdapter.ServicePrincipalName
        };

        var result = await IAdapterService
            .PingAsync<PingRs_MType>(JhaSerializer.Serialize(ping), SampleiAdapter.IAdapterInstitutionId);

        Assert.NotNull(result);
        Assert.NotNull(result.Payload_Rs);

        Assert.Equal(SampleiAdapter.ServicePrincipalName, result.Payload_Rs.PingRs);
    }

    [Fact]
    public async Task Can_Do_Acct_Search_Async()
    {
        SetupIAdapter();

        IAdapterService = new IAdapterService(Adapter.Object, new TransportService());

        var xmlRequest = TestUtils.LoadSampleRequest("AcctSrch.xml");

        var result = await IAdapterService
            .SearchAsync<AcctSrchRs_MType>(xmlRequest, SampleiAdapter.IAdapterInstitutionId);

        Assert.NotNull(result);

        Assert.NotNull(result.Payload_Rs);
    }

    [Fact]
    public async Task Can_Do_Acct_Inquiry_Async()
    {
        SetupIAdapter();

        IAdapterService = new IAdapterService(Adapter.Object, new TransportService());

        var xmlRequest = TestUtils.LoadSampleRequest("AcctInq.xml");

        var result = await IAdapterService
            .InquireAsync<AcctInqRs_MType>(xmlRequest, SampleiAdapter.IAdapterInstitutionId);

        Assert.NotNull(result);

        Assert.NotNull(result.Payload_Rs);
    }

    private void SetupIAdapter()
    {
        Adapter.Reset();
        Adapter.SetupGet(x => x.IsSSL).Returns(SampleiAdapter.IsSSL);
        Adapter.SetupGet(x => x.IAdapterInstitutionId).Returns(SampleiAdapter.IAdapterInstitutionId);
        Adapter.SetupGet(x => x.Key).Returns(SampleiAdapter.Key);
        Adapter.SetupGet(x => x.Port).Returns(SampleiAdapter.Port);
        Adapter.SetupGet(x => x.Server).Returns(SampleiAdapter.Server);
        Adapter.SetupGet(x => x.EncryptedKey).Returns(SampleiAdapter.EncryptedKey);
        Adapter.SetupGet(x => x.ServicePrincipalName).Returns(SampleiAdapter.ServicePrincipalName);
        Adapter.SetupGet(x => x.HeaderVersion).Returns(SampleiAdapter.HeaderVersion);
    }
}
