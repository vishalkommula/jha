﻿namespace IAdapterService.Controllers;

using Microsoft.AspNetCore.Mvc;
using JackHenry.Enterprise.BusinessObjects.Jes;
using System.Threading.Tasks;
using JackHenry.Banking.IAdapter.Infrastructure.Services;
using JackHenry.Banking.IAdapter.Infrastructure.Interfaces;
using JackHenry.Banking.IAdapter.Infrastructure.Models;

[Route("api/[controller]")]
[ApiController]
public class IAdapterTesterController : ControllerBase
{
    public IAdapterTesterController(ITransportService transportService)
    {
        TransportService = transportService;
    }

    public ITransportService TransportService { get; }

    [HttpGet]
    public async Task<string> Get()
    {
        var masterAdapterSettings = new MasterAdapterSetting()
        {
            IAdapterInstitutionId = "2022510"
        };

        IAdapterService adapterService = new IAdapterService(masterAdapterSettings, TransportService);

        PingRq_MType rq = new PingRq_MType()
        {
            PingRq = new PingRq_Type()
            {
                Value = "iCoreDev"
            }
        };

        ITypedResponse<PingRs_MType> rs = await adapterService.PingAsync<PingRs_MType>(JhaSerializer.Serialize(rq), null!);
        return $"Hello, World! The response to the ping was { rs.Payload_Rs.PingRs.Value }";
    }
}
