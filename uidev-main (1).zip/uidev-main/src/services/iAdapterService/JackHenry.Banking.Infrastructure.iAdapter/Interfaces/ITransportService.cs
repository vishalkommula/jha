﻿using JackHenry.Banking.IAdapter.Infrastructure.Models;
using JackHenry.JHAContractTypes;

namespace JackHenry.Banking.IAdapter.Infrastructure.Interfaces;
public interface ITransportService : IEnumerable<KeyValuePair<string, IAdapterTransport>>
{
    void SetTransport(IIAdapter adapter);

    IAdapterTransport GetTransport(string institution);
    ITypedResponse<TRs> SendXML<TRs>(string requestXML, string adapterFunction, string institution);

    IAdapterTransport this[string key] { get; }
}
