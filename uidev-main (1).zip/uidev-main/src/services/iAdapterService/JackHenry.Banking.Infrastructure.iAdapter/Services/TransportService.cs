﻿using JackHenry.Banking.IAdapter.Infrastructure.Extensions;
using JackHenry.Banking.IAdapter.Infrastructure.Interfaces;
using JackHenry.Banking.IAdapter.Infrastructure.Models;
using JackHenry.JHAContractTypes;

using Microsoft.Extensions.Logging;

using System.Collections;
using System.Collections.Concurrent;

namespace JackHenry.Banking.IAdapter.Infrastructure.Services;

public class TransportService : ITransportService
{
    public TransportService()
    {
    }

    public TransportService(ILogger<TransportService> logger, IIAdapter adapter)
    {
        SetTransport(adapter);
        Logger = logger;
    }

    private ConcurrentDictionary<string, IAdapterTransport> Transports { get; } = new();

    private ILogger<TransportService> Logger { get; }

    public void SetTransport(IIAdapter adapter)
    {
        Transports[adapter.IAdapterInstitutionId] = new IAdapterTransport(adapter);
    }

    public IAdapterTransport GetTransport(string institution)
    {
        Transports.TryGetValue(institution, out IAdapterTransport transport);

        return transport;
    }

    public ITypedResponse<TRs> SendXML<TRs>(string requestXML, string adapterFunction, string institution)
    {
        string responseXML;
        try
        {
            IAdapterTransport transport;

            if (institution == null)
            {
                MasterAdapterSetting adapter = new MasterAdapterSetting
                {
                    IAdapterInstitutionId = "2022510",
                    Key = "66ce7003ffae1a4293d60004ac1c6f9b",
                    Port = 42510,
                    Server = "iCoreDev",
                    EncryptedKey = "48L8FM1fYnTSfViR9XAPfviKHNiTr04EuZII6bauBA20qSF8ijJSFRSuzEAMnHxw",
                    ServicePrincipalName = "iCoreDev.dev.jha"
                };

                transport = new IAdapterTransport(adapter);
            }
            else
            {
                transport = GetTransport(institution);
            }

            if (transport == null)
            {
                throw new Exception("transport is null or invalid");
            }

            requestXML = requestXML.Replace("utf-16", "utf-8");

            responseXML = transport.SendRequest($"{requestXML}");

            if (!responseXML.StartsWith("<?xml version") && !responseXML.StartsWith("<HdrFault"))
            {
                responseXML = @"<?xml version=""1.0"" encoding=""UTF-8"" ?>" + responseXML;
            }

            List<IResultInfoMessage> returnMessages = new List<IResultInfoMessage>();

            returnMessages.AddRange(CheckForFault(responseXML));

            if (!returnMessages.IsNullOrEmpty())
            {
                return GenericResponseImpl<TRs>.CreateFaultedResponse(returnMessages);
            }

            Exception ex;
            if ((ex = CheckForError(responseXML)) != null)
            {
                return GenericResponseImpl<TRs>.CreateExceptionResponse(new GenericException("Errors found in response", ex));
            }

            string contractName = typeof(TRs).ToString();

            TRs deserialized = JhaSerializer.XmlDeserialize<TRs>(responseXML);

            return new GenericResponseImpl<TRs>(deserialized);
        }
        catch (IAdapterCommunicationException aex)
        {
            string message = GenericExceptions.IAdapterDown;
            string detailedMessage = string.Format("Error processing Transport Request and response for {0} type.", typeof(TRs));

            return GenericResponseImpl<TRs>.CreateExceptionResponse(message, detailedMessage, aex);
        }
        catch (Exception ex)
        {
            string message = string.Format("Error processing Transport Request and response for {0} type.", typeof(TRs));

            Logger.LogError(ex, "{Method}: {message}", nameof(SendXML), message);

            return GenericResponseImpl<TRs>.CreateExceptionResponse(message, ex.Message);
        }
    }

    private Exception CheckForError(string responseXML)
    {
        try
        {
            string tmpXML = responseXML.Replace("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>", string.Empty);

            if (!tmpXML.StartsWith("<error"))
            {
                return null;
            }

            return new Exception(responseXML);
        }
        catch (Exception ex)
        {
            return new Exception("An error was returned from the socket call.  " + ex.Message, ex);
        }
    }

    private IResultInfoMessage[] CheckForFault(string responseXML)
    {
        List<IResultInfoMessage> faults = new List<IResultInfoMessage>();
        try
        {
            if (string.IsNullOrEmpty(responseXML))
            {
                throw new Exception("Invalid XML response passed into check for faults");
            }

            if (!responseXML.StartsWith("<HdrFault"))
            {
                return faults.ToArray();
            }

            responseXML = responseXML.Replace("<HdrFault xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">", "<HdrFault xmlns=\"http://jackhenry.com/jxchange/TPG/2008\">");

            HdrFault_MType hdrFaults = JhaSerializer.XmlDeserialize<HdrFault_MType>(responseXML);

            if (hdrFaults == null || hdrFaults.FaultRecInfoArray == null)
            {
                throw new Exception("Empty or null fault arry returned.");
            }

            foreach (FaultMsgRec_CType fhdrFault in hdrFaults.FaultRecInfoArray)
            {
                GenericExceptions.PrefixIAdapterErrorMessageWithServiceProvider(fhdrFault);
                ResultMessage message = new ResultMessage(fhdrFault);
                faults.Add(message);
            }

            return faults.ToArray();
        }
        catch (Exception ex)
        {
            throw new Exception(string.Format("Error in check for fault: {0}", ex), ex);
        }
    }

    public IAdapterTransport this[string key] => GetTransport(key);

    IAdapterTransport ITransportService.this[string key] => GetTransport(key);

    public IEnumerator<KeyValuePair<string, IAdapterTransport>> GetEnumerator()
    {
        return Transports.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return Transports.GetEnumerator();
    }
}
