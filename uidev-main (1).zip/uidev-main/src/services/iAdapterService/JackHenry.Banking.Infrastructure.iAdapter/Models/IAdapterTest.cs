﻿// -----------------------------------------------------------------------
// <copyright file="IAdapterTest.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Models;
public class IAdapterTest
{
    public IAdapterTest(bool success)
    {
        this.IsSuccessful = success;
    }

    public bool IsSuccessful
    {
        get;
        private set;
    }
}
