﻿// -----------------------------------------------------------------------
// <copyright file="Response.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Models;

using JackHenry.Banking.IAdapter.Infrastructure.Interfaces;

using System;

public class Response<TPayload> : IResponse<TPayload>
{
    public Response(TPayload payload)
    {
        this.Payload_Rs = payload;
    }

    public Response(Exception exception)
    {
        this.Exception = exception;
    }

    public Exception Exception
    {
        get;
        set;
    }

    public bool HasException
    {
        get
        {
            return this.Exception != null;
        }
    }

    public TPayload Payload_Rs
    {
        get;
        set;
    }

    public string MessageId
    {
        get;
        set;
    }
}
