﻿// -----------------------------------------------------------------------
// <copyright file="IAdapterCommunicationException.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Models;
using System;

public class IAdapterCommunicationException : Exception
{
    public IAdapterCommunicationException(string message)
        : base(message)
    {
    }

    public IAdapterCommunicationException(string message, Exception innerException)
        : base(message, innerException)
    {
    }
}
